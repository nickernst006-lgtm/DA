import SwiftUI
import SwiftData

/// Вкладка «Коллекция»: «Хочу посмотреть» и «Посмотрел».
struct CollectionView: View {
    var onBrowse: () -> Void = {}

    @Environment(Library.self) private var library
    @Query(sort: \CollectionItem.addedAt, order: .reverse) private var items: [CollectionItem]
    @Query private var surveys: [SurveyEntry]

    @State private var list: CollectionStatus = .want
    @State private var surveyFilm: FilmItem?

    private let columns = [
        GridItem(.flexible(), spacing: 10, alignment: .top),
        GridItem(.flexible(), spacing: 10, alignment: .top),
        GridItem(.flexible(), spacing: 10, alignment: .top)
    ]

    private var wantFilms: [FilmItem] {
        items.filter { $0.status == .want }
            .compactMap { library.film(id: $0.filmID) }
    }

    private var seenFilms: [FilmItem] {
        items.filter { $0.status == .seen }
            .sorted { ($0.seenAt ?? $0.addedAt) > ($1.seenAt ?? $1.addedAt) }
            .compactMap { library.film(id: $0.filmID) }
    }

    /// «8 · гипноз» — оценка и слово из анкеты.
    private func note(for filmID: String) -> String? {
        guard let survey = surveys.first(where: { $0.filmID == filmID }) else { return nil }
        var parts: [String] = []
        if survey.rating > 0 { parts.append("\(survey.rating)") }
        if !survey.word.isEmpty { parts.append(survey.word.lowercased()) }
        return parts.isEmpty ? nil : parts.joined(separator: " · ")
    }

    /// Последний просмотренный фильм без опроса.
    private var pendingSurveyFilm: FilmItem? {
        seenFilms.first { film in !surveys.contains { $0.filmID == film.id } }
    }

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 20) {
                    VStack(alignment: .leading, spacing: ScreenLayout.titleGap) {
                        ScreenTitle("Коллекция")
                            .padding(.top, 12)

                        SegmentedControl(
                            options: [
                                SegmentOption(value: CollectionStatus.want, title: "Хочу посмотреть · \(wantFilms.count)"),
                                SegmentOption(value: CollectionStatus.seen, title: "Посмотрел · \(seenFilms.count)")
                            ],
                            selection: $list
                        )
                    }

                    // Напоминание об анкете — под переключателем, чтобы тот всегда стоял на месте.
                    if let pending = pendingSurveyFilm {
                        reminder(pending)
                    }

                    let films = list == .want ? wantFilms : seenFilms
                    if films.isEmpty {
                        emptyState
                    } else {
                        LazyVGrid(columns: columns, alignment: .leading, spacing: 22) {
                            ForEach(films) { film in
                                NavigationLink(value: FilmRoute(id: film.id)) {
                                    FilmTile(
                                        film: film,
                                        subtitle: film.shortMeta,
                                        note: list == .seen ? note(for: film.id) : nil,
                                        titleSize: 13
                                    )
                                }
                                .buttonStyle(.plain)
                            }
                        }
                    }
                }
                .padding(.horizontal, 20)
                .padding(.bottom, 24)
            }
            .background(Theme.background.ignoresSafeArea())
            .toolbar(.hidden, for: .navigationBar)
            .navigationDestination(for: FilmRoute.self) { route in
                FilmDetailView(filmID: route.id)
            }
        }
        .fullScreenCover(item: $surveyFilm) { film in
            SurveyView(film: film)
        }
    }

    private func reminder(_ film: FilmItem) -> some View {
        Button {
            surveyFilm = film
        } label: {
            HStack(spacing: 14) {
                CoverView(film: film, cornerRadius: 8)
                    .frame(width: 46)
                VStack(alignment: .leading, spacing: 3) {
                    Text("Как вам «\(film.title)»?")
                        .font(AppFont.ui(15, .bold))
                        .foregroundStyle(Theme.text)
                        .lineLimit(2)
                    Text("Короткая анкета — и «Сеанс» лучше поймёт ваш вкус")
                        .font(AppFont.ui(13))
                        .foregroundStyle(Theme.muted)
                        .fixedSize(horizontal: false, vertical: true)
                }
                Spacer(minLength: 0)
                Image(systemName: "arrow.right")
                    .font(.system(size: 15, weight: .medium))
                    .foregroundStyle(Theme.muted)
                    .accessibilityHidden(true)
            }
            .padding(12)
            .background(RoundedRectangle(cornerRadius: 20, style: .continuous).fill(Theme.surface))
        }
        .buttonStyle(.plain)
    }

    private var emptyState: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text(list == .want ? "Список пока пуст" : "Вы ещё ничего не отметили")
                .font(AppFont.ui(18, .bold))
                .foregroundStyle(Theme.text)
            Text(list == .want
                 ? "Найдите фильм во «Вселенной» и нажмите «Хочу посмотреть»."
                 : "Отметьте фильм как просмотренный и заполните анкету.")
                .font(AppFont.ui(15))
                .foregroundStyle(Theme.muted)
                .fixedSize(horizontal: false, vertical: true)
            Button("Открыть Вселенную", action: onBrowse)
                .buttonStyle(SecondaryButtonStyle())
                .padding(.top, 6)
        }
        .padding(.top, 8)
    }
}
