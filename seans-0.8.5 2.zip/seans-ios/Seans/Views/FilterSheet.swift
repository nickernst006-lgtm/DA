import SwiftUI
import SwiftData

/// Окно одного фильтра «Вселенной»: открывается кнопкой под строкой поиска
/// (Страна, Период, Режиссёр, Жанр, Архетип, Чувства).
struct FilterSheet: View {
    @Binding var filter: FilmFilter
    let section: FilterSection

    @Environment(Library.self) private var library
    @Environment(\.dismiss) private var dismiss
    @Query private var surveys: [SurveyEntry]

    @State private var draft = FilmFilter()
    @State private var directorText = ""
    @State private var showAllCountries = false
    @State private var showAllGenres = false

    private var personal: [String: PersonalTags] {
        var result: [String: PersonalTags] = [:]
        for s in surveys { result[s.filmID] = PersonalTags(emotions: s.emotions, word: s.word) }
        return result
    }

    private var resultCount: Int {
        draft.isEmpty ? library.catalog.count : library.filter(draft, personal: personal).count
    }

    var body: some View {
        VStack(spacing: 0) {
            HStack {
                Button("Закрыть") { dismiss() }
                    .font(AppFont.ui(16))
                    .foregroundStyle(Theme.textSecondary)
                    .frame(minWidth: 44, minHeight: 44, alignment: .leading)
                Spacer()
                Text(section.title)
                    .font(AppFont.ui(16, .bold))
                    .foregroundStyle(Theme.text)
                Spacer()
                Button("Сбросить") {
                    draft.clear(section)
                    if section == .director { directorText = "" }
                }
                .font(AppFont.ui(16))
                .foregroundStyle(draft.isActive(section) ? Theme.text : Theme.muted)
                .disabled(!draft.isActive(section))
                .frame(minWidth: 44, minHeight: 44, alignment: .trailing)
            }
            .padding(.horizontal, 16)
            .padding(.top, 8)

            ScrollView {
                VStack(alignment: .leading, spacing: 16) {
                    switch section {
                    case .country:
                        flow {
                            ForEach(showAllCountries ? Array(library.countryFacets.prefix(60)) : Array(library.countryFacets.prefix(14)), id: \.self) { country in
                                Chip(title: country, isSelected: draft.countries.contains(country), height: 40) {
                                    toggle(country, in: &draft.countries)
                                }
                            }
                            if library.countryFacets.count > 14 && !showAllCountries {
                                moreButton { showAllCountries = true }
                            }
                        }
                    case .period:
                        flow {
                            ForEach(FilmFilter.decadeOptions, id: \.self) { decade in
                                Chip(title: FilmFilter.decadeTitle(decade), isSelected: draft.decades.contains(decade), height: 40) {
                                    if draft.decades.contains(decade) { draft.decades.remove(decade) } else { draft.decades.insert(decade) }
                                }
                            }
                        }
                    case .director:
                        directorSection
                    case .genre:
                        flow {
                            ForEach(showAllGenres ? library.genreFacets : Array(library.genreFacets.prefix(12)), id: \.self) { genre in
                                Chip(title: genre, isSelected: draft.genres.contains(genre), height: 40) {
                                    toggle(genre, in: &draft.genres)
                                }
                            }
                            if library.genreFacets.count > 12 && !showAllGenres {
                                moreButton { showAllGenres = true }
                            }
                        }
                    case .archetype:
                        SectionTitle("Кому фильм подойдёт")
                        flow {
                            ForEach(Archetype.allCases) { archetype in
                                Chip(title: archetype.title, isSelected: draft.archetypes.contains(archetype.rawValue), height: 40) {
                                    toggle(archetype.rawValue, in: &draft.archetypes)
                                }
                            }
                        }
                    case .feeling:
                        SectionTitle("Что фильм вызывает")
                        flow {
                            ForEach(SurveyOptions.emotions.filter { $0.id != "bored" }) { option in
                                Chip(title: option.title, isSelected: draft.feelings.contains(option.id), height: 40) {
                                    toggle(option.id, in: &draft.feelings)
                                }
                            }
                        }
                    }
                }
                .padding(.horizontal, 20)
                .padding(.vertical, 16)
            }
            .scrollDismissesKeyboard(.interactively)

            Button(resultCount == 0 ? "Ничего не найдено" : "Показать \(resultCount) \(TasteProfile.plural(resultCount, "фильм", "фильма", "фильмов"))") {
                filter = draft
                dismiss()
            }
            .buttonStyle(PrimaryButtonStyle())
            .disabled(resultCount == 0)
            .opacity(resultCount == 0 ? 0.5 : 1)
            .padding(.horizontal, 20)
            .padding(.top, 8)
            .padding(.bottom, 12)
        }
        .background(Theme.background.ignoresSafeArea())
        .presentationBackground(Theme.background)
        .onAppear {
            draft = filter
            directorText = filter.director
        }
    }

    // MARK: Режиссёр

    private var directorSection: some View {
        VStack(alignment: .leading, spacing: 12) {
            if !draft.director.isEmpty {
                HStack(spacing: 8) {
                    Chip(title: draft.director, isSelected: true, height: 40) {
                        draft.director = ""
                        directorText = ""
                    }
                    Text("нажмите, чтобы убрать")
                        .font(AppFont.ui(13))
                        .foregroundStyle(Theme.muted)
                }
            } else {
                TextField("", text: $directorText, prompt: Text("Фамилия режиссёра").foregroundColor(Theme.muted))
                    .font(AppFont.ui(16))
                    .foregroundStyle(Theme.text)
                    .autocorrectionDisabled()
                    .submitLabel(.done)
                    .onSubmit {
                        let text = directorText.trimmingCharacters(in: .whitespacesAndNewlines)
                        if !text.isEmpty { draft.director = text }
                    }
                    .padding(.horizontal, 14)
                    .frame(minHeight: 48)
                    .background(Capsule().fill(Theme.surface))
                    .accessibilityLabel("Режиссёр")
                FlowLayout(spacing: 8, lineSpacing: 8) {
                    ForEach(library.directorSuggestions(directorText), id: \.self) { name in
                        Chip(title: name, isSelected: false, height: 40) {
                            draft.director = name
                            directorText = name
                        }
                    }
                }
            }
        }
    }

    // MARK: Помощники

    private func flow<Content: View>(@ViewBuilder content: () -> Content) -> some View {
        FlowLayout(spacing: 8, lineSpacing: 8) {
            content()
        }
    }

    private func moreButton(_ action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Text("Ещё")
                .font(AppFont.ui(15, .medium))
                .foregroundStyle(Theme.textSecondary)
                .padding(.horizontal, 16)
                .frame(minHeight: 40)
                .overlay(Capsule().stroke(Theme.lineStrong, lineWidth: 1))
        }
        .buttonStyle(.plain)
    }

    private func toggle(_ value: String, in set: inout Set<String>) {
        if set.contains(value) { set.remove(value) } else { set.insert(value) }
    }
}
