import SwiftUI

/// Иконка архетипа в плитке со скруглёнными углами — как маленькое приложение.
struct ArchetypeTile: View {
    let archetype: Archetype
    var size: CGFloat = 64

    var body: some View {
        Image(archetype.iconAsset)
            .renderingMode(.template)
            .resizable()
            .scaledToFit()
            .frame(width: size * 0.56, height: size * 0.56)
            .foregroundStyle(archetype.color)
            .frame(width: size, height: size)
            .background(
                RoundedRectangle(cornerRadius: size * 0.225, style: .continuous)
                    .fill(Theme.surfaceRaised)
            )
            .accessibilityHidden(true)
    }
}

/// Три архетипа фильма внизу карточки. Нажатие — описание архетипа.
struct ArchetypeBadges: View {
    let archetypes: [Archetype]
    @State private var selected: Archetype?

    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            SectionTitle("Кому подойдёт", hint: "Архетипы зрителя — нажмите, чтобы узнать подробнее")
            HStack(alignment: .top, spacing: 10) {
                ForEach(archetypes) { archetype in
                    Button {
                        selected = archetype
                    } label: {
                        VStack(spacing: 8) {
                            ArchetypeTile(archetype: archetype)
                            Text(archetype.title)
                                .font(AppFont.ui(13, .medium))
                                .foregroundStyle(Theme.textSecondary)
                                .lineLimit(1)
                                .minimumScaleFactor(0.8)
                        }
                        .frame(maxWidth: .infinity)
                        .contentShape(Rectangle())
                    }
                    .buttonStyle(.plain)
                    .accessibilityLabel("Архетип: \(archetype.title)")
                    .accessibilityHint("Показать описание")
                }
                // Если архетипов меньше трёх — сохраняем ширину ячеек.
                ForEach(0..<max(0, Archetype.maxPerFilm - archetypes.count), id: \.self) { _ in
                    Color.clear.frame(maxWidth: .infinity, maxHeight: 1)
                }
            }
        }
        .sheet(item: $selected) { archetype in
            ArchetypeInfoSheet(archetype: archetype)
                .presentationDetents([.medium])
        }
    }
}

/// Описание архетипа.
struct ArchetypeInfoSheet: View {
    let archetype: Archetype
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            HStack {
                Spacer()
                CloseButton { dismiss() }
            }
            ArchetypeTile(archetype: archetype, size: 72)
            VStack(alignment: .leading, spacing: 6) {
                Text(archetype.title)
                    .font(AppFont.title(28, relativeTo: .title))
                    .tracking(-0.6)
                    .foregroundStyle(Theme.text)
                Text("«\(archetype.motto)»")
                    .font(AppFont.ui(15, .medium))
                    .foregroundStyle(Theme.accent)
            }
            Text(archetype.description)
                .font(AppFont.ui(16))
                .foregroundStyle(Theme.textSecondary)
                .lineSpacing(2)
                .fixedSize(horizontal: false, vertical: true)
            Spacer(minLength: 0)
        }
        .padding(20)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Theme.background.ignoresSafeArea())
        .presentationBackground(Theme.background)
    }
}
