import Foundation

/// Чувства для фильмов без ручной разметки — по жанрам.
enum FilmTags {
    private static let genreFeelings: [String: [String]] = [
        "Комедия": ["laugh", "warm"],
        "Ужасы": ["anx", "chills"],
        "Триллер": ["anx", "chills"],
        "Боевик": ["wow", "chills"],
        "Драма": ["think", "sad"],
        "Мелодрама": ["warm", "sad"],
        "Фантастика": ["wow", "think"],
        "Фэнтези": ["wow", "insp"],
        "Анимация": ["warm", "wow"],
        "Семейный": ["warm"],
        "Приключения": ["wow", "insp"],
        "Мюзикл": ["insp", "warm"],
        "Криминал": ["chills"],
        "Детектив": ["think", "chills"],
        "Военный": ["sad", "think"],
        "Биография": ["insp"],
        "Исторический": ["think"],
        "Документальный": ["think"],
        "Вестерн": ["nostalgia"],
        "Нуар": ["anx"],
        "Спорт": ["insp"]
    ]

    static func feelings(genres: [String], year: Int?) -> [String] {
        var result: [String] = []
        for genre in genres {
            for feeling in genreFeelings[genre] ?? [] where !result.contains(feeling) {
                result.append(feeling)
            }
        }
        if let year, year < 1985, !result.contains("nostalgia") {
            result.append("nostalgia")
        }
        return result
    }
}

/// Собственные ответы пользователя по фильму — тоже участвуют в фильтрах.
struct PersonalTags {
    let emotions: [String]
    let word: String
}

/// Фильтры «Вселенной». Внутри одной группы — «или», между группами — «и».
/// Фильтры «Вселенной» — кнопки под строкой поиска, в этом порядке.
enum FilterSection: String, CaseIterable, Identifiable {
    case country, period, director, genre, archetype, feeling

    var id: String { rawValue }

    var title: String {
        switch self {
        case .country: return "Страна"
        case .period: return "Период"
        case .director: return "Режиссёр"
        case .genre: return "Жанр"
        case .archetype: return "Архетип"
        case .feeling: return "Чувства"
        }
    }
}

struct FilmFilter: Equatable {
    var genres: Set<String> = []
    var countries: Set<String> = []
    /// Десятилетия: 1990 — «1990-е», 0 — «до 1950».
    var decades: Set<Int> = []
    var director: String = ""
    var feelings: Set<String> = []
    var archetypes: Set<String> = []

    static let decadeOptions: [Int] = [2020, 2010, 2000, 1990, 1980, 1970, 1960, 1950, 0]

    static func decadeTitle(_ decade: Int) -> String {
        decade == 0 ? "До 1950" : "\(decade)-е"
    }

    static func decade(for year: Int) -> Int {
        year < 1950 ? 0 : (year / 10) * 10
    }

    var isEmpty: Bool {
        genres.isEmpty && countries.isEmpty && decades.isEmpty && trimmedDirector.isEmpty
            && feelings.isEmpty && archetypes.isEmpty
    }

    var activeCount: Int {
        genres.count + countries.count + decades.count + (trimmedDirector.isEmpty ? 0 : 1)
            + feelings.count + archetypes.count
    }

    private var trimmedDirector: String {
        director.trimmingCharacters(in: .whitespacesAndNewlines)
    }

    func matches(_ film: FilmItem, personal: PersonalTags?) -> Bool {
        if !genres.isEmpty && !film.genres.contains(where: { genres.contains($0) }) { return false }
        if !countries.isEmpty && !film.countries.contains(where: { countries.contains($0) }) { return false }
        if !decades.isEmpty {
            guard let year = film.year, decades.contains(FilmFilter.decade(for: year)) else { return false }
        }
        let director = trimmedDirector.normalizedForSearch
        if !director.isEmpty && !film.directors.contains(where: { $0.normalizedForSearch.contains(director) }) {
            return false
        }
        if !feelings.isEmpty {
            let own = personal?.emotions ?? []
            if !film.feelings.contains(where: { feelings.contains($0) }) && !own.contains(where: { feelings.contains($0) }) { return false }
        }
        if !archetypes.isEmpty && !film.archetypes.contains(where: { archetypes.contains($0) }) { return false }
        return true
    }

    /// Активные фильтры — для строки чипов под поиском.
    struct Token: Identifiable {
        let id: String
        let title: String
    }

    var tokens: [Token] {
        var result: [Token] = []
        // В том же порядке, что и в окне фильтров.
        for c in countries.sorted() { result.append(Token(id: "c:" + c, title: c)) }
        for d in decades.sorted(by: >) { result.append(Token(id: "d:\(d)", title: FilmFilter.decadeTitle(d))) }
        if !trimmedDirector.isEmpty { result.append(Token(id: "r:", title: trimmedDirector)) }
        for g in genres.sorted() { result.append(Token(id: "g:" + g, title: g)) }
        for a in Archetype.allCases where archetypes.contains(a.rawValue) { result.append(Token(id: "t:" + a.rawValue, title: a.title)) }
        for f in SurveyOptions.emotions where feelings.contains(f.id) { result.append(Token(id: "f:" + f.id, title: f.title)) }
        return result
    }

    mutating func remove(_ token: Token) {
        let parts = token.id.split(separator: ":", maxSplits: 1).map(String.init)
        let kind = parts.first ?? ""
        let value = parts.count > 1 ? parts[1] : ""
        switch kind {
        case "g": genres.remove(value)
        case "d": decades.remove(Int(value) ?? -1)
        case "c": countries.remove(value)
        case "r": director = ""
        case "f": feelings.remove(value)
        case "t": archetypes.remove(value)
        default: break
        }
    }

    // MARK: По разделам — для кнопок под поиском

    /// Выбранные значения раздела — названия для кнопки.
    func selectedTitles(_ section: FilterSection) -> [String] {
        switch section {
        case .country: return countries.sorted()
        case .period: return decades.sorted(by: >).map(FilmFilter.decadeTitle)
        case .director: return trimmedDirector.isEmpty ? [] : [trimmedDirector]
        case .genre: return genres.sorted()
        case .archetype: return Archetype.allCases.filter { archetypes.contains($0.rawValue) }.map(\.title)
        case .feeling: return SurveyOptions.emotions.filter { feelings.contains($0.id) }.map(\.title)
        }
    }

    func isActive(_ section: FilterSection) -> Bool {
        !selectedTitles(section).isEmpty
    }

    /// Надпись на кнопке: «Страна», «Франция» или «Страна · 3».
    func label(_ section: FilterSection) -> String {
        let titles = selectedTitles(section)
        switch titles.count {
        case 0: return section.title
        case 1: return titles[0]
        default: return "\(section.title) · \(titles.count)"
        }
    }

    mutating func clear(_ section: FilterSection) {
        switch section {
        case .country: countries = []
        case .period: decades = []
        case .director: director = ""
        case .genre: genres = []
        case .archetype: archetypes = []
        case .feeling: feelings = []
        }
    }
}
