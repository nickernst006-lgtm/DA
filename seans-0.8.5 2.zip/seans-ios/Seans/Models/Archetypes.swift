import SwiftUI

/// 12 архетипов зрителя по Юнгу (система Кэрол Пирсон).
/// Названия — как на выставке Третьяковской галереи «Архетипы авангарда» (2025–2026):
/// Дитя, Славный малый, Воин, Опекун, Искатель, Бунтарь, Эстет, Творец, Правитель, Маг, Мудрец, Шут.
/// id в базе остались прежними (innocent, everyman, hero, caregiver, explorer, rebel,
/// lover, creator, ruler, magician, sage, jester), чтобы не ломать разметку фильмов.
/// У каждого — что он ищет в кино и по каким признакам его узнать:
/// чувства из анкеты, стороны фильма, шкалы и жанры.
/// У фильма — не больше трёх архетипов.
enum Archetype: String, CaseIterable, Identifiable {
    case innocent, everyman, hero, caregiver, explorer, rebel
    case lover, creator, jester, sage, magician, ruler

    var id: String { rawValue }

    static let maxPerFilm = 3

    var title: String {
        switch self {
        case .innocent: return "Дитя"
        case .everyman: return "Славный малый"
        case .hero: return "Воин"
        case .caregiver: return "Опекун"
        case .explorer: return "Искатель"
        case .rebel: return "Бунтарь"
        case .lover: return "Эстет"
        case .creator: return "Творец"
        case .jester: return "Шут"
        case .sage: return "Мудрец"
        case .magician: return "Маг"
        case .ruler: return "Правитель"
        }
    }

    /// Иконка архетипа — векторная картинка в каталоге ресурсов (Phosphor Icons, MIT).
    /// Принцип — как у выставки
    /// «Архетипы авангарда»: простой предмет и свой цвет.
    /// Дитя — воздушный шар, Славный малый — кепка, Воин — меч, Опекун — миска с паром,
    /// Искатель — компас, Бунтарь — молния, Эстет — тюльпан, Творец — кисть,
    /// Правитель — корона, Маг — волшебная палочка, Мудрец — открытая книга, Шут — маска.
    var iconAsset: String { "archetype-" + rawValue }

    /// Свой цвет у каждого архетипа — приглушённые, но различимые на тёмном фоне.
    var color: Color {
        switch self {
        case .innocent: return Color(hex: 0xF4A6C6)   // розовый
        case .everyman: return Color(hex: 0x8EC5E8)   // голубой
        case .hero: return Color(hex: 0xE5534B)       // красный
        case .caregiver: return Color(hex: 0xD29A6E)  // карамельный
        case .explorer: return Color(hex: 0x4FBF8B)   // зелёный
        case .rebel: return Color(hex: 0xC4C4C4)      // графитово-серый
        case .lover: return Color(hex: 0xB9A8F2)      // лавандовый
        case .creator: return Color(hex: 0xFF8A3D)    // оранжевый
        case .jester: return Color(hex: 0xF2C14E)     // жёлтый
        case .sage: return Color(hex: 0x5B8DEF)       // синий
        case .magician: return Color(hex: 0x9A7CF0)   // фиолетовый
        case .ruler: return Color(hex: 0xD9576F)      // малиновый
        }
    }

    /// Короткий девиз.
    var motto: String {
        switch self {
        case .innocent: return "Смотреть на мир впервые"
        case .everyman: return "Всё как в жизни"
        case .hero: return "Выстоять и победить"
        case .caregiver: return "Беречь и защищать"
        case .explorer: return "За горизонт"
        case .rebel: return "Правила созданы, чтобы их нарушать"
        case .lover: return "Красота — в деталях"
        case .creator: return "Создать небывалое"
        case .jester: return "Жизнь — игра"
        case .sage: return "Понять, как всё устроено"
        case .magician: return "Превратить невозможное в реальное"
        case .ruler: return "Власть и порядок"
        }
    }

    /// Что этот зритель ищет в кино.
    var description: String {
        switch self {
        case .innocent:
            return "Вы смотрите кино с открытым сердцем, как в детстве: ищете свет, надежду и чудо простых вещей. Вам близки добрые истории, после которых хочется жить чуть бережнее."
        case .everyman:
            return "Вам важны узнаваемые люди и честные истории без пафоса. Лучший фильм — тот, где вы узнаёте себя и своих знакомых."
        case .hero:
            return "Вас ведут истории борьбы: испытание, выбор, победа вопреки. Вы любите кино, после которого хочется расправить плечи."
        case .caregiver:
            return "Вас трогают забота, сострадание и защита слабых. Вы цените героев, которые берут на себя ответственность за других."
        case .explorer:
            return "Вас зовут новые миры, дороги и открытия. Кино для вас — способ побывать там, где вы ещё не были."
        case .rebel:
            return "Вы любите кино, которое бросает вызов системе: острые темы, неудобные герои, нарушенные правила."
        case .lover:
            return "Вы смотрите кино ради красоты: света, цвета, фактуры, музыки и чувств между людьми. Для вас фильм — это прежде всего то, как он ощущается."
        case .creator:
            return "Вас притягивают авторский стиль, необычная форма и смелые решения. Вы замечаете, как фильм сделан."
        case .jester:
            return "Вы цените иронию, игру и абсурд. Хороший фильм для вас — тот, где можно смеяться даже над серьёзным."
        case .sage:
            return "Вы смотрите, чтобы понять. Вам близки фильмы-размышления, которые задают вопросы и не спешат с ответами."
        case .magician:
            return "Вас завораживают превращения, загадки и чудо. Вы любите кино, которое переворачивает представление о реальности."
        case .ruler:
            return "Вас интересуют власть, ответственность и большие истории — о людях, которые управляют судьбами других."
        }
    }

    /// Чувства из анкеты, которые выдают этот архетип.
    var feelings: [String] {
        switch self {
        case .innocent: return ["warm", "insp", "nostalgia"]
        case .everyman: return ["laugh", "warm"]
        case .hero: return ["wow", "insp", "chills"]
        case .caregiver: return ["warm", "sad"]
        case .explorer: return ["wow", "insp"]
        case .rebel: return ["chills", "anx"]
        case .lover: return ["warm", "sad"]
        case .creator: return ["insp", "wow"]
        case .jester: return ["laugh"]
        case .sage: return ["think"]
        case .magician: return ["wow", "chills"]
        case .ruler: return ["think", "wow"]
        }
    }

    /// Стороны фильма, которые этот зритель ценит выше всего.
    var aspects: [String] {
        switch self {
        case .innocent: return ["atmosphere"]
        case .everyman: return ["cast", "dialogue"]
        case .hero: return ["plot"]
        case .caregiver: return ["cast"]
        case .explorer: return ["visual", "atmosphere"]
        case .rebel: return ["plot", "dialogue"]
        case .lover: return ["sound", "visual"]
        case .creator: return ["visual", "sound"]
        case .jester: return ["dialogue"]
        case .sage: return ["atmosphere", "plot"]
        case .magician: return ["plot", "visual"]
        case .ruler: return ["plot", "cast"]
        }
    }

    /// Шкалы анкеты: +1 — любит правую сторону (динамичный, мрачный, сложный, неожиданный), −1 — левую.
    var scales: [(String, Double)] {
        switch self {
        case .innocent: return [("tone", -1)]
        case .everyman: return [("complexity", -1)]
        case .hero: return [("tempo", 1)]
        case .caregiver: return [("tone", -0.5)]
        case .explorer: return [("surprise", 1)]
        case .rebel: return [("tone", 1)]
        case .lover: return [("tempo", -0.5)]
        case .creator: return [("complexity", 1)]
        case .jester: return [("tone", -0.5)]
        case .sage: return [("complexity", 1), ("tempo", -0.5)]
        case .magician: return [("surprise", 1)]
        case .ruler: return [("complexity", 0.5), ("tone", 0.5)]
        }
    }

    /// Жанры и их вес — для фильмов без ручной разметки.
    static let genreWeights: [String: [(Archetype, Double)]] = [
        "Комедия": [(.jester, 2), (.everyman, 1)],
        "Драма": [(.sage, 1), (.caregiver, 1), (.everyman, 1)],
        "Мелодрама": [(.lover, 2), (.innocent, 0.5)],
        "Мюзикл": [(.lover, 1), (.creator, 1), (.innocent, 1)],
        "Анимация": [(.innocent, 1.5), (.explorer, 1), (.creator, 0.5)],
        "Семейный": [(.innocent, 2), (.caregiver, 1)],
        "Боевик": [(.hero, 2), (.rebel, 0.5)],
        "Приключения": [(.explorer, 2), (.hero, 1)],
        "Фантастика": [(.explorer, 1), (.magician, 1), (.sage, 1)],
        "Фэнтези": [(.magician, 2), (.explorer, 1)],
        "Ужасы": [(.magician, 1), (.rebel, 1)],
        "Триллер": [(.rebel, 1), (.magician, 0.5)],
        "Криминал": [(.rebel, 2), (.ruler, 1)],
        "Детектив": [(.sage, 1), (.magician, 1)],
        "Военный": [(.hero, 2), (.caregiver, 0.5), (.ruler, 0.5)],
        "Вестерн": [(.hero, 1), (.rebel, 1), (.explorer, 1)],
        "Биография": [(.hero, 1), (.creator, 0.5)],
        "Исторический": [(.ruler, 2), (.sage, 1)],
        "Документальный": [(.sage, 2)],
        "Спорт": [(.hero, 2), (.everyman, 1)],
        "Нуар": [(.rebel, 1.5), (.sage, 0.5)]
    ]

    /// Архетипы фильма по жанрам — не больше трёх.
    static func forGenres(_ genres: [String]) -> [String] {
        var score: [Archetype: Double] = [:]
        for (position, genre) in genres.enumerated() {
            // Первый жанр — главный.
            let boost = position == 0 ? 1.2 : 1.0
            for (archetype, weight) in genreWeights[genre] ?? [] {
                score[archetype, default: 0] += weight * boost
            }
        }
        return score
            .sorted { $0.value == $1.value ? $0.key.order < $1.key.order : $0.value > $1.value }
            .prefix(maxPerFilm)
            .map(\.key.rawValue)
    }

    var order: Int { Archetype.allCases.firstIndex(of: self) ?? 0 }
}
