import Foundation
import Observation

/// Встроенная база фильмов. Две части:
/// - films.json — ручная база: авторские обложки, описания, подборки;
/// - films_wikidata.json — большая база из Wikidata, обновляется при сборке.
/// Обе обновляются только вместе с новой версией приложения.
@Observable
final class Library {
    /// Ручная база — «Рекомендации» во «Вселенной», в порядке файла.
    let featured: [FilmItem]
    /// Подборки «Русские» и «Зарубежные» — самые известные, без рекомендованных.
    let russian: [FilmItem]
    let foreign: [FilmItem]
    /// Вся база в случайном порядке — новый порядок при каждом запуске.
    let shuffled: [FilmItem]
    /// Страны, которые считаются «русским» кино.
    static let homeCountries: Set<String> = ["Россия", "СССР"]
    /// Вся база: сначала ручная, затем Wikidata по убыванию известности.
    let catalog: [FilmItem]
    private let index: [String: FilmItem]

    /// Сколько фильмов в подборках «Русские» и «Зарубежные».
    static let shelfSize = 30

    /// Варианты для фильтров — по убыванию числа фильмов.
    let genreFacets: [String]
    let countryFacets: [String]
    private let directorFacets: [(name: String, key: String, count: Int)]

    init(bundle: Bundle = .main) {
        let curated = Library.load("films", bundle: bundle)
        let bulk = Library.load("films_wikidata", bundle: bundle)
        var all = curated
        var ids = Set(curated.map(\.id))
        all.reserveCapacity(curated.count + bulk.count)
        for film in bulk where !ids.contains(film.id) {
            all.append(film)
            ids.insert(film.id)
        }
        let recommended = curated.filter(\.isRecommended)
        featured = recommended
        catalog = all
        let featuredIDs = Set(recommended.map(\.id))
        let rest = all.filter { !featuredIDs.contains($0.id) }
        let isHome: (FilmItem) -> Bool = { film in
            film.countries.contains { Library.homeCountries.contains($0) }
        }
        russian = Array(rest.filter { isHome($0) }.prefix(Library.shelfSize))
        foreign = Array(rest.filter { !$0.countries.isEmpty && !isHome($0) }.prefix(Library.shelfSize))
        shuffled = all.shuffled()
        var map: [String: FilmItem] = [:]
        map.reserveCapacity(all.count)
        for film in all { map[film.id] = film }
        index = map

        var genreCount: [String: Int] = [:]
        var countryCount: [String: Int] = [:]
        var directorCount: [String: Int] = [:]
        for film in all {
            for g in film.genres { genreCount[g, default: 0] += 1 }
            for c in film.countries { countryCount[c, default: 0] += 1 }
            for d in film.directors { directorCount[d, default: 0] += 1 }
        }
        func ranked(_ counts: [String: Int]) -> [String] {
            counts.sorted { $0.value == $1.value ? $0.key < $1.key : $0.value > $1.value }.map(\.key)
        }
        genreFacets = ranked(genreCount)
        countryFacets = ranked(countryCount)
        directorFacets = directorCount
            .sorted { $0.value == $1.value ? $0.key < $1.key : $0.value > $1.value }
            .map { (name: $0.key, key: $0.key.normalizedForSearch, count: $0.value) }
    }

    /// Подсказки режиссёров по введённому тексту.
    func directorSuggestions(_ query: String, limit: Int = 8) -> [String] {
        let q = query.normalizedForSearch
        guard !q.isEmpty else { return Array(directorFacets.prefix(limit).map(\.name)) }
        var starts: [String] = []
        var contains: [String] = []
        for item in directorFacets {
            if item.key.hasPrefix(q) || item.key.split(separator: " ").contains(where: { $0.hasPrefix(q) }) {
                starts.append(item.name)
            } else if item.key.contains(q) {
                contains.append(item.name)
            }
            if starts.count >= limit { break }
        }
        return Array((starts + contains).prefix(limit))
    }

    /// Фильмы по фильтрам — в порядке известности.
    func filter(_ filter: FilmFilter, personal: [String: PersonalTags]) -> [FilmItem] {
        catalog.filter { filter.matches($0, personal: personal[$0.id]) }
    }

    private static func load(_ name: String, bundle: Bundle) -> [FilmItem] {
        guard let url = bundle.url(forResource: name, withExtension: "json"),
              let data = try? Data(contentsOf: url) else { return [] }
        do {
            return try JSONDecoder().decode([CatalogFilm].self, from: data).map(FilmItem.init(catalog:))
        } catch {
            print("Не удалось прочитать \(name).json: \(error)")
            return []
        }
    }

    /// Найти фильм по id. В «Сеансе» только фильмы из базы.
    func film(id: String) -> FilmItem? {
        index[id]
    }

    /// Самые известные фильмы — для подборок и «Что посмотрим вечером?».
    func popular(_ count: Int) -> [FilmItem] {
        Array(catalog.prefix(count))
    }

    /// Фильмы для «Вселенной»: избранные и самые известные из большой базы.
    func films(for mood: Mood?, limit: Int = 90) -> [FilmItem] {
        let pool = catalog.prefix(1500)
        guard let mood else { return Array(pool.prefix(max(limit, featured.count))) }
        return Array(pool.filter { $0.moods.contains(mood) }.prefix(limit))
    }

    /// Поиск: сначала совпадения с началом названия, затем с началом слова, затем любые.
    /// Внутри каждой группы — по известности.
    func search(_ query: String, limit: Int = 120) -> [FilmItem] {
        let words = query.normalizedForSearch
            .split(separator: " ")
            .map(String.init)
            .filter { !$0.isEmpty }
        guard let first = words.first else { return [] }
        let full = words.joined(separator: " ")

        var exact: [FilmItem] = []
        var prefix: [FilmItem] = []
        var wordStart: [FilmItem] = []
        var other: [FilmItem] = []
        for film in catalog {
            let key = film.searchKey
            guard words.allSatisfy({ key.contains($0) }) else { continue }
            let title = film.titleKey
            if title == full {
                exact.append(film)
            } else if title.hasPrefix(full) {
                prefix.append(film)
            } else if title.split(separator: " ").contains(where: { $0.hasPrefix(first) }) {
                wordStart.append(film)
            } else {
                other.append(film)
            }
            if exact.count + prefix.count >= limit { break }
        }
        return Array((exact + prefix + wordStart + other).prefix(limit))
    }
}
