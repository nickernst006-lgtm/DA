import SwiftUI
import SwiftData

/// Открытие анкеты: с начала или сразу на эссе.
struct SurveyLaunch: Identifiable {
    let film: FilmItem
    var essayOnly = false
    var id: String { film.id + (essayOnly ? "-essay" : "") }
}

/// Карточка фильма.
struct FilmDetailView: View {
    let filmID: String

    @Environment(Library.self) private var library
    @Environment(\.modelContext) private var context
    @Environment(\.dismiss) private var dismiss
    @Query private var collection: [CollectionItem]
    @Query private var surveys: [SurveyEntry]

    @State private var launch: SurveyLaunch?

    private var film: FilmItem? { library.film(id: filmID) }
    private var entry: CollectionItem? { collection.first { $0.filmID == filmID } }
    private var survey: SurveyEntry? { surveys.first { $0.filmID == filmID } }

    var body: some View {
        Group {
            if let film {
                content(film)
            } else {
                VStack(spacing: Space.s12) {
                    Text("Фильм не найден")
                        .textStyle(.body, .bold)
                        .foregroundStyle(Theme.text)
                    Button("Назад") { dismiss() }
                        .buttonStyle(SecondaryButtonStyle())
                        .frame(width: 160)
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
            }
        }
        .background(Theme.background.ignoresSafeArea())
        .toolbar(.visible, for: .navigationBar)
        .toolbarBackground(Theme.background, for: .navigationBar)
        .navigationBarTitleDisplayMode(.inline)
        .fullScreenCover(item: $launch) { item in
            SurveyView(film: item.film, startAtEssay: item.essayOnly)
        }
    }

    private func content(_ film: FilmItem) -> some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 0) {
                hero(film)

                if let synopsis = film.synopsis, !synopsis.isEmpty {
                    Text(synopsis)
                        .textStyle(.body)
                        .foregroundStyle(Theme.textSecondary)
                        .fixedSize(horizontal: false, vertical: true)
                        .padding(.top, Space.s24)
                }

                actions(film)
                    .padding(.top, Space.s24)

                if let survey {
                    review(survey, film: film)
                        .padding(.top, Space.s24)
                }

                if entry?.status == .seen {
                    JournalSection(filmID: film.id, essay: survey?.essay ?? "") {
                        launch = SurveyLaunch(film: film, essayOnly: true)
                    }
                    .padding(.top, Space.s32)
                }

                let archetypes = film.archetypes.compactMap(Archetype.init(rawValue:))
                if !archetypes.isEmpty {
                    ArchetypeBadges(archetypes: archetypes)
                        .padding(.top, Space.s32)
                }
            }
            .padding(.horizontal, ScreenLayout.sideMargin)
            .padding(.top, Space.s12)
            .padding(.bottom, Space.s32)
        }
        .dockClearance()
    }

    /// Шапка: обложка и рядом название (Заголовок 1), год, режиссёр, страна, длительность.
    private func hero(_ film: FilmItem) -> some View {
        HStack(alignment: .top, spacing: Space.s16) {
            CoverView(film: film, cornerRadius: Radius.medium)
                .frame(width: 112)
            VStack(alignment: .leading, spacing: 0) {
                Text(film.title)
                    .textStyle(.h1)
                    .foregroundStyle(Theme.text)
                    .fixedSize(horizontal: false, vertical: true)
                if let original = film.originalTitle, !original.isEmpty, original != film.title {
                    Text(original)
                        .textStyle(.sub)
                        .foregroundStyle(Theme.muted)
                        .padding(.top, Space.s4)
                }
                VStack(alignment: .leading, spacing: 0) {
                    if !film.fullMeta.isEmpty { Text(film.fullMeta) }
                    if !film.originMeta.isEmpty { Text(film.originMeta) }
                }
                .textStyle(.sub)
                .foregroundStyle(Theme.muted)
                .fixedSize(horizontal: false, vertical: true)
                .padding(.top, Space.s8)
                if entry?.status == .seen {
                    Text(seenCaption)
                        .textStyle(.sub)
                        .foregroundStyle(Theme.textSecondary)
                        .padding(.top, Space.s12)
                }
            }
        }
    }

    @ViewBuilder
    private func actions(_ film: FilmItem) -> some View {
        let status = entry?.status
        VStack(spacing: Space.s8) {
            switch status {
            case .some(.seen):
                if survey == nil {
                    Button("Заполнить анкету") { launch = SurveyLaunch(film: film) }
                        .buttonStyle(PrimaryButtonStyle())
                }
                Button("Хочу пересмотреть") {
                    CollectionActions.setStatus(.want, for: film.id, in: context)
                }
                .buttonStyle(SecondaryButtonStyle())
            case .some(.want):
                Button("Посмотрел") { markSeen(film) }
                    .buttonStyle(PrimaryButtonStyle())
                Button {
                    CollectionActions.setStatus(nil, for: film.id, in: context)
                } label: {
                    Label("В списке «Хочу посмотреть»", systemImage: "checkmark")
                }
                .buttonStyle(SecondaryButtonStyle(highlighted: true))
            case .none:
                Button("Посмотрел") { markSeen(film) }
                    .buttonStyle(PrimaryButtonStyle())
                Button("Хочу посмотреть") {
                    CollectionActions.setStatus(.want, for: film.id, in: context)
                }
                .buttonStyle(SecondaryButtonStyle())
            }
        }
        .sensoryFeedback(.success, trigger: entry?.statusRaw)
    }

    private var seenCaption: String {
        guard let date = entry?.seenAt else { return "Отмечен как просмотренный" }
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "ru_RU")
        formatter.dateFormat = "d MMMM yyyy"
        return "Просмотрен \(formatter.string(from: date))"
    }

    /// Плашка анкеты: подпись «АНКЕТА», слово о фильме (Заголовок 1) и квадрат оценки
    /// в правом верхнем углу; чувства; стороны фильма — шкалами из пяти делений;
    /// подробности одной строкой; внизу — «Изменить анкету».
    private func review(_ survey: SurveyEntry, film: FilmItem) -> some View {
        VStack(alignment: .leading, spacing: 0) {
            HStack(alignment: .top, spacing: Space.s12) {
                VStack(alignment: .leading, spacing: Space.s4) {
                    SectionLabel("Анкета")
                    if !survey.word.isEmpty {
                        Text(survey.word)
                            .textStyle(.h1)
                            .foregroundStyle(Theme.accent)
                            .fixedSize(horizontal: false, vertical: true)
                    }
                }
                Spacer(minLength: 0)
                if survey.rating > 0 {
                    RatingBadge(value: survey.rating, style: .h1)
                }
            }

            let feel = SurveyOptions.titles(for: survey.emotions, in: SurveyOptions.emotions)
            if !feel.isEmpty {
                Text(feel.joined(separator: " · "))
                    .textStyle(.sub)
                    .foregroundStyle(Theme.textSecondary)
                    .fixedSize(horizontal: false, vertical: true)
                    .padding(.top, Space.s8)
            }

            let aspects = survey.aspectValues()
            let rated = SurveyOptions.aspects.filter { (aspects[$0.id] ?? 0) > 0 }
            if !rated.isEmpty {
                LazyVGrid(columns: [GridItem(.flexible(), spacing: Space.s16, alignment: .leading),
                                    GridItem(.flexible(), spacing: Space.s16, alignment: .leading)],
                          alignment: .leading, spacing: Space.s12) {
                    ForEach(rated) { aspect in
                        let value = aspects[aspect.id] ?? 0
                        VStack(alignment: .leading, spacing: Space.s4) {
                            Text(aspect.title)
                                .textStyle(.caption)
                                .foregroundStyle(Theme.textSecondary)
                                .lineLimit(1)
                            AspectMeter(value: value)
                        }
                        .accessibilityElement(children: .ignore)
                        .accessibilityLabel("\(aspect.title): \(value) из 5")
                    }
                }
                .padding(.top, Space.s16)
            }

            let details = detailsLine(survey)
            if !details.isEmpty {
                Text(details)
                    .textStyle(.caption)
                    .foregroundStyle(Theme.muted)
                    .fixedSize(horizontal: false, vertical: true)
                    .padding(.top, Space.s16)
            }

            Rectangle()
                .fill(Theme.line)
                .frame(height: 1)
                .padding(.top, Space.s16)
            Button {
                launch = SurveyLaunch(film: film)
            } label: {
                Text("Изменить анкету")
                    .textStyle(.sub, .bold)
                    .foregroundStyle(Theme.textSecondary)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .touchArea()
            }
            .buttonStyle(.plain)
            .padding(.top, Space.s12)
        }
        .padding(Space.s16)
        .background(RoundedRectangle(cornerRadius: Radius.large, style: .continuous).fill(Theme.surface))
    }

    private func detailsLine(_ survey: SurveyEntry) -> String {
        var parts: [String] = []
        if let e = SurveyOptions.title(for: survey.ending, in: SurveyOptions.endings) { parts.append(e) }
        if let r = SurveyOptions.rewatchShort[survey.rewatch] { parts.append(r) }
        let company = SurveyOptions.title(for: survey.company, in: SurveyOptions.company)
        let place = SurveyOptions.title(for: survey.place, in: SurveyOptions.places)
        let context = [company, place].compactMap { $0 }.map { $0.lowercased() }
        if !context.isEmpty { parts.append("Смотрели: " + context.joined(separator: ", ")) }
        return parts.joined(separator: " · ")
    }

    private func markSeen(_ film: FilmItem) {
        CollectionActions.setStatus(.seen, for: film.id, in: context)
        if survey == nil {
            launch = SurveyLaunch(film: film)
        }
    }
}
