#!/usr/bin/env python3
"""Закачка каталога фильмов из ПоискКино (данные Кинопоиска) в библиотеку ance на Supabase.

Бесплатный ключ ПоискКино — 200 запросов в сутки, по 250 фильмов в запросе.
Пока библиотека не заполнена, скрипт за запуск тратит до 190 запросов (~47 000 фильмов),
идёт от самых известных фильмов и запоминает, на какой странице остановился, —
за три запуска (в разные дни) набирается ~100 000 фильмов. Когда цель достигнута,
каждый запуск тратит лишь 20 запросов на свежие фильмы.

У скрипта нет доступа к базе: только публичный ключ приложения и CATALOG_TOKEN —
ключ «почтовой щели», которым можно лишь добавить или обновить фильмы.

Переменные окружения:
  POISKKINO_API_KEY  — ключ ПоискКино (Telegram-бот @poiskkinodev_bot)
  SUPABASE_URL       — https://<проект>.supabase.co
  SUPABASE_ANON_KEY  — публичный ключ (тот же, что в приложении)
  CATALOG_TOKEN      — ключ щели (выдаёт SQL-скрипт схемы)
  CATALOG_TARGET     — сколько фильмов собрать (по умолчанию 100000)
"""
import json
import os
import sys
import time
import urllib.error
import urllib.parse
import urllib.request

API = "https://api.poiskkino.dev/v1.4/movie"
PAGE_SIZE = 250
KINDS = ["movie", "cartoon", "anime"]  # полнометражные: фильмы, мультфильмы, аниме

# Жанры Кинопоиска → наши жанры (как в приложении: Archetype.genreWeights, FilmTags).
GENRE_RULES = [
    (("мульт", "аниме"), "Анимация"),
    (("фантастик",), "Фантастика"),
    (("фэнтези",), "Фэнтези"),
    (("ужас",), "Ужасы"),
    (("триллер",), "Триллер"),
    (("боевик",), "Боевик"),
    (("приключен",), "Приключения"),
    (("комеди",), "Комедия"),
    (("мелодрам",), "Мелодрама"),
    (("мюзикл", "музык"), "Мюзикл"),
    (("криминал",), "Криминал"),
    (("детектив",), "Детектив"),
    (("военн",), "Военный"),
    (("вестерн",), "Вестерн"),
    (("биограф",), "Биография"),
    (("истори",), "Исторический"),
    (("документ",), "Документальный"),
    (("семейн", "детск"), "Семейный"),
    (("спорт",), "Спорт"),
    (("нуар",), "Нуар"),
    (("драм",), "Драма"),
]


def log(message):
    print(message, flush=True)


def env(name, default=None):
    value = os.environ.get(name, default)
    if value is None or value == "":
        sys.exit(f"Нет переменной {name}")
    return value


def map_genres(names):
    result = []
    for name in names:
        low = name.lower()
        for keys, genre in GENRE_RULES:
            if any(k in low for k in keys) and genre not in result:
                result.append(genre)
                break
    return result


def http(method, url, headers, body=None, retries=4):
    data = json.dumps(body).encode() if body is not None else None
    for attempt in range(retries):
        request = urllib.request.Request(url, data=data, method=method, headers=headers)
        try:
            with urllib.request.urlopen(request, timeout=120) as response:
                raw = response.read()
                return json.loads(raw) if raw else None
        except urllib.error.HTTPError as error:
            text = error.read().decode(errors="replace")[:300]
            if error.code in (401, 403):
                sys.exit(f"Доступ запрещён ({error.code}) к {url.split('?')[0]}: {text}")
            if error.code == 429 or error.code >= 500:
                log(f"  {error.code}, повтор через {5 * (attempt + 1)} с: {text}")
                time.sleep(5 * (attempt + 1))
                continue
            sys.exit(f"Ошибка {error.code} {url.split('?')[0]}: {text}")
        except urllib.error.URLError as error:
            log(f"  сеть: {error}, повтор")
            time.sleep(5 * (attempt + 1))
    sys.exit(f"Не удалось обратиться к {url.split('?')[0]}")


class Library:
    """Работа с библиотекой только через функции «почтовой щели»."""

    def __init__(self, url, anon_key, token):
        self.base = url.rstrip("/") + "/rest/v1/rpc"
        anon_key = anon_key.strip()
        self.headers = {"apikey": anon_key, "Content-Type": "application/json"}
        # Старый ключ anon — это JWT, его же передаём как Bearer.
        # Новый publishable (sb_publishable_…) достаточно передать в apikey.
        if anon_key.startswith("eyJ"):
            self.headers["Authorization"] = f"Bearer {anon_key}"
        self.token = token

    def rpc(self, name, **args):
        return http("POST", f"{self.base}/{name}", self.headers, dict(token=self.token, **args))

    def progress(self):
        data = self.rpc("catalog_progress") or {}
        return int(data.get("films") or 0), data.get("state") or {}

    def set_state(self, key, value):
        self.rpc("set_catalog_state", k=key, v=str(value))

    def load(self, rows):
        return self.rpc("load_films", rows=rows)


def fetch_page(key, kind, page, sort_field):
    params = [("page", page), ("limit", PAGE_SIZE), ("type", kind),
              ("sortField", sort_field), ("sortType", "-1"),
              ("notNullFields", "name"), ("notNullFields", "poster.url")]
    for field in ["id", "name", "alternativeName", "enName", "year", "description", "shortDescription",
                  "movieLength", "countries", "genres", "poster", "rating", "votes", "persons", "type"]:
        params.append(("selectFields", field))
    url = API + "?" + urllib.parse.urlencode(params)
    return http("GET", url, {"X-API-KEY": key, "Accept": "application/json"})


def to_row(doc, kind):
    rating = doc.get("rating") or {}
    votes = doc.get("votes") or {}
    poster = doc.get("poster") or {}
    directors = [p.get("name") or p.get("enName") for p in (doc.get("persons") or [])
                 if p.get("enProfession") == "director" and (p.get("name") or p.get("enName"))]
    original = doc.get("alternativeName") or doc.get("enName")
    def num(v):
        try:
            return round(float(v), 1) if v not in (None, "", 0) else None
        except (TypeError, ValueError):
            return None
    return {
        "id": doc["id"],
        "title": doc.get("name") or original or "Без названия",
        "original_title": original if original and original != doc.get("name") else None,
        "year": doc.get("year"),
        "description": doc.get("description"),
        "short_description": doc.get("shortDescription"),
        "minutes": doc.get("movieLength"),
        "countries": [c["name"] for c in (doc.get("countries") or []) if c.get("name")],
        "genres": map_genres([g["name"] for g in (doc.get("genres") or []) if g.get("name")]),
        "directors": directors[:3],
        "poster_url": poster.get("url"),
        "poster_preview_url": poster.get("previewUrl"),
        "rating_kp": num(rating.get("kp")),
        "rating_imdb": num(rating.get("imdb")),
        "votes_kp": int(votes.get("kp") or 0),
        "kind": kind,
    }


def main():
    key = env("POISKKINO_API_KEY")
    library = Library(env("SUPABASE_URL"), env("SUPABASE_ANON_KEY"), env("CATALOG_TOKEN"))
    target = int(os.environ.get("CATALOG_TARGET") or 100000)

    total, state = library.progress()
    share = {"movie": 0.8, "cartoon": 0.12, "anime": 0.08}
    pages_needed = {kind: max(1, round(target * share[kind] / PAGE_SIZE)) for kind in KINDS}
    filling = any(int(state.get(f"page:{kind}", "1")) <= pages_needed[kind] for kind in KINDS)
    budget = 190 if filling else 20
    log(f"В библиотеке {total} фильмов, цель {target}. "
        + ("Заполняем: до 190 запросов." if filling else "Заполнена: 20 запросов на свежие фильмы."))

    used = 0
    for kind in KINDS:
        page = int(state.get(f"page:{kind}", "1"))
        while page <= pages_needed[kind] and used < budget:
            data = fetch_page(key, kind, page, "votes.kp")
            used += 1
            docs = data.get("docs") or []
            rows = [to_row(d, kind) for d in docs if d.get("id") and (d.get("name") or d.get("alternativeName"))]
            if rows:
                library.load(rows)
            log(f"{kind}: страница {page}/{pages_needed[kind]} — {len(rows)} фильмов")
            page += 1
            if not docs or page > (data.get("pages") or page):
                page = pages_needed[kind] + 1
            library.set_state(f"page:{kind}", page)

    # Остаток — на свежие фильмы: самые новые по году, только с заметным числом оценок.
    fresh_page = int(state.get("page:fresh", "1"))
    while used < budget:
        data = fetch_page(key, "movie", fresh_page, "year")
        used += 1
        rows = [to_row(d, "movie") for d in (data.get("docs") or []) if d.get("id") and d.get("name")]
        rows = [r for r in rows if r["votes_kp"] >= 500]
        if rows:
            library.load(rows)
        log(f"свежие: страница {fresh_page} — {len(rows)} фильмов с 500+ оценками")
        fresh_page = 1 if fresh_page >= 20 else fresh_page + 1
        library.set_state("page:fresh", fresh_page)

    total, _ = library.progress()
    log(f"Готово: запросов к ПоискКино {used}, в библиотеке {total} фильмов")


if __name__ == "__main__":
    main()
