import SwiftUI

enum AppTab: String, CaseIterable, Identifiable {
    case afisha, collection, taste

    var id: String { rawValue }

    var title: String {
        switch self {
        case .afisha: return "Афиша"
        case .collection: return "Коллекция"
        case .taste: return "Вкусы"
        }
    }

    var icon: String {
        switch self {
        case .afisha: return "ticket"
        case .collection: return "rectangle.stack"
        case .taste: return "sparkle"
        }
    }
}

struct RootView: View {
    @AppStorage("didFinishWelcome") private var didFinishWelcome = false
    @State private var showSplash = true

    var body: some View {
        ZStack {
            Theme.background.ignoresSafeArea()

            if didFinishWelcome {
                MainTabsView()
            } else {
                WelcomeView {
                    withAnimation(.easeInOut(duration: 0.35)) { didFinishWelcome = true }
                }
            }

            if showSplash {
                SplashView()
                    .transition(.opacity)
                    .zIndex(1)
            }
        }
        .task {
            try? await Task.sleep(nanoseconds: 1_700_000_000)
            withAnimation(.easeInOut(duration: 0.5)) { showSplash = false }
        }
    }
}

/// Три вкладки и нижняя панель в стиле дока iPhone.
struct MainTabsView: View {
    @State private var tab: AppTab = .afisha

    var body: some View {
        VStack(spacing: 0) {
            ZStack {
                AfishaView()
                    .opacity(tab == .afisha ? 1 : 0)
                    .allowsHitTesting(tab == .afisha)
                    .accessibilityHidden(tab != .afisha)
                CollectionView(onBrowse: { tab = .afisha })
                    .opacity(tab == .collection ? 1 : 0)
                    .allowsHitTesting(tab == .collection)
                    .accessibilityHidden(tab != .collection)
                TasteView()
                    .opacity(tab == .taste ? 1 : 0)
                    .allowsHitTesting(tab == .taste)
                    .accessibilityHidden(tab != .taste)
            }
            DockBar(selection: $tab)
        }
        .background(Theme.background.ignoresSafeArea())
    }
}

struct DockBar: View {
    @Binding var selection: AppTab

    var body: some View {
        HStack(spacing: 0) {
            ForEach(AppTab.allCases) { tab in
                let isSelected = tab == selection
                Button {
                    selection = tab
                } label: {
                    Image(systemName: tab.icon)
                        .font(.system(size: 23, weight: .regular))
                        .foregroundStyle(isSelected ? Color.black : Theme.textSecondary)
                        .frame(width: 62, height: 62)
                        .background(
                            RoundedRectangle(cornerRadius: 18, style: .continuous)
                                .fill(isSelected ? Theme.text : Theme.dockButton)
                        )
                }
                .buttonStyle(.plain)
                .frame(maxWidth: .infinity)
                .accessibilityLabel(tab.title)
                .accessibilityAddTraits(isSelected ? .isSelected : [])
            }
        }
        .padding(.vertical, 10)
        .padding(.horizontal, 14)
        .background(
            RoundedRectangle(cornerRadius: 30, style: .continuous)
                .fill(Theme.dock)
        )
        .padding(.horizontal, 16)
        .padding(.top, 6)
        .padding(.bottom, 4)
        .sensoryFeedback(.selection, trigger: selection)
    }
}

/// Заставка: на чёрном фоне плавно появляется название.
struct SplashView: View {
    @State private var visible = false

    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()
            Text("Сеанс")
                .font(AppFont.titleFixed(40))
                .tracking(-1)
                .foregroundStyle(Theme.text)
                .opacity(visible ? 1 : 0)
        }
        .onAppear {
            withAnimation(.easeIn(duration: 0.9).delay(0.15)) { visible = true }
        }
        .accessibilityLabel("Сеанс")
    }
}

/// Первый запуск.
struct WelcomeView: View {
    let onStart: () -> Void

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            Spacer()
            HStack(spacing: -24) {
                CoverView(film: WelcomeView.sample[0]).frame(width: 108).rotationEffect(.degrees(-7))
                CoverView(film: WelcomeView.sample[1]).frame(width: 132).zIndex(1)
                    .overlay(RoundedRectangle(cornerRadius: 12, style: .continuous).stroke(Color.black, lineWidth: 6))
                CoverView(film: WelcomeView.sample[2]).frame(width: 108).rotationEffect(.degrees(7))
            }
            .frame(maxWidth: .infinity)
            .padding(.bottom, 48)

            VStack(alignment: .leading, spacing: 12) {
                Text("Сеанс")
                    .font(AppFont.title(40))
                    .tracking(-1)
                    .foregroundStyle(Theme.text)
                Text("Отмечайте фильмы, рассказывайте, как они вам, — и узнавайте свой киновкус.")
                    .font(AppFont.ui(17))
                    .foregroundStyle(Theme.textSecondary)
                    .fixedSize(horizontal: false, vertical: true)
            }

            HStack(alignment: .top, spacing: 14) {
                Image(systemName: "lock.fill")
                    .font(.system(size: 17))
                    .foregroundStyle(Theme.accent)
                    .accessibilityHidden(true)
                VStack(alignment: .leading, spacing: 4) {
                    Text("Без регистрации и паролей")
                        .font(AppFont.ui(15, .bold))
                        .foregroundStyle(Theme.text)
                    Text("Ваши фильмы, анкеты и эссе хранятся только на этом iPhone. Мы их не видим и не храним.")
                        .font(AppFont.ui(14))
                        .foregroundStyle(Theme.muted)
                        .fixedSize(horizontal: false, vertical: true)
                }
            }
            .padding(16)
            .background(RoundedRectangle(cornerRadius: 18, style: .continuous).fill(Theme.surface))
            .padding(.top, 28)

            Spacer()

            Button("Начать", action: onStart)
                .buttonStyle(PrimaryButtonStyle())
                .padding(.bottom, 12)
        }
        .padding(.horizontal, 24)
        .background(Theme.background.ignoresSafeArea())
    }

    static let sample: [FilmItem] = [
        FilmItem(previewTitle: "Амели", year: 2001,
                 cover: CoverStyle(bg: "#8C2427", accent: "#F0BE5E", x: 0.32, y: 0.34, size: 0.48), photo: nil),
        FilmItem(previewTitle: "Сталкер", year: 1979,
                 cover: CoverStyle(bg: "#33402F", accent: "#D9C27A", x: 0.6, y: 0.4, size: 0.5), photo: nil),
        FilmItem(previewTitle: "Начало", year: 2010,
                 cover: CoverStyle(bg: "#22324A", accent: "#A9BDD3", x: 0.66, y: 0.36, size: 0.44), photo: nil)
    ]
}
