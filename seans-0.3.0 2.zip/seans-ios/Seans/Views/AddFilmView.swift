import SwiftUI
import SwiftData
import PhotosUI
import UIKit

/// Добавление своего фильма, которого нет в базе. Хранится только у пользователя.
@MainActor
struct AddFilmView: View {
    var prefillTitle: String = ""

    @Environment(\.modelContext) private var context
    @Environment(\.dismiss) private var dismiss

    private enum CoverMode: Hashable { case style, photo }

    @State private var title = ""
    @State private var yearText = ""
    @State private var director = ""
    @State private var paletteIndex = 0
    @State private var coverMode: CoverMode = .style
    @State private var photoItem: PhotosPickerItem?
    @State private var photoData: Data?
    @State private var status: CollectionStatus = .want
    @State private var didPrefill = false

    private var trimmedTitle: String { title.trimmingCharacters(in: .whitespacesAndNewlines) }
    private var year: Int? { Int(yearText) }

    private var previewFilm: FilmItem {
        FilmItem(
            previewTitle: trimmedTitle.isEmpty ? "Название фильма" : trimmedTitle,
            year: year,
            director: director.isEmpty ? nil : director,
            cover: CoverStyle.user(palette: paletteIndex),
            photo: coverMode == .photo ? photoData : nil
        )
    }

    var body: some View {
        VStack(spacing: 0) {
            HStack {
                Button("Отмена") { dismiss() }
                    .font(AppFont.ui(16))
                    .foregroundStyle(Theme.textSecondary)
                    .frame(minWidth: 44, minHeight: 44, alignment: .leading)
                Spacer()
                Text("Свой фильм")
                    .font(AppFont.ui(16, .bold))
                    .foregroundStyle(Theme.text)
                Spacer()
                Color.clear.frame(width: 64, height: 44)
            }
            .padding(.horizontal, 16)
            .padding(.top, 8)

            ScrollView {
                VStack(alignment: .leading, spacing: 26) {
                    coverSection
                    fields
                    VStack(alignment: .leading, spacing: 8) {
                        Text("Куда добавить")
                            .font(AppFont.ui(13))
                            .foregroundStyle(Theme.muted)
                        SegmentedControl(
                            options: [
                                SegmentOption(value: CollectionStatus.want, title: "Хочу посмотреть"),
                                SegmentOption(value: CollectionStatus.seen, title: "Посмотрел")
                            ],
                            selection: $status
                        )
                    }
                }
                .padding(.horizontal, 20)
                .padding(.vertical, 12)
            }
            .scrollDismissesKeyboard(.interactively)

            VStack(spacing: 8) {
                Button("Добавить в коллекцию", action: save)
                    .buttonStyle(PrimaryButtonStyle())
                    .disabled(trimmedTitle.isEmpty)
                    .opacity(trimmedTitle.isEmpty ? 0.4 : 1)
                Text("Фильм сохранится только у вас")
                    .font(AppFont.ui(12))
                    .foregroundStyle(Theme.muted)
            }
            .padding(.horizontal, 20)
            .padding(.top, 8)
            .padding(.bottom, 12)
        }
        .background(Theme.background.ignoresSafeArea())
        .presentationBackground(Theme.background)
        .onAppear {
            if !didPrefill {
                title = prefillTitle.trimmingCharacters(in: .whitespacesAndNewlines)
                didPrefill = true
            }
        }
        .onChange(of: photoItem) { _, newItem in
            Task { await loadPhoto(newItem) }
        }
    }

    private var coverSection: some View {
        VStack(spacing: 18) {
            FilmTile(film: previewFilm, subtitle: previewFilm.shortMeta)
                .frame(width: 150)
                .overlay(alignment: .top) {
                    if coverMode == .photo && photoData == nil {
                        RoundedRectangle(cornerRadius: 14, style: .continuous)
                            .fill(Theme.surface)
                            .aspectRatio(2.0 / 3.0, contentMode: .fit)
                            .overlay(
                                VStack(spacing: 8) {
                                    Image(systemName: "photo")
                                        .font(.system(size: 28, weight: .light))
                                    Text("Фото не выбрано")
                                        .font(AppFont.ui(13))
                                }
                                .foregroundStyle(Theme.muted)
                            )
                    }
                }

            SegmentedControl(
                options: [
                    SegmentOption(value: CoverMode.style, title: "Обложка «Сеанса»"),
                    SegmentOption(value: CoverMode.photo, title: "Своё фото")
                ],
                selection: $coverMode
            )

            if coverMode == .style {
                VStack(alignment: .leading, spacing: 10) {
                    Text("Цвет")
                        .font(AppFont.ui(13))
                        .foregroundStyle(Theme.muted)
                    HStack(spacing: 10) {
                        ForEach(CoverStyle.userPalettes.indices, id: \.self) { i in
                            let palette = CoverStyle.userPalettes[i]
                            let isSelected = i == paletteIndex
                            Button {
                                paletteIndex = i
                            } label: {
                                Circle()
                                    .fill(Color(hexString: palette.bg))
                                    .frame(width: 40, height: 40)
                                    .overlay(Circle().fill(Color(hexString: palette.accent)).frame(width: 16, height: 16))
                                    .overlay(Circle().stroke(isSelected ? Theme.text : Color.clear, lineWidth: 2).padding(-4))
                                    .frame(width: 48, height: 48)
                            }
                            .buttonStyle(.plain)
                            .accessibilityLabel("Цвет \(i + 1)")
                            .accessibilityAddTraits(isSelected ? .isSelected : [])
                        }
                    }
                    .sensoryFeedback(.selection, trigger: paletteIndex)

                }
            } else {
                VStack(spacing: 6) {
                    PhotosPicker(selection: $photoItem, matching: .images) {
                        Text(photoData == nil ? "Выбрать фото" : "Выбрать другое фото")
                            .font(AppFont.ui(15, .medium))
                            .foregroundStyle(Theme.text)
                            .padding(.horizontal, 20)
                            .frame(minHeight: 44)
                            .background(Capsule().fill(Theme.surface))
                    }
                    Text("Приложение увидит только выбранное фото")
                        .font(AppFont.ui(12))
                        .foregroundStyle(Theme.muted)
                }
            }
        }
        .frame(maxWidth: .infinity)
    }

    private var fields: some View {
        VStack(alignment: .leading, spacing: 14) {
            field(label: "Название", text: $title, prompt: "Как называется фильм")
            HStack(alignment: .top, spacing: 10) {
                field(label: "Год", text: $yearText, prompt: "2026", keyboard: .numberPad)
                    .onChange(of: yearText) { _, newValue in
                        let digits = String(newValue.filter(\.isNumber).prefix(4))
                        if digits != newValue { yearText = digits }
                    }
                field(label: "Режиссёр", text: $director, prompt: "Необязательно")
            }
        }
    }

    private func field(label: String, text: Binding<String>, prompt: String, keyboard: UIKeyboardType = .default) -> some View {
        VStack(alignment: .leading, spacing: 6) {
            Text(label)
                .font(AppFont.ui(13))
                .foregroundStyle(Theme.muted)
            TextField("", text: text, prompt: Text(prompt).foregroundColor(Theme.muted))
                .font(AppFont.ui(16))
                .foregroundStyle(Theme.text)
                .keyboardType(keyboard)
                .padding(.horizontal, 14)
                .frame(minHeight: 50)
                .background(RoundedRectangle(cornerRadius: 14, style: .continuous).fill(Theme.surface))
                .accessibilityLabel(label)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }

    private func loadPhoto(_ item: PhotosPickerItem?) async {
        guard let item,
              let data = try? await item.loadTransferable(type: Data.self),
              let image = UIImage(data: data) else { return }
        photoData = AddFilmView.downscaled(image, maxSide: 900)
    }

    /// Уменьшаем фото, чтобы не занимать лишнее место на телефоне.
    static func downscaled(_ image: UIImage, maxSide: CGFloat) -> Data? {
        let size = image.size
        let scale = min(1, maxSide / max(size.width, size.height))
        let target = CGSize(width: size.width * scale, height: size.height * scale)
        let format = UIGraphicsImageRendererFormat()
        format.scale = 1
        let renderer = UIGraphicsImageRenderer(size: target, format: format)
        let resized = renderer.image { _ in image.draw(in: CGRect(origin: .zero, size: target)) }
        return resized.jpegData(compressionQuality: 0.8)
    }

    private func save() {
        guard !trimmedTitle.isEmpty else { return }
        let film = CustomFilm(
            title: trimmedTitle,
            year: year,
            director: director.trimmingCharacters(in: .whitespacesAndNewlines),
            paletteIndex: paletteIndex,
            motifIndex: 0,
            photo: coverMode == .photo ? photoData : nil
        )
        context.insert(film)
        context.insert(CollectionItem(filmID: film.filmID, status: status))
        try? context.save()
        dismiss()
    }
}
