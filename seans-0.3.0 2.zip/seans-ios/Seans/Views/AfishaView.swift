import SwiftUI
import SwiftData

/// Вкладка «Афиша»: поиск по базе, подборки под настроение, вечер вдвоём.
struct AfishaView: View {
    @Environment(Library.self) private var library
    @Query(sort: \CustomFilm.createdAt, order: .reverse) private var customFilms: [CustomFilm]

    @State private var query = ""
    @State private var mood: Mood? = nil
    @State private var showAddFilm = false
    @State private var showEvening = false

    private let columns = [
        GridItem(.flexible(), spacing: 14, alignment: .top),
        GridItem(.flexible(), spacing: 14, alignment: .top)
    ]

    private var isSearching: Bool {
        !query.trimmingCharacters(in: .whitespaces).isEmpty
    }

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 22) {
                    ScreenTitle("Афиша")
                        .padding(.top, 12)

                    VStack(alignment: .leading, spacing: 4) {
                        SearchField(text: $query)
                        Button {
                            showAddFilm = true
                        } label: {
                            HStack(spacing: 5) {
                                Text("Нет нужного фильма?")
                                    .foregroundStyle(Theme.muted)
                                Text("Добавить свой")
                                    .foregroundStyle(Theme.text)
                            }
                            .font(AppFont.ui(14, .medium))
                            .frame(minHeight: 44)
                        }
                        .buttonStyle(.plain)
                    }

                    if isSearching {
                        searchResults
                    } else {
                        moodPicker
                        eveningCard
                        filmGrid(title: mood?.sectionTitle ?? "Стоит посмотреть", films: library.films(for: mood))
                    }
                }
                .padding(.horizontal, 20)
                .padding(.bottom, 24)
            }
            .scrollDismissesKeyboard(.immediately)
            .background(Theme.background.ignoresSafeArea())
            .toolbar(.hidden, for: .navigationBar)
            .navigationDestination(for: FilmRoute.self) { route in
                FilmDetailView(filmID: route.id)
            }
        }
        .sheet(isPresented: $showAddFilm) {
            AddFilmView(prefillTitle: isSearching ? query : "")
        }
        .fullScreenCover(isPresented: $showEvening) {
            EveningView()
        }
    }

    private var moodPicker: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 8) {
                Chip(title: "Всё", isSelected: mood == nil, height: 38) { mood = nil }
                ForEach(Mood.allCases) { item in
                    Chip(title: item.title, isSelected: mood == item, height: 38) { mood = item }
                }
            }
            .padding(.horizontal, 20)
        }
        .padding(.horizontal, -20)
    }

    private var eveningCard: some View {
        Button {
            showEvening = true
        } label: {
            HStack(spacing: 14) {
                Image(systemName: "person.2.fill")
                    .font(.system(size: 17))
                    .foregroundStyle(Color.black)
                    .frame(width: 44, height: 44)
                    .background(Circle().fill(Theme.text))
                    .accessibilityHidden(true)
                VStack(alignment: .leading, spacing: 2) {
                    Text("Что посмотрим вечером?")
                        .font(AppFont.ui(16, .bold))
                        .foregroundStyle(Theme.text)
                    Text("Выберите фильм вдвоём")
                        .font(AppFont.ui(14))
                        .foregroundStyle(Theme.muted)
                }
                Spacer(minLength: 0)
                Image(systemName: "arrow.right")
                    .font(.system(size: 15, weight: .medium))
                    .foregroundStyle(Theme.muted)
                    .accessibilityHidden(true)
            }
            .padding(14)
            .background(RoundedRectangle(cornerRadius: 20, style: .continuous).fill(Theme.surface))
        }
        .buttonStyle(.plain)
    }

    @ViewBuilder
    private var searchResults: some View {
        let results = library.search(query, custom: customFilms)
        if results.isEmpty {
            VStack(alignment: .leading, spacing: 8) {
                Text("Ничего не нашлось")
                    .font(AppFont.ui(18, .bold))
                    .foregroundStyle(Theme.text)
                Text("Этого фильма пока нет в базе «Сеанса». Добавьте его сами — он сохранится только у вас.")
                    .font(AppFont.ui(15))
                    .foregroundStyle(Theme.muted)
                    .fixedSize(horizontal: false, vertical: true)
                Button("Добавить «\(query.trimmingCharacters(in: .whitespaces))»") {
                    showAddFilm = true
                }
                .buttonStyle(SecondaryButtonStyle())
                .padding(.top, 8)
            }
            .padding(.top, 8)
        } else {
            filmGrid(title: "Найдено: \(results.count)", films: results)
        }
    }

    private func filmGrid(title: String, films: [FilmItem]) -> some View {
        VStack(alignment: .leading, spacing: 14) {
            SectionTitle(title)
            LazyVGrid(columns: columns, alignment: .leading, spacing: 24) {
                ForEach(films) { film in
                    NavigationLink(value: FilmRoute(id: film.id)) {
                        FilmTile(film: film, subtitle: film.shortMeta)
                    }
                    .buttonStyle(.plain)
                }
            }
        }
    }
}
