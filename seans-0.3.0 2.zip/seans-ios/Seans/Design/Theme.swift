import SwiftUI
import UIKit

/// Цвета приложения. Все экраны — на чистом чёрном фоне.
enum Theme {
    static let background = Color.black
    static let surface = Color(hex: 0x141414)
    static let surfaceRaised = Color(hex: 0x1F1F1F)
    static let dock = Color(hex: 0x141414)
    static let dockButton = Color(hex: 0x262626)
    static let line = Color(hex: 0x1C1C1C)
    static let lineStrong = Color(hex: 0x2C2C2C)

    static let text = Color(hex: 0xF5F5F5)
    static let textSecondary = Color(hex: 0xC8C8C8)
    static let muted = Color(hex: 0x8E8E8E)

    /// Тёплый акцент — только точечно.
    static let accent = Color(hex: 0xE8B04B)
}

/// Шрифт приложения — Helvetica Neue (встроена в iOS).
/// Все размеры масштабируются вместе с системным размером текста.
enum AppFont {
    private static func name(_ weight: Font.Weight) -> String {
        switch weight {
        case .bold, .heavy, .black, .semibold: return "HelveticaNeue-Bold"
        case .medium: return "HelveticaNeue-Medium"
        case .light, .thin, .ultraLight: return "HelveticaNeue-Light"
        default: return "HelveticaNeue"
        }
    }

    private static func isAvailable(_ name: String) -> Bool {
        UIFont(name: name, size: 12) != nil
    }

    /// Крупные заголовки.
    static func title(_ size: CGFloat, _ weight: Font.Weight = .bold, relativeTo style: Font.TextStyle = .largeTitle) -> Font {
        ui(size, weight, relativeTo: style)
    }

    /// Заголовок фиксированного размера (для картинок, которые отправляются в соцсети).
    static func titleFixed(_ size: CGFloat, _ weight: Font.Weight = .bold) -> Font {
        uiFixed(size, weight)
    }

    /// Текст интерфейса.
    static func ui(_ size: CGFloat, _ weight: Font.Weight = .regular, relativeTo style: Font.TextStyle = .body) -> Font {
        let fontName = name(weight)
        if isAvailable(fontName) {
            return .custom(fontName, size: size, relativeTo: style)
        }
        return .system(size: size, weight: weight)
    }

    static func uiFixed(_ size: CGFloat, _ weight: Font.Weight = .regular) -> Font {
        let fontName = name(weight)
        if isAvailable(fontName) {
            return .custom(fontName, fixedSize: size)
        }
        return .system(size: size, weight: weight)
    }
}

extension Color {
    init(hex: UInt32) {
        let r = Double((hex >> 16) & 0xFF) / 255
        let g = Double((hex >> 8) & 0xFF) / 255
        let b = Double(hex & 0xFF) / 255
        self.init(.sRGB, red: r, green: g, blue: b, opacity: 1)
    }

    /// Цвет из строки вида "#33402F".
    init(hexString: String, fallback: Color = .gray) {
        var cleaned = hexString.trimmingCharacters(in: .whitespacesAndNewlines)
        if cleaned.hasPrefix("#") { cleaned.removeFirst() }
        if cleaned.count == 6, let value = UInt32(cleaned, radix: 16) {
            self.init(hex: value)
        } else {
            self = fallback
        }
    }
}
