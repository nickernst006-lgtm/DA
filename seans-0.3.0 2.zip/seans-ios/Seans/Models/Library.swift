import Foundation
import Observation

/// Встроенная база фильмов. Две части:
/// - films.json — ручная база: авторские обложки, описания, подборки;
/// - films_wikidata.json — большая база из Wikidata, обновляется при сборке.
/// Обе обновляются только вместе с новой версией приложения.
@Observable
final class Library {
    /// Ручная база — избранные фильмы.
    let featured: [FilmItem]
    /// Вся база: сначала ручная, затем Wikidata по убыванию известности.
    let catalog: [FilmItem]
    private let index: [String: FilmItem]

    init(bundle: Bundle = .main) {
        let curated = Library.load("films", bundle: bundle)
        let bulk = Library.load("films_wikidata", bundle: bundle)
        var all = curated
        var ids = Set(curated.map(\.id))
        all.reserveCapacity(curated.count + bulk.count)
        for film in bulk where !ids.contains(film.id) {
            all.append(film)
            ids.insert(film.id)
        }
        featured = curated
        catalog = all
        var map: [String: FilmItem] = [:]
        map.reserveCapacity(all.count)
        for film in all { map[film.id] = film }
        index = map
    }

    private static func load(_ name: String, bundle: Bundle) -> [FilmItem] {
        guard let url = bundle.url(forResource: name, withExtension: "json"),
              let data = try? Data(contentsOf: url) else { return [] }
        do {
            return try JSONDecoder().decode([CatalogFilm].self, from: data).map(FilmItem.init(catalog:))
        } catch {
            print("Не удалось прочитать \(name).json: \(error)")
            return []
        }
    }

    /// Найти фильм по id — в базе или среди добавленных пользователем.
    func film(id: String, custom: [CustomFilm]) -> FilmItem? {
        if let film = index[id] { return film }
        if let own = custom.first(where: { $0.filmID == id }) { return FilmItem(custom: own) }
        return nil
    }

    /// Самые известные фильмы — для подборок и «Что посмотрим вечером?».
    func popular(_ count: Int) -> [FilmItem] {
        Array(catalog.prefix(count))
    }

    /// Фильмы для Афиши: избранные и самые известные из большой базы.
    func films(for mood: Mood?, limit: Int = 90) -> [FilmItem] {
        let pool = catalog.prefix(1500)
        guard let mood else { return Array(pool.prefix(max(limit, featured.count))) }
        return Array(pool.filter { $0.moods.contains(mood) }.prefix(limit))
    }

    /// Поиск: сначала совпадения с началом названия, затем с началом слова, затем любые.
    /// Внутри каждой группы — по известности.
    func search(_ query: String, custom: [CustomFilm], limit: Int = 120) -> [FilmItem] {
        let words = query.normalizedForSearch
            .split(separator: " ")
            .map(String.init)
            .filter { !$0.isEmpty }
        guard let first = words.first else { return [] }
        let full = words.joined(separator: " ")

        var exact: [FilmItem] = []
        var prefix: [FilmItem] = []
        var wordStart: [FilmItem] = []
        var other: [FilmItem] = []
        let all = custom.map(FilmItem.init(custom:)) + catalog
        for film in all {
            let key = film.searchKey
            guard words.allSatisfy({ key.contains($0) }) else { continue }
            let title = film.titleKey
            if title == full {
                exact.append(film)
            } else if title.hasPrefix(full) {
                prefix.append(film)
            } else if title.split(separator: " ").contains(where: { $0.hasPrefix(first) }) {
                wordStart.append(film)
            } else {
                other.append(film)
            }
            if exact.count + prefix.count >= limit { break }
        }
        return Array((exact + prefix + wordStart + other).prefix(limit))
    }
}
