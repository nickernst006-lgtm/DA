import Foundation

struct SurveyOption: Identifiable, Hashable {
    let id: String
    let title: String
}

/// Шкала «от — до», например темп: медленный ↔ динамичный.
struct SurveyScale: Identifiable, Hashable {
    let id: String
    let title: String
    let left: String
    let right: String
    /// «неспешное», «динамичное» — для фразы «вы любите … кино».
    let leftFilm: String
    let rightFilm: String
}

/// Варианты ответов в анкете после просмотра.
enum SurveyOptions {
    static let emotions: [SurveyOption] = [
        SurveyOption(id: "wow", title: "Восторг"),
        SurveyOption(id: "chills", title: "Мурашки"),
        SurveyOption(id: "anx", title: "Тревога"),
        SurveyOption(id: "sad", title: "Светлая грусть"),
        SurveyOption(id: "think", title: "Задумчивость"),
        SurveyOption(id: "insp", title: "Вдохновение"),
        SurveyOption(id: "warm", title: "Тепло"),
        SurveyOption(id: "laugh", title: "Смех"),
        SurveyOption(id: "nostalgia", title: "Ностальгия"),
        SurveyOption(id: "bored", title: "Скука")
    ]

    /// Стороны фильма, которые оцениваются от 1 до 5.
    static let aspects: [SurveyOption] = [
        SurveyOption(id: "plot", title: "Сюжет"),
        SurveyOption(id: "cast", title: "Актёры"),
        SurveyOption(id: "visual", title: "Картинка"),
        SurveyOption(id: "sound", title: "Музыка и звук"),
        SurveyOption(id: "dialogue", title: "Диалоги"),
        SurveyOption(id: "atmosphere", title: "Атмосфера")
    ]

    /// Соответствие старых ответов версии 0.1 («что зацепило») сторонам фильма.
    static let legacyHookToAspect: [String: String] = [
        "atm": "atmosphere", "pic": "visual", "sound": "sound",
        "cast": "cast", "plot": "plot", "talk": "dialogue"
    ]

    static let scales: [SurveyScale] = [
        SurveyScale(id: "tempo", title: "Темп", left: "Медленный", right: "Динамичный", leftFilm: "неспешное", rightFilm: "динамичное"),
        SurveyScale(id: "tone", title: "Настроение", left: "Светлый", right: "Мрачный", leftFilm: "светлое", rightFilm: "мрачное"),
        SurveyScale(id: "complexity", title: "Сложность", left: "Простой", right: "Сложный", leftFilm: "простое", rightFilm: "сложное"),
        SurveyScale(id: "surprise", title: "Сюжет", left: "Предсказуемый", right: "Неожиданный", leftFilm: "предсказуемое", rightFilm: "непредсказуемое")
    ]

    static let endings: [SurveyOption] = [
        SurveyOption(id: "strong", title: "Сильный финал"),
        SurveyOption(id: "open", title: "Открытый — и это хорошо"),
        SurveyOption(id: "predictable", title: "Предсказуемый"),
        SurveyOption(id: "letdown", title: "Разочаровал")
    ]

    static let company: [SurveyOption] = [
        SurveyOption(id: "alone", title: "Один"),
        SurveyOption(id: "pair", title: "Вдвоём"),
        SurveyOption(id: "friends", title: "С друзьями"),
        SurveyOption(id: "family", title: "С семьёй")
    ]

    static let places: [SurveyOption] = [
        SurveyOption(id: "home", title: "Дома"),
        SurveyOption(id: "cinema", title: "В кино"),
        SurveyOption(id: "road", title: "В дороге")
    ]

    static let rewatch: [SurveyOption] = [
        SurveyOption(id: "yes", title: "Обязательно пересмотрю"),
        SurveyOption(id: "maybe", title: "Может быть, когда-нибудь"),
        SurveyOption(id: "no", title: "Одного раза хватило")
    ]

    static let rewatchShort: [String: String] = [
        "yes": "Пересмотрю обязательно",
        "maybe": "Может, пересмотрю",
        "no": "Одного раза хватило"
    ]

    static let recommend: [SurveyOption] = [
        SurveyOption(id: "cinephile", title: "Другу-киноману"),
        SurveyOption(id: "date", title: "На свидание"),
        SurveyOption(id: "parents", title: "Родителям"),
        SurveyOption(id: "kids", title: "Детям"),
        SurveyOption(id: "alone", title: "Для вечера в одиночестве"),
        SurveyOption(id: "none", title: "Никому")
    ]

    static let wordSuggestions = ["Шедевр", "Гипноз", "Тепло", "Тягуче", "Неожиданно", "Пусто"]

    static let essayPrompts = [
        "Что я почувствовал в финале?",
        "Какая сцена не отпускает?",
        "С чем этот фильм хочется сравнить?",
        "Что бы я спросил у режиссёра?"
    ]

    static func ratingLabel(_ rating: Int) -> String {
        switch rating {
        case 1...3: return "Не моё"
        case 4...5: return "Так себе"
        case 6...7: return "Хорошо"
        case 8...9: return "Отлично"
        case 10: return "Шедевр"
        default: return ""
        }
    }

    static func titles(for ids: [String], in options: [SurveyOption]) -> [String] {
        options.filter { ids.contains($0.id) }.map(\.title)
    }

    static func title(for id: String, in options: [SurveyOption]) -> String? {
        options.first { $0.id == id }?.title
    }
}

/// Тип зрителя — главный итог анкет.
enum ViewerType: String, CaseIterable {
    case contemplative, aesthete, melomane, actorsFan, storyteller, listener, thinker, thrillSeeker, romantic

    var title: String {
        switch self {
        case .contemplative: return "Созерцатель"
        case .aesthete: return "Эстет"
        case .melomane: return "Меломан"
        case .actorsFan: return "Ценитель игры"
        case .storyteller: return "Искатель историй"
        case .listener: return "Слушатель"
        case .thinker: return "Исследователь смыслов"
        case .thrillSeeker: return "Охотник за адреналином"
        case .romantic: return "Романтик"
        }
    }

    var description: String {
        switch self {
        case .contemplative:
            return "Вас ведёт атмосфера, а не сюжетные повороты. Вы любите неспешное кино, после которого хочется помолчать."
        case .aesthete:
            return "Вы смотрите глазами: свет, кадр и цвет для вас важнее всего. Красивый фильм вы узнаёте по первой сцене."
        case .melomane:
            return "Музыка и звук делают для вас половину фильма. Хороший саундтрек вы помните годами."
        case .actorsFan:
            return "Вы приходите за людьми на экране — за живой игрой, характерами и взглядами."
        case .storyteller:
            return "Вам важно, что будет дальше. Хорошо закрученная история и неожиданный поворот — лучший подарок."
        case .listener:
            return "Вы цените точные диалоги и фразы, которые хочется цитировать друзьям."
        case .thinker:
            return "Вы любите кино, которое задаёт вопросы. Сложные фильмы не пугают вас, а притягивают."
        case .thrillSeeker:
            return "Вам нужен пульс: быстрый темп, напряжение и мурашки по коже."
        case .romantic:
            return "Вы ищете в кино тепло и чувства. Лучший фильм для вас — тот, после которого светло на душе."
        }
    }
}

/// Профиль вкуса, посчитанный по анкетам.
struct TasteProfile {
    struct Bar: Identifiable {
        let id: String
        let title: String
        let value: Double // 0…1
        let label: String
    }

    struct Count: Identifiable {
        let id: String
        let title: String
        let count: Int
    }

    struct Axis: Identifiable {
        let id: String
        let title: String
        let left: String
        let right: String
        let leftFilm: String
        let rightFilm: String
        let value: Double // −1…1
    }

    let seenCount: Int
    let surveyCount: Int
    let essayCount: Int
    let essayWords: Int
    let averageRating: Double?
    let favoriteDecade: String?
    let favoriteDirector: String?
    let type: ViewerType?
    let reason: String?
    let aspects: [Bar]
    let axes: [Axis]
    let feelings: [Count]
    let words: [Count]
    let favoriteIDs: [String]

    init(surveys: [SurveyEntry], seenFilms: [FilmItem]) {
        seenCount = seenFilms.count
        surveyCount = surveys.count

        // Эссе.
        let essays = surveys.map { $0.essay.trimmingCharacters(in: .whitespacesAndNewlines) }.filter { !$0.isEmpty }
        essayCount = essays.count
        essayWords = essays.reduce(0) { $0 + $1.split(whereSeparator: { $0.isWhitespace || $0.isNewline }).count }

        // Средняя оценка.
        let ratings = surveys.map(\.rating).filter { $0 > 0 }
        averageRating = ratings.isEmpty ? nil : Double(ratings.reduce(0, +)) / Double(ratings.count)

        // Любимое десятилетие и режиссёр — по просмотренным.
        var decades: [Int: Int] = [:]
        var directors: [String: Int] = [:]
        for film in seenFilms {
            if let year = film.year { decades[(year / 10) * 10, default: 0] += 1 }
            if let surname = film.directorSurname { directors[surname, default: 0] += 1 }
        }
        if let best = decades.max(by: { $0.value == $1.value ? $0.key < $1.key : $0.value < $1.value })?.key {
            favoriteDecade = best < 2000 ? "\(best % 100)-е" : "\(best)-е"
        } else {
            favoriteDecade = nil
        }
        if let top = directors.max(by: { $0.value == $1.value ? $0.key > $1.key : $0.value < $1.value }), top.value >= 2 {
            favoriteDirector = top.key
        } else {
            favoriteDirector = nil
        }

        // Стороны фильма: средняя оценка 1–5.
        var aspectSum: [String: Double] = [:]
        var aspectCount: [String: Double] = [:]
        for survey in surveys {
            var values = survey.aspectValues()
            if values.isEmpty {
                for hook in survey.hooks {
                    if let aspect = SurveyOptions.legacyHookToAspect[hook] { values[aspect] = 5 }
                }
            }
            for (key, value) in values where value > 0 {
                aspectSum[key, default: 0] += Double(value)
                aspectCount[key, default: 0] += 1
            }
        }
        var aspectAverage: [String: Double] = [:]
        for (key, sum) in aspectSum {
            aspectAverage[key] = sum / max(1, aspectCount[key] ?? 1)
        }
        aspects = SurveyOptions.aspects
            .compactMap { option -> Bar? in
                guard let avg = aspectAverage[option.id] else { return nil }
                return Bar(id: option.id, title: option.title, value: avg / 5, label: String(format: "%.1f", avg))
            }
            .sorted { $0.value > $1.value }

        // Шкалы: какое кино вам нравится. Фильмы с высокой оценкой весят больше.
        var scaleSum: [String: Double] = [:]
        var scaleWeight: [String: Double] = [:]
        for survey in surveys {
            let weight: Double
            switch survey.rating {
            case 0: weight = 1
            case 1...4: weight = 0.25
            case 5...6: weight = 0.7
            case 7...8: weight = 1.5
            default: weight = 2.5
            }
            for (key, value) in survey.scaleValues() {
                scaleSum[key, default: 0] += Double(value) * weight
                scaleWeight[key, default: 0] += weight
            }
        }
        var scaleAverage: [String: Double] = [:]
        for (key, sum) in scaleSum {
            if let w = scaleWeight[key], w > 0 { scaleAverage[key] = sum / w / 2 } // −1…1
        }
        axes = SurveyOptions.scales.compactMap { scale -> Axis? in
            guard let value = scaleAverage[scale.id] else { return nil }
            return Axis(id: scale.id, title: scale.title, left: scale.left, right: scale.right,
                        leftFilm: scale.leftFilm, rightFilm: scale.rightFilm, value: max(-1, min(1, value)))
        }

        // Чувства.
        var emotionCounts: [String: Int] = [:]
        for survey in surveys { for e in survey.emotions { emotionCounts[e, default: 0] += 1 } }
        feelings = SurveyOptions.emotions
            .compactMap { (option: SurveyOption) -> Count? in
                guard let n = emotionCounts[option.id], n > 0 else { return nil }
                return Count(id: option.id, title: option.title, count: n)
            }
            .sorted { $0.count > $1.count }
            .prefix(5)
            .map { $0 }

        // Слова о кино.
        var wordCounts: [String: Int] = [:]
        var order: [String] = []
        for survey in surveys.sorted(by: { $0.date > $1.date }) {
            let w = survey.word.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
            guard !w.isEmpty else { continue }
            if wordCounts[w] == nil { order.append(w) }
            wordCounts[w, default: 0] += 1
        }
        words = order.prefix(14).map { Count(id: $0, title: $0, count: wordCounts[$0] ?? 1) }

        // Любимые фильмы: высокие оценки, затем «пересмотрю».
        let sortedFavorites = surveys
            .filter { $0.rating >= 8 || ($0.rating == 0 && $0.rewatch == "yes") }
            .sorted { $0.rating == $1.rating ? $0.date > $1.date : $0.rating > $1.rating }
        favoriteIDs = sortedFavorites.prefix(10).map(\.filmID)

        // Тип зрителя.
        if surveys.isEmpty {
            type = nil
            reason = nil
        } else {
            func a(_ key: String) -> Double { (aspectAverage[key] ?? 3) - 3 }          // −2…2
            func s(_ key: String) -> Double { (scaleAverage[key] ?? 0) * 2 }            // −2…2
            func e(_ key: String) -> Double { Double(emotionCounts[key] ?? 0) / Double(surveys.count) * 3 }
            let scores: [(ViewerType, Double)] = [
                (.contemplative, a("atmosphere") * 0.7 - s("tempo") * 0.6 + e("think") * 0.3),
                (.aesthete, a("visual") * 0.9 + a("atmosphere") * 0.2),
                (.melomane, a("sound") * 1.0),
                (.actorsFan, a("cast") * 1.0),
                (.storyteller, a("plot") * 0.8 + s("surprise") * 0.4),
                (.listener, a("dialogue") * 1.0),
                (.thinker, s("complexity") * 0.7 + e("think") * 0.5),
                (.thrillSeeker, s("tempo") * 0.6 + (e("chills") + e("anx")) * 0.5),
                (.romantic, (e("warm") + e("sad")) * 0.5 - s("tone") * 0.4)
            ]
            let best = scores.max { $0.1 < $1.1 }
            type = best?.0 ?? .contemplative

            var parts: [String] = []
            if let topAspect = aspects.first {
                parts.append("выше всего вы оцениваете «\(topAspect.title.lowercased())»")
            }
            if let strongest = axes.max(by: { abs($0.value) < abs($1.value) }), abs(strongest.value) >= 0.25 {
                let side = strongest.value < 0 ? strongest.leftFilm : strongest.rightFilm
                parts.append("любите \(side) кино")
            }
            if let feeling = feelings.first {
                parts.append("чаще всего чувствуете «\(feeling.title.lowercased())»")
            }
            let n = surveys.count
            let surveysWord = TasteProfile.plural(n, "анкете", "анкетам", "анкетам")
            reason = parts.isEmpty ? nil : "По \(n) \(surveysWord): " + parts.joined(separator: ", ") + "."
        }
    }

    /// Склонение: 1 фильм, 2 фильма, 5 фильмов.
    static func plural(_ n: Int, _ one: String, _ few: String, _ many: String) -> String {
        let mod10 = n % 10
        let mod100 = n % 100
        if mod10 == 1 && mod100 != 11 { return one }
        if (2...4).contains(mod10) && !(12...14).contains(mod100) { return few }
        return many
    }
}
