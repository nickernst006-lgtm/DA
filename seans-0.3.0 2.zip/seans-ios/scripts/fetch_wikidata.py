#!/usr/bin/env python3
"""Загрузка базы фильмов из Wikidata.

Данные Wikidata распространяются по лицензии CC0 — их можно свободно
использовать в приложении. Ключ и регистрация не нужны.

Запуск (из корня проекта):
    python3 scripts/fetch_wikidata.py --limit 10000

Результат — Seans/Resources/films_wikidata.json. Если загрузка не удалась
или фильмов получилось подозрительно мало, старый файл остаётся как есть.

Что берётся: русское и оригинальное название, год, режиссёры, страны,
жанры, длительность. Известность фильма оценивается по числу статей о нём
в разных языковых разделах Википедии. Фильмы из ручной базы films.json
(совпадение по названию и году) пропускаются — ручная запись главнее.
"""
import argparse
import json
import os
import re
import sys
import time
import unicodedata
import urllib.parse
import urllib.request

ENDPOINT = "https://query.wikidata.org/sparql"
USER_AGENT = "SeansApp/0.3 (iOS film diary; https://github.com/nickernst006-lgtm/DA) python-urllib"
CURATED = "Seans/Resources/films.json"
OUTPUT = "Seans/Resources/films_wikidata.json"
BATCH = 150

# Фильм, полнометражный фильм, анимационный фильм, полнометражный анимационный фильм.
FILM_TYPES = "wd:Q11424 wd:Q24869 wd:Q202866 wd:Q29168811"

GENRE_RULES = [
    # (ключевые слова в английском или русском названии жанра, наш жанр)
    (("animated", "animation", "анимац", "мульт"), "Анимация"),
    (("science fiction", "sci-fi", "научно-фантаст", "фантастическ"), "Фантастика"),
    (("fantasy", "фэнтези"), "Фэнтези"),
    (("horror", "ужас"), "Ужасы"),
    (("thriller", "триллер"), "Триллер"),
    (("action", "боевик", "martial arts", "superhero", "супергеро"), "Боевик"),
    (("adventure", "приключен"), "Приключения"),
    (("comedy", "комеди"), "Комедия"),
    (("romance", "romantic", "мелодрам", "романтич"), "Мелодрама"),
    (("musical", "мюзикл", "music film", "музыкальн"), "Мюзикл"),
    (("crime", "heist", "gangster", "криминал", "гангстер"), "Криминал"),
    (("mystery", "detective", "детектив"), "Детектив"),
    (("war film", "военн"), "Военный"),
    (("western", "вестерн"), "Вестерн"),
    (("biographical", "биограф"), "Биография"),
    (("historical", "period", "истори"), "Исторический"),
    (("documentary", "документ"), "Документальный"),
    (("family", "children", "семейн", "детск"), "Семейный"),
    (("sport", "спортив"), "Спорт"),
    (("noir", "нуар"), "Нуар"),
    (("drama", "драм"), "Драма"),
]

COUNTRY_SHORT = {
    "Соединённые Штаты Америки": "США",
    "Соединенные Штаты Америки": "США",
    "Союз Советских Социалистических Республик": "СССР",
    "Соединённое Королевство": "Великобритания",
    "Соединённое Королевство Великобритании и Северной Ирландии": "Великобритания",
    "Федеративная Республика Германия": "Германия",
    "Германская Демократическая Республика": "ГДР",
    "Российская Федерация": "Россия",
    "Китайская Народная Республика": "Китай",
    "Республика Корея": "Южная Корея",
    "Корейская Народно-Демократическая Республика": "КНДР",
    "Королевство Нидерландов": "Нидерланды",
}


def log(message):
    print(message, flush=True)


def sparql(query, retries=5):
    body = urllib.parse.urlencode({"query": query, "format": "json"}).encode()
    for attempt in range(retries):
        try:
            request = urllib.request.Request(
                ENDPOINT,
                data=body,
                headers={
                    "User-Agent": USER_AGENT,
                    "Accept": "application/sparql-results+json",
                    "Content-Type": "application/x-www-form-urlencoded",
                },
            )
            with urllib.request.urlopen(request, timeout=120) as response:
                return json.load(response)["results"]["bindings"]
        except Exception as error:  # сеть, таймаут, 429 — пробуем ещё раз
            wait = 10 * (attempt + 1)
            log(f"  Wikidata не ответила ({error}), повтор через {wait} с")
            time.sleep(wait)
    raise RuntimeError("Wikidata не отвечает")


def value(row, key):
    """Значение из строки ответа SPARQL или из уже разобранного словаря."""
    cell = row.get(key)
    if isinstance(cell, dict):
        return cell.get("value", "")
    return cell or ""


def normalize(text):
    text = unicodedata.normalize("NFKD", text.lower().replace("ё", "е"))
    text = "".join(ch for ch in text if not unicodedata.combining(ch))
    return re.sub(r"[^\w]+", " ", text).strip()


def short_person(name):
    """«Андрей Арсеньевич Тарковский» → «Андрей Тарковский»."""
    parts = name.split()
    if len(parts) == 3 and re.search(r"(вич|вна|ична|ич)$", parts[1]):
        return f"{parts[0]} {parts[2]}"
    return name


def map_genres(labels):
    result = []
    lowered = [label.lower() for label in labels]
    for keywords, genre in GENRE_RULES:
        if any(any(k in label for k in keywords) for label in lowered):
            if genre not in result:
                result.append(genre)
    return result[:3]


def moods_for(genres):
    g = set(genres)
    moods = []
    if "Комедия" in g:
        moods.append("laugh")
    if g & {"Триллер", "Ужасы", "Боевик"}:
        moods.append("chills")
    if g & {"Семейный", "Анимация", "Мюзикл"} or ("Мелодрама" in g and not g & {"Триллер", "Ужасы"}):
        moods.append("cozy")
    if "Драма" in g and not g & {"Комедия", "Боевик", "Ужасы"}:
        moods.append("think")
    return moods


def top_films(limit):
    log(f"Ищу {limit} самых известных фильмов…")
    query = f"""
    SELECT ?film (MAX(?links) AS ?l) WHERE {{
      VALUES ?type {{ {FILM_TYPES} }}
      ?film wdt:P31 ?type ;
            wikibase:sitelinks ?links .
      FILTER(?links >= 10)
    }}
    GROUP BY ?film
    ORDER BY DESC(?l)
    LIMIT {int(limit * 1.25)}
    """
    rows = sparql(query)
    films = []
    for row in rows:
        qid = value(row, "film").rsplit("/", 1)[-1]
        films.append((qid, int(float(value(row, "l") or 0))))
    log(f"  найдено кандидатов: {len(films)}")
    return films


def details(qids):
    """Данные о фильмах. Несколько небольших запросов вместо одного большого —
    так Wikidata не упирается в лимит времени."""
    values = " ".join(f"wd:{q}" for q in qids)
    parts = [
        # Названия, год, длительность.
        """(SAMPLE(?ru) AS ?ruLabel) (SAMPLE(?en) AS ?enLabel)
           (GROUP_CONCAT(DISTINCT CONCAT(LANG(?ot), ":", STR(?ot)); separator="|") AS ?titles)
           (MIN(YEAR(?date)) AS ?year) (MIN(?secs) AS ?seconds)""",
        """OPTIONAL { ?film rdfs:label ?ru . FILTER(LANG(?ru) = "ru") }
           OPTIONAL { ?film rdfs:label ?en . FILTER(LANG(?en) = "en") }
           OPTIONAL { ?film wdt:P1476 ?ot . }
           OPTIONAL { ?film wdt:P577 ?date . }
           OPTIONAL { ?film p:P2047/psn:P2047/wikibase:quantityAmount ?secs . }""",
    ], [
        # Режиссёры.
        """(GROUP_CONCAT(DISTINCT ?dirName; separator="|") AS ?directors)""",
        """?film wdt:P57 ?dir .
           OPTIONAL { ?dir rdfs:label ?dirRu . FILTER(LANG(?dirRu) = "ru") }
           OPTIONAL { ?dir rdfs:label ?dirEn . FILTER(LANG(?dirEn) = "en") }
           BIND(COALESCE(?dirRu, ?dirEn) AS ?dirName)""",
    ], [
        # Страны.
        """(GROUP_CONCAT(DISTINCT ?countryName; separator="|") AS ?countries)""",
        """?film wdt:P495 ?country .
           ?country rdfs:label ?countryName . FILTER(LANG(?countryName) = "ru")""",
    ], [
        # Жанры — русские и английские названия, чтобы надёжнее сопоставить.
        """(GROUP_CONCAT(DISTINCT ?genreName; separator="|") AS ?genres)""",
        """?film wdt:P136 ?genre .
           ?genre rdfs:label ?genreName . FILTER(LANG(?genreName) IN ("ru", "en"))""",
    ]
    merged = {q: {} for q in qids}
    for select, where in parts:
        query = f"""
        SELECT ?film {select} WHERE {{
          VALUES ?film {{ {values} }}
          {where}
        }}
        GROUP BY ?film
        """
        for row in sparql(query):
            qid = value(row, "film").rsplit("/", 1)[-1]
            if qid in merged:
                for key, cell in row.items():
                    if key != "film":
                        merged[qid][key] = cell["value"]
    return merged


def build(limit):
    curated = []
    if os.path.exists(CURATED):
        with open(CURATED, encoding="utf-8") as f:
            curated = json.load(f)
    curated_keys = set()
    for film in curated:
        title = normalize(film.get("title", ""))
        year = film.get("year")
        if year:
            for y in (year - 1, year, year + 1):
                curated_keys.add((title, y))

    candidates = top_films(limit)
    films = []
    seen_keys = set()

    for start in range(0, len(candidates), BATCH):
        if len(films) >= limit:
            break
        chunk = [qid for qid, _ in candidates[start:start + BATCH]]
        log(f"  данные о фильмах {start + 1}–{start + len(chunk)}…")
        info = details(chunk)
        for qid in chunk:
            row = info.get(qid, {})
            year_text = row.get("year", "")
            if not year_text:
                continue
            year = int(float(year_text))

            originals = [t.split(":", 1) for t in value(row, "titles").split("|") if ":" in t]
            original = next((text for lang, text in originals if lang != "ru" and text), "")
            title = value(row, "ruLabel") or original or value(row, "enLabel")
            if not title or re.fullmatch(r"Q\d+", title):
                continue

            key = (normalize(title), year)
            if key in curated_keys or key in seen_keys:
                continue
            seen_keys.add(key)

            film = {"id": f"wd-{qid}", "title": title}
            if original and normalize(original) != normalize(title):
                film["originalTitle"] = original
            film["year"] = year

            countries = []
            for name in value(row, "countries").split("|"):
                name = COUNTRY_SHORT.get(name, name)
                if name and name not in countries:
                    countries.append(name)
            if countries:
                film["countries"] = countries[:3]

            directors = [short_person(n) for n in value(row, "directors").split("|") if n]
            if directors:
                film["directors"] = directors[:3]

            seconds = value(row, "seconds")
            if seconds:
                minutes = round(float(seconds) / 60)
                if 20 <= minutes <= 600:
                    film["minutes"] = minutes

            genres = map_genres([g for g in value(row, "genres").split("|") if g])
            if genres:
                film["genres"] = genres
                moods = moods_for(genres)
                if moods:
                    film["moods"] = moods

            films.append(film)
            if len(films) >= limit:
                break
        time.sleep(1)  # бережно к серверу Wikidata
    return films


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--limit", type=int, default=10000)
    parser.add_argument("--min", type=int, default=1000, help="минимум фильмов, иначе файл не перезаписывается")
    args = parser.parse_args()

    try:
        films = build(args.limit)
    except Exception as error:
        log(f"Не удалось загрузить базу из Wikidata: {error}")
        log("Оставляю прежний файл films_wikidata.json.")
        return 1

    if len(films) < args.min:
        log(f"Получено только {len(films)} фильмов — подозрительно мало, прежний файл не трогаю.")
        return 1

    lines = [json.dumps(f, ensure_ascii=False, separators=(",", ":")) for f in films]
    with open(OUTPUT, "w", encoding="utf-8") as f:
        f.write("[\n" + ",\n".join(lines) + "\n]\n")
    size_mb = os.path.getsize(OUTPUT) / 1024 / 1024
    log(f"Готово: {len(films)} фильмов, {size_mb:.1f} МБ → {OUTPUT}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
