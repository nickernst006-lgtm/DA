import Foundation
import SwiftData

/// Приглашение в друзья: личный код и имя.
/// Ссылка вида seans://friend?code=ABCD-EF23&name=Ник открывает приложение у друга.
struct FriendInvite: Equatable {
    let code: String
    let name: String

    static let scheme = "seans"
    private static let alphabet = Array("ABCDEFGHJKLMNPQRSTUVWXYZ23456789")

    init(code: String, name: String) {
        self.code = code
        self.name = name
    }

    /// Из ссылки seans://friend?…
    init?(url: URL) {
        guard url.scheme?.lowercased() == FriendInvite.scheme,
              url.host?.lowercased() == "friend",
              let items = URLComponents(url: url, resolvingAgainstBaseURL: false)?.queryItems,
              let raw = items.first(where: { $0.name == "code" })?.value,
              let code = FriendInvite.normalize(code: raw) else { return nil }
        self.code = code
        self.name = (items.first(where: { $0.name == "name" })?.value ?? "")
            .trimmingCharacters(in: .whitespacesAndNewlines)
    }

    /// Из того, что пользователь вставил: ссылки целиком или одного кода.
    init?(text: String) {
        let trimmed = text.trimmingCharacters(in: .whitespacesAndNewlines)
        if let range = trimmed.range(of: "seans://"),
           let url = URL(string: String(trimmed[range.lowerBound...]).components(separatedBy: .whitespacesAndNewlines).first ?? ""),
           let invite = FriendInvite(url: url) {
            self = invite
            return
        }
        guard let code = FriendInvite.normalize(code: trimmed) else { return nil }
        self.code = code
        self.name = ""
    }

    /// Ссылка для отправки другу.
    var url: URL? {
        var components = URLComponents()
        components.scheme = FriendInvite.scheme
        components.host = "friend"
        var items = [URLQueryItem(name: "code", value: code)]
        if !name.isEmpty { items.append(URLQueryItem(name: "name", value: name)) }
        components.queryItems = items
        return components.url
    }

    /// Текст сообщения с приглашением.
    var message: String {
        var lines = ["Давай дружить в ance — дневнике кино."]
        if let url { lines.append("Открой ссылку на iPhone с приложением: \(url.absoluteString)") }
        lines.append("Или введи мой код во вкладке «Друзья»: \(code)")
        return lines.joined(separator: "\n")
    }

    /// Новый личный код: 8 символов без похожих букв и цифр, «ABCD-EF23».
    static func makeCode() -> String {
        let chars = (0..<8).map { _ in alphabet.randomElement() ?? "A" }
        return String(chars[0..<4]) + "-" + String(chars[4..<8])
    }

    /// Приводит введённый код к виду «ABCD-EF23». nil — если это не код.
    static func normalize(code raw: String) -> String? {
        let cleaned = raw.uppercased().filter { alphabet.contains($0) }
        guard cleaned.count == 8, raw.filter({ $0.isLetter || $0.isNumber }).count == 8 else { return nil }
        let chars = Array(cleaned)
        return String(chars[0..<4]) + "-" + String(chars[4..<8])
    }
}

enum FriendAddResult {
    case added, updated, isSelf
}

enum FriendActions {
    /// Добавить друга или обновить имя, если он уже есть.
    @discardableResult
    static func add(_ invite: FriendInvite, myCode: String, in context: ModelContext) -> FriendAddResult {
        if invite.code == myCode { return .isSelf }
        let code = invite.code
        let descriptor = FetchDescriptor<Friend>(predicate: #Predicate { $0.code == code })
        if let existing = (try? context.fetch(descriptor))?.first {
            if !invite.name.isEmpty { existing.name = invite.name }
            try? context.save()
            return .updated
        }
        context.insert(Friend(code: invite.code, name: invite.name.isEmpty ? "Друг" : invite.name))
        try? context.save()
        return .added
    }
}
