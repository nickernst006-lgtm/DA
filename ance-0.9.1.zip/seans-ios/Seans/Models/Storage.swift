import Foundation
import SwiftData

/// Статус фильма в коллекции пользователя.
enum CollectionStatus: String, Codable {
    case want
    case seen
}

/// Фильм в коллекции: «Хочу посмотреть» или «Посмотрел».
/// Все данные хранятся только на устройстве.
@Model
final class CollectionItem {
    var filmID: String = ""
    var statusRaw: String = CollectionStatus.want.rawValue
    var addedAt: Date = Date()
    var seenAt: Date?

    init(filmID: String, status: CollectionStatus) {
        self.filmID = filmID
        self.statusRaw = status.rawValue
        self.addedAt = Date()
        self.seenAt = status == .seen ? Date() : nil
    }

    var status: CollectionStatus {
        get { CollectionStatus(rawValue: statusRaw) ?? .want }
        set {
            statusRaw = newValue.rawValue
            if newValue == .seen && seenAt == nil { seenAt = Date() }
            if newValue == .want { seenAt = nil }
        }
    }
}

/// Анкета после просмотра и эссе.
@Model
final class SurveyEntry {
    var filmID: String = ""
    var date: Date = Date()
    /// Оценка 1–10, 0 — не поставлена.
    var rating: Int = 0
    var emotions: [String] = []
    /// Старое поле версии 0.1 — «что зацепило». Используется, если нет оценок сторон.
    var hooks: [String] = []
    /// Оценки сторон фильма 1–5 в виде "plot:4,cast:5".
    var aspectsRaw: String = ""
    /// Шкалы −2…2 в виде "tempo:-1,tone:2".
    var scalesRaw: String = ""
    var ending: String = ""
    var company: String = ""
    var place: String = ""
    var rewatch: String = ""
    var recommend: [String] = []
    var word: String = ""
    var essay: String = ""

    init(filmID: String) {
        self.filmID = filmID
        self.date = Date()
    }

    func aspectValues() -> [String: Int] {
        SurveyEntry.decode(aspectsRaw)
    }

    func scaleValues() -> [String: Int] {
        SurveyEntry.decode(scalesRaw)
    }

    func setAspects(_ values: [String: Int]) {
        aspectsRaw = SurveyEntry.encode(values)
    }

    func setScales(_ values: [String: Int]) {
        scalesRaw = SurveyEntry.encode(values)
    }

    static func decode(_ raw: String) -> [String: Int] {
        var result: [String: Int] = [:]
        for part in raw.split(separator: ",") {
            let pair = part.split(separator: ":")
            if pair.count == 2, let value = Int(pair[1]) {
                result[String(pair[0])] = value
            }
        }
        return result
    }

    static func encode(_ values: [String: Int]) -> String {
        values.keys.sorted()
            .map { key in "\(key):\(values[key] ?? 0)" }
            .joined(separator: ",")
    }
}

/// Фильм, который пользователь добавил сам (было до версии 0.7.5).
/// Добавлять свои фильмы больше нельзя — в ance только фильмы из базы.
/// Модель оставлена, чтобы у тех, кто уже добавлял фильмы, хранилище открылось без ошибок.
@Model
final class CustomFilm {
    var filmID: String = ""
    var title: String = ""
    var year: Int?
    var director: String = ""
    var paletteIndex: Int = 0
    var motifIndex: Int = 0
    @Attribute(.externalStorage) var photo: Data?
    var createdAt: Date = Date()

    init(title: String, year: Int?, director: String, paletteIndex: Int, motifIndex: Int, photo: Data?) {
        self.filmID = "user-" + UUID().uuidString
        self.title = title
        self.year = year
        self.director = director
        self.paletteIndex = paletteIndex
        self.motifIndex = motifIndex
        self.photo = photo
        self.createdAt = Date()
    }
}

/// Операции с коллекцией.
enum CollectionActions {
    static func item(for filmID: String, in context: ModelContext) -> CollectionItem? {
        let descriptor = FetchDescriptor<CollectionItem>(predicate: #Predicate { $0.filmID == filmID })
        return (try? context.fetch(descriptor))?.first
    }

    static func survey(for filmID: String, in context: ModelContext) -> SurveyEntry? {
        let descriptor = FetchDescriptor<SurveyEntry>(predicate: #Predicate { $0.filmID == filmID })
        return (try? context.fetch(descriptor))?.first
    }

    /// Установить статус; nil — убрать из коллекции.
    static func setStatus(_ status: CollectionStatus?, for filmID: String, in context: ModelContext) {
        let existing = item(for: filmID, in: context)
        switch (existing, status) {
        case (nil, nil):
            break
        case (let item?, nil):
            context.delete(item)
        case (nil, let newStatus?):
            context.insert(CollectionItem(filmID: filmID, status: newStatus))
        case (let item?, let newStatus?):
            item.status = newStatus
        }
        try? context.save()
    }
}

/// Друг, добавленный по ссылке или коду. Хранится только на этом iPhone.
@Model
final class Friend {
    var code: String = ""
    var name: String = ""
    var addedAt: Date = Date()

    init(code: String, name: String) {
        self.code = code
        self.name = name
        self.addedAt = Date()
    }
}
