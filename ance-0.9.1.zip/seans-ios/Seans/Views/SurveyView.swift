import SwiftUI
import SwiftData

/// Анкета после просмотра: восемь коротких шагов, затем эссе и карточка для соцсетей.
@MainActor
struct SurveyView: View {
    let film: FilmItem
    /// Открыть сразу на шаге эссе.
    var startAtEssay = false

    @Environment(\.modelContext) private var context
    @Environment(\.dismiss) private var dismiss

    private enum Field: Hashable { case word, essay }

    @State private var step = 0
    @State private var rating = 0
    @State private var emotions: Set<String> = []
    @State private var aspects: [String: Int] = [:]
    @State private var scales: [String: Int] = [:]
    @State private var ending = ""
    @State private var company = ""
    @State private var place = ""
    @State private var rewatch = ""
    @State private var recommend: Set<String> = []
    @State private var word = ""
    @State private var essay = ""
    @State private var shareImage: Image?
    @State private var didLoad = false
    @FocusState private var focus: Field?

    /// Шаги 0…7 — вопросы, 8 — итоговая карточка.
    private let questionCount = 8
    private let essayStepIndex = 7

    var body: some View {
        VStack(spacing: 0) {
            header
            ScrollView {
                VStack(alignment: .leading, spacing: 26) {
                    switch step {
                    case 0: ratingStep
                    case 1: emotionsStep
                    case 2: aspectsStep
                    case 3: scalesStep
                    case 4: contextStep
                    case 5: verdictStep
                    case 6: wordStep
                    case 7: essayStep
                    default: resultStep
                    }
                }
                .padding(.horizontal, 20)
                .padding(.top, 28)
                .padding(.bottom, 24)
                .frame(maxWidth: .infinity, alignment: .leading)
            }
            .scrollDismissesKeyboard(.interactively)
            footer
        }
        .background(Theme.background.ignoresSafeArea())
        .onAppear(perform: loadExisting)
        .animation(.easeInOut(duration: 0.2), value: step)
    }

    // MARK: Шапка и прогресс

    private var header: some View {
        VStack(spacing: 16) {
            HStack {
                CloseButton(label: "Закрыть анкету") { dismiss() }
                Spacer()
                Text(film.title)
                    .font(AppFont.ui(15, .bold))
                    .foregroundStyle(Theme.text)
                    .lineLimit(1)
                Spacer()
                Text(step < questionCount ? "\(step + 1)/\(questionCount)" : "")
                    .font(AppFont.ui(13, .medium))
                    .foregroundStyle(Theme.muted)
                    .frame(width: 44, alignment: .trailing)
            }
            HStack(spacing: 4) {
                ForEach(0..<questionCount, id: \.self) { i in
                    Capsule()
                        .fill(i <= step ? Theme.text : Theme.lineStrong)
                        .frame(height: 3)
                }
            }
            .accessibilityHidden(true)
        }
        .padding(.horizontal, 20)
        .padding(.top, 12)
    }

    private func question(_ title: String, hint: String? = nil) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(title)
                .font(AppFont.title(30, relativeTo: .title))
                .tracking(-0.6)
                .foregroundStyle(Theme.text)
                .fixedSize(horizontal: false, vertical: true)
                .accessibilityAddTraits(.isHeader)
            if let hint {
                Text(hint)
                    .font(AppFont.ui(15))
                    .foregroundStyle(Theme.muted)
                    .fixedSize(horizontal: false, vertical: true)
            }
        }
    }

    private func groupLabel(_ text: String) -> some View {
        Text(text)
            .font(AppFont.ui(13, .medium))
            .foregroundStyle(Theme.muted)
            .textCase(nil)
    }

    // MARK: 1. Оценка

    private var ratingStep: some View {
        VStack(alignment: .leading, spacing: 24) {
            question("Ваша оценка")
            LazyVGrid(columns: Array(repeating: GridItem(.flexible(), spacing: 8), count: 5), spacing: 8) {
                ForEach(1...10, id: \.self) { value in
                    let isSelected = rating == value
                    Button {
                        rating = value
                    } label: {
                        Text("\(value)")
                            .font(AppFont.ui(22, .bold))
                            .foregroundStyle(isSelected ? Color.black : Theme.text)
                            .frame(maxWidth: .infinity, minHeight: 60)
                            .background(
                                RoundedRectangle(cornerRadius: 16, style: .continuous)
                                    .fill(isSelected ? Theme.text : Theme.surface)
                            )
                    }
                    .buttonStyle(.plain)
                    .accessibilityLabel("\(value) из 10")
                    .accessibilityAddTraits(isSelected ? .isSelected : [])
                }
            }
            .sensoryFeedback(.selection, trigger: rating)
            Text(rating > 0 ? SurveyOptions.ratingLabel(rating) : "Нажмите на число")
                .font(AppFont.title(22, .medium, relativeTo: .title3))
                .foregroundStyle(rating > 0 ? Theme.accent : Theme.muted)
        }
    }

    // MARK: 2. Чувства

    private var emotionsStep: some View {
        VStack(alignment: .leading, spacing: 24) {
            question("Какие чувства остались?", hint: "Можно выбрать несколько")
            FlowLayout(spacing: 8, lineSpacing: 8) {
                ForEach(SurveyOptions.emotions) { option in
                    Chip(title: option.title, isSelected: emotions.contains(option.id), height: 46) {
                        toggle(option.id, in: &emotions)
                    }
                }
            }
        }
    }

    // MARK: 3. Стороны фильма

    private var aspectsStep: some View {
        VStack(alignment: .leading, spacing: 20) {
            question("Оцените стороны фильма", hint: "От 1 до 5. То, что не запомнилось, можно пропустить.")
            VStack(spacing: 4) {
                ForEach(SurveyOptions.aspects) { aspect in
                    aspectRow(aspect)
                }
            }
        }
    }

    private func aspectRow(_ aspect: SurveyOption) -> some View {
        let value = aspects[aspect.id] ?? 0
        return HStack(spacing: 8) {
            Text(aspect.title)
                .font(AppFont.ui(16, .medium))
                .foregroundStyle(Theme.text)
                .frame(maxWidth: .infinity, alignment: .leading)
            HStack(spacing: 0) {
                ForEach(1...5, id: \.self) { v in
                    Button {
                        aspects[aspect.id] = (value == v) ? 0 : v
                    } label: {
                        Circle()
                            .fill(v <= value ? Theme.text : Theme.lineStrong)
                            .frame(width: 20, height: 20)
                            .frame(width: 38, height: 48)
                            .contentShape(Rectangle())
                    }
                    .buttonStyle(.plain)
                }
            }
        }
        .padding(.leading, 16)
        .padding(.trailing, 6)
        .background(RoundedRectangle(cornerRadius: 16, style: .continuous).fill(Theme.surface))
        .sensoryFeedback(.selection, trigger: value)
        .accessibilityElement(children: .ignore)
        .accessibilityLabel(aspect.title)
        .accessibilityValue(value == 0 ? "не оценено" : "\(value) из 5")
        .accessibilityAdjustableAction { direction in
            switch direction {
            case .increment: aspects[aspect.id] = min(5, value + 1)
            case .decrement: aspects[aspect.id] = max(0, value - 1)
            @unknown default: break
            }
        }
    }

    // MARK: 4. Шкалы

    private var scalesStep: some View {
        VStack(alignment: .leading, spacing: 20) {
            question("Каким он вам показался?", hint: "Отметьте ближе к той стороне, что вернее")
            VStack(spacing: 10) {
                ForEach(SurveyOptions.scales) { scale in
                    scaleRow(scale)
                }
            }
        }
    }

    private func scaleRow(_ scale: SurveyScale) -> some View {
        let selected = scales[scale.id]
        let sizes: [CGFloat] = [26, 19, 13, 19, 26]
        return VStack(alignment: .leading, spacing: 8) {
            Text(scale.title)
                .font(AppFont.ui(13, .medium))
                .foregroundStyle(Theme.muted)
            HStack(spacing: 0) {
                ForEach(-2...2, id: \.self) { v in
                    Button {
                        if selected == v { scales[scale.id] = nil } else { scales[scale.id] = v }
                    } label: {
                        Circle()
                            .fill(selected == v ? Theme.text : Theme.lineStrong)
                            .frame(width: sizes[v + 2], height: sizes[v + 2])
                            .frame(maxWidth: .infinity, minHeight: 44)
                            .contentShape(Rectangle())
                    }
                    .buttonStyle(.plain)
                }
            }
            HStack {
                Text(scale.left)
                Spacer()
                Text(scale.right)
            }
            .font(AppFont.ui(14, .medium))
            .foregroundStyle(Theme.textSecondary)
        }
        .padding(16)
        .background(RoundedRectangle(cornerRadius: 18, style: .continuous).fill(Theme.surface))
        .sensoryFeedback(.selection, trigger: selected)
        .accessibilityElement(children: .ignore)
        .accessibilityLabel("\(scale.title): от «\(scale.left)» до «\(scale.right)»")
        .accessibilityValue(scaleAccessibilityValue(scale, selected))
        .accessibilityAdjustableAction { direction in
            let current = selected ?? 0
            switch direction {
            case .increment: scales[scale.id] = min(2, current + 1)
            case .decrement: scales[scale.id] = max(-2, current - 1)
            @unknown default: break
            }
        }
    }

    private func scaleAccessibilityValue(_ scale: SurveyScale, _ value: Int?) -> String {
        guard let value else { return "не отмечено" }
        switch value {
        case -2: return "очень \(scale.left.lowercased())"
        case -1: return "скорее \(scale.left.lowercased())"
        case 0: return "посередине"
        case 1: return "скорее \(scale.right.lowercased())"
        default: return "очень \(scale.right.lowercased())"
        }
    }

    // MARK: 5. Как это было

    private var contextStep: some View {
        VStack(alignment: .leading, spacing: 22) {
            question("Как это было")
            singleChoice("Финал", options: SurveyOptions.endings, selection: $ending)
            singleChoice("С кем смотрели", options: SurveyOptions.company, selection: $company)
            singleChoice("Где", options: SurveyOptions.places, selection: $place)
        }
    }

    private func singleChoice(_ label: String, options: [SurveyOption], selection: Binding<String>) -> some View {
        VStack(alignment: .leading, spacing: 10) {
            groupLabel(label)
            FlowLayout(spacing: 8, lineSpacing: 8) {
                ForEach(options) { option in
                    Chip(title: option.title, isSelected: selection.wrappedValue == option.id, height: 44) {
                        selection.wrappedValue = selection.wrappedValue == option.id ? "" : option.id
                    }
                }
            }
        }
    }

    // MARK: 6. Вердикт

    private var verdictStep: some View {
        VStack(alignment: .leading, spacing: 22) {
            question("Пересмотрели бы?")
            VStack(spacing: 8) {
                ForEach(SurveyOptions.rewatch) { option in
                    let isSelected = rewatch == option.id
                    Button {
                        rewatch = isSelected ? "" : option.id
                    } label: {
                        Text(option.title)
                            .font(AppFont.ui(16, .medium))
                            .foregroundStyle(isSelected ? Color.black : Theme.text)
                            .frame(maxWidth: .infinity, minHeight: 56, alignment: .leading)
                            .padding(.horizontal, 18)
                            .background(
                                RoundedRectangle(cornerRadius: 16, style: .continuous)
                                    .fill(isSelected ? Theme.text : Theme.surface)
                            )
                    }
                    .buttonStyle(.plain)
                    .accessibilityAddTraits(isSelected ? .isSelected : [])
                }
            }
            .sensoryFeedback(.selection, trigger: rewatch)
            VStack(alignment: .leading, spacing: 10) {
                groupLabel("Кому бы посоветовали")
                FlowLayout(spacing: 8, lineSpacing: 8) {
                    ForEach(SurveyOptions.recommend) { option in
                        Chip(title: option.title, isSelected: recommend.contains(option.id), height: 44) {
                            if option.id == "none" {
                                recommend = recommend.contains("none") ? [] : ["none"]
                            } else {
                                recommend.remove("none")
                                toggle(option.id, in: &recommend)
                            }
                        }
                    }
                }
            }
            .padding(.top, 4)
        }
    }

    // MARK: 7. Слово

    private var wordStep: some View {
        VStack(alignment: .leading, spacing: 22) {
            question("Одно слово о фильме", hint: "Оно появится на вашей карточке и во «Вкусах»")
            TextField("", text: $word, prompt: Text("Ваше слово").foregroundColor(Theme.muted))
                .font(AppFont.title(24, .bold, relativeTo: .title2))
                .foregroundStyle(Theme.text)
                .focused($focus, equals: .word)
                .submitLabel(.done)
                .padding(.horizontal, 18)
                .frame(minHeight: 60)
                .background(RoundedRectangle(cornerRadius: 16, style: .continuous).fill(Theme.surface))
                .accessibilityLabel("Одно слово о фильме")
                .onChange(of: word) { _, newValue in
                    if newValue.count > 24 { word = String(newValue.prefix(24)) }
                }
            FlowLayout(spacing: 8, lineSpacing: 8) {
                ForEach(SurveyOptions.wordSuggestions, id: \.self) { suggestion in
                    Chip(title: suggestion, isSelected: word == suggestion, height: 44) {
                        word = suggestion
                    }
                }
            }
        }
    }

    // MARK: 8. Эссе

    private var essayStep: some View {
        VStack(alignment: .leading, spacing: 18) {
            question("Эссе", hint: "Или короткий отзыв — всё, что хочется сохранить об этом фильме. Его видите только вы.")
            ZStack(alignment: .topLeading) {
                TextEditor(text: $essay)
                    .font(AppFont.ui(17))
                    .foregroundStyle(Theme.text)
                    .scrollContentBackground(.hidden)
                    .focused($focus, equals: .essay)
                    .padding(12)
                    .frame(minHeight: 240)
                    .accessibilityLabel("Эссе о фильме")
                if essay.isEmpty {
                    Text("Начните с любой мысли…")
                        .font(AppFont.ui(17))
                        .foregroundStyle(Theme.muted)
                        .padding(.horizontal, 17)
                        .padding(.vertical, 20)
                        .allowsHitTesting(false)
                }
            }
            .background(RoundedRectangle(cornerRadius: 18, style: .continuous).fill(Theme.surface))

            HStack {
                Text(essayWordCount == 0 ? "Можно пропустить" : "\(essayWordCount) \(TasteProfile.plural(essayWordCount, "слово", "слова", "слов"))")
                    .font(AppFont.ui(13))
                    .foregroundStyle(Theme.muted)
                Spacer()
                if focus == .essay {
                    Button("Скрыть клавиатуру") { focus = nil }
                        .font(AppFont.ui(13, .medium))
                        .foregroundStyle(Theme.text)
                        .frame(minHeight: 44)
                }
            }

            VStack(alignment: .leading, spacing: 10) {
                groupLabel("Если не знаете, с чего начать")
                FlowLayout(spacing: 8, lineSpacing: 8) {
                    ForEach(SurveyOptions.essayPrompts, id: \.self) { prompt in
                        Chip(title: prompt, isSelected: false, height: 40) {
                            let starter = prompt + "\n"
                            essay = essay.isEmpty ? starter : essay + (essay.hasSuffix("\n") ? "\n" : "\n\n") + starter
                            focus = .essay
                        }
                    }
                }
            }
        }
    }

    private var essayWordCount: Int {
        essay.split(whereSeparator: { $0.isWhitespace || $0.isNewline }).count
    }

    // MARK: Итог

    private var resultStep: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text("Сохранено")
                .font(AppFont.ui(13, .medium))
                .foregroundStyle(Theme.accent)
            ShareCard(
                film: film,
                rating: rating,
                word: trimmedWord,
                feelings: feelingsLine,
                details: detailsLine,
                essay: essay.trimmingCharacters(in: .whitespacesAndNewlines)
            )
        }
    }

    // MARK: Нижние кнопки

    private var footer: some View {
        HStack(spacing: 10) {
            if step > 0 && step < questionCount && !(startAtEssay && step == essayStepIndex) {
                Button {
                    focus = nil
                    step -= 1
                } label: {
                    Image(systemName: "arrow.left")
                        .font(.system(size: 17, weight: .medium))
                        .foregroundStyle(Theme.text)
                        .frame(width: 52, height: 52)
                        .background(RoundedRectangle(cornerRadius: 16, style: .continuous).fill(Theme.surface))
                }
                .buttonStyle(.plain)
                .accessibilityLabel("Назад")
            }
            if step < questionCount {
                Button(step == essayStepIndex ? "Готово" : "Дальше") {
                    focus = nil
                    if step == essayStepIndex {
                        save()
                    }
                    step += 1
                }
                .buttonStyle(PrimaryButtonStyle())
            } else {
                if let shareImage {
                    ShareLink(
                        item: shareImage,
                        preview: SharePreview("«\(film.title)» в ance", image: shareImage)
                    ) {
                        Text("Поделиться")
                    }
                    .buttonStyle(PrimaryButtonStyle())
                }
                Button("Закрыть") { dismiss() }
                    .buttonStyle(SecondaryButtonStyle())
            }
        }
        .padding(.horizontal, 20)
        .padding(.top, 10)
        .padding(.bottom, 12)
    }

    // MARK: Логика

    private var trimmedWord: String {
        word.trimmingCharacters(in: .whitespacesAndNewlines)
    }

    private var feelingsLine: String {
        SurveyOptions.titles(for: Array(emotions), in: SurveyOptions.emotions).joined(separator: " · ")
    }

    private var detailsLine: String {
        var parts: [String] = []
        if let r = SurveyOptions.rewatchShort[rewatch] { parts.append(r) }
        if let e = SurveyOptions.title(for: ending, in: SurveyOptions.endings) { parts.append(e) }
        let rec = SurveyOptions.titles(for: Array(recommend), in: SurveyOptions.recommend)
        if !rec.isEmpty {
            if recommend.contains("none") {
                parts.append("Никому не посоветую")
            } else {
                parts.append("Посоветую: " + rec.map { $0.lowercased() }.joined(separator: ", "))
            }
        }
        return parts.joined(separator: " · ")
    }

    private func toggle(_ id: String, in set: inout Set<String>) {
        if set.contains(id) { set.remove(id) } else { set.insert(id) }
    }

    private func loadExisting() {
        guard !didLoad else { return }
        didLoad = true
        if let existing = CollectionActions.survey(for: film.id, in: context) {
            rating = existing.rating
            emotions = Set(existing.emotions)
            var loadedAspects = existing.aspectValues()
            if loadedAspects.isEmpty {
                for hook in existing.hooks {
                    if let aspect = SurveyOptions.legacyHookToAspect[hook] { loadedAspects[aspect] = 5 }
                }
            }
            aspects = loadedAspects
            scales = existing.scaleValues()
            ending = existing.ending
            company = existing.company
            place = existing.place
            rewatch = existing.rewatch
            recommend = Set(existing.recommend)
            word = existing.word
            essay = existing.essay
        }
        if startAtEssay { step = essayStepIndex }
    }

    private func save() {
        let entry = CollectionActions.survey(for: film.id, in: context) ?? {
            let created = SurveyEntry(filmID: film.id)
            context.insert(created)
            return created
        }()
        entry.date = Date()
        entry.rating = rating
        entry.emotions = SurveyOptions.emotions.map(\.id).filter { emotions.contains($0) }
        entry.setAspects(aspects.filter { $0.value > 0 })
        entry.setScales(scales)
        entry.ending = ending
        entry.company = company
        entry.place = place
        entry.rewatch = rewatch
        entry.recommend = SurveyOptions.recommend.map(\.id).filter { recommend.contains($0) }
        entry.word = trimmedWord
        entry.essay = essay.trimmingCharacters(in: .whitespacesAndNewlines)
        // Если фильм ещё не отмечен как просмотренный — отмечаем.
        if CollectionActions.item(for: film.id, in: context)?.status != .seen {
            CollectionActions.setStatus(.seen, for: film.id, in: context)
        }
        try? context.save()
        renderShareImage()
    }

    private func renderShareImage() {
        let card = ShareCard(
            film: film,
            rating: rating,
            word: trimmedWord,
            feelings: feelingsLine,
            details: detailsLine,
            essay: essay.trimmingCharacters(in: .whitespacesAndNewlines),
            forExport: true
        )
        .frame(width: 360)
        .padding(24)
        .background(Color.black)
        let renderer = ImageRenderer(content: card)
        renderer.scale = 3
        if let uiImage = renderer.uiImage {
            shareImage = Image(uiImage: uiImage)
        }
    }
}

/// Карточка отзыва — показывается в приложении и отправляется в соцсети картинкой.
struct ShareCard: View {
    let film: FilmItem
    let rating: Int
    let word: String
    let feelings: String
    let details: String
    let essay: String
    var forExport = false

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            HStack(alignment: .top, spacing: 16) {
                CoverView(film: film, cornerRadius: 10)
                    .frame(width: 92)
                VStack(alignment: .leading, spacing: 5) {
                    Text(film.title)
                        .font(AppFont.uiFixed(17, .bold))
                        .foregroundStyle(Theme.text)
                        .fixedSize(horizontal: false, vertical: true)
                    if !film.shortMeta.isEmpty {
                        Text(film.shortMeta)
                            .font(AppFont.uiFixed(13))
                            .foregroundStyle(Theme.muted)
                    }
                    Spacer(minLength: 8)
                    if rating > 0 {
                        HStack(alignment: .firstTextBaseline, spacing: 3) {
                            Text("\(rating)")
                                .font(AppFont.uiFixed(34, .bold))
                                .foregroundStyle(Theme.text)
                            Text("/10")
                                .font(AppFont.uiFixed(15, .medium))
                                .foregroundStyle(Theme.muted)
                        }
                    }
                }
                Spacer(minLength: 0)
            }
            .padding(18)

            VStack(alignment: .leading, spacing: 12) {
                if !word.isEmpty {
                    Text(word)
                        .font(AppFont.uiFixed(36, .bold))
                        .tracking(-0.8)
                        .foregroundStyle(Theme.accent)
                        .fixedSize(horizontal: false, vertical: true)
                }
                if !feelings.isEmpty {
                    Text(feelings)
                        .font(AppFont.uiFixed(15))
                        .foregroundStyle(Theme.textSecondary)
                        .fixedSize(horizontal: false, vertical: true)
                }
                if !details.isEmpty {
                    Text(details)
                        .font(AppFont.uiFixed(14))
                        .foregroundStyle(Theme.muted)
                        .fixedSize(horizontal: false, vertical: true)
                }
                if !essay.isEmpty {
                    Text(essay)
                        .font(AppFont.uiFixed(15))
                        .foregroundStyle(Theme.text)
                        .lineLimit(forExport ? 6 : 4)
                        .lineSpacing(2)
                        .fixedSize(horizontal: false, vertical: true)
                        .padding(.top, 4)
                }
                HStack {
                    AnceLogo(size: 15)
                    Spacer()
                    Text("дневник кино")
                        .font(AppFont.uiFixed(13))
                        .foregroundStyle(Theme.muted)
                }
                .padding(.top, 8)
            }
            .padding(.horizontal, 18)
            .padding(.bottom, 18)
        }
        .background(RoundedRectangle(cornerRadius: 22, style: .continuous).fill(Theme.surface))
    }
}
