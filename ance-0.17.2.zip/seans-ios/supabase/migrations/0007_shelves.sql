-- ance: отметка «Не хочу», сериалы и подборки «Вселенной» по виду (фильмы, сериалы, мультфильмы).
-- Вставить целиком в SQL Editor и нажать Run. Можно запускать повторно. Требует 0001–0006.

-- ───────────────────────── «Не хочу» ─────────────────────────
-- У фильма в коллекции теперь три отметки: хочу, посмотрел, не хочу.
alter table public.collection_items drop constraint if exists collection_items_status_check;
alter table public.collection_items
    add constraint collection_items_status_check check (status in ('want', 'seen', 'skip'));

-- ───────────────────────── Подборки по виду ─────────────────────────
-- Вид фильма (kind): movie — фильм, tv-series — сериал, cartoon и anime — мультфильмы.
create index if not exists films_kind_votes on public.films (kind, votes_kp desc);

-- Фильтр «Вселенной» с новым условием «вид». Старую версию убираем, чтобы не было двух одинаковых имён.
drop function if exists public.filter_films(text[], text[], text[], text[], int[], text, int, int, int);

create or replace function public.filter_films(
    genres text[] default '{}',
    any_genres text[] default '{}',
    countries text[] default '{}',
    exclude_countries text[] default '{}',
    decades int[] default '{}',
    director text default '',
    kinds text[] default '{}',
    min_votes int default 0,
    lim int default 60,
    skip int default 0)
returns setof public.films
language sql stable as $$
    select f.* from public.films f
    where (cardinality(filter_films.genres) = 0 or f.genres && filter_films.genres)
      and (cardinality(any_genres) = 0 or f.genres && any_genres)
      and (cardinality(filter_films.countries) = 0 or f.countries && filter_films.countries)
      and (cardinality(exclude_countries) = 0 or not (f.countries && exclude_countries))
      and (cardinality(decades) = 0 or (case when f.year < 1950 then 0 else (f.year / 10) * 10 end) = any(decades))
      and (coalesce(trim(director), '') = '' or exists (
            select 1 from unnest(f.directors) d where d ilike '%' || trim(filter_films.director) || '%'))
      and (cardinality(kinds) = 0 or f.kind = any(kinds))
      and f.votes_kp >= min_votes
    order by f.votes_kp desc
    limit lim offset skip;
$$;

revoke execute on function public.filter_films(text[], text[], text[], text[], int[], text, text[], int, int, int) from public, anon;
grant execute on function public.filter_films(text[], text[], text[], text[], int[], text, text[], int, int, int) to authenticated;

select 'Готово: «Не хочу» и подборки по виду' as "Результат";
