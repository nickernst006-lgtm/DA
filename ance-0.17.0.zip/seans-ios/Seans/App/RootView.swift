import SwiftUI
import SwiftData

enum AppTab: String, CaseIterable, Identifiable {
    case universe, collection, taste, friends

    var id: String { rawValue }

    var title: String {
        switch self {
        case .universe: return "Вселенная"
        case .collection: return "Коллекция"
        case .taste: return "Вкусы"
        case .friends: return "Профиль"
        }
    }
}

struct RootView: View {
    @AppStorage("didFinishWelcome") private var didFinishWelcome = false
    @Environment(Server.self) private var server
    @State private var showSplash = true

    var body: some View {
        ZStack {
            Theme.background.ignoresSafeArea()

            if !server.isSignedIn {
                LoginView()
                    .transition(.opacity)
            } else if didFinishWelcome {
                MainTabsView()
            } else {
                WelcomeView {
                    withAnimation(.easeInOut(duration: 0.35)) { didFinishWelcome = true }
                }
            }

            if showSplash {
                SplashView()
                    .transition(.opacity)
                    .zIndex(1)
            }
        }
        .animation(.easeInOut(duration: 0.35), value: server.isSignedIn)
        .task {
            // Заставка держится, пока точка не допрыгает до «а», и ещё полсекунды.
            try? await Task.sleep(nanoseconds: UInt64((AnceMark.duration + 0.5) * 1_000_000_000))
            withAnimation(.easeInOut(duration: 0.5)) { showSplash = false }
        }
    }
}

/// Четыре вкладки и док внизу — как на экране «Домой» iPhone.
struct MainTabsView: View {
    @Query private var collectionItems: [CollectionItem]
    @Environment(Social.self) private var social
    @Environment(SyncEngine.self) private var sync
    @Environment(Server.self) private var server
    @Environment(\.modelContext) private var context
    @Environment(\.scenePhase) private var scenePhase
    @State private var pendingSync: Task<Void, Never>?
    @State private var tab: AppTab = .universe

    /// Отметки «Хочу», «Не хочу», «Просмотрено» — для значков на обложках во всём приложении.
    private var statusMap: [String: CollectionStatus] {
        var map: [String: CollectionStatus] = [:]
        for item in collectionItems { map[item.filmID] = item.status }
        return map
    }

    var body: some View {
        ZStack {
            // Страницы — с учётом клавиатуры: при поиске содержимое поднимается над ней.
            GeometryReader { proxy in
                ZStack {
                    AfishaView()
                        .opacity(tab == .universe ? 1 : 0)
                        .allowsHitTesting(tab == .universe)
                        .accessibilityHidden(tab != .universe)
                    CollectionView(onBrowse: { tab = .universe })
                        .opacity(tab == .collection ? 1 : 0)
                        .allowsHitTesting(tab == .collection)
                        .accessibilityHidden(tab != .collection)
                    TasteView()
                        .opacity(tab == .taste ? 1 : 0)
                        .allowsHitTesting(tab == .taste)
                        .accessibilityHidden(tab != .taste)
                    ProfileView()
                        .opacity(tab == .friends ? 1 : 0)
                        .allowsHitTesting(tab == .friends)
                        .accessibilityHidden(tab != .friends)
                }
                // Сколько места снизу оставить страницам, чтобы конец текста можно было
                // долистать до видимой области над доком (плюс немного воздуха).
                // Когда открыта клавиатура, док под ней — запас становится минимальным.
                .environment(\.dockClearance,
                             DockMetrics(screenWidth: proxy.size.width).clearance(safeBottom: proxy.safeAreaInsets.bottom))
            }

            // Док — отдельным слоем, который клавиатуру не учитывает:
            // при поиске клавиатура закрывает его, как у системных приложений, а не поднимает.
            GeometryReader { proxy in
                let metrics = DockMetrics(screenWidth: proxy.size.width)
                DockBar(selection: $tab, metrics: metrics, badge: social.incoming.count)
                    // Как у iPhone: от дока до нижнего края экрана столько же, сколько до боковых (17,3 pt).
                    // Слой стоит внутри безопасной зоны, поэтому её высоту вычитаем:
                    // отрицательный отступ опускает док в зону полоски «Домой», как у системного дока.
                    .padding(.bottom, metrics.margin - proxy.safeAreaInsets.bottom)
                    .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .bottom)
            }
            .ignoresSafeArea(.keyboard, edges: .bottom)
        }
        .environment(\.filmStatuses, statusMap)
        .background(Theme.background.ignoresSafeArea())
        // Профиль, заявки и синхронизация — при запуске, при возвращении в приложение и при уходе из него.
        .task {
            SyncEngine.purgeLegacy(context)
            if let covers = try? await server.coverOverrides() { CoverOverrides.update(covers) }
            await social.load()
            await sync.sync(context)
        }
        .onChange(of: scenePhase) { _, phase in
            switch phase {
            case .active: Task { await social.load(); await sync.sync(context) }
            case .background: Task { await sync.sync(context) }
            default: break
            }
        }
        // Любое изменение на телефоне уходит на сервер через пару секунд после последней правки.
        .onReceive(NotificationCenter.default.publisher(for: ModelContext.didSave)) { _ in
            guard !sync.isApplying else { return }
            pendingSync?.cancel()
            pendingSync = Task {
                try? await Task.sleep(nanoseconds: 2_000_000_000)
                guard !Task.isCancelled else { return }
                await sync.sync(context)
            }
        }
    }
}

/// Место под доком внизу прокручиваемых страниц — задаётся в MainTabsView.
private struct DockClearanceKey: EnvironmentKey {
    static let defaultValue: CGFloat = 0
}

extension EnvironmentValues {
    var dockClearance: CGFloat {
        get { self[DockClearanceKey.self] }
        set { self[DockClearanceKey.self] = newValue }
    }
}

/// Прокручиваемая страница во вкладке: конец можно долистать до видимой области над доком.
private struct DockClearanceModifier: ViewModifier {
    @Environment(\.dockClearance) private var clearance
    func body(content: Content) -> some View {
        content.safeAreaPadding(.bottom, clearance)
    }
}

extension View {
    func dockClearance() -> some View { modifier(DockClearanceModifier()) }
}

/// Размеры дока iPhone, снятые со скриншота домашнего экрана iPhone
/// (экран 440 pt): отступ от краёв экрана 17,3 pt — и по бокам, и снизу;
/// высота дока 116,7 pt, скругление 36,7 pt; иконка 68 pt со скруглением 17,7 pt;
/// от края дока до иконки 24,3 pt. На других экранах всё масштабируется по ширине.
struct DockMetrics {
    let screenWidth: CGFloat

    private var k: CGFloat { screenWidth / 440 }
    var margin: CGFloat { 17.33 * k }
    var height: CGFloat { 116.67 * k }
    var cornerRadius: CGFloat { 36.67 * k }
    var inset: CGFloat { 24.33 * k }
    var icon: CGFloat { 68 * k }
    var iconRadius: CGFloat { 17.67 * k }
    /// Сколько места оставить внизу прокручиваемой страницы над безопасной зоной:
    /// док с отступом от края экрана и ещё 24 pt воздуха.
    func clearance(safeBottom: CGFloat) -> CGFloat {
        max(0, margin + height - safeBottom) + 24
    }
    /// Расстояние между иконками — то, что остаётся, поровну.
    var spacing: CGFloat {
        let dockWidth = screenWidth - margin * 2
        return max(0, (dockWidth - inset * 2 - icon * CGFloat(AppTab.allCases.count)) / CGFloat(AppTab.allCases.count - 1))
    }
}

/// Док: точь-в-точь как док iPhone — та же плашка, тот же размер
/// и то же положение четырёх иконок-«приложений».
struct DockBar: View {
    @Binding var selection: AppTab
    let metrics: DockMetrics
    /// Заявки в друзья — жёлтый кружок с числом в правом верхнем углу иконки «Профиль».
    var badge: Int = 0

    var body: some View {
        HStack(spacing: metrics.spacing) {
            ForEach(AppTab.allCases) { tab in
                let isSelected = tab == selection
                let tile = isSelected ? Theme.text : Theme.dockButton
                Button {
                    selection = tab
                } label: {
                    TabIcon(tab: tab, iconSize: metrics.icon)
                        .foregroundStyle(isSelected ? Color.black : Theme.textSecondary)
                        .frame(width: metrics.icon, height: metrics.icon)
                        .background(
                            RoundedRectangle(cornerRadius: metrics.iconRadius, style: .circular)
                                .fill(tile)
                        )
                        .contentShape(Rectangle())
                        .overlay(alignment: .topTrailing) {
                            if tab == .friends && badge > 0 {
                                Text("\(badge)")
                                    .font(.system(size: 14, weight: .bold))
                                    .monospacedDigit()
                                    .foregroundStyle(Color.black)
                                    .padding(.horizontal, 6)
                                    .frame(minWidth: 24, minHeight: 24)
                                    .background(Capsule().fill(Theme.accent))
                                    .offset(x: 6, y: -6)
                                    .transition(.scale.combined(with: .opacity))
                            }
                        }
                }
                .buttonStyle(.plain)
                .accessibilityLabel(tab == .friends && badge > 0 ? "\(tab.title), заявок: \(badge)" : tab.title)
                .accessibilityAddTraits(isSelected ? .isSelected : [])
            }
        }
        .padding(.horizontal, metrics.inset)
        .frame(width: metrics.screenWidth - metrics.margin * 2, height: metrics.height)
        .background(
            RoundedRectangle(cornerRadius: metrics.cornerRadius, style: .circular)
                .fill(.ultraThinMaterial)
        )
        .overlay(
            RoundedRectangle(cornerRadius: metrics.cornerRadius, style: .circular)
                .stroke(Color.white.opacity(0.08), lineWidth: 1)
        )
        .frame(maxWidth: .infinity)
        .environment(\.colorScheme, .dark)
        .sensoryFeedback(.selection, trigger: selection)
    }
}

/// Значки вкладок — все из системного набора Apple, в одном стиле (заливка)
/// и в одинаковом квадрате, чтобы выглядели одного размера.
struct TabIcon: View {
    let tab: AppTab
    let iconSize: CGFloat

    private var symbol: String {
        switch tab {
        case .universe: return "" // не используется — рисуем MoonIcon
        case .collection: return "rectangle.stack.fill"
        case .taste: return "sparkle"
        case .friends: return "person.fill"
        }
    }

    /// Значок — половина иконки; звезда визуально мельче остальных — ей чуть больше места.
    private var side: CGFloat {
        (iconSize * (tab == .taste ? 0.5625 : 0.5)).rounded()
    }

    var body: some View {
        if tab == .universe {
            MoonIcon(size: (iconSize * 0.56).rounded())
        } else {
            Image(systemName: symbol)
                .resizable()
                .scaledToFit()
                .frame(width: side, height: side)
        }
    }
}

/// Заставка: жёлтая точка выпрыгивает справа и скачет по буквам «ance» до «а».
struct SplashView: View {
    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()
            AnceSplashMark()
        }
    }
}

/// Иконка «Вселенная» — заполненный круг (луна): два кратера внутри и две вмятины по краю,
/// вырезанные насквозь, поэтому сквозь них виден фон иконки.
struct MoonIcon: View {
    let size: CGFloat

    // Кратеры: смещение (x, y) от центра и радиус — в долях диаметра.
    // Два кратера внутри и две вмятины по краю — силуэт становится неровным, как у луны.
    private let craters: [(CGFloat, CGFloat, CGFloat)] = [
        (-0.14,  0.12, 0.14),    // крупный левее центра
        ( 0.20, -0.10, 0.10),    // средний справа
        ( 0.46,  0.18, 0.10),    // вмятина на правом краю
        (-0.30, -0.40, 0.12),    // вмятина слева вверху
    ]

    var body: some View {
        Canvas { ctx, _ in
            let r = size / 2
            let c = CGPoint(x: r, y: r)
            // Основной круг
            ctx.fill(Path(ellipseIn: CGRect(x: 0, y: 0, width: size, height: size)),
                     with: .foreground)
            // Кратеры цвета фона — вырезаем через blendMode
            ctx.blendMode = .destinationOut
            for (dx, dy, kr) in craters {
                let cx = c.x + dx * size
                let cy = c.y + dy * size
                let d = kr * size * 2
                ctx.fill(Path(ellipseIn: CGRect(x: cx - kr * size, y: cy - kr * size,
                                                width: d, height: d)),
                         with: .foreground)
            }
        }
        .frame(width: size, height: size)
        .compositingGroup()
    }
}

/// Первый запуск.
struct WelcomeView: View {
    let onStart: () -> Void

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            Spacer()
            HStack(spacing: -24) {
                CoverView(film: WelcomeView.sample[0]).frame(width: 108).rotationEffect(.degrees(-7))
                CoverView(film: WelcomeView.sample[1]).frame(width: 132).zIndex(1)
                    .overlay(RoundedRectangle(cornerRadius: Radius.medium, style: .continuous).stroke(Color.black, lineWidth: 6))
                CoverView(film: WelcomeView.sample[2]).frame(width: 108).rotationEffect(.degrees(7))
            }
            .frame(maxWidth: .infinity)
            .padding(.bottom, Space.s48)

            VStack(alignment: .leading, spacing: Space.s12) {
                AnceLogo(size: 40)
                Text("Отмечайте фильмы, рассказывайте, как они вам, — и узнавайте свой киновкус.")
                    .textStyle(.body)
                    .foregroundStyle(Theme.textSecondary)
                    .fixedSize(horizontal: false, vertical: true)
            }

            Spacer()

            Button("Начать", action: onStart)
                .buttonStyle(PrimaryButtonStyle())
                .padding(.bottom, Space.s12)
        }
        .padding(.horizontal, ScreenLayout.sideMargin)
        .background(Theme.background.ignoresSafeArea())
    }

    static let sample: [FilmItem] = [
        FilmItem(previewTitle: "Амели", year: 2001,
                 cover: CoverStyle(bg: "#8C2427", accent: "#F0BE5E", x: 0.32, y: 0.34, size: 0.48), photo: nil),
        FilmItem(previewTitle: "Сталкер", year: 1979,
                 cover: CoverStyle(bg: "#33402F", accent: "#D9C27A", x: 0.6, y: 0.4, size: 0.5), photo: nil),
        FilmItem(previewTitle: "Начало", year: 2010,
                 cover: CoverStyle(bg: "#22324A", accent: "#A9BDD3", x: 0.66, y: 0.36, size: 0.44), photo: nil)
    ]
}
