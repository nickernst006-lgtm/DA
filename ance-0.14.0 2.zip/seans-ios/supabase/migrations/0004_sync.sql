-- ance: синхронизация. Номер фильма в коллекции, анкетах и журналах — тот же, что в приложении:
-- «kp123» для фильмов библиотеки на сервере и прежние номера для встроенных фильмов.
-- Вставить целиком в SQL Editor и нажать Run. Можно запускать повторно.
-- Требует 0001–0003.

do $$
declare t text; c record;
begin
    foreach t in array array['collection_items', 'surveys', 'journal_blocks'] loop
        -- Связь с таблицей films больше не нужна: встроенных фильмов там нет.
        for c in select conname from pg_constraint
                 where conrelid = ('public.' || t)::regclass and contype = 'f'
                   and confrelid = 'public.films'::regclass loop
            execute format('alter table public.%I drop constraint %I', t, c.conname);
        end loop;
        -- bigint → text: прежние числовые номера становятся «kp…».
        if (select data_type from information_schema.columns
             where table_schema = 'public' and table_name = t and column_name = 'film_id') <> 'text' then
            execute format('alter table public.%I alter column film_id type text using ''kp'' || film_id::text', t);
        end if;
    end loop;
end $$;

-- Быстрая выборка своих строк при синхронизации и чужой коллекции на странице друга.
create index if not exists collection_items_user_idx on public.collection_items (user_id, status);
create index if not exists surveys_user_idx          on public.surveys (user_id);
create index if not exists journal_photos_user_idx   on public.journal_photos (user_id);
create index if not exists board_items_user_idx      on public.board_items (user_id);

select 'Готово: синхронизация включена' as "Результат";
