-- ance: свои обложки. Владелец заменяет обложку любого фильма — с Кинопоиска или встроенного.
-- Как: Storage → covers → загрузить картинку → скопировать её адрес (Get URL) →
--      Table Editor → cover_overrides → Insert row: film_id (номер фильма в приложении) и image_url.
-- Номер фильма: у фильмов библиотеки — «kp» и номер на Кинопоиске (kp258687), у встроенных — их id.
-- Закачка из ПоискКино эту таблицу не трогает. Вставить в SQL Editor и нажать Run; можно повторно.

create table if not exists public.cover_overrides (
    film_id    text primary key,
    image_url  text not null,
    updated_at timestamptz not null default now()
);

alter table public.cover_overrides enable row level security;
drop policy if exists "Обложки видны участникам" on public.cover_overrides;
create policy "Обложки видны участникам" on public.cover_overrides for select to authenticated using (true);
-- Менять — только владелец в панели Supabase (политик на запись нет).
revoke all on public.cover_overrides from anon, authenticated;
grant select on public.cover_overrides to authenticated;

-- Открытая корзина для картинок обложек: обложки не секретны, а так их проще вставлять ссылкой.
insert into storage.buckets (id, name, public)
values ('covers', 'covers', true)
on conflict (id) do update set public = true;

select 'Готово: свои обложки включены' as "Результат";
