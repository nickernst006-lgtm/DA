import SwiftUI
import SwiftData

@main
struct SeansApp: App {
    @State private var library = Library()
    @State private var server: Server
    @State private var social: Social
    @State private var sync: SyncEngine

    init() {
        let server = Server()
        _server = State(initialValue: server)
        _social = State(initialValue: Social(server: server))
        _sync = State(initialValue: SyncEngine(server: server))
    }

    var body: some Scene {
        WindowGroup {
            RootView()
                .environment(library)
                .environment(server)
                .environment(social)
                .environment(sync)
                .preferredColorScheme(.dark)
                .tint(Theme.text)
        }
        .modelContainer(for: [CollectionItem.self, SurveyEntry.self, CustomFilm.self, Friend.self,
                             JournalBlock.self, JournalPhoto.self, BoardItem.self])
    }
}
