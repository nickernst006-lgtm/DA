import SwiftUI
import PhotosUI
import UIKit
import CoreText

/// Куда ведут строки вкладки «Профиль».
enum ProfileRoute: Hashable {
    case settings
    case person(String)
}

/// Вкладка «Профиль»: вы и ваши друзья.
struct ProfileView: View {
    @Environment(Server.self) private var server
    @Environment(Social.self) private var social
    @State private var query = ""

    private var trimmedQuery: String { query.trimmingCharacters(in: .whitespacesAndNewlines) }

    /// Ищем по имени и по ID; «@» в начале запроса не мешает.
    private func matches(_ person: Person) -> Bool {
        var q = trimmedQuery.normalizedForSearch
        if q.hasPrefix("@") { q.removeFirst() }
        guard !q.isEmpty else { return true }
        return person.displayName.normalizedForSearch.contains(q) || (person.username ?? "").contains(q)
    }

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: ScreenLayout.blockGap) {
                    ScreenTitle("Профиль")
                        .padding(.top, Space.s12)
                    userCard
                    friendsBlock
                }
                .padding(.horizontal, ScreenLayout.sideMargin)
                .padding(.bottom, ScreenLayout.blockGap)
            }
            .dockClearance()
            .scrollDismissesKeyboard(.interactively)
            .background(Theme.background.ignoresSafeArea())
            .navigationTitle("Профиль")
            .toolbar(.hidden, for: .navigationBar)
            .refreshable { await social.load() }
            .navigationDestination(for: ProfileRoute.self) { route in
                switch route {
                case .settings: ProfileSettingsView()
                case .person(let id): PersonView(personID: id)
                }
            }
            .navigationDestination(for: FilmRoute.self) { route in
                FilmDetailView(filmID: route.id)
            }
        }
    }

    // MARK: Вы

    private var userCard: some View {
        let me = social.me
        let name = me?.name.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
        let about = me?.about.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
        return VStack(alignment: .leading, spacing: 0) {
            PersonHeader(path: me?.avatarPath, name: name.isEmpty ? "Без имени" : name, seed: server.userID ?? "",
                         handle: me?.username.map { "@" + $0 }, muted: name.isEmpty)
            if !about.isEmpty {
                Text(about)
                    .textStyle(.body)
                    .foregroundStyle(Theme.textSecondary)
                    .fixedSize(horizontal: false, vertical: true)
                    .padding(.top, Space.s12)
            }
            NavigationLink(value: ProfileRoute.settings) {
                Text(me?.username == nil ? "Придумайте ID и имя" : "Настройки профиля")
            }
            .buttonStyle(RaisedButtonStyle())
            .padding(.top, Space.s16)
        }
        .plate()
    }

    // MARK: Друзья

    private var friendsBlock: some View {
        let requests = social.incoming.filter(matches)
        let pending = social.outgoing.filter(matches)
        let friends = social.friends.filter(matches)
        let amongFriends = requests + pending + friends
        let searching = !trimmedQuery.isEmpty

        return ScreenBlock(title: "Друзья", count: social.friends.count) {
            VStack(alignment: .leading, spacing: Space.s12) {
                SearchField(text: $query, placeholder: "Имя или ID")
                if !amongFriends.isEmpty {
                    PeopleList(people: amongFriends)
                } else if searching {
                    strangerResults
                } else if social.loaded || !social.people.isEmpty {
                    GroupFooter("Найдите участника ance по имени или ID и отправьте заявку.")
                } else if social.failed {
                    GroupFooter("Нет связи. Потяните экран вниз, чтобы обновить.")
                }
            }
        }
    }

    /// Среди друзей никого — остальные участники ance с таким именем или ID.
    @ViewBuilder
    private var strangerResults: some View {
        let others = social.strangers.filter(matches)
        if others.isEmpty {
            GroupFooter("Никого не нашлось.")
        } else {
            VStack(alignment: .leading, spacing: ScreenLayout.groupLabelGap) {
                GroupLabel("Участники ance")
                PeopleList(people: others)
            }
        }
    }
}

// MARK: - Шапка человека

/// Фото 96 слева, справа имя (22/28) и ID. Одинаковая в своём профиле и на странице участника.
struct PersonHeader: View {
    let path: String?
    let name: String
    let seed: String
    var handle: String?
    var muted = false

    var body: some View {
        HStack(alignment: .center, spacing: Space.s16) {
            AvatarView(path: path, name: muted ? "" : name, seed: seed, size: 96)
            VStack(alignment: .leading, spacing: 0) {
                Text(name)
                    .textStyle(.h2)
                    .foregroundStyle(muted ? Theme.muted : Theme.text)
                    .lineLimit(2)
                if let handle {
                    Text(handle)
                        .textStyle(.sub)
                        .foregroundStyle(Theme.muted)
                        .lineLimit(1)
                }
            }
            Spacer(minLength: 0)
        }
    }
}

// MARK: - Строки

/// Список людей одной плашкой. Заявки вам — со своими кнопками.
private struct PeopleList: View {
    let people: [Person]

    var body: some View {
        RowGroup {
            ForEach(Array(people.enumerated()), id: \.element.id) { index, person in
                if index > 0 {
                    RowDivider(inset: ScreenLayout.textInset + Space.s48 + Space.s12)
                }
                if person.relation == .incoming {
                    RequestRow(person: person)
                } else {
                    PersonRow(person: person)
                }
            }
        }
    }
}

/// Фото и имя; нажатие — страница участника.
private struct PersonLabel: View {
    let person: Person
    var caption: String? = nil

    var body: some View {
        NavigationLink(value: ProfileRoute.person(person.id)) {
            HStack(spacing: Space.s12) {
                AvatarView(path: person.avatarPath, name: person.name, seed: person.id, size: Space.s48)
                VStack(alignment: .leading, spacing: 0) {
                    Text(person.displayName)
                        .textStyle(.body, .bold)
                        .foregroundStyle(Theme.text)
                        .lineLimit(1)
                    if let caption {
                        Text(caption)
                            .textStyle(.caption)
                            .foregroundStyle(Theme.muted)
                            .lineLimit(1)
                    }
                }
                Spacer(minLength: 0)
            }
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
    }
}

private struct PersonRow: View {
    @Environment(Social.self) private var social
    let person: Person

    var body: some View {
        HStack(spacing: Space.s12) {
            // ID — у незнакомцев в поиске, чтобы различать одинаковые имена.
            PersonLabel(person: person, caption: person.relation == .none ? person.handle : nil)
            switch person.relation {
            case .friend:
                Image(systemName: "chevron.right")
                    .font(.system(size: 14, weight: .semibold))
                    .foregroundStyle(Theme.muted)
                    .accessibilityHidden(true)
            case .outgoing:
                StatusPill(text: "На рассмотрении")
            case .incoming:
                StatusPill(text: "Заявка")
            case .none:
                Button {
                    Task { await social.sendRequest(to: person) }
                } label: {
                    if social.busy.contains(person.id) {
                        ProgressView().tint(Color.black)
                    } else {
                        Label("Добавить", systemImage: "plus")
                    }
                }
                .buttonStyle(SmallButtonStyle(kind: .accent))
                .disabled(social.busy.contains(person.id))
            }
        }
        .padding(.horizontal, ScreenLayout.textInset)
        .frame(minHeight: ScreenLayout.personRowHeight)
    }
}

/// Заявка вам: принять или отклонить прямо в строке.
private struct RequestRow: View {
    @Environment(Social.self) private var social
    let person: Person

    var body: some View {
        let busy = social.busy.contains(person.id)
        HStack(spacing: Space.s8) {
            PersonLabel(person: person, caption: "Заявка в друзья")
            if busy {
                ProgressView().tint(Theme.muted)
            } else {
                Button {
                    Task { await social.respond(to: person, accept: false) }
                } label: {
                    Image(systemName: "xmark")
                        .font(.system(size: 13, weight: .bold))
                }
                .buttonStyle(SmallButtonStyle(kind: .plain, square: true))
                .accessibilityLabel("Отклонить заявку")
                Button("Принять") {
                    Task { await social.respond(to: person, accept: true) }
                }
                .buttonStyle(SmallButtonStyle(kind: .white))
            }
        }
        .padding(.horizontal, ScreenLayout.textInset)
        .frame(minHeight: ScreenLayout.personRowHeight)
    }
}

private struct StatusPill: View {
    let text: String

    var body: some View {
        Text(text)
            .textStyle(.caption, .bold)
            .foregroundStyle(Theme.accent)
            .lineLimit(1)
            .padding(.horizontal, Space.s8)
            .frame(height: 28)
            .background(RoundedRectangle(cornerRadius: Radius.small, style: .continuous).fill(Theme.accent.opacity(0.16)))
    }
}

/// Малая кнопка в строке списка: капсула 36.
struct SmallButtonStyle: ButtonStyle {
    enum Kind { case white, accent, plain }
    var kind: Kind
    var square = false

    func makeBody(configuration: Configuration) -> some View {
        let fill: Color = switch kind {
        case .white: Theme.text
        case .accent: Theme.accent
        case .plain: Theme.dockButton
        }
        return configuration.label
            .textStyle(.sub, .bold)
            .foregroundStyle(kind == .plain ? Theme.textSecondary : Color.black)
            .padding(.horizontal, square ? 0 : Space.s12)
            .frame(width: square ? 36 : nil, height: 36)
            .background(Capsule().fill(fill.opacity(configuration.isPressed ? 0.8 : 1)))
            .touchArea()
    }
}

// MARK: - Фото профиля

/// Круглое фото. Пока фото нет — первая буква имени на цветном круге.
struct AvatarView: View {
    @Environment(Server.self) private var server
    let path: String?
    let name: String
    /// Из чего выбирается цвет круга без фото (id участника).
    let seed: String
    let size: CGFloat

    @State private var loaded: (path: String, image: UIImage)?

    private var image: UIImage? {
        guard let path else { return nil }
        if let loaded, loaded.path == path { return loaded.image }
        return AvatarCache.cached(path)
    }

    private var letter: String {
        name.trimmingCharacters(in: .whitespacesAndNewlines).first.map { String($0).uppercased() } ?? ""
    }

    private var color: Color {
        var hash: UInt64 = 1469598103934665603
        for byte in seed.utf8 { hash = (hash ^ UInt64(byte)) &* 1099511628211 }
        return Color(hex: StickerPalette.color(Int(hash % 5)))
    }

    var body: some View {
        ZStack {
            if let image {
                Image(uiImage: image)
                    .resizable()
                    .scaledToFill()
            } else {
                color
                if letter.isEmpty {
                    Image(systemName: "person.fill")
                        .font(.system(size: size * 0.42))
                        .foregroundStyle(Color.black.opacity(0.75))
                } else {
                    Text(letter)
                        .font(.system(size: size * 0.4, weight: .bold))
                        .foregroundStyle(Color.black.opacity(0.85))
                }
            }
        }
        .frame(width: size, height: size)
        .clipShape(Circle())
        .accessibilityHidden(true)
        .task(id: path) {
            guard let path, AvatarCache.cached(path) == nil else { return }
            if let image = await AvatarCache.load(path, server: server) {
                loaded = (path, image)
            }
        }
    }
}

// MARK: - Страница участника

/// Страница друга или участника: шапка, действия и полки с фильмами, если человек их показывает.
struct PersonView: View {
    @Environment(Server.self) private var server
    @Environment(Social.self) private var social
    @Environment(Library.self) private var library
    let personID: String

    @State private var seen: [FilmItem] = []
    @State private var want: [FilmItem] = []
    @State private var confirmRemove = false

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: ScreenLayout.blockGap) {
                if let person = social.person(personID) {
                    ScreenTitle(person.relation == .friend ? "Друзья" : "Участники")
                        .padding(.top, ScreenLayout.pushedTitleTop)
                    header(person)
                    if person.seesCollection {
                        if !seen.isEmpty {
                            ScreenBlock(title: "Посмотрено", count: seen.count) { PosterShelf(films: seen) }
                        }
                        if !want.isEmpty {
                            ScreenBlock(title: "Хочет посмотреть", count: want.count) { PosterShelf(films: want) }
                        }
                    }
                }
            }
            .padding(.horizontal, ScreenLayout.sideMargin)
            .padding(.bottom, ScreenLayout.blockGap)
        }
        .dockClearance()
        .background(Theme.background.ignoresSafeArea())
        .pushedPage()
        .toolbar {
            if social.person(personID)?.relation == .friend {
                ToolbarItem(placement: .topBarTrailing) {
                    Menu {
                        Button("Удалить из друзей", role: .destructive) { confirmRemove = true }
                    } label: {
                        Image(systemName: "ellipsis")
                            .foregroundStyle(Theme.text)
                    }
                    .accessibilityLabel("Ещё")
                }
            }
        }
        .task(id: social.person(personID)?.seesCollection) { await loadCollection() }
        .confirmationDialog("Удалить из друзей?", isPresented: $confirmRemove, titleVisibility: .visible) {
            Button("Удалить", role: .destructive) {
                if let person = social.person(personID) {
                    Task { await social.remove(person) }
                }
            }
            Button("Отмена", role: .cancel) {}
        } message: {
            Text("Вы перестанете видеть то, что этот человек показывает только друзьям. Он тоже.")
        }
    }

    private func header(_ person: Person) -> some View {
        let about = person.about.trimmingCharacters(in: .whitespacesAndNewlines)
        return VStack(alignment: .leading, spacing: 0) {
            PersonHeader(path: person.avatarPath, name: person.displayName, seed: person.id, handle: person.handle)
            if !about.isEmpty {
                Text(about)
                    .textStyle(.body)
                    .foregroundStyle(Theme.textSecondary)
                    .fixedSize(horizontal: false, vertical: true)
                    .padding(.top, Space.s12)
            }
            actions(person)
        }
        .plate()
    }

    @ViewBuilder
    private func actions(_ person: Person) -> some View {
        let busy = social.busy.contains(person.id)
        switch person.relation {
        case .friend:
            EmptyView()
        case .none:
            Button {
                Task { await social.sendRequest(to: person) }
            } label: {
                if busy { ProgressView().tint(Color.black) } else { Label("Добавить в друзья", systemImage: "plus") }
            }
            .buttonStyle(PrimaryButtonStyle())
            .disabled(busy)
            .padding(.top, Space.s16)
        case .outgoing:
            Button("Отменить заявку") {
                Task { await social.remove(person) }
            }
            .buttonStyle(RaisedButtonStyle())
            .disabled(busy)
            .padding(.top, Space.s16)
        case .incoming:
            HStack(spacing: Space.s8) {
                Button("Отклонить") {
                    Task { await social.respond(to: person, accept: false) }
                }
                .buttonStyle(RaisedButtonStyle())
                Button("Принять") {
                    Task { await social.respond(to: person, accept: true) }
                }
                .buttonStyle(PrimaryButtonStyle())
            }
            .disabled(busy)
            .padding(.top, Space.s16)
        }
    }

    /// Коллекция человека: фильмы встроенной базы — с телефона, фильмы библиотеки — с сервера.
    private func loadCollection() async {
        guard let person = social.person(personID), person.seesCollection,
              let data = try? await server.collection(of: person.id),
              let rows = try? SyncCoding.decoder.decode([CollectionRow].self, from: data) else {
            seen = []
            want = []
            return
        }
        let missing = rows.compactMap { row -> Int? in
            guard library.film(id: row.filmId) == nil, row.filmId.hasPrefix("kp") else { return nil }
            return Int(row.filmId.dropFirst(2))
        }
        if !missing.isEmpty, let films = try? await server.films(ids: missing) {
            library.remember(films)
        }
        seen = rows.filter { $0.status == "seen" }
            .sorted { ($0.seenAt ?? $0.addedAt) > ($1.seenAt ?? $1.addedAt) }
            .compactMap { library.film(id: $0.filmId) }
        want = rows.filter { $0.status == "want" }.compactMap { library.film(id: $0.filmId) }
    }
}

/// Лента постеров: плитки 112, шаг 12, от края экрана до края.
struct PosterShelf: View {
    let films: [FilmItem]

    var body: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            LazyHStack(alignment: .top, spacing: Space.s12) {
                ForEach(films) { film in
                    NavigationLink(value: FilmRoute(id: film.id)) {
                        FilmTile(film: film, subtitle: film.year.map(String.init), compact: true)
                            .frame(width: 112)
                    }
                    .buttonStyle(.plain)
                }
            }
            .padding(.horizontal, ScreenLayout.sideMargin)
        }
        .padding(.horizontal, -ScreenLayout.sideMargin)
    }
}

// MARK: - Настройки профиля

/// Фото, имя, ID, «О себе», почта, пароль, видимость и выход.
struct ProfileSettingsView: View {
    @Environment(Server.self) private var server
    @Environment(Social.self) private var social
    @Environment(SyncEngine.self) private var sync
    @Environment(\.modelContext) private var context
    @Environment(\.dismiss) private var dismiss

    @State private var name = ""
    @State private var username = ""
    @State private var usernameStatus: UsernameStatus = .unchanged
    @State private var about = ""
    @State private var didLoad = false
    @State private var photo: PhotosPickerItem?
    @State private var showEmail = false
    @State private var showPassword = false
    @State private var confirmSignOut = false
    @State private var signingOut = false
    @State private var signOutFailed = false
    @State private var error: String?

    static let aboutLimit = 250

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: ScreenLayout.blockGap) {
                ScreenTitle("Настройки")
                    .padding(.top, ScreenLayout.pushedTitleTop)

                photoPlate

                FormGroup(label: "Профиль",
                          footer: "Строчные латинские буквы и цифры, от 3 до 20 знаков") {
                    InputRow(title: "Имя") {
                        TextField("", text: $name, prompt: Text("Как вас зовут").foregroundColor(Theme.muted))
                            .textContentType(.name)
                            .submitLabel(.done)
                    }
                    RowDivider()
                    InputRow(title: "ID") {
                        HStack(spacing: 0) {
                            Spacer(minLength: 0)
                            Text("@").foregroundStyle(Theme.muted)
                            TextField("", text: $username, prompt: Text("придумайте").foregroundColor(Theme.muted))
                                .textInputAutocapitalization(.never)
                                .autocorrectionDisabled()
                                .keyboardType(.asciiCapable)
                                .textContentType(.username)
                                .fixedSize()
                        }
                    } accessory: {
                        usernameBadge
                    }
                }

                aboutGroup

                if let error {
                    GroupFooter(error, color: Theme.accent)
                }

                FormGroup(label: "Вход") {
                    ValueRow(title: "Почта", value: server.email ?? "") { showEmail = true }
                    RowDivider()
                    ValueRow(title: "Пароль", value: "Сменить") { showPassword = true }
                }

                FormGroup(label: "Что видят друзья") {
                    toggle("О себе", \.friendsAbout, "friends_about")
                    RowDivider()
                    toggle("Коллекция и оценки", \.shareCollection, "share_collection")
                    RowDivider()
                    toggle("Анкеты и эссе", \.shareJournal, "share_journal")
                }

                FormGroup(label: "Что видят незнакомцы") {
                    toggle("О себе", \.strangersAbout, "strangers_about")
                    RowDivider()
                    toggle("Коллекция и оценки", \.strangersCollection, "strangers_collection")
                    RowDivider()
                    toggle("Анкеты и эссе", \.strangersJournal, "strangers_journal")
                }

                RowGroup {
                    if signingOut {
                        ProgressView().tint(Theme.muted).frame(maxWidth: .infinity, minHeight: ScreenLayout.rowHeight)
                    } else {
                        DestructiveRow(title: "Выйти из аккаунта") { confirmSignOut = true }
                    }
                }
            }
            .padding(.horizontal, ScreenLayout.sideMargin)
            .padding(.bottom, ScreenLayout.blockGap)
        }
        .dockClearance()
        .scrollDismissesKeyboard(.interactively)
        .background(Theme.background.ignoresSafeArea())
        .pushedPage()
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                Button("Готово") {
                    Task { if await saveText() { dismiss() } }
                }
                .fontWeight(.bold)
                .foregroundStyle(Theme.accent)
            }
        }
        .onAppear {
            guard !didLoad else { return }
            name = social.me?.name ?? ""
            username = social.me?.username ?? ""
            about = social.me?.about ?? ""
            didLoad = true
        }
        .onDisappear {
            Task { _ = await saveText() }
        }
        .onChange(of: username) { _, value in
            let clean = Username.clean(value)
            if clean != value { username = clean }
        }
        .onChange(of: about) { _, value in
            if value.count > Self.aboutLimit { about = String(value.prefix(Self.aboutLimit)) }
        }
        .task(id: username) { await checkUsername() }
        .onChange(of: photo) { _, item in
            guard let item else { return }
            Task {
                if let data = try? await item.loadTransferable(type: Data.self) {
                    if !(await social.setAvatar(from: data)) {
                        error = "Не удалось загрузить фото. Проверьте интернет и попробуйте ещё раз."
                    }
                }
                photo = nil
            }
        }
        .sheet(isPresented: $showEmail) { ChangeEmailSheet() }
        .sheet(isPresented: $showPassword) { ChangePasswordSheet() }
        .confirmationDialog("Выйти из аккаунта?", isPresented: $confirmSignOut, titleVisibility: .visible) {
            Button("Выйти", role: .destructive) { Task { await signOut(force: false) } }
            Button("Отмена", role: .cancel) {}
        } message: {
            Text("Коллекция, анкеты и эссе сохранятся в аккаунте. Чтобы вернуться, понадобятся почта и пароль.")
        }
        .alert("Не всё сохранилось", isPresented: $signOutFailed) {
            Button("Выйти всё равно", role: .destructive) { Task { await signOut(force: true) } }
            Button("Остаться", role: .cancel) {}
        } message: {
            Text("Нет связи, и последние изменения ещё не в аккаунте. Если выйти сейчас, они пропадут.")
        }
    }

    // MARK: Блоки

    private var photoPlate: some View {
        HStack(spacing: Space.s16) {
            ZStack {
                AvatarView(path: social.me?.avatarPath, name: name, seed: server.userID ?? "", size: 64)
                if social.uploadingAvatar {
                    Circle().fill(Color.black.opacity(0.5)).frame(width: 64, height: 64)
                    ProgressView().tint(Theme.text)
                }
            }
            PhotosPicker(selection: $photo, matching: .images) {
                Text(social.me?.avatarPath == nil ? "Добавить фото" : "Изменить фото")
                    .textStyle(.body, .bold)
                    .foregroundStyle(Theme.accent)
            }
            .touchArea()
            Spacer(minLength: 0)
            if social.me?.avatarPath != nil {
                Button("Удалить") { Task { await social.removeAvatar() } }
                    .textStyle(.sub, .medium)
                    .foregroundStyle(Theme.muted)
                    .touchArea()
            }
        }
        .plate()
    }

    private var aboutGroup: some View {
        VStack(alignment: .leading, spacing: ScreenLayout.groupLabelGap) {
            GroupLabel("О себе")
            VStack(alignment: .trailing, spacing: Space.s4) {
                TextField("", text: $about, prompt: Text("Пара слов о том, что вы любите смотреть").foregroundColor(Theme.muted),
                          axis: .vertical)
                    .lineLimit(2...8)
                    .font(Font(AppFont.uiFont(.body) as CTFont))
                    .foregroundStyle(Theme.text)
                    .frame(maxWidth: .infinity, alignment: .leading)
                Text("\(about.count)/\(Self.aboutLimit)")
                    .textStyle(.caption)
                    .foregroundStyle(about.count >= Self.aboutLimit ? Theme.accent : Theme.muted)
                    .monospacedDigit()
            }
            .plate()
        }
    }

    private func toggle(_ title: String, _ keyPath: WritableKeyPath<MyProfile, Bool>, _ column: String) -> some View {
        ToggleRow(title: title, isOn: Binding(
            get: { social.me?[keyPath: keyPath] ?? false },
            set: { social.setFlag(keyPath, column: column, to: $0) }
        ))
        .disabled(social.me == nil)
    }

    // MARK: Сохранение и выход

    private func saveText() async -> Bool {
        guard didLoad, social.me != nil else { return true }
        if usernameStatus == .taken {
            error = "Этот ID уже занят. Придумайте другой."
            return false
        }
        error = await social.saveText(name: name, username: username, about: about)
        return error == nil
    }

    /// Перед выходом всё уходит на сервер, затем телефон очищается — следующий вход загрузит всё обратно.
    private func signOut(force: Bool) async {
        signingOut = true
        defer { signingOut = false }
        _ = await saveText()
        if !force {
            guard await sync.sync(context) else {
                signOutFailed = true
                return
            }
        }
        sync.eraseLocal(context)
        social.reset()
        server.signOut()
    }

    private enum UsernameStatus { case unchanged, short, checking, free, taken }

    @ViewBuilder
    private var usernameBadge: some View {
        switch usernameStatus {
        case .unchanged:
            EmptyView()
        case .short:
            Text("мин. 3").textStyle(.caption).foregroundStyle(Theme.muted)
        case .checking:
            ProgressView().controlSize(.small).tint(Theme.muted)
        case .free:
            Image(systemName: "checkmark.circle.fill").foregroundStyle(Color(hex: 0x34C759))
                .accessibilityLabel("ID свободен")
        case .taken:
            Text("занят").textStyle(.caption, .bold).foregroundStyle(Color(hex: 0xE5735F))
        }
    }

    /// Проверка ID, пока пользователь печатает: через полсекунды после последней буквы.
    private func checkUsername() async {
        let value = username
        if value.isEmpty || value == (social.me?.username ?? "") { usernameStatus = .unchanged; return }
        if value.count < Username.range.lowerBound { usernameStatus = .short; return }
        usernameStatus = .checking
        try? await Task.sleep(nanoseconds: 500_000_000)
        guard !Task.isCancelled else { return }
        if let free = try? await server.usernameAvailable(value), !Task.isCancelled {
            usernameStatus = free ? .free : .taken
        } else if !Task.isCancelled {
            usernameStatus = .unchanged
        }
    }
}

// MARK: - Смена почты и пароля

/// Окно на чёрном фоне: заголовок, группа полей, главная кнопка — как в остальном приложении.
private struct FormSheet<Content: View>: View {
    let title: String
    var note: String? = nil
    @ViewBuilder var content: Content

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: ScreenLayout.blockGap) {
                VStack(alignment: .leading, spacing: Space.s8) {
                    Text(title)
                        .textStyle(.h1)
                        .foregroundStyle(Theme.text)
                    if let note {
                        Text(note)
                            .textStyle(.sub)
                            .foregroundStyle(Theme.muted)
                            .fixedSize(horizontal: false, vertical: true)
                    }
                }
                .padding(.top, Space.s32)
                content
            }
            .padding(.horizontal, ScreenLayout.sideMargin)
            .padding(.bottom, ScreenLayout.blockGap)
        }
        .scrollDismissesKeyboard(.interactively)
        .background(Theme.background.ignoresSafeArea())
        .presentationBackground(Theme.background)
    }
}

private struct ChangeEmailSheet: View {
    @Environment(Server.self) private var server
    @Environment(\.dismiss) private var dismiss
    @State private var email = ""
    @State private var busy = false
    @State private var message: String?

    var body: some View {
        FormSheet(title: "Почта", note: "Сейчас: \(server.email ?? "—"). Новой почтой вы будете входить в ance.") {
            RowGroup {
                InputRow(title: "Новая") {
                    TextField("", text: $email, prompt: Text("name@mail.ru").foregroundColor(Theme.muted))
                        .keyboardType(.emailAddress)
                        .textContentType(.emailAddress)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                }
            }
            if let message { GroupFooter(message, color: Theme.accent) }
            Button {
                Task { await submit() }
            } label: {
                if busy { ProgressView().tint(Color.black) } else { Text("Сменить почту") }
            }
            .buttonStyle(PrimaryButtonStyle())
            .disabled(busy || !email.contains("@"))
        }
        .presentationDetents([.medium])
    }

    private func submit() async {
        busy = true
        defer { busy = false }
        do {
            if try await server.changeEmail(email) {
                dismiss()
            } else {
                message = "Мы отправили письмо на новую почту. Откройте ссылку в нём — после этого почта сменится."
            }
        } catch {
            message = (error as? LocalizedError)?.errorDescription ?? error.localizedDescription
        }
    }
}

private struct ChangePasswordSheet: View {
    @Environment(Server.self) private var server
    @Environment(\.dismiss) private var dismiss
    @State private var current = ""
    @State private var new = ""
    @State private var repeated = ""
    @State private var busy = false
    @State private var message: String?

    private var problem: String? {
        if new.isEmpty || repeated.isEmpty { return nil }
        if new.count < 6 { return "Нужно не меньше 6 знаков." }
        if new != repeated { return "Пароли не совпадают." }
        return nil
    }

    var body: some View {
        FormSheet(title: "Пароль") {
            RowGroup {
                InputRow(title: "Текущий") {
                    SecureField("", text: $current, prompt: Text("обязательно").foregroundColor(Theme.muted))
                        .textContentType(.password)
                }
                RowDivider()
                InputRow(title: "Новый") {
                    SecureField("", text: $new, prompt: Text("от 6 знаков").foregroundColor(Theme.muted))
                        .textContentType(.newPassword)
                }
                RowDivider()
                InputRow(title: "Ещё раз") {
                    SecureField("", text: $repeated, prompt: Text("новый пароль").foregroundColor(Theme.muted))
                        .textContentType(.newPassword)
                }
            }
            if let text = message ?? problem { GroupFooter(text, color: Theme.accent) }
            Button {
                Task { await submit() }
            } label: {
                if busy { ProgressView().tint(Color.black) } else { Text("Сменить пароль") }
            }
            .buttonStyle(PrimaryButtonStyle())
            .disabled(busy || current.isEmpty || new.count < 6 || new != repeated)
        }
        .presentationDetents([.medium, .large])
    }

    private func submit() async {
        busy = true
        defer { busy = false }
        do {
            try await server.changePassword(current: current, new: new)
            dismiss()
        } catch {
            message = (error as? LocalizedError)?.errorDescription ?? error.localizedDescription
        }
    }
}
