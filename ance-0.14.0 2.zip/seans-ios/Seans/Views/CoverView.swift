import SwiftUI
import UIKit

/// Обложка фильма. Порядок выбора:
/// 1. замена, которую владелец задал на сервере (таблица cover_overrides);
/// 2. фото, которое пользователь выбрал для своего фильма;
/// 3. картинка из папки Seans/Resources/Covers с именем, равным id фильма;
/// 4. оригинальная афиша с Кинопоиска (пока грузится — цветной фон);
/// 5. просто цветной фон.
struct CoverView: View {
    let film: FilmItem
    var cornerRadius: CGFloat = 12
    /// Крупная афиша — для карточки фильма. В сетках и лентах — уменьшенная.
    var fullSize = false

    @State private var loaded: LoadedPoster?

    private struct LoadedPoster {
        let url: URL
        let image: UIImage
    }

    private var posterURL: URL? {
        if let custom = CoverOverrides.url(for: film.id) { return custom }
        return fullSize ? (film.posterURL ?? film.posterPreviewURL) : (film.posterPreviewURL ?? film.posterURL)
    }

    private var hasOverride: Bool { CoverOverrides.url(for: film.id) != nil }

    /// Самая длинная сторона картинки в пикселях: плитка в сетке ~180 pt × 3.
    private var maxPixel: CGFloat { fullSize ? 1500 : 720 }

    private var image: UIImage? {
        if !hasOverride {
            if let data = film.photo, let photo = UIImage(data: data) { return photo }
            if let bundled = CoverImages.image(for: film.id) { return bundled }
        }
        guard let url = posterURL else { return nil }
        if let loaded, loaded.url == url { return loaded.image }
        return PosterStore.cached(url, maxPixel: maxPixel)
    }

    var body: some View {
        GeometryReader { geo in
            let size = geo.size
            ZStack {
                if let image {
                    Image(uiImage: image)
                        .resizable()
                        .scaledToFill()
                        .frame(width: size.width, height: size.height)
                        .clipped()
                        .transition(.opacity)
                } else {
                    CoverArt(style: film.cover, seed: film.id, size: size)
                }
            }
            .frame(width: size.width, height: size.height)
        }
        .aspectRatio(2.0 / 3.0, contentMode: .fit)
        .clipShape(RoundedRectangle(cornerRadius: cornerRadius, style: .continuous))
        .accessibilityHidden(true)
        .task(id: posterURL) {
            guard let url = posterURL,
                  hasOverride || (film.photo == nil && CoverImages.image(for: film.id) == nil),
                  PosterStore.cached(url, maxPixel: maxPixel) == nil else { return }
            if let image = await PosterStore.load(url, maxPixel: maxPixel), !Task.isCancelled {
                withAnimation(.easeOut(duration: 0.2)) { loaded = LoadedPoster(url: url, image: image) }
            }
        }
    }
}

/// Готовые обложки, вложенные в приложение: файл «id фильма».jpg / .jpeg / .png / .webp.
enum CoverImages {
    private static let cache = NSCache<NSString, UIImage>()
    private static var missing = Set<String>()
    private static let lock = NSLock()
    private static let extensions = ["jpg", "jpeg", "png", "webp"]

    static func image(for filmID: String) -> UIImage? {
        if let cached = cache.object(forKey: filmID as NSString) { return cached }
        lock.lock()
        let knownMissing = missing.contains(filmID)
        lock.unlock()
        if knownMissing { return nil }

        for ext in extensions {
            if let url = Bundle.main.url(forResource: filmID, withExtension: ext),
               let image = UIImage(contentsOfFile: url.path) {
                cache.setObject(image, forKey: filmID as NSString)
                return image
            }
        }
        lock.lock()
        missing.insert(filmID)
        lock.unlock()
        return nil
    }
}

/// Обложка без картинки — просто цвет фильма.
struct CoverArt: View {
    let style: CoverStyle
    let seed: String
    let size: CGSize

    var body: some View {
        style.bgColor
            .frame(width: size.width, height: size.height)
    }
}

/// Замены обложек от владельца: таблица cover_overrides на сервере (номер фильма → адрес картинки).
/// Хранятся и на телефоне, чтобы обложки были видны сразу при запуске и без сети.
enum CoverOverrides {
    private static let key = "coverOverrides"
    private static var map: [String: URL] = load()

    private static func load() -> [String: URL] {
        guard let saved = UserDefaults.standard.dictionary(forKey: key) as? [String: String] else { return [:] }
        return saved.compactMapValues { URL(string: $0) }
    }

    static func url(for filmID: String) -> URL? { map[filmID] }

    static func update(_ rows: [String: String]) {
        UserDefaults.standard.set(rows, forKey: key)
        map = rows.compactMapValues { URL(string: $0.trimmingCharacters(in: .whitespacesAndNewlines)) }
    }
}

/// Плитка фильма для сеток и подборок: обложка, название, год и фамилия режиссёра.
/// compact — для сетки в три колонки: название мелким стилем, скругление поменьше.
struct FilmTile: View {
    let film: FilmItem
    var subtitle: String? = nil
    var compact = false

    var body: some View {
        VStack(alignment: .leading, spacing: Space.s8) {
            // Обложка всегда 2:3 по ширине плитки и не сжимается,
            // даже если у соседней плитки название длиннее.
            CoverView(film: film, cornerRadius: compact ? Radius.small : Radius.medium)
                .fixedSize(horizontal: false, vertical: true)
            VStack(alignment: .leading, spacing: 0) {
                // Название — до двух строк; год и режиссёр сразу под ним.
                Text(film.title)
                    .textStyle(compact ? .caption : .sub, .medium)
                    .foregroundStyle(Theme.text)
                    .lineLimit(2)
                    .multilineTextAlignment(.leading)
                    .fixedSize(horizontal: false, vertical: true)
                if let subtitle, !subtitle.isEmpty {
                    Text(subtitle)
                        .textStyle(.caption)
                        .foregroundStyle(Theme.muted)
                        .lineLimit(1)
                        .padding(.top, Space.s4)
                }
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .contentShape(Rectangle())
        .accessibilityElement(children: .combine)
    }
}
