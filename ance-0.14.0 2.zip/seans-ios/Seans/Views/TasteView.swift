import SwiftUI
import SwiftData

/// Вкладка «Вкусы»: тип зрителя и портрет вкуса по анкетам.
struct TasteView: View {
    @Environment(Library.self) private var library
    @Query private var surveys: [SurveyEntry]
    @Query private var items: [CollectionItem]

    private var seenFilms: [FilmItem] {
        items.filter { $0.status == .seen }
            .compactMap { library.film(id: $0.filmID) }
    }

    var body: some View {
        let profile = TasteProfile(surveys: surveys, seenFilms: seenFilms)
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: ScreenLayout.blockGap) {
                    ScreenTitle("Вкусы")
                        .padding(.top, Space.s12)

                    typeCard(profile)

                    if profile.surveyCount > 0 {
                        stats(profile)
                        favorites(profile)
                        if !profile.axes.isEmpty { axesSection(profile) }
                        if !profile.aspects.isEmpty { aspectsSection(profile) }
                        if !profile.feelings.isEmpty { feelingsSection(profile) }
                        if !profile.words.isEmpty { wordsSection(profile) }
                    }
                }
                .padding(.horizontal, ScreenLayout.sideMargin)
                .padding(.bottom, ScreenLayout.blockGap)
            }
            .dockClearance()
            .background(Theme.background.ignoresSafeArea())
            .navigationTitle("Вкусы")
            .toolbar(.hidden, for: .navigationBar)
            .navigationDestination(for: FilmRoute.self) { route in
                FilmDetailView(filmID: route.id)
            }
        }
    }

    // MARK: Плашка архетипа зрителя

    private func typeCard(_ p: TasteProfile) -> some View {
        VStack(alignment: .leading, spacing: 0) {
            // Верхняя светло-серая зона — место под авторскую обложку.
            // Иконка архетипа — правый верхний угол.
            ZStack(alignment: .topTrailing) {
                Color(hex: 0x2A2A2A)
                    .frame(maxWidth: .infinity)
                if let archetype = p.archetype {
                    Image(archetype.iconAsset)
                        .renderingMode(.template)
                        .resizable()
                        .scaledToFit()
                        .frame(width: 56, height: 56)
                        .foregroundStyle(archetype.color)
                        .padding(Space.s16)
                }
            }
            .frame(height: 200)
            .accessibilityHidden(true)

            // Нижняя тёмно-серая зона — название архетипа, кредо, описание.
            VStack(alignment: .leading, spacing: 0) {
                if let archetype = p.archetype {
                    Text(archetype.title)
                        .textStyle(.h1)
                        .foregroundStyle(Theme.text)
                        .fixedSize(horizontal: false, vertical: true)
                        .padding(.bottom, Space.s12)
                    Text("«\(archetype.motto)»")
                        .textStyle(.sub, .medium)
                        .foregroundStyle(Theme.accent)
                        .fixedSize(horizontal: false, vertical: true)
                    Text(archetype.description)
                        .textStyle(.body)
                        .foregroundStyle(Theme.textSecondary)
                        .fixedSize(horizontal: false, vertical: true)
                        .padding(.top, Space.s12)
                } else {
                    Text("Появится после первой анкеты")
                        .textStyle(.h2)
                        .foregroundStyle(Theme.text)
                        .fixedSize(horizontal: false, vertical: true)
                        .padding(.bottom, Space.s8)
                    Text("Отметьте фильм как просмотренный и заполните короткую анкету. С каждой новой анкетой портрет вашего вкуса будет точнее.")
                        .textStyle(.sub)
                        .foregroundStyle(Theme.textSecondary)
                        .fixedSize(horizontal: false, vertical: true)
                }
            }
            .padding(ScreenLayout.cardPadding)
            .frame(maxWidth: .infinity, alignment: .leading)
            Spacer(minLength: 0)
        }
        .frame(minHeight: ScreenLayout.cardMinHeight, alignment: .top)
        .background(Theme.surface)
        .clipShape(RoundedRectangle(cornerRadius: ScreenLayout.cardRadius, style: .continuous))
        .accessibilityElement(children: .combine)
    }

    // MARK: Цифры

    private func stats(_ p: TasteProfile) -> some View {
        VStack(alignment: .leading, spacing: ScreenLayout.blockTitleGap) {
            SectionTitle("В цифрах")
            HStack(alignment: .top, spacing: Space.s12) {
                stat(value: "\(p.seenCount)", label: TasteProfile.plural(p.seenCount, "фильм", "фильма", "фильмов"))
                stat(value: p.averageRating.map { String(format: "%.1f", $0).replacingOccurrences(of: ".", with: ",") } ?? "—",
                     label: "средняя оценка")
                stat(value: "\(p.essayCount)", label: TasteProfile.plural(p.essayCount, "эссе", "эссе", "эссе"))
            }
            let extrasRaw: [String?] = [
                p.favoriteDecade.map { "Любимое десятилетие — \($0)" },
                p.favoriteDirector.map { "Чаще всего смотрите — \($0)" },
                p.essayWords > 0 ? "Написано \(p.essayWords) \(TasteProfile.plural(p.essayWords, "слово", "слова", "слов")) о кино" : nil
            ]
            let extras = extrasRaw.compactMap { $0 }
            if !extras.isEmpty {
                VStack(alignment: .leading, spacing: Space.s8) {
                    ForEach(extras, id: \.self) { line in
                        Text(line)
                            .textStyle(.sub)
                            .foregroundStyle(Theme.textSecondary)
                    }
                }
                .plate()
            }
        }
    }

    private func stat(value: String, label: String) -> some View {
        VStack(alignment: .leading, spacing: Space.s4) {
            Text(value)
                .textStyle(.h1)
                .foregroundStyle(Theme.text)
            Text(label)
                .textStyle(.caption)
                .foregroundStyle(Theme.muted)
                .fixedSize(horizontal: false, vertical: true)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(Space.s16)
        .background(RoundedRectangle(cornerRadius: Radius.large, style: .continuous).fill(Theme.surface))
        .accessibilityElement(children: .combine)
    }

    // MARK: Любимые фильмы

    @ViewBuilder
    private func favorites(_ p: TasteProfile) -> some View {
        let films = p.favoriteIDs.compactMap { library.film(id: $0) }
        if !films.isEmpty {
            VStack(alignment: .leading, spacing: ScreenLayout.blockTitleGap) {
                SectionTitle("Любимые фильмы", hint: "Оценка 8 и выше")
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(alignment: .top, spacing: Space.s12) {
                        ForEach(films) { film in
                            NavigationLink(value: FilmRoute(id: film.id)) {
                                FilmTile(film: film, subtitle: film.shortMeta, compact: true)
                                    .frame(width: 112)
                            }
                            .buttonStyle(.plain)
                        }
                    }
                    .padding(.horizontal, ScreenLayout.sideMargin)
                }
                .padding(.horizontal, -ScreenLayout.sideMargin)
            }
        }
    }

    // MARK: Ваше кино — шкалы

    private func axesSection(_ p: TasteProfile) -> some View {
        VStack(alignment: .leading, spacing: ScreenLayout.blockTitleGap) {
            SectionTitle("Ваше кино", hint: "Какие фильмы вы оцениваете выше")
            VStack(spacing: Space.s16) {
                ForEach(p.axes) { axis in
                    VStack(spacing: Space.s8) {
                        GeometryReader { geo in
                            let width = geo.size.width
                            let x = CGFloat(axis.value + 1) / 2 * width
                            ZStack(alignment: .leading) {
                                Capsule().fill(Theme.lineStrong).frame(height: 2)
                                Circle()
                                    .fill(Theme.text)
                                    .frame(width: 16, height: 16)
                                    .offset(x: min(max(0, x - 8), width - 16))
                            }
                            .frame(height: 16)
                        }
                        .frame(height: 16)
                        HStack {
                            Text(axis.left)
                            Spacer()
                            Text(axis.right)
                        }
                        .textStyle(.sub, .medium)
                        .foregroundStyle(Theme.textSecondary)
                    }
                    .accessibilityElement(children: .ignore)
                    .accessibilityLabel("\(axis.title): ближе к «\(axis.value < 0 ? axis.left : axis.right)»")
                }
            }
            .padding(Space.s16)
            .background(RoundedRectangle(cornerRadius: Radius.large, style: .continuous).fill(Theme.surface))
        }
    }

    // MARK: Стороны фильма

    private func aspectsSection(_ p: TasteProfile) -> some View {
        VStack(alignment: .leading, spacing: ScreenLayout.blockTitleGap) {
            SectionTitle("Что для вас важнее", hint: "Средняя оценка сторон фильма в ваших анкетах")
            VStack(spacing: Space.s12) {
                ForEach(Array(p.aspects.enumerated()), id: \.element.id) { index, bar in
                    VStack(alignment: .leading, spacing: Space.s8) {
                        HStack {
                            Text(bar.title)
                                .textStyle(.sub, .medium)
                                .foregroundStyle(Theme.text)
                            Spacer()
                            Text(bar.label.replacingOccurrences(of: ".", with: ","))
                                .textStyle(.sub)
                                .foregroundStyle(Theme.muted)
                        }
                        GeometryReader { geo in
                            ZStack(alignment: .leading) {
                                Capsule().fill(Theme.lineStrong)
                                Capsule()
                                    .fill(index == 0 ? Theme.accent : Theme.text)
                                    .frame(width: geo.size.width * CGFloat(bar.value))
                            }
                        }
                        .frame(height: 6)
                    }
                    .accessibilityElement(children: .combine)
                }
            }
        }
    }

    // MARK: Чувства

    private func feelingsSection(_ p: TasteProfile) -> some View {
        VStack(alignment: .leading, spacing: ScreenLayout.blockTitleGap) {
            SectionTitle("Чувства, за которыми вы приходите")
            FlowLayout(spacing: Space.s8, lineSpacing: 8) {
                ForEach(p.feelings) { feeling in
                    HStack(spacing: Space.s8) {
                        Text(feeling.title)
                            .foregroundStyle(Theme.text)
                        Text("\(feeling.count)")
                            .foregroundStyle(Theme.muted)
                    }
                    .textStyle(.sub, .medium)
                    .padding(.horizontal, Space.s16)
                    .frame(minHeight: 40)
                    .background(Capsule().fill(Theme.surface))
                    .accessibilityElement(children: .combine)
                }
            }
        }
    }

    // MARK: Слова

    private func wordsSection(_ p: TasteProfile) -> some View {
        let maxCount = p.words.map(\.count).max() ?? 1
        return VStack(alignment: .leading, spacing: ScreenLayout.blockTitleGap) {
            SectionTitle("Ваши слова о кино")
            FlowLayout(spacing: Space.s12, lineSpacing: 4) {
                ForEach(Array(p.words.enumerated()), id: \.element.id) { index, word in
                    // размер — по частоте, но только из шкалы: 28, 22 или 19
                    let weight = Double(word.count) / Double(maxCount)
                    Text(word.title)
                        .textStyle(weight > 0.66 && index < 3 ? .h1 : (weight > 0.33 ? .h2 : .h3))
                        .foregroundStyle(index == 0 ? Theme.accent : (index % 3 == 1 ? Theme.textSecondary : Theme.text))
                }
            }
        }
    }
}
