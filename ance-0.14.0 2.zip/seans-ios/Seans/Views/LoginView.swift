import SwiftUI
import UIKit
import CoreText

/// Вход в ance: почта и пароль. Регистрации нет — аккаунты выдаёт владелец.
struct LoginView: View {
    @Environment(Server.self) private var server

    @State private var email = ""
    @State private var password = ""
    @State private var error: String?
    @State private var busy = false
    @State private var showServerSettings = false
    @FocusState private var focus: Field?

    private enum Field { case email, password }

    private var canSubmit: Bool {
        email.contains("@") && !password.isEmpty && !busy
    }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: ScreenLayout.blockGap) {
                // Логотип. Долгое нажатие — запасной адрес сервера (для владельца, на случай блокировки).
                AnceLogo(size: 64)
                    .frame(maxWidth: .infinity, minHeight: 200)
                    .contentShape(Rectangle())
                    .onLongPressGesture(minimumDuration: 1.5) { showServerSettings = true }

                ScreenTitle("Вход")

                RowGroup {
                    InputRow(title: "Почта") {
                        TextField("", text: $email, prompt: Text("name@mail.ru").foregroundColor(Theme.muted))
                            .keyboardType(.emailAddress)
                            .textContentType(.username)
                            .textInputAutocapitalization(.never)
                            .autocorrectionDisabled()
                            .submitLabel(.next)
                            .focused($focus, equals: .email)
                            .onSubmit { focus = .password }
                    }
                    RowDivider()
                    InputRow(title: "Пароль") {
                        SecureField("", text: $password, prompt: Text("••••••").foregroundColor(Theme.muted))
                            .textContentType(.password)
                            .submitLabel(.go)
                            .focused($focus, equals: .password)
                            .onSubmit { submit() }
                    }
                }

                if let error {
                    GroupFooter(error, color: Theme.accent)
                }

                Button {
                    submit()
                } label: {
                    if busy {
                        ProgressView().tint(Color.black)
                    } else {
                        Text("Войти")
                    }
                }
                .buttonStyle(PrimaryButtonStyle())
                .disabled(!canSubmit)
                .opacity(canSubmit || busy ? 1 : 0.5)
            }
            .padding(.horizontal, ScreenLayout.sideMargin)
            .padding(.bottom, ScreenLayout.blockGap)
        }
        .scrollDismissesKeyboard(.interactively)
        .background(Theme.background.ignoresSafeArea())
        .sheet(isPresented: $showServerSettings) {
            ServerSettingsView()
                .presentationDetents([.medium, .large])
        }
        .onAppear {
            if server.config == nil { error = ServerError.notConfigured.errorDescription }
        }
    }

    private func submit() {
        guard canSubmit else { return }
        busy = true
        error = nil
        focus = nil
        Task {
            do {
                try await server.signIn(email: email, password: password)
            } catch {
                self.error = (error as? LocalizedError)?.errorDescription ?? error.localizedDescription
            }
            busy = false
        }
    }
}

/// Адрес сервера и публичный ключ. Обычно вшиты в приложение при сборке;
/// здесь их можно заменить — например, если адрес заблокировали и сервер переехал.
struct ServerSettingsView: View {
    @Environment(Server.self) private var server
    @Environment(\.dismiss) private var dismiss

    @State private var url = ""
    @State private var key = ""

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: ScreenLayout.blockGap) {
                Text("Сервер")
                    .textStyle(.h1)
                    .foregroundStyle(Theme.text)
                    .padding(.top, Space.s32)
                FormGroup(footer: "Пустые поля — адрес, вшитый в приложение.") {
                    InputRow(title: "Адрес") {
                        TextField("", text: $url, prompt: Text("xxxx.supabase.co").foregroundColor(Theme.muted))
                            .keyboardType(.URL)
                            .textInputAutocapitalization(.never)
                            .autocorrectionDisabled()
                    }
                    RowDivider()
                    InputRow(title: "Ключ") {
                        TextField("", text: $key, prompt: Text("публичный").foregroundColor(Theme.muted))
                            .textInputAutocapitalization(.never)
                            .autocorrectionDisabled()
                    }
                }
                Button("Сохранить") {
                    if url.trimmingCharacters(in: .whitespaces).isEmpty {
                        ServerConfig.clearManual()
                    } else {
                        ServerConfig.saveManual(url: url, key: key)
                    }
                    server.reloadConfig()
                    dismiss()
                }
                .buttonStyle(PrimaryButtonStyle())
            }
            .padding(.horizontal, ScreenLayout.sideMargin)
            .padding(.bottom, ScreenLayout.blockGap)
        }
        .background(Theme.background.ignoresSafeArea())
        .presentationBackground(Theme.background)
        .onAppear {
            url = UserDefaults.standard.string(forKey: ServerConfig.manualURLKey) ?? ""
            key = UserDefaults.standard.string(forKey: ServerConfig.manualKeyKey) ?? ""
        }
    }
}
