import SwiftUI
import SwiftData

/// Открытие анкеты.
struct SurveyLaunch: Identifiable {
    let film: FilmItem
    var essayOnly = false
    var id: String { film.id + (essayOnly ? "-essay" : "") }
}

/// Карточка фильма: крупное название, плашка с постером и фактами, кнопки,
/// «О фильме», «Анкета», «Эссе» и «Кому подойдёт».
struct FilmDetailView: View {
    let filmID: String

    @Environment(Library.self) private var library
    @Environment(\.modelContext) private var context
    @Environment(\.dismiss) private var dismiss
    @Query private var collection: [CollectionItem]
    @Query private var surveys: [SurveyEntry]
    @Query private var essayBlocks: [JournalBlock]

    @State private var launch: SurveyLaunch?
    @State private var editEssay: FilmItem?

    init(filmID: String) {
        self.filmID = filmID
        let id = filmID
        let essayKind = JournalKind.essay.rawValue
        _essayBlocks = Query(filter: #Predicate<JournalBlock> { $0.filmID == id && $0.kindRaw == essayKind })
    }

    private var film: FilmItem? { library.film(id: filmID) }
    private var entry: CollectionItem? { collection.first { $0.filmID == filmID } }
    private var survey: SurveyEntry? { surveys.first { $0.filmID == filmID } }
    private var essayPhotos: [JournalPhoto] { essayBlocks.first?.sortedPhotos ?? [] }

    var body: some View {
        Group {
            if let film {
                content(film)
            } else {
                VStack(spacing: Space.s12) {
                    Text("Фильм не найден")
                        .textStyle(.body, .bold)
                        .foregroundStyle(Theme.text)
                    Button("Назад") { dismiss() }
                        .buttonStyle(SecondaryButtonStyle())
                        .frame(width: 160)
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
            }
        }
        .background(Theme.background.ignoresSafeArea())
        .pushedPage()
        .toolbar {
            if entry != nil {
                ToolbarItem(placement: .topBarTrailing) {
                    Menu {
                        if entry?.status == .seen {
                            Button("Хочу пересмотреть") { CollectionActions.setStatus(.want, for: filmID, in: context) }
                        }
                        Button("Убрать из коллекции", role: .destructive) {
                            CollectionActions.setStatus(nil, for: filmID, in: context)
                        }
                    } label: {
                        Image(systemName: "ellipsis").foregroundStyle(Theme.text)
                    }
                    .accessibilityLabel("Ещё")
                }
            }
        }
        .fullScreenCover(item: $launch) { item in
            SurveyView(film: item.film, startAtEssay: item.essayOnly)
        }
        .fullScreenCover(item: $editEssay) { film in
            EssayEditorView(film: film)
        }
    }

    private func content(_ film: FilmItem) -> some View {
        ScrollView {
            VStack(alignment: .leading, spacing: ScreenLayout.blockGap) {
                // Крупный заголовок вложенной страницы — название фильма, под ним оригинальное.
                VStack(alignment: .leading, spacing: Space.s4) {
                    ScreenTitle(film.title)
                        .fixedSize(horizontal: false, vertical: true)
                    if let original = film.originalTitle, !original.isEmpty, original != film.title {
                        Text(original)
                            .textStyle(.body)
                            .foregroundStyle(Theme.muted)
                    }
                }
                .padding(.top, ScreenLayout.pushedTitleTop)

                hero(film)

                if entry?.status != .seen {
                    actions(film)
                } else if survey == nil {
                    Button("Заполнить анкету") { launch = SurveyLaunch(film: film) }
                        .buttonStyle(PrimaryButtonStyle())
                }

                if let synopsis = film.synopsis, !synopsis.isEmpty {
                    ScreenBlock(title: "О фильме") {
                        Text(synopsis)
                            .textStyle(.body)
                            .foregroundStyle(Theme.textSecondary)
                            .fixedSize(horizontal: false, vertical: true)
                            .plate()
                    }
                }

                if let survey {
                    BlockWithAction(title: "Анкета", action: "Изменить") { launch = SurveyLaunch(film: film) } content: {
                        review(survey, film: film)
                    }
                }

                if entry?.status == .seen {
                    essayBlock(film)
                }

                let archetypes = film.archetypes.compactMap(Archetype.init(rawValue:))
                if !archetypes.isEmpty {
                    ScreenBlock(title: "Кому подойдёт") {
                        ArchetypeBadges(archetypes: archetypes)
                    }
                }
            }
            .padding(.horizontal, ScreenLayout.sideMargin)
            .padding(.bottom, ScreenLayout.blockGap)
        }
        .dockClearance()
    }

    /// Плашка: постер слева, справа факты строками «название — значение» и оценки внизу.
    private func hero(_ film: FilmItem) -> some View {
        HStack(alignment: .top, spacing: Space.s16) {
            CoverView(film: film, cornerRadius: Radius.medium, fullSize: true)
                .frame(width: 112)
            VStack(alignment: .leading, spacing: Space.s12) {
                Grid(alignment: .leading, horizontalSpacing: Space.s12, verticalSpacing: Space.s4) {
                    ForEach(facts(film)) { fact in
                        GridRow {
                            Text(fact.title)
                                .foregroundStyle(Theme.muted)
                            Text(fact.value)
                                .foregroundStyle(Theme.text)
                                .fixedSize(horizontal: false, vertical: true)
                        }
                    }
                }
                .textStyle(.sub)
                Spacer(minLength: 0)
                HStack(spacing: Space.s8) {
                    if entry?.status == .seen {
                        InfoChip(text: "✓ " + seenCaption, accent: true)
                    } else {
                        if let kp = film.ratingKP, kp > 0 { InfoChip(text: "КП " + Self.score(kp), accent: true) }
                        if let imdb = film.ratingIMDb, imdb > 0 { InfoChip(text: "IMDb " + Self.score(imdb)) }
                    }
                }
            }
            .frame(maxWidth: .infinity, alignment: .leading)
        }
        .fixedSize(horizontal: false, vertical: true)
        .plate()
    }

    private static func score(_ value: Double) -> String {
        String(format: "%.1f", value).replacingOccurrences(of: ".", with: ",")
    }

    private struct Fact: Identifiable {
        let title: String
        let value: String
        var id: String { title }
    }

    private func facts(_ film: FilmItem) -> [Fact] {
        var result: [Fact] = []
        if let year = film.year { result.append(Fact(title: "Год", value: String(year))) }
        if !film.directors.isEmpty { result.append(Fact(title: "Режиссёр", value: film.directors.prefix(2).joined(separator: ", "))) }
        if !film.countries.isEmpty { result.append(Fact(title: "Страна", value: film.countries.prefix(2).joined(separator: ", "))) }
        if !film.genres.isEmpty { result.append(Fact(title: "Жанр", value: film.genres.prefix(2).joined(separator: ", "))) }
        if let minutes = film.minutes, minutes > 0 {
            let h = minutes / 60, m = minutes % 60
            result.append(Fact(title: "Время", value: h > 0 ? (m > 0 ? "\(h) ч \(m) мин" : "\(h) ч") : "\(m) мин"))
        }
        return result
    }

    /// Кнопки в ряд: «Посмотрел» и «Хочу».
    private func actions(_ film: FilmItem) -> some View {
        HStack(spacing: Space.s12) {
            Button("Посмотрел") { markSeen(film) }
                .buttonStyle(PrimaryButtonStyle())
            if entry?.status == .want {
                Button {
                    CollectionActions.setStatus(nil, for: film.id, in: context)
                } label: {
                    Label("Хочу", systemImage: "checkmark")
                }
                .buttonStyle(SecondaryButtonStyle(highlighted: true))
            } else {
                Button("Хочу") {
                    CollectionActions.setStatus(.want, for: film.id, in: context)
                }
                .buttonStyle(SecondaryButtonStyle())
            }
        }
        .sensoryFeedback(.success, trigger: entry?.statusRaw)
    }

    @ViewBuilder
    private func essayBlock(_ film: FilmItem) -> some View {
        let essay = survey?.essay ?? ""
        if essay.isEmpty && essayPhotos.isEmpty {
            ScreenBlock(title: "Эссе") {
                Button("Написать эссе") { editEssay = film }
                    .buttonStyle(SecondaryButtonStyle())
            }
        } else {
            BlockWithAction(title: "Эссе", action: "Изменить") { editEssay = film } content: {
                EssayView(essay: essay, photos: essayPhotos)
                    .plate()
            }
        }
    }

    private var seenCaption: String {
        guard let date = entry?.seenAt else { return "Посмотрел" }
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "ru_RU")
        let sameYear = Calendar.current.isDate(date, equalTo: Date(), toGranularity: .year)
        formatter.dateFormat = sameYear ? "d MMMM" : "d MMMM yyyy"
        return "Посмотрел " + formatter.string(from: date)
    }

    /// Плашка анкеты: подпись «АНКЕТА», слово о фильме (Заголовок 1) и квадрат оценки
    /// в правом верхнем углу; чувства; стороны фильма — шкалами из пяти делений;
    /// подробности одной строкой; внизу — «Изменить анкету».
    private func review(_ survey: SurveyEntry, film: FilmItem) -> some View {
        VStack(alignment: .leading, spacing: 0) {
            HStack(alignment: .top, spacing: Space.s12) {
                VStack(alignment: .leading, spacing: Space.s4) {
                    if !survey.word.isEmpty {
                        Text(survey.word)
                            .textStyle(.h1)
                            .foregroundStyle(Theme.accent)
                            .fixedSize(horizontal: false, vertical: true)
                    }
                }
                Spacer(minLength: 0)
                if survey.rating > 0 {
                    RatingBadge(value: survey.rating, style: .h1)
                }
            }

            let feel = SurveyOptions.titles(for: survey.emotions, in: SurveyOptions.emotions)
            if !feel.isEmpty {
                Text(feel.joined(separator: " · "))
                    .textStyle(.sub)
                    .foregroundStyle(Theme.textSecondary)
                    .fixedSize(horizontal: false, vertical: true)
                    .padding(.top, Space.s8)
            }

            let aspects = survey.aspectValues()
            let rated = SurveyOptions.aspects.filter { (aspects[$0.id] ?? 0) > 0 }
            if !rated.isEmpty {
                LazyVGrid(columns: [GridItem(.flexible(), spacing: Space.s16, alignment: .leading),
                                    GridItem(.flexible(), spacing: Space.s16, alignment: .leading)],
                          alignment: .leading, spacing: Space.s12) {
                    ForEach(rated) { aspect in
                        let value = aspects[aspect.id] ?? 0
                        VStack(alignment: .leading, spacing: Space.s4) {
                            Text(aspect.title)
                                .textStyle(.caption)
                                .foregroundStyle(Theme.textSecondary)
                                .lineLimit(1)
                            AspectMeter(value: value)
                        }
                        .accessibilityElement(children: .ignore)
                        .accessibilityLabel("\(aspect.title): \(value) из 5")
                    }
                }
                .padding(.top, Space.s16)
            }

            let details = detailsLine(survey)
            if !details.isEmpty {
                Text(details)
                    .textStyle(.caption)
                    .foregroundStyle(Theme.muted)
                    .fixedSize(horizontal: false, vertical: true)
                    .padding(.top, Space.s16)
            }

        }
        .plate()
    }

    private func detailsLine(_ survey: SurveyEntry) -> String {
        var parts: [String] = []
        if let e = SurveyOptions.title(for: survey.ending, in: SurveyOptions.endings) { parts.append(e) }
        if let r = SurveyOptions.rewatchShort[survey.rewatch] { parts.append(r) }
        let company = SurveyOptions.title(for: survey.company, in: SurveyOptions.company)
        let place = SurveyOptions.title(for: survey.place, in: SurveyOptions.places)
        let context = [company, place].compactMap { $0 }.map { $0.lowercased() }
        if !context.isEmpty { parts.append("Смотрели: " + context.joined(separator: ", ")) }
        return parts.joined(separator: " · ")
    }

    private func markSeen(_ film: FilmItem) {
        CollectionActions.setStatus(.seen, for: film.id, in: context)
        if survey == nil {
            launch = SurveyLaunch(film: film)
        }
    }
}
