import Foundation

struct SurveyOption: Identifiable, Hashable {
    let id: String
    let title: String
}

/// Шкала «от — до», например темп: медленный ↔ динамичный.
struct SurveyScale: Identifiable, Hashable {
    let id: String
    let title: String
    let left: String
    let right: String
    /// «неспешное», «динамичное» — для фразы «вы любите … кино».
    let leftFilm: String
    let rightFilm: String
}

/// Варианты ответов в анкете после просмотра (с версии 0.15).
/// Анкета отвечает на вопрос «подойдёт ли этот фильм другому зрителю»:
/// что фильм даёт (удовольствие или смысл), под какое он настроение, что в нём удалось, с кем его смотреть и стоит ли.
/// Хранение в SurveyEntry: emotions — «основное», scalesRaw — четыре шкалы, aspectsRaw — сильные (5) и слабые (1)
/// стороны, ending — итог, recommend — с кем смотреть, rewatch — впервые или пересмотр, place — где.
enum SurveyOptions {
    /// «Что дал фильм?» — до двух. title — для вопроса («дал… смех»), noun — для карточки («Смех»).
    static let emotions: [SurveyOption] = [
        SurveyOption(id: "rest", title: "Отдых"),
        SurveyOption(id: "laugh", title: "Смех"),
        SurveyOption(id: "adrenaline", title: "Адреналин"),
        SurveyOption(id: "fear", title: "Страх"),
        SurveyOption(id: "mind", title: "Пищу для ума"),
        SurveyOption(id: "feelings", title: "Сильные чувства"),
        SurveyOption(id: "insp", title: "Вдохновение"),
        SurveyOption(id: "beauty", title: "Красоту"),
        SurveyOption(id: "world", title: "Другой мир"),
        SurveyOption(id: "nostalgia", title: "Ностальгию")
    ]
    static let mainLimit = 2

    /// Те же ответы в именительном падеже — для строки «Основное» в карточке.
    static let emotionNouns: [String: String] = [
        "rest": "отдых", "laugh": "смех", "adrenaline": "адреналин", "fear": "страх", "mind": "пища для ума",
        "feelings": "сильные чувства", "insp": "вдохновение", "beauty": "красота", "world": "другой мир",
        "nostalgia": "ностальгия"
    ]

    /// Сильные стороны — до двух.
    static let aspects: [SurveyOption] = [
        SurveyOption(id: "story", title: "История"),
        SurveyOption(id: "cast", title: "Актёры"),
        SurveyOption(id: "visual", title: "Картинка"),
        SurveyOption(id: "sound", title: "Музыка"),
        SurveyOption(id: "ideas", title: "Идеи"),
        SurveyOption(id: "atmosphere", title: "Атмосфера"),
        SurveyOption(id: "humor", title: "Юмор"),
        SurveyOption(id: "spectacle", title: "Зрелищность")
    ]
    /// Слабые стороны — до двух, по желанию.
    static let weaknesses: [SurveyOption] = [
        SurveyOption(id: "story", title: "История"),
        SurveyOption(id: "cast", title: "Актёры"),
        SurveyOption(id: "pace", title: "Длина и темп"),
        SurveyOption(id: "finale", title: "Финал"),
        SurveyOption(id: "dialogue", title: "Диалоги")
    ]
    static let sideLimit = 2

    /// Совместимость со старыми анкетами версии 0.1.
    static let legacyHookToAspect: [String: String] = [:]

    /// «Каким он был?» — четыре шкалы −2…2.
    static let scales: [SurveyScale] = [
        SurveyScale(id: "tone", title: "Настроение", left: "Светлый", right: "Мрачный", leftFilm: "светлое", rightFilm: "мрачное"),
        SurveyScale(id: "weight", title: "Тяжесть", left: "Лёгкий", right: "Тяжёлый", leftFilm: "лёгкое", rightFilm: "тяжёлое"),
        SurveyScale(id: "tempo", title: "Темп", left: "Неспешный", right: "Динамичный", leftFilm: "неспешное", rightFilm: "динамичное"),
        SurveyScale(id: "attention", title: "Внимание", left: "Можно фоном", right: "Нужно внимание", leftFilm: "лёгкое для фона", rightFilm: "требующее внимания")
    ]

    /// Слова для строки «Настроение»: левая и правая сторона шкалы.
    static let scaleWords: [String: (String, String)] = [
        "tone": ("светлый", "мрачный"), "weight": ("лёгкий", "тяжёлый"),
        "tempo": ("неспешный", "динамичный"), "attention": ("можно фоном", "нужно внимание")
    ]

    /// «Стоит смотреть?»
    static let endings: [SurveyOption] = [
        SurveyOption(id: "must", title: "Обязательно"),
        SurveyOption(id: "fan", title: "Если любите такое"),
        SurveyOption(id: "skip", title: "Можно пропустить")
    ]
= [
        "must": "смотреть обязательно", "fan": "если любите такое", "skip": "можно пропустить"
    ]

    /// «С кем смотреть» — строка «Просмотр».
    static let recommend: [SurveyOption] = [
        SurveyOption(id: "alone", title: "Одному"),
        SurveyOption(id: "pair", title: "Вдвоём"),
        SurveyOption(id: "company", title: "Компанией"),
        SurveyOption(id: "family", title: "С семьёй"),
        SurveyOption(id: "kids", title: "С детьми")
    ]

    /// «Как смотрели» — впервые или пересмотр, и где.
    static let rewatch: [SurveyOption] = [
        SurveyOption(id: "first", title: "Впервые"),
        SurveyOption(id: "again", title: "Пересмотр")
    ]
    static let places: [SurveyOption] = [
        SurveyOption(id: "home", title: "Дома"),
        SurveyOption(id: "cinema", title: "В кино"),
        SurveyOption(id: "road", title: "В дороге")
    ]
    static let company: [SurveyOption] = []
    static let rewatchShort: [String: String] = ["first": "впервые", "again": "пересмотр"]

    /// «Заключение» в карточке фильма.
    static let verdictCard: [String: String] = [
        "must": "Обязательно к просмотру", "fan": "Смотреть, если любите такое", "skip": "Можно пропустить"
    ]
    static let verdictShort: [String: String] = [
        "must": "обязательно к просмотру", "fan": "если любите такое", "skip": "можно пропустить"
    ]

    /// Ответы анкеты для карточки фильма: заголовок и капсулы с ответами.
    /// «Основное», «Настроение», «Сильное», «Слабое», «Просмотр» и в конце «Заключение». Пустые пропускаются.
    static func pointGroups(_ s: SurveyEntry) -> [(title: String, answers: [String])] {
        var result: [(title: String, answers: [String])] = []
        let main = emotions.map(\.id).filter { s.emotions.contains($0) }.compactMap { emotionNouns[$0] }.map(capitalized)
        if !main.isEmpty { result.append((title: "Основное", answers: main)) }
        let values = s.scaleValues()
        let mood = scales.compactMap { scale -> String? in
            guard let v = values[scale.id], v != 0, let words = scaleWords[scale.id] else { return nil }
            return capitalized(v < 0 ? words.0 : words.1)
        }
        if !mood.isEmpty { result.append((title: "Настроение", answers: mood)) }
        let sides = s.aspectValues()
        let strong = aspects.filter { (sides[$0.id] ?? 0) >= 4 }.map(\.title)
        if !strong.isEmpty { result.append((title: "Сильное", answers: strong)) }
        let weak = weaknesses.filter { (sides[$0.id] ?? 0) == 1 }.map(\.title)
        if !weak.isEmpty { result.append((title: "Слабое", answers: weak)) }
        let with = recommend.filter { s.recommend.contains($0.id) }.map(\.title)
        if !with.isEmpty { result.append((title: "Просмотр", answers: with)) }
        if let verdict = verdictCard[s.ending] { result.append((title: "Заключение", answers: [verdict])) }
        return result
    }

    /// Те же пункты одной строкой — для карточки в соцсети.
    static func points(_ s: SurveyEntry) -> [(title: String, value: String)] {
        pointGroups(s).map { (title: $0.title, value: $0.answers.joined(separator: ", ")) }
    }

    static func capitalized(_ text: String) -> String {
        text.prefix(1).uppercased() + text.dropFirst()
    }

    static let wordSuggestions = ["Шедевр", "Гипноз", "Тепло", "Тягуче", "Неожиданно", "Пусто"]

    static let essayPrompts = [
        "Что я почувствовал в финале?",
        "Какая сцена не отпускает?",
        "С чем этот фильм хочется сравнить?",
        "Что бы я спросил у режиссёра?"
    ]

    static func ratingLabel(_ rating: Int) -> String {
        switch rating {
        case 1...3: return "Не моё"
        case 4...5: return "Так себе"
        case 6...7: return "Хорошо"
        case 8...9: return "Отлично"
        case 10: return "Шедевр"
        default: return ""
        }
    }

    static func titles(for ids: [String], in options: [SurveyOption]) -> [String] {
        options.filter { ids.contains($0.id) }.map(\.title)
    }

    static func title(for id: String, in options: [SurveyOption]) -> String? {
        options.first { $0.id == id }?.title
    }
}

/// Профиль вкуса, посчитанный по анкетам.
struct TasteProfile {
    struct Bar: Identifiable {
        let id: String
        let title: String
        let value: Double // 0…1
        let label: String
    }

    struct Count: Identifiable {
        let id: String
        let title: String
        let count: Int
    }

    struct Axis: Identifiable {
        let id: String
        let title: String
        let left: String
        let right: String
        let leftFilm: String
        let rightFilm: String
        let value: Double // −1…1
    }

    let seenCount: Int
    let surveyCount: Int
    let essayCount: Int
    let essayWords: Int
    let averageRating: Double?
    let favoriteDecade: String?
    let favoriteDirector: String?
    /// Архетип зрителя — главный итог анкет.
    let archetype: Archetype?
    /// Второй по силе архетип.
    let secondArchetype: Archetype?
    let reason: String?
    let aspects: [Bar]
    let axes: [Axis]
    let feelings: [Count]
    let words: [Count]
    let favoriteIDs: [String]

    init(surveys: [SurveyEntry], seenFilms: [FilmItem]) {
        seenCount = seenFilms.count
        surveyCount = surveys.count

        // Эссе.
        let essays = surveys.map { $0.essay.trimmingCharacters(in: .whitespacesAndNewlines) }.filter { !$0.isEmpty }
        essayCount = essays.count
        essayWords = essays.reduce(0) { $0 + $1.split(whereSeparator: { $0.isWhitespace || $0.isNewline }).count }

        // Средняя оценка.
        let ratings = surveys.map(\.rating).filter { $0 > 0 }
        averageRating = ratings.isEmpty ? nil : Double(ratings.reduce(0, +)) / Double(ratings.count)

        // Любимое десятилетие и режиссёр — по просмотренным.
        var decades: [Int: Int] = [:]
        var directors: [String: Int] = [:]
        for film in seenFilms {
            if let year = film.year { decades[(year / 10) * 10, default: 0] += 1 }
            if let surname = film.directorSurname { directors[surname, default: 0] += 1 }
        }
        if let best = decades.max(by: { $0.value == $1.value ? $0.key < $1.key : $0.value < $1.value })?.key {
            favoriteDecade = best < 2000 ? "\(best % 100)-е" : "\(best)-е"
        } else {
            favoriteDecade = nil
        }
        if let top = directors.max(by: { $0.value == $1.value ? $0.key > $1.key : $0.value < $1.value }), top.value >= 2 {
            favoriteDirector = top.key
        } else {
            favoriteDirector = nil
        }

        // Стороны фильма: средняя оценка 1–5.
        var aspectSum: [String: Double] = [:]
        var aspectCount: [String: Double] = [:]
        for survey in surveys {
            var values = survey.aspectValues()
            if values.isEmpty {
                for hook in survey.hooks {
                    if let aspect = SurveyOptions.legacyHookToAspect[hook] { values[aspect] = 5 }
                }
            }
            for (key, value) in values where value > 0 {
                aspectSum[key, default: 0] += Double(value)
                aspectCount[key, default: 0] += 1
            }
        }
        var aspectAverage: [String: Double] = [:]
        for (key, sum) in aspectSum {
            aspectAverage[key] = sum / max(1, aspectCount[key] ?? 1)
        }
        // Сильные стороны: как часто вы отмечаете каждую.
        var strongCount: [String: Int] = [:]
        for survey in surveys {
            for (key, value) in survey.aspectValues() where value >= 4 { strongCount[key, default: 0] += 1 }
        }
        let maxStrong = Double(max(1, strongCount.values.max() ?? 1))
        aspects = SurveyOptions.aspects
            .compactMap { option -> Bar? in
                guard let n = strongCount[option.id], n > 0 else { return nil }
                return Bar(id: option.id, title: option.title, value: Double(n) / maxStrong, label: "\(n)")
            }
            .sorted { $0.value > $1.value }

        // Шкалы: какое кино вам нравится. Фильмы с высокой оценкой весят больше.
        var scaleSum: [String: Double] = [:]
        var scaleWeight: [String: Double] = [:]
        for survey in surveys {
            let weight: Double
            switch survey.rating {
            case 0: weight = 1
            case 1...4: weight = 0.25
            case 5...6: weight = 0.7
            case 7...8: weight = 1.5
            default: weight = 2.5
            }
            for (key, value) in survey.scaleValues() {
                scaleSum[key, default: 0] += Double(value) * weight
                scaleWeight[key, default: 0] += weight
            }
        }
        var scaleAverage: [String: Double] = [:]
        for (key, sum) in scaleSum {
            if let w = scaleWeight[key], w > 0 { scaleAverage[key] = sum / w / 2 } // −1…1
        }
        axes = SurveyOptions.scales.compactMap { scale -> Axis? in
            guard let value = scaleAverage[scale.id] else { return nil }
            return Axis(id: scale.id, title: scale.title, left: scale.left, right: scale.right,
                        leftFilm: scale.leftFilm, rightFilm: scale.rightFilm, value: max(-1, min(1, value)))
        }

        // Чувства.
        var emotionCounts: [String: Int] = [:]
        for survey in surveys { for e in survey.emotions { emotionCounts[e, default: 0] += 1 } }
        feelings = SurveyOptions.emotions
            .compactMap { (option: SurveyOption) -> Count? in
                guard let n = emotionCounts[option.id], n > 0 else { return nil }
                return Count(id: option.id,
                             title: SurveyOptions.capitalized(SurveyOptions.emotionNouns[option.id] ?? option.title),
                             count: n)
            }
            .sorted { $0.count > $1.count }
            .prefix(5)
            .map { $0 }

        // Слова о кино.
        var wordCounts: [String: Int] = [:]
        var order: [String] = []
        for survey in surveys.sorted(by: { $0.date > $1.date }) {
            let w = survey.word.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
            guard !w.isEmpty else { continue }
            if wordCounts[w] == nil { order.append(w) }
            wordCounts[w, default: 0] += 1
        }
        words = order.prefix(14).map { Count(id: $0, title: $0, count: wordCounts[$0] ?? 1) }

        // Любимые фильмы: высокие оценки, затем «пересмотрю».
        let sortedFavorites = surveys
            .filter { $0.rating >= 8 || ($0.rating == 0 && $0.rewatch == "yes") }
            .sorted { $0.rating == $1.rating ? $0.date > $1.date : $0.rating > $1.rating }
        favoriteIDs = sortedFavorites.prefix(10).map(\.filmID)

        // Архетип зрителя.
        if surveys.isEmpty {
            archetype = nil
            secondArchetype = nil
            reason = nil
        } else {
            let scored = TasteProfile.archetypeScores(
                surveys: surveys,
                seenFilms: seenFilms,
                aspectAverage: aspectAverage,
                scaleAverage: scaleAverage,
                emotionCounts: emotionCounts
            )
            archetype = scored.first?.0
            secondArchetype = scored.count > 1 && scored[1].1 > 0 ? scored[1].0 : nil

            var parts: [String] = []
            if let topAspect = aspects.first {
                parts.append("в фильмах вы цените «\(topAspect.title.lowercased())»")
            }
            if let strongest = axes.max(by: { abs($0.value) < abs($1.value) }), abs(strongest.value) >= 0.25 {
                let side = strongest.value < 0 ? strongest.leftFilm : strongest.rightFilm
                parts.append("любите \(side) кино")
            }
            if let feeling = feelings.first, let noun = SurveyOptions.emotionNouns[feeling.id] {
                parts.append("чаще всего кино даёт вам «\(noun)»")
            }
            let n = surveys.count
            let surveysWord = TasteProfile.plural(n, "анкете", "анкетам", "анкетам")
            reason = parts.isEmpty ? nil : "По \(n) \(surveysWord): " + parts.joined(separator: ", ") + "."
        }
    }

    /// Правило определения архетипа. Для каждого из 12 архетипов складываются:
    /// - архетипы фильмов, которые вы оценили высоко (самый сильный признак);
    /// - оценки сторон фильма, которые этот архетип ценит;
    /// - шкалы (темп, настроение, сложность, предсказуемость) в нужную сторону;
    /// - чувства из анкет, которые ему свойственны.
    static func archetypeScores(
        surveys: [SurveyEntry],
        seenFilms: [FilmItem],
        aspectAverage: [String: Double],
        scaleAverage: [String: Double],
        emotionCounts: [String: Int]
    ) -> [(Archetype, Double)] {
        let total = Double(max(1, surveys.count))
        var films: [String: FilmItem] = [:]
        for film in seenFilms { films[film.id] = film }

        // Архетипы любимых фильмов: оценка 8–10 тянет к архетипу, 1–4 — отталкивает.
        var affinity: [Archetype: Double] = [:]
        for survey in surveys {
            guard let film = films[survey.filmID] else { continue }
            let weight: Double
            switch survey.rating {
            case 0: weight = survey.rewatch == "yes" ? 0.8 : 0.3
            case 1...4: weight = -0.5
            case 5...6: weight = 0.2
            case 7: weight = 0.6
            case 8: weight = 1.0
            default: weight = 1.4
            }
            for raw in film.archetypes {
                if let a = Archetype(rawValue: raw) { affinity[a, default: 0] += weight }
            }
        }

        func aspect(_ key: String) -> Double { (aspectAverage[key] ?? 3) - 3 }          // −2…2
        func scale(_ key: String) -> Double { (scaleAverage[key] ?? 0) * 2 }            // −2…2
        func emotion(_ key: String) -> Double { Double(emotionCounts[key] ?? 0) / total * 2 }

        return Archetype.allCases
            .map { a -> (Archetype, Double) in
                var score = (affinity[a] ?? 0) / total * 3
                score += a.aspects.reduce(0) { $0 + aspect($1) * 0.4 }
                score += a.scales.reduce(0) { $0 + scale($1.0) * $1.1 * 0.35 }
                score += a.feelings.reduce(0) { $0 + emotion($1) * 0.45 }
                return (a, score)
            }
            .sorted { $0.1 == $1.1 ? $0.0.order < $1.0.order : $0.1 > $1.1 }
    }

    /// Склонение: 1 фильм, 2 фильма, 5 фильмов.
    static func plural(_ n: Int, _ one: String, _ few: String, _ many: String) -> String {
        let mod10 = n % 10
        let mod100 = n % 100
        if mod10 == 1 && mod100 != 11 { return one }
        if (2...4).contains(mod10) && !(12...14).contains(mod100) { return few }
        return many
    }
}
