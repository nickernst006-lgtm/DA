-- ance: новая анкета — «Где посоветуете смотреть».
-- Вставить целиком в SQL Editor и нажать Run. Можно запускать повторно. Требует 0001–0007.

alter table public.surveys add column if not exists recommend_places text[] not null default '{}';

select 'Готово: анкета обновлена' as "Результат";
