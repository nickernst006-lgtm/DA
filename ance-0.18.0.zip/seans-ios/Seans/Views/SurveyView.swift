import SwiftUI
import SwiftData

/// Анкета после просмотра: оценка, одно слово, что дал фильм, каким он был, сильные и слабые стороны,
/// как и с кем смотрели (и где и с кем посоветуете), стоит ли смотреть и эссе.
@MainActor
struct SurveyView: View {
    let film: FilmItem
    /// Открыть сразу на шаге эссе.
    var startAtEssay = false

    @Environment(\.modelContext) private var context
    @Environment(\.dismiss) private var dismiss

    private enum Field: Hashable { case word, essay }

    @State private var step = 0
    @State private var rating = 0
    @State private var emotions: Set<String> = []
    @State private var aspects: [String: Int] = [:]
    @State private var scales: [String: Int] = [:]
    @State private var ending = ""
    @State private var company = ""
    @State private var place = ""
    @State private var rewatch = ""
    @State private var recommend: Set<String> = []
    @State private var recommendPlaces: Set<String> = []
    @State private var word = ""
    @State private var essay = ""
    /// Эссе с цитатами и фото — собирается на последнем шаге.
    @State private var essayDraft: EssayDraft?
    @FocusState private var essayFocus: UUID?
    @State private var didLoad = false
    @FocusState private var focus: Field?

    /// Шаги 0…8 — вопросы; «Готово» на эссе сохраняет анкету и закрывает её.
    private let questionCount = 9
    private let essayStepIndex = 8

    var body: some View {
        VStack(spacing: 0) {
            header
            ScrollView {
                VStack(alignment: .leading, spacing: ScreenLayout.blockGap) {
                    switch step {
                    case 0: ratingStep
                    case 1: wordStep
                    case 2: emotionsStep
                    case 3: scalesStep
                    case 4: aspectsStep
                    case 5: contextStep
                    case 6: companyStep
                    case 7: verdictStep
                    default: essayStep
                    }
                }
                .padding(.horizontal, Space.s20)
                .padding(.top, Space.s32)
                .padding(.bottom, Space.s24)
                .frame(maxWidth: .infinity, alignment: .leading)
            }
            .scrollDismissesKeyboard(.interactively)
            footer
        }
        .background(Theme.background.ignoresSafeArea())
        .onAppear(perform: loadExisting)
        .animation(.easeInOut(duration: 0.2), value: step)
    }

    // MARK: Шапка и прогресс

    private var header: some View {
        VStack(spacing: Space.s16) {
            HStack {
                CloseButton(label: "Закрыть анкету") { dismiss() }
                Spacer()
                Text(film.title)
                    .textStyle(.sub, .bold)
                    .foregroundStyle(Theme.text)
                    .lineLimit(1)
                Spacer()
                Text(step < questionCount ? "\(step + 1)/\(questionCount)" : "")
                    .textStyle(.caption, .medium)
                    .foregroundStyle(Theme.muted)
                    .frame(width: 44, alignment: .trailing)
            }
            HStack(spacing: Space.s4) {
                ForEach(0..<questionCount, id: \.self) { i in
                    Capsule()
                        .fill(i <= step ? Theme.text : Theme.lineStrong)
                        .frame(height: 3)
                }
            }
            .accessibilityHidden(true)
        }
        .padding(.horizontal, Space.s20)
        .padding(.top, Space.s12)
    }

    private func question(_ title: String, hint: String? = nil) -> some View {
        VStack(alignment: .leading, spacing: Space.s8) {
            Text(title)
                .textStyle(.h1)
                .foregroundStyle(Theme.text)
                .fixedSize(horizontal: false, vertical: true)
                .accessibilityAddTraits(.isHeader)
            if let hint {
                Text(hint)
                    .textStyle(.sub)
                    .foregroundStyle(Theme.muted)
                    .fixedSize(horizontal: false, vertical: true)
            }
        }
    }

    private func groupLabel(_ text: String) -> some View {
        Text(text)
            .textStyle(.caption, .medium)
            .foregroundStyle(Theme.muted)
            .textCase(nil)
    }

    // MARK: 1. Оценка

    private var ratingStep: some View {
        VStack(alignment: .leading, spacing: ScreenLayout.blockGap) {
            question("Ваша оценка")
            LazyVGrid(columns: Array(repeating: GridItem(.flexible(), spacing: Space.s8), count: 5), spacing: Space.s8) {
                ForEach(1...10, id: \.self) { value in
                    let isSelected = rating == value
                    Button {
                        rating = value
                    } label: {
                        Text("\(value)")
                            .textStyle(.h2)
                            .foregroundStyle(isSelected ? Color.black : Theme.text)
                            .frame(maxWidth: .infinity, minHeight: 60)
                            .background(
                                RoundedRectangle(cornerRadius: Radius.medium, style: .continuous)
                                    .fill(isSelected ? Theme.text : Theme.surface)
                            )
                    }
                    .buttonStyle(.plain)
                    .accessibilityLabel("\(value) из 10")
                    .accessibilityAddTraits(isSelected ? .isSelected : [])
                }
            }
            .sensoryFeedback(.selection, trigger: rating)
            Text(rating > 0 ? SurveyOptions.ratingLabel(rating) : "Нажмите на число")
                .textStyle(.h2, .medium)
                .foregroundStyle(rating > 0 ? Theme.accent : Theme.muted)
        }
    }

    // MARK: 3. Что дал фильм

    private var emotionsStep: some View {
        let full = emotions.count >= SurveyOptions.mainLimit
        return VStack(alignment: .leading, spacing: ScreenLayout.blockGap) {
            question("Что дал фильм?", hint: emotions.isEmpty ? "До трёх ответов" : "До трёх ответов · выбрано \(emotions.count)")
            ForEach(SurveyOptions.emotionGroups) { group in
                VStack(alignment: .leading, spacing: ScreenLayout.groupLabelGap) {
                    groupHeader(group.title)
                    FlowLayout(spacing: Space.s8, lineSpacing: 8) {
                        ForEach(group.options) { option in
                            AnswerChip(title: option.title, look: emotionLook(option.id, full: full), height: 40) {
                                toggleLimited(option.id, in: &emotions, limit: SurveyOptions.mainLimit)
                            }
                        }
                    }
                }
            }
        }
        .sensoryFeedback(.selection, trigger: emotions)
    }

    private func emotionLook(_ id: String, full: Bool) -> AnswerChip.Look {
        if emotions.contains(id) { return .selected }
        return full ? .dimmed : .normal
    }

    /// Подпись группы ответов; справа — счётчик, если нужен.
    private func groupHeader(_ title: String, trailing: String? = nil) -> some View {
        HStack(alignment: .firstTextBaseline) {
            Text(title)
                .textStyle(.caption, .medium, tracking: 0.8)
                .textCase(.uppercase)
                .foregroundStyle(Theme.muted)
            Spacer(minLength: Space.s8)
            if let trailing {
                Text(trailing)
                    .textStyle(.caption)
                    .foregroundStyle(Theme.muted)
            }
        }
        .padding(.horizontal, ScreenLayout.textInset)
        .accessibilityAddTraits(.isHeader)
    }

    // MARK: 5. Сильные и слабые стороны

    private var aspectsStep: some View {
        VStack(alignment: .leading, spacing: ScreenLayout.blockGap) {
            question("Сильные и слабые стороны", hint: "До трёх в каждой группе")
            sideGroup("Сильные стороны", value: 5)
            sideGroup("Слабые стороны", value: 1)
        }
        .sensoryFeedback(.selection, trigger: aspects)
    }

    /// Группа сторон: сильные хранятся как 5, слабые — как 1. Список один и тот же;
    /// отмеченное в другой группе здесь зачёркнуто.
    private func sideGroup(_ label: String, value: Int) -> some View {
        let chosen = aspects.values.filter { $0 == value }.count
        return VStack(alignment: .leading, spacing: ScreenLayout.groupLabelGap) {
            groupHeader(label, trailing: "\(chosen) из \(SurveyOptions.sideLimit)")
            FlowLayout(spacing: Space.s8, lineSpacing: 8) {
                ForEach(SurveyOptions.aspects) { option in
                    AnswerChip(title: option.title, look: sideLook(option.id, value: value, chosen: chosen), height: 44) {
                        let current = aspects[option.id]
                        if current == value {
                            aspects[option.id] = nil
                        } else if current == nil && chosen < SurveyOptions.sideLimit {
                            aspects[option.id] = value
                        }
                    }
                }
            }
        }
    }

    private func sideLook(_ id: String, value: Int, chosen: Int) -> AnswerChip.Look {
        guard let current = aspects[id] else {
            return chosen >= SurveyOptions.sideLimit ? .dimmed : .normal
        }
        if current == value { return value == 1 ? .bad : .selected }
        return .struck
    }

    // MARK: 4. Шкалы

    private var scalesStep: some View {
        VStack(alignment: .leading, spacing: ScreenLayout.blockGap) {
            question("Каким он был?", hint: "Можно пропустить любую шкалу")
            VStack(spacing: Space.s12) {
                ForEach(SurveyOptions.scales) { scale in
                    scaleRow(scale)
                }
            }
        }
    }

    private static let scaleSteps = ["Очень", "Скорее", "Средне", "Скорее", "Очень"]

    /// Шкала: название крупно, выбранное значение справа жёлтым, пять одинаковых кнопок, направления под ними.
    private func scaleRow(_ scale: SurveyScale) -> some View {
        let selected = scales[scale.id]
        return VStack(alignment: .leading, spacing: Space.s12) {
            HStack(alignment: .firstTextBaseline) {
                Text(scale.title)
                    .textStyle(.body, .bold)
                    .foregroundStyle(Theme.text)
                Spacer(minLength: Space.s8)
                if let selected {
                    Text(scaleAccessibilityValue(scale, selected))
                        .textStyle(.sub, .medium)
                        .foregroundStyle(Theme.accent)
                        .lineLimit(1)
                        .minimumScaleFactor(0.8)
                }
            }
            HStack(spacing: 6) {
                ForEach(-2...2, id: \.self) { v in
                    scaleButton(scale, value: v, isOn: selected == v)
                }
            }
            HStack {
                Text("← " + scale.left)
                Spacer(minLength: Space.s8)
                Text(scale.right + " →")
            }
            .textStyle(.caption, .medium)
            .foregroundStyle(Theme.muted)
        }
        .padding(Space.s16)
        .background(RoundedRectangle(cornerRadius: 24, style: .continuous).fill(Theme.surface))
        .sensoryFeedback(.selection, trigger: selected)
        .accessibilityElement(children: .ignore)
        .accessibilityLabel("\(scale.title): от «\(scale.left)» до «\(scale.right)»")
        .accessibilityValue(selected.map { scaleAccessibilityValue(scale, $0) } ?? "не отмечено")
        .accessibilityAdjustableAction { direction in
            let current = selected ?? 0
            switch direction {
            case .increment: scales[scale.id] = min(2, current + 1)
            case .decrement: scales[scale.id] = max(-2, current - 1)
            @unknown default: break
            }
        }
    }

    private func scaleButton(_ scale: SurveyScale, value: Int, isOn: Bool) -> some View {
        Button {
            scales[scale.id] = isOn ? nil : value
        } label: {
            Text(SurveyView.scaleSteps[value + 2])
                .textStyle(.caption, .bold)
                .foregroundStyle(isOn ? Color.black : Theme.textSecondary)
                .lineLimit(1)
                .minimumScaleFactor(0.75)
                .frame(maxWidth: .infinity, minHeight: 44)
                .background(
                    RoundedRectangle(cornerRadius: Radius.medium, style: .continuous)
                        .fill(isOn ? Theme.text : Theme.dockButton)
                )
        }
        .buttonStyle(.plain)
    }

    private func scaleAccessibilityValue(_ scale: SurveyScale, _ value: Int) -> String {
        switch value {
        case -2: return "очень \(scale.left.lowercased())"
        case -1: return "скорее \(scale.left.lowercased())"
        case 0: return "средне"
        case 1: return "скорее \(scale.right.lowercased())"
        default: return "очень \(scale.right.lowercased())"
        }
    }

    // MARK: 6. Как смотрели

    private var contextStep: some View {
        VStack(alignment: .leading, spacing: ScreenLayout.blockGap) {
            question("Как смотрели?")
            singleChoice("Впервые или пересмотр", options: SurveyOptions.rewatch, selection: $rewatch)
            singleChoice("Где смотрели", options: SurveyOptions.places, selection: $place)
            multiChoice("Где посоветуете смотреть", options: SurveyOptions.places, selection: $recommendPlaces)
        }
    }

    // MARK: 7. С кем смотрели

    private var companyStep: some View {
        VStack(alignment: .leading, spacing: ScreenLayout.blockGap) {
            question("С кем смотрели?")
            singleChoice("С кем смотрели", options: SurveyOptions.recommend, selection: $company, height: 48)
            multiChoice("С кем посоветуете смотреть", options: SurveyOptions.recommend, selection: $recommend, height: 48)
        }
    }

    private func singleChoice(_ label: String, options: [SurveyOption], selection: Binding<String>, height: CGFloat = 44) -> some View {
        VStack(alignment: .leading, spacing: ScreenLayout.groupLabelGap) {
            GroupLabel(label)
            FlowLayout(spacing: Space.s8, lineSpacing: 8) {
                ForEach(options) { option in
                    Chip(title: option.title, isSelected: selection.wrappedValue == option.id, height: height) {
                        selection.wrappedValue = selection.wrappedValue == option.id ? "" : option.id
                    }
                }
            }
        }
    }

    private func multiChoice(_ label: String, options: [SurveyOption], selection: Binding<Set<String>>, height: CGFloat = 44) -> some View {
        VStack(alignment: .leading, spacing: ScreenLayout.groupLabelGap) {
            GroupLabel(label)
            FlowLayout(spacing: Space.s8, lineSpacing: 8) {
                ForEach(options) { option in
                    Chip(title: option.title, isSelected: selection.wrappedValue.contains(option.id), height: height) {
                        if selection.wrappedValue.contains(option.id) {
                            selection.wrappedValue.remove(option.id)
                        } else {
                            selection.wrappedValue.insert(option.id)
                        }
                    }
                }
            }
        }
    }

    // MARK: 8. Стоит смотреть

    private var verdictStep: some View {
        VStack(alignment: .leading, spacing: ScreenLayout.blockGap) {
            question("Стоит смотреть?")
            VStack(spacing: Space.s8) {
                ForEach(SurveyOptions.endings) { option in
                    let isSelected = ending == option.id
                    Button {
                        ending = isSelected ? "" : option.id
                    } label: {
                        Text(option.title)
                            .textStyle(.body, .bold)
                            .foregroundStyle(isSelected ? Color.black : Theme.text)
                            .frame(maxWidth: .infinity, minHeight: 56, alignment: .leading)
                            .padding(.horizontal, Space.s16)
                            .background(
                                RoundedRectangle(cornerRadius: 20, style: .continuous)
                                    .fill(isSelected ? Theme.text : Theme.surface)
                            )
                    }
                    .buttonStyle(.plain)
                    .accessibilityAddTraits(isSelected ? .isSelected : [])
                }
            }
            .sensoryFeedback(.selection, trigger: ending)
        }
    }

    // MARK: 7. Слово

    private var wordStep: some View {
        VStack(alignment: .leading, spacing: ScreenLayout.blockGap) {
            question("Одним словом", hint: "Выберите или напишите своё")
            TextField("", text: $word, prompt: Text("Ваше слово").foregroundColor(Theme.muted))
                .textStyle(.h2)
                .foregroundStyle(Theme.text)
                .focused($focus, equals: .word)
                .submitLabel(.done)
                .padding(.horizontal, Space.s16)
                .frame(minHeight: 60)
                .background(RoundedRectangle(cornerRadius: Radius.medium, style: .continuous).fill(Theme.surface))
                .accessibilityLabel("Одно слово о фильме")
                .onChange(of: word) { _, newValue in
                    if newValue.count > 24 { word = String(newValue.prefix(24)) }
                }
            wordGroup("Понравилось", SurveyOptions.wordsPositive)
            wordGroup("Не очень", SurveyOptions.wordsNegative)
        }
    }

    private func wordGroup(_ title: String, _ words: [String]) -> some View {
        VStack(alignment: .leading, spacing: ScreenLayout.groupLabelGap) {
            groupHeader(title)
            FlowLayout(spacing: Space.s8, lineSpacing: 8) {
                ForEach(words, id: \.self) { suggestion in
                    Chip(title: suggestion, isSelected: word == suggestion, height: 44) {
                        word = word == suggestion ? "" : suggestion
                    }
                }
            }
        }
    }

    /// Подпись главной кнопки: «Дальше», перед эссе — «К эссе», на эссе — «Готово».
    private var nextTitle: String {
        if step == essayStepIndex { return "Готово" }
        return step == essayStepIndex - 1 ? "К эссе" : "Дальше"
    }

    // MARK: 9. Эссе

    private var essayStep: some View {
        VStack(alignment: .leading, spacing: ScreenLayout.blockGap) {
            question("Эссе", hint: "Ваш отзыв о фильме. Можно вставить цитату и до 10 фото.")
            if let essayDraft {
                EssayComposer(draft: essayDraft, focused: $essayFocus)
                    .frame(minHeight: 160, alignment: .top)
                    .plate()
                EssayTools(draft: essayDraft, focused: essayFocus) { essayFocus = $0 }
                Text(essayWordCount == 0 ? "Можно пропустить" : "\(essayWordCount) \(TasteProfile.plural(essayWordCount, "слово", "слова", "слов"))")
                    .textStyle(.caption)
                    .foregroundStyle(Theme.muted)
                    .padding(.horizontal, ScreenLayout.textInset)
            }
        }
    }

    private var essayWordCount: Int {
        EssayFormat.plain(essayDraft?.text ?? essay).split(whereSeparator: { $0.isWhitespace || $0.isNewline }).count
    }

    // MARK: Нижние кнопки

    private var footer: some View {
        HStack(spacing: Space.s8) {
            if step > 0 && step < questionCount && !(startAtEssay && step == essayStepIndex) {
                Button {
                    focus = nil
                    step -= 1
                } label: {
                    Image(systemName: "arrow.left")
                        .font(.system(size: 17, weight: .medium))
                        .foregroundStyle(Theme.text)
                        .frame(width: 52, height: 52)
                        .background(RoundedRectangle(cornerRadius: Radius.medium, style: .continuous).fill(Theme.surface))
                }
                .buttonStyle(.plain)
                .accessibilityLabel("Назад")
            }
            Button(nextTitle) {
                focus = nil
                if step == essayStepIndex {
                    save()
                    dismiss()
                } else {
                    step += 1
                }
            }
            .buttonStyle(PrimaryButtonStyle())
        }
        .padding(.horizontal, Space.s20)
        .padding(.top, Space.s8)
        .padding(.bottom, Space.s12)
    }

    // MARK: Логика

    private var trimmedWord: String {
        word.trimmingCharacters(in: .whitespacesAndNewlines)
    }

    private func toggleLimited(_ id: String, in set: inout Set<String>, limit: Int) {
        if set.contains(id) { set.remove(id) } else if set.count < limit { set.insert(id) }
    }

    private func toggle(_ id: String, in set: inout Set<String>) {
        if set.contains(id) { set.remove(id) } else { set.insert(id) }
    }

    private func loadExisting() {
        guard !didLoad else { return }
        didLoad = true
        if let existing = CollectionActions.survey(for: film.id, in: context) {
            rating = existing.rating
            emotions = Set(existing.emotions)
            aspects = existing.aspectValues()
            scales = existing.scaleValues()
            ending = existing.ending
            company = existing.company
            place = existing.place
            rewatch = existing.rewatch
            recommend = Set(existing.recommend)
            recommendPlaces = Set(existing.recommendPlaces)
            word = existing.word
            essay = existing.essay
        }
        essayDraft = EssayDraft(essay: essay, photos: EssayPhotos.photos(for: film.id, in: context))
        if startAtEssay { step = essayStepIndex }
    }

    private func save() {
        let entry = CollectionActions.survey(for: film.id, in: context) ?? {
            let created = SurveyEntry(filmID: film.id)
            context.insert(created)
            return created
        }()
        entry.date = Date()
        entry.rating = rating
        entry.emotions = SurveyOptions.emotions.map(\.id).filter { emotions.contains($0) }
        entry.setAspects(aspects.filter { $0.value > 0 })
        entry.setScales(scales)
        entry.ending = ending
        entry.company = company
        entry.place = place
        entry.rewatch = rewatch
        entry.recommend = SurveyOptions.recommend.map(\.id).filter { recommend.contains($0) }
        entry.recommendPlaces = SurveyOptions.places.map(\.id).filter { recommendPlaces.contains($0) }
        entry.word = trimmedWord
        if let essayDraft {
            essayDraft.apply(filmID: film.id, entry: entry, in: context)
            essay = entry.essay
        } else {
            entry.essay = essay.trimmingCharacters(in: .whitespacesAndNewlines)
        }
        // Если фильм ещё не отмечен как просмотренный — отмечаем.
        if CollectionActions.item(for: film.id, in: context)?.status != .seen {
            CollectionActions.setStatus(.seen, for: film.id, in: context)
        }
        try? context.save()
    }

}

/// Вариант ответа в анкете: обычный, выбранный, выбранный как слабая сторона, бледный (лимит набран)
/// или зачёркнутый (уже отмечен в другой группе).
private struct AnswerChip: View {
    enum Look { case normal, selected, bad, dimmed, struck }

    let title: String
    let look: Look
    var height: CGFloat = 44
    let action: () -> Void

    private var isOn: Bool { look == .selected || look == .bad }

    private var fill: Color {
        switch look {
        case .selected: return Theme.text
        case .bad: return Color(hex: 0xE5735F)
        default: return Theme.surface
        }
    }

    var body: some View {
        Button(action: action) {
            Text(title)
                .strikethrough(look == .struck)
                .textStyle(.sub, .medium)
                .foregroundStyle(isOn ? Color.black : Theme.text)
                .padding(.horizontal, Space.s16)
                .frame(minHeight: height)
                .background(Capsule().fill(fill))
                .opacity(look == .dimmed || look == .struck ? 0.35 : 1)
        }
        .buttonStyle(.plain)
        .accessibilityAddTraits(isOn ? .isSelected : [])
    }
}
