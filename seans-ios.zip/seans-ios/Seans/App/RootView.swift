import SwiftUI

enum AppTab: String, CaseIterable, Identifiable {
    case afisha, collection, taste

    var id: String { rawValue }

    var title: String {
        switch self {
        case .afisha: return "Афиша"
        case .collection: return "Коллекция"
        case .taste: return "Вкусы"
        }
    }

    var icon: String {
        switch self {
        case .afisha: return "ticket"
        case .collection: return "rectangle.stack"
        case .taste: return "sparkle"
        }
    }
}

struct RootView: View {
    @AppStorage("didFinishWelcome") private var didFinishWelcome = false
    @State private var showSplash = true

    var body: some View {
        ZStack {
            Theme.background.ignoresSafeArea()

            if didFinishWelcome {
                MainTabsView()
            } else {
                WelcomeView {
                    withAnimation(.easeInOut(duration: 0.35)) { didFinishWelcome = true }
                }
            }

            if showSplash {
                SplashView()
                    .transition(.opacity)
                    .zIndex(1)
            }
        }
        .task {
            try? await Task.sleep(nanoseconds: 1_800_000_000)
            withAnimation(.easeInOut(duration: 0.5)) { showSplash = false }
        }
    }
}

/// Три вкладки и нижняя панель в стиле дока iPhone.
struct MainTabsView: View {
    @State private var tab: AppTab = .afisha

    var body: some View {
        VStack(spacing: 0) {
            ZStack {
                AfishaView()
                    .opacity(tab == .afisha ? 1 : 0)
                    .allowsHitTesting(tab == .afisha)
                    .accessibilityHidden(tab != .afisha)
                CollectionView(onBrowse: { tab = .afisha })
                    .opacity(tab == .collection ? 1 : 0)
                    .allowsHitTesting(tab == .collection)
                    .accessibilityHidden(tab != .collection)
                TasteView()
                    .opacity(tab == .taste ? 1 : 0)
                    .allowsHitTesting(tab == .taste)
                    .accessibilityHidden(tab != .taste)
            }
            DockBar(selection: $tab)
        }
        .background(Theme.background.ignoresSafeArea())
    }
}

struct DockBar: View {
    @Binding var selection: AppTab

    var body: some View {
        HStack(spacing: 0) {
            ForEach(AppTab.allCases) { tab in
                let isSelected = tab == selection
                Button {
                    selection = tab
                } label: {
                    Image(systemName: tab.icon)
                        .font(.system(size: 24, weight: .light))
                        .foregroundStyle(isSelected ? Color.black : Theme.textSecondary)
                        .frame(width: 64, height: 64)
                        .background(
                            RoundedRectangle(cornerRadius: 18, style: .continuous)
                                .fill(isSelected ? Theme.text : Theme.dockButton)
                        )
                }
                .buttonStyle(.plain)
                .frame(maxWidth: .infinity)
                .accessibilityLabel(tab.title)
                .accessibilityAddTraits(isSelected ? .isSelected : [])
            }
        }
        .padding(.vertical, 10)
        .padding(.horizontal, 14)
        .background(
            RoundedRectangle(cornerRadius: 30, style: .continuous)
                .fill(Theme.dock)
        )
        .padding(.horizontal, 16)
        .padding(.top, 6)
        .padding(.bottom, 4)
        .sensoryFeedback(.selection, trigger: selection)
    }
}

/// Заставка: на чёрном фоне плавно появляется название.
struct SplashView: View {
    @State private var visible = false

    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()
            Text("Сеанс")
                .font(AppFont.serifFixed(44))
                .tracking(-0.4)
                .foregroundStyle(Theme.text)
                .opacity(visible ? 1 : 0)
        }
        .onAppear {
            withAnimation(.easeIn(duration: 1.0).delay(0.15)) { visible = true }
        }
        .accessibilityLabel("Сеанс")
    }
}

/// Первый запуск.
struct WelcomeView: View {
    let onStart: () -> Void

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            Spacer()
            HStack(spacing: -28) {
                CoverView(film: WelcomeView.sample[0]).frame(width: 112).rotationEffect(.degrees(-8))
                CoverView(film: WelcomeView.sample[1]).frame(width: 136).zIndex(1)
                    .overlay(RoundedRectangle(cornerRadius: 12, style: .continuous).stroke(Color.black, lineWidth: 6))
                CoverView(film: WelcomeView.sample[2]).frame(width: 112).rotationEffect(.degrees(8))
            }
            .frame(maxWidth: .infinity)
            .padding(.bottom, 44)

            VStack(alignment: .leading, spacing: 14) {
                Text("Сеанс")
                    .font(AppFont.serif(44))
                    .tracking(-0.4)
                    .foregroundStyle(Theme.text)
                Text("Отмечайте фильмы, рассказывайте, как они вам, — и узнавайте свой киновкус.")
                    .font(AppFont.ui(17))
                    .foregroundStyle(Theme.textSecondary)
                    .fixedSize(horizontal: false, vertical: true)
            }

            HStack(alignment: .top, spacing: 14) {
                Image(systemName: "lock")
                    .font(.system(size: 20, weight: .light))
                    .foregroundStyle(Theme.accent)
                    .accessibilityHidden(true)
                VStack(alignment: .leading, spacing: 4) {
                    Text("Без регистрации и паролей")
                        .font(AppFont.ui(15, .semibold))
                        .foregroundStyle(Theme.text)
                    Text("Ваши фильмы и ответы хранятся только на этом iPhone. Мы их не видим и не храним.")
                        .font(AppFont.ui(14))
                        .foregroundStyle(Theme.muted)
                        .fixedSize(horizontal: false, vertical: true)
                }
            }
            .padding(.top, 20)
            .overlay(alignment: .top) {
                Rectangle().fill(Theme.line).frame(height: 1)
            }
            .padding(.top, 24)

            Spacer()

            Button("Начать", action: onStart)
                .buttonStyle(PrimaryButtonStyle())
                .padding(.bottom, 12)
        }
        .padding(.horizontal, 24)
        .background(Theme.background.ignoresSafeArea())
    }

    static let sample: [FilmItem] = [
        FilmItem(previewTitle: "Амели", year: 2001, palette: CoverPalette(base: "#8C2427", accent: "#F0BE5E", deep: "#4A1013"), photo: nil),
        FilmItem(previewTitle: "Сталкер", year: 1979, palette: CoverPalette(base: "#33402F", accent: "#D9C27A", deep: "#1B2318"), photo: nil),
        FilmItem(previewTitle: "Начало", year: 2010, palette: CoverPalette(base: "#22324A", accent: "#A9BDD3", deep: "#121B2A"), photo: nil)
    ]
}
