import SwiftUI
import UIKit

/// Цвета приложения. Все экраны — на чистом чёрном фоне.
enum Theme {
    static let background = Color.black
    static let surface = Color(hex: 0x121212)
    static let surfaceRaised = Color(hex: 0x1C1C1C)
    static let dock = Color(hex: 0x141414)
    static let dockButton = Color(hex: 0x262626)
    static let line = Color(hex: 0x1C1C1C)
    static let lineStrong = Color(hex: 0x2A2A2A)

    static let text = Color(hex: 0xF5F5F5)
    static let textSecondary = Color(hex: 0xD4D4D4)
    static let muted = Color(hex: 0x9B9B9B)

    /// Тёплый акцент — только точечно.
    static let accent = Color(hex: 0xE8B04B)
}

/// Шрифты: Noto Serif Display — для заголовков, Onest — для интерфейса.
/// Если файл шрифта почему-то не подключился, используется системный.
enum AppFont {
    private static let serifName = "NotoSerifDisplay-Medium"

    private static func uiName(_ weight: Font.Weight) -> String {
        switch weight {
        case .semibold, .bold, .heavy, .black: return "Onest-SemiBold"
        case .medium: return "Onest-Medium"
        default: return "Onest-Regular"
        }
    }

    private static func isAvailable(_ name: String) -> Bool {
        UIFont(name: name, size: 12) != nil
    }

    /// Заголовки. Масштабируется вместе с системным размером текста.
    static func serif(_ size: CGFloat, relativeTo style: Font.TextStyle = .largeTitle) -> Font {
        if isAvailable(serifName) {
            return .custom(serifName, size: size, relativeTo: style)
        }
        return .system(size: size, weight: .medium, design: .serif)
    }

    /// Заголовок фиксированного размера (для обложек, где размер зависит от самой обложки).
    static func serifFixed(_ size: CGFloat) -> Font {
        if isAvailable(serifName) {
            return .custom(serifName, fixedSize: size)
        }
        return .system(size: size, weight: .medium, design: .serif)
    }

    /// Текст интерфейса.
    static func ui(_ size: CGFloat, _ weight: Font.Weight = .regular, relativeTo style: Font.TextStyle = .body) -> Font {
        let name = uiName(weight)
        if isAvailable(name) {
            return .custom(name, size: size, relativeTo: style)
        }
        return .system(size: size, weight: weight)
    }

    static func uiFixed(_ size: CGFloat, _ weight: Font.Weight = .regular) -> Font {
        let name = uiName(weight)
        if isAvailable(name) {
            return .custom(name, fixedSize: size)
        }
        return .system(size: size, weight: weight)
    }
}

extension Color {
    init(hex: UInt32) {
        let r = Double((hex >> 16) & 0xFF) / 255
        let g = Double((hex >> 8) & 0xFF) / 255
        let b = Double(hex & 0xFF) / 255
        self.init(.sRGB, red: r, green: g, blue: b, opacity: 1)
    }

    /// Цвет из строки вида "#33402F".
    init(hexString: String, fallback: Color = .gray) {
        var cleaned = hexString.trimmingCharacters(in: .whitespacesAndNewlines)
        if cleaned.hasPrefix("#") { cleaned.removeFirst() }
        if cleaned.count == 6, let value = UInt32(cleaned, radix: 16) {
            self.init(hex: value)
        } else {
            self = fallback
        }
    }
}
