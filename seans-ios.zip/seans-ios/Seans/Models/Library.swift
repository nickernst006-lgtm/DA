import Foundation
import Observation

/// Встроенная база фильмов. Загружается из films.json внутри приложения
/// и обновляется только вместе с новой версией приложения.
@Observable
final class Library {
    let films: [FilmItem]
    private let index: [String: FilmItem]

    init(bundle: Bundle = .main) {
        var loaded: [FilmItem] = []
        if let url = bundle.url(forResource: "films", withExtension: "json"),
           let data = try? Data(contentsOf: url) {
            do {
                let decoded = try JSONDecoder().decode([CatalogFilm].self, from: data)
                loaded = decoded.map(FilmItem.init(catalog:))
            } catch {
                print("Не удалось прочитать films.json: \(error)")
            }
        }
        films = loaded
        var map: [String: FilmItem] = [:]
        for film in loaded { map[film.id] = film }
        index = map
    }

    /// Найти фильм по id — в базе или среди добавленных пользователем.
    func film(id: String, custom: [CustomFilm]) -> FilmItem? {
        if let film = index[id] { return film }
        if let own = custom.first(where: { $0.filmID == id }) { return FilmItem(custom: own) }
        return nil
    }

    func films(for mood: Mood?) -> [FilmItem] {
        guard let mood else { return films }
        return films.filter { $0.moods.contains(mood) }
    }

    func search(_ query: String, custom: [CustomFilm]) -> [FilmItem] {
        let words = query.normalizedForSearch
            .split(separator: " ")
            .map(String.init)
            .filter { !$0.isEmpty }
        guard !words.isEmpty else { return [] }
        let all = custom.map(FilmItem.init(custom:)) + films
        return all.filter { film in
            let haystack = film.searchText
            return words.allSatisfy { haystack.contains($0) }
        }
    }
}
