import Foundation
import SwiftData

/// Статус фильма в коллекции пользователя.
enum CollectionStatus: String, Codable {
    case want
    case seen
}

/// Фильм в коллекции: «Хочу посмотреть» или «Посмотрел».
/// Все данные хранятся только на устройстве.
@Model
final class CollectionItem {
    var filmID: String = ""
    var statusRaw: String = CollectionStatus.want.rawValue
    var addedAt: Date = Date()
    var seenAt: Date?

    init(filmID: String, status: CollectionStatus) {
        self.filmID = filmID
        self.statusRaw = status.rawValue
        self.addedAt = Date()
        self.seenAt = status == .seen ? Date() : nil
    }

    var status: CollectionStatus {
        get { CollectionStatus(rawValue: statusRaw) ?? .want }
        set {
            statusRaw = newValue.rawValue
            if newValue == .seen && seenAt == nil { seenAt = Date() }
            if newValue == .want { seenAt = nil }
        }
    }
}

/// Ответы на опрос после просмотра.
@Model
final class SurveyEntry {
    var filmID: String = ""
    var date: Date = Date()
    var emotions: [String] = []
    var hooks: [String] = []
    var rewatch: String = ""
    var recommend: [String] = []
    var word: String = ""

    init(filmID: String) {
        self.filmID = filmID
        self.date = Date()
    }
}

/// Фильм, который пользователь добавил сам.
@Model
final class CustomFilm {
    var filmID: String = ""
    var title: String = ""
    var year: Int?
    var director: String = ""
    var paletteIndex: Int = 0
    @Attribute(.externalStorage) var photo: Data?
    var createdAt: Date = Date()

    init(title: String, year: Int?, director: String, paletteIndex: Int, photo: Data?) {
        self.filmID = "user-" + UUID().uuidString
        self.title = title
        self.year = year
        self.director = director
        self.paletteIndex = paletteIndex
        self.photo = photo
        self.createdAt = Date()
    }
}

/// Операции с коллекцией.
enum CollectionActions {
    static func item(for filmID: String, in context: ModelContext) -> CollectionItem? {
        let descriptor = FetchDescriptor<CollectionItem>(predicate: #Predicate { $0.filmID == filmID })
        return (try? context.fetch(descriptor))?.first
    }

    static func survey(for filmID: String, in context: ModelContext) -> SurveyEntry? {
        let descriptor = FetchDescriptor<SurveyEntry>(predicate: #Predicate { $0.filmID == filmID })
        return (try? context.fetch(descriptor))?.first
    }

    /// Установить статус; nil — убрать из коллекции.
    static func setStatus(_ status: CollectionStatus?, for filmID: String, in context: ModelContext) {
        let existing = item(for: filmID, in: context)
        switch (existing, status) {
        case (nil, nil):
            break
        case (let item?, nil):
            context.delete(item)
        case (nil, let newStatus?):
            context.insert(CollectionItem(filmID: filmID, status: newStatus))
        case (let item?, let newStatus?):
            item.status = newStatus
        }
        try? context.save()
    }

    /// Удалить фильм пользователя вместе с его записями.
    static func deleteCustomFilm(_ film: CustomFilm, in context: ModelContext) {
        let id = film.filmID
        if let item = item(for: id, in: context) { context.delete(item) }
        if let survey = survey(for: id, in: context) { context.delete(survey) }
        context.delete(film)
        try? context.save()
    }
}
