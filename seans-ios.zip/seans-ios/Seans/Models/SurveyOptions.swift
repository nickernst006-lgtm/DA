import Foundation

struct SurveyOption: Identifiable, Hashable {
    let id: String
    let title: String
}

/// Варианты ответов в опросе после просмотра.
enum SurveyOptions {
    static let emotions: [SurveyOption] = [
        SurveyOption(id: "wow", title: "Восторг"),
        SurveyOption(id: "chills", title: "Мурашки"),
        SurveyOption(id: "anx", title: "Тревога"),
        SurveyOption(id: "sad", title: "Светлая грусть"),
        SurveyOption(id: "think", title: "Задумчивость"),
        SurveyOption(id: "insp", title: "Вдохновение"),
        SurveyOption(id: "warm", title: "Тепло"),
        SurveyOption(id: "laugh", title: "Смех"),
        SurveyOption(id: "bored", title: "Скука")
    ]

    static let hooks: [SurveyOption] = [
        SurveyOption(id: "atm", title: "Атмосфера"),
        SurveyOption(id: "pic", title: "Картинка"),
        SurveyOption(id: "sound", title: "Музыка и звук"),
        SurveyOption(id: "cast", title: "Актёры"),
        SurveyOption(id: "plot", title: "Сюжет"),
        SurveyOption(id: "talk", title: "Диалоги")
    ]

    static let rewatch: [SurveyOption] = [
        SurveyOption(id: "yes", title: "Обязательно пересмотрю"),
        SurveyOption(id: "maybe", title: "Может быть, когда-нибудь"),
        SurveyOption(id: "no", title: "Одного раза хватило")
    ]

    static let rewatchShort: [String: String] = [
        "yes": "Пересмотрю обязательно",
        "maybe": "Может, пересмотрю",
        "no": "Одного раза хватило"
    ]

    static let recommend: [SurveyOption] = [
        SurveyOption(id: "cinephile", title: "Другу-киноману"),
        SurveyOption(id: "date", title: "На свидание"),
        SurveyOption(id: "parents", title: "Родителям"),
        SurveyOption(id: "kids", title: "Детям"),
        SurveyOption(id: "alone", title: "Для вечера в одиночестве"),
        SurveyOption(id: "none", title: "Никому")
    ]

    static let wordSuggestions = ["Шедевр", "Гипноз", "Тепло", "Тягуче", "Неожиданно", "Пусто"]

    static func titles(for ids: [String], in options: [SurveyOption]) -> [String] {
        options.filter { ids.contains($0.id) }.map(\.title)
    }
}

/// Профиль вкуса, посчитанный по ответам на опросы.
struct TasteProfile {
    struct Bar: Identifiable {
        let id: String
        let title: String
        let percent: Int
    }

    struct Count: Identifiable {
        let id: String
        let title: String
        let count: Int
    }

    let seenCount: Int
    let surveyCount: Int
    let favoriteDecade: String?
    let viewerType: String?
    let viewerDescription: String?
    let bars: [Bar]
    let feelings: [Count]
    let words: [Count]

    init(surveys: [SurveyEntry], seenFilms: [FilmItem]) {
        seenCount = seenFilms.count
        surveyCount = surveys.count

        // Любимое десятилетие — по годам просмотренных фильмов.
        var decades: [Int: Int] = [:]
        for film in seenFilms {
            if let year = film.year { decades[(year / 10) * 10, default: 0] += 1 }
        }
        if let best = decades.max(by: { $0.value == $1.value ? $0.key < $1.key : $0.value < $1.value })?.key {
            favoriteDecade = best < 2000 ? "\(best % 100)-е" : "\(best)-е"
        } else {
            favoriteDecade = nil
        }

        // Что важнее: как часто каждый пункт отмечали.
        var hookCounts: [String: Int] = [:]
        for s in surveys { for h in s.hooks { hookCounts[h, default: 0] += 1 } }
        let total = max(1, surveys.count)
        bars = SurveyOptions.hooks
            .map { Bar(id: $0.id, title: $0.title, percent: Int((Double(hookCounts[$0.id] ?? 0) / Double(total) * 100).rounded())) }
            .sorted { $0.percent > $1.percent }

        if let top = bars.first, top.percent > 0 {
            let type = TasteProfile.types[top.id]
            viewerType = type?.0
            viewerDescription = type?.1
        } else {
            viewerType = nil
            viewerDescription = nil
        }

        var emotionCounts: [String: Int] = [:]
        for s in surveys { for e in s.emotions { emotionCounts[e, default: 0] += 1 } }
        feelings = SurveyOptions.emotions
            .compactMap { (option: SurveyOption) -> Count? in
                guard let n = emotionCounts[option.id], n > 0 else { return nil }
                return Count(id: option.id, title: option.title, count: n)
            }
            .sorted { $0.count > $1.count }
            .prefix(5)
            .map { $0 }

        var wordCounts: [String: Int] = [:]
        var order: [String] = []
        for s in surveys.sorted(by: { $0.date > $1.date }) {
            let w = s.word.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
            guard !w.isEmpty else { continue }
            if wordCounts[w] == nil { order.append(w) }
            wordCounts[w, default: 0] += 1
        }
        words = order.prefix(12).map { Count(id: $0, title: $0, count: wordCounts[$0] ?? 1) }
    }

    static let types: [String: (String, String)] = [
        "atm": ("Созерцатель", "Вас ведёт атмосфера, а не сюжетные повороты. Вы любите кино, после которого хочется помолчать."),
        "pic": ("Эстет", "Вы смотрите глазами: свет, кадр и цвет для вас важнее всего остального."),
        "sound": ("Меломан", "Музыка и звук делают для вас половину фильма. Хороший саундтрек вы помните годами."),
        "cast": ("Ценитель игры", "Вы приходите за людьми на экране: за живой игрой и характерами."),
        "plot": ("Искатель историй", "Вам важно, что будет дальше. Хорошо закрученный сюжет — лучший подарок."),
        "talk": ("Слушатель", "Вы цените точные диалоги и фразы, которые хочется цитировать.")
    ]
}
