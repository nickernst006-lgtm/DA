import SwiftUI

/// Настроения для подборок в Афише.
enum Mood: String, CaseIterable, Identifiable, Codable {
    case think, cozy, chills, laugh, beauty

    var id: String { rawValue }

    var title: String {
        switch self {
        case .think: return "Подумать"
        case .cozy: return "Уютное"
        case .chills: return "До мурашек"
        case .laugh: return "Посмеяться"
        case .beauty: return "Красиво"
        }
    }

    var sectionTitle: String {
        switch self {
        case .think: return "Чтобы подумать"
        case .cozy: return "Для уютного вечера"
        case .chills: return "До мурашек"
        case .laugh: return "Чтобы посмеяться"
        case .beauty: return "Просто красиво"
        }
    }
}

/// Цвета обложки в стиле «Титры»: фон, акцент (линия и год), кружок.
struct CoverPalette: Codable, Hashable {
    var base: String
    var accent: String
    var deep: String

    var baseColor: Color { Color(hexString: base) }
    var accentColor: Color { Color(hexString: accent) }
    var deepColor: Color { Color(hexString: deep) }

    /// Палитры для фильмов, которые пользователь добавляет сам.
    static let userPalettes: [CoverPalette] = [
        CoverPalette(base: "#33402F", accent: "#D9C27A", deep: "#1B2318"),
        CoverPalette(base: "#8C2427", accent: "#F0BE5E", deep: "#4A1013"),
        CoverPalette(base: "#22324A", accent: "#A9BDD3", deep: "#121B2A"),
        CoverPalette(base: "#3B2A5C", accent: "#F2C14E", deep: "#1D1533"),
        CoverPalette(base: "#C0803F", accent: "#F7E0B0", deep: "#5A3417"),
        CoverPalette(base: "#3A3A3A", accent: "#F5F5F5", deep: "#161616")
    ]
}

/// Фильм из встроенной базы (файл films.json).
struct CatalogFilm: Codable, Identifiable, Hashable {
    let id: String
    let title: String
    let originalTitle: String?
    let year: Int?
    let countries: [String]?
    let directors: [String]?
    let minutes: Int?
    let genres: [String]?
    let synopsis: String?
    /// Строки: think, cozy, chills, laugh, beauty. Неизвестные значения пропускаются.
    let moods: [String]?
    let cover: CoverPalette
}

/// Единое представление фильма для экранов — из базы или добавленного пользователем.
struct FilmItem: Identifiable, Hashable {
    let id: String
    let title: String
    let originalTitle: String?
    let year: Int?
    let countries: [String]
    let directors: [String]
    let minutes: Int?
    let genres: [String]
    let synopsis: String?
    let moods: [Mood]
    let palette: CoverPalette
    let photo: Data?
    let isCustom: Bool

    init(catalog f: CatalogFilm) {
        id = f.id
        title = f.title
        originalTitle = f.originalTitle
        year = f.year
        countries = f.countries ?? []
        directors = f.directors ?? []
        minutes = f.minutes
        genres = f.genres ?? []
        synopsis = f.synopsis
        moods = (f.moods ?? []).compactMap(Mood.init(rawValue:))
        palette = f.cover
        photo = nil
        isCustom = false
    }

    init(custom f: CustomFilm) {
        id = f.filmID
        title = f.title
        originalTitle = nil
        year = f.year
        countries = []
        let director = f.director.trimmingCharacters(in: .whitespacesAndNewlines)
        directors = director.isEmpty ? [] : [director]
        minutes = nil
        genres = []
        synopsis = nil
        moods = []
        let index = max(0, min(CoverPalette.userPalettes.count - 1, f.paletteIndex))
        palette = CoverPalette.userPalettes[index]
        photo = f.photo
        isCustom = true
    }

    /// Для предпросмотра на экране добавления фильма.
    init(previewTitle: String, year: Int?, palette: CoverPalette, photo: Data?) {
        id = "preview"
        title = previewTitle
        originalTitle = nil
        self.year = year
        countries = []
        directors = []
        minutes = nil
        genres = []
        synopsis = nil
        moods = []
        self.palette = palette
        self.photo = photo
        isCustom = true
    }

    /// «1979 · Тарковский»
    var shortMeta: String {
        var parts: [String] = []
        if let year { parts.append(String(year)) }
        if let first = directors.first {
            parts.append(first.split(separator: " ").last.map(String.init) ?? first)
        }
        return parts.joined(separator: " · ")
    }

    /// «1979 · Андрей Тарковский · 2 ч 42 мин»
    var fullMeta: String {
        var parts: [String] = []
        if let year { parts.append(String(year)) }
        if !directors.isEmpty { parts.append(directors.joined(separator: ", ")) }
        if let minutes, minutes > 0 {
            let h = minutes / 60
            let m = minutes % 60
            if h > 0 && m > 0 {
                parts.append("\(h) ч \(m) мин")
            } else if h > 0 {
                parts.append("\(h) ч")
            } else {
                parts.append("\(m) мин")
            }
        }
        return parts.joined(separator: " · ")
    }

    /// «СССР · Драма, Фантастика»
    var originMeta: String {
        var parts: [String] = []
        if !countries.isEmpty { parts.append(countries.joined(separator: ", ")) }
        if !genres.isEmpty { parts.append(genres.joined(separator: ", ")) }
        return parts.joined(separator: " · ")
    }

    /// Строка, по которой ищем.
    var searchText: String {
        ([title, originalTitle ?? "", year.map(String.init) ?? ""] + directors)
            .joined(separator: " ")
            .normalizedForSearch
    }
}

/// Маршрут для перехода на карточку фильма.
struct FilmRoute: Hashable {
    let id: String
}

extension String {
    /// Нижний регистр, «ё» → «е», без диакритики.
    var normalizedForSearch: String {
        self.lowercased()
            .replacingOccurrences(of: "ё", with: "е")
            .folding(options: [.diacriticInsensitive], locale: Locale(identifier: "ru_RU"))
    }
}
