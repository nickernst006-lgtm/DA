import SwiftUI
import SwiftData

/// Вкладка «Коллекция»: «Хочу посмотреть» и «Посмотрел».
struct CollectionView: View {
    var onBrowse: () -> Void = {}

    @Environment(Library.self) private var library
    @Query(sort: \CollectionItem.addedAt, order: .reverse) private var items: [CollectionItem]
    @Query private var surveys: [SurveyEntry]
    @Query private var customFilms: [CustomFilm]

    @State private var list: CollectionStatus = .want
    @State private var surveyFilm: FilmItem?

    private let columns = [
        GridItem(.flexible(), spacing: 10, alignment: .top),
        GridItem(.flexible(), spacing: 10, alignment: .top),
        GridItem(.flexible(), spacing: 10, alignment: .top)
    ]

    private var wantFilms: [FilmItem] {
        items.filter { $0.status == .want }
            .compactMap { library.film(id: $0.filmID, custom: customFilms) }
    }

    private var seenFilms: [FilmItem] {
        items.filter { $0.status == .seen }
            .sorted { ($0.seenAt ?? $0.addedAt) > ($1.seenAt ?? $1.addedAt) }
            .compactMap { library.film(id: $0.filmID, custom: customFilms) }
    }

    private func word(for filmID: String) -> String? {
        guard let w = surveys.first(where: { $0.filmID == filmID })?.word, !w.isEmpty else { return nil }
        return "«\(w)»"
    }

    /// Последний просмотренный фильм без опроса.
    private var pendingSurveyFilm: FilmItem? {
        seenFilms.first { film in !surveys.contains { $0.filmID == film.id } }
    }

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 20) {
                    ScreenTitle("Коллекция")
                        .padding(.top, 8)

                    if let pending = pendingSurveyFilm {
                        reminder(pending)
                    }

                    SegmentedControl(
                        options: [
                            SegmentOption(value: CollectionStatus.want, title: "Хочу посмотреть · \(wantFilms.count)"),
                            SegmentOption(value: CollectionStatus.seen, title: "Посмотрел · \(seenFilms.count)")
                        ],
                        selection: $list
                    )

                    let films = list == .want ? wantFilms : seenFilms
                    if films.isEmpty {
                        emptyState
                    } else {
                        LazyVGrid(columns: columns, alignment: .leading, spacing: 18) {
                            ForEach(films) { film in
                                NavigationLink(value: FilmRoute(id: film.id)) {
                                    if list == .seen {
                                        if let w = word(for: film.id) {
                                            FilmTile(film: film, subtitle: w, subtitleIsWord: true, titleSize: 13)
                                        } else {
                                            FilmTile(film: film, subtitle: "без опроса", titleSize: 13)
                                        }
                                    } else {
                                        FilmTile(film: film, subtitle: film.year.map(String.init), titleSize: 13)
                                    }
                                }
                                .buttonStyle(.plain)
                            }
                        }
                    }
                }
                .padding(.horizontal, 20)
                .padding(.bottom, 24)
            }
            .background(Theme.background.ignoresSafeArea())
            .toolbar(.hidden, for: .navigationBar)
            .navigationDestination(for: FilmRoute.self) { route in
                FilmDetailView(filmID: route.id)
            }
        }
        .fullScreenCover(item: $surveyFilm) { film in
            SurveyView(film: film)
        }
    }

    private func reminder(_ film: FilmItem) -> some View {
        Button {
            surveyFilm = film
        } label: {
            HStack(spacing: 14) {
                CoverView(film: film, cornerRadius: 8)
                    .frame(width: 44)
                VStack(alignment: .leading, spacing: 3) {
                    Text("Как вам «\(film.title)»?")
                        .font(AppFont.ui(15, .semibold))
                        .foregroundStyle(Theme.text)
                        .lineLimit(2)
                    Text("Пять вопросов — и «Сеанс» лучше поймёт ваш вкус")
                        .font(AppFont.ui(13))
                        .foregroundStyle(Theme.muted)
                        .fixedSize(horizontal: false, vertical: true)
                }
                Spacer(minLength: 0)
                Image(systemName: "chevron.right")
                    .font(.system(size: 14, weight: .semibold))
                    .foregroundStyle(Theme.muted)
                    .accessibilityHidden(true)
            }
            .padding(12)
            .background(RoundedRectangle(cornerRadius: 16, style: .continuous).fill(Theme.surface))
        }
        .buttonStyle(.plain)
    }

    private var emptyState: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text(list == .want ? "Список пока пуст" : "Вы ещё ничего не отметили")
                .font(AppFont.ui(17, .semibold))
                .foregroundStyle(Theme.text)
            Text(list == .want
                 ? "Откройте фильм в Афише и нажмите «Хочу посмотреть»."
                 : "Отметьте фильм как просмотренный и расскажите, как он вам.")
                .font(AppFont.ui(15))
                .foregroundStyle(Theme.muted)
                .fixedSize(horizontal: false, vertical: true)
            Button("Открыть Афишу", action: onBrowse)
                .buttonStyle(SecondaryButtonStyle())
                .padding(.top, 6)
        }
        .padding(.top, 8)
    }
}
