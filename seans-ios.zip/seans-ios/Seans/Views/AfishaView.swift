import SwiftUI
import SwiftData

/// Вкладка «Афиша»: поиск по базе, подборки под настроение, вечер вдвоём.
struct AfishaView: View {
    @Environment(Library.self) private var library
    @Query(sort: \CustomFilm.createdAt, order: .reverse) private var customFilms: [CustomFilm]

    @State private var query = ""
    @State private var mood: Mood? = nil
    @State private var showAddFilm = false
    @State private var showEvening = false

    private let columns = [
        GridItem(.flexible(), spacing: 12, alignment: .top),
        GridItem(.flexible(), spacing: 12, alignment: .top)
    ]

    private var isSearching: Bool {
        !query.trimmingCharacters(in: .whitespaces).isEmpty
    }

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 20) {
                    ScreenTitle("Афиша")
                        .padding(.top, 8)

                    VStack(alignment: .leading, spacing: 2) {
                        SearchField(text: $query)
                        Button {
                            showAddFilm = true
                        } label: {
                            HStack(spacing: 6) {
                                Text("Нет нужного фильма?")
                                    .foregroundStyle(Theme.muted)
                                Text("Добавить свой")
                                    .foregroundStyle(Theme.text)
                                    .fontWeight(.semibold)
                            }
                            .font(AppFont.ui(14))
                            .frame(minHeight: 44)
                        }
                        .buttonStyle(.plain)
                    }

                    if isSearching {
                        searchResults
                    } else {
                        moodPicker
                        eveningCard
                        filmGrid(title: mood?.sectionTitle ?? "Стоит посмотреть", films: library.films(for: mood))
                    }
                }
                .padding(.horizontal, 20)
                .padding(.bottom, 24)
            }
            .scrollDismissesKeyboard(.immediately)
            .background(Theme.background.ignoresSafeArea())
            .toolbar(.hidden, for: .navigationBar)
            .navigationDestination(for: FilmRoute.self) { route in
                FilmDetailView(filmID: route.id)
            }
        }
        .sheet(isPresented: $showAddFilm) {
            AddFilmView(prefillTitle: isSearching ? query : "")
        }
        .fullScreenCover(isPresented: $showEvening) {
            EveningView()
        }
    }

    private var moodPicker: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 8) {
                Chip(title: "Всё", isSelected: mood == nil, height: 40) { mood = nil }
                ForEach(Mood.allCases) { item in
                    Chip(title: item.title, isSelected: mood == item, height: 40) { mood = item }
                }
            }
            .padding(.horizontal, 20)
        }
        .padding(.horizontal, -20)
    }

    private var eveningCard: some View {
        Button {
            showEvening = true
        } label: {
            HStack(spacing: 14) {
                HStack(spacing: -10) {
                    Circle().fill(Theme.text).frame(width: 34, height: 34)
                        .overlay(Image(systemName: "person.fill").font(.system(size: 14)).foregroundStyle(Color.black))
                    Circle().fill(Theme.lineStrong).frame(width: 34, height: 34)
                        .overlay(Image(systemName: "person.fill").font(.system(size: 14)).foregroundStyle(Theme.text))
                        .overlay(Circle().stroke(Theme.surface, lineWidth: 2))
                }
                .accessibilityHidden(true)
                VStack(alignment: .leading, spacing: 2) {
                    Text("Что посмотрим вечером?")
                        .font(AppFont.ui(15, .semibold))
                        .foregroundStyle(Theme.text)
                    Text("Выберите фильм вдвоём на одном телефоне")
                        .font(AppFont.ui(13))
                        .foregroundStyle(Theme.muted)
                }
                Spacer(minLength: 0)
                Image(systemName: "chevron.right")
                    .font(.system(size: 14, weight: .semibold))
                    .foregroundStyle(Theme.muted)
                    .accessibilityHidden(true)
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 14)
            .background(RoundedRectangle(cornerRadius: 16, style: .continuous).fill(Theme.surface))
        }
        .buttonStyle(.plain)
    }

    @ViewBuilder
    private var searchResults: some View {
        let results = library.search(query, custom: customFilms)
        if results.isEmpty {
            VStack(alignment: .leading, spacing: 8) {
                Text("Ничего не нашлось")
                    .font(AppFont.ui(17, .semibold))
                    .foregroundStyle(Theme.text)
                Text("Этого фильма пока нет в базе «Сеанса». Добавьте его сами — он сохранится только у вас.")
                    .font(AppFont.ui(15))
                    .foregroundStyle(Theme.muted)
                    .fixedSize(horizontal: false, vertical: true)
                Button("Добавить «\(query.trimmingCharacters(in: .whitespaces))»") {
                    showAddFilm = true
                }
                .buttonStyle(SecondaryButtonStyle())
                .padding(.top, 8)
            }
            .padding(.top, 8)
        } else {
            filmGrid(title: "Найдено: \(results.count)", films: results)
        }
    }

    private func filmGrid(title: String, films: [FilmItem]) -> some View {
        VStack(alignment: .leading, spacing: 14) {
            Text(title)
                .font(AppFont.ui(17, .semibold))
                .foregroundStyle(Theme.text)
                .accessibilityAddTraits(.isHeader)
            LazyVGrid(columns: columns, alignment: .leading, spacing: 20) {
                ForEach(films) { film in
                    NavigationLink(value: FilmRoute(id: film.id)) {
                        FilmTile(film: film, subtitle: film.shortMeta)
                    }
                    .buttonStyle(.plain)
                }
            }
        }
    }
}
