import SwiftUI
import SwiftData

/// Карточка фильма.
struct FilmDetailView: View {
    let filmID: String

    @Environment(Library.self) private var library
    @Environment(\.modelContext) private var context
    @Environment(\.dismiss) private var dismiss
    @Query private var customFilms: [CustomFilm]
    @Query private var collection: [CollectionItem]
    @Query private var surveys: [SurveyEntry]

    @State private var surveyFilm: FilmItem?
    @State private var confirmDelete = false

    private var film: FilmItem? { library.film(id: filmID, custom: customFilms) }
    private var entry: CollectionItem? { collection.first { $0.filmID == filmID } }
    private var survey: SurveyEntry? { surveys.first { $0.filmID == filmID } }

    var body: some View {
        Group {
            if let film {
                content(film)
            } else {
                VStack(spacing: 12) {
                    Text("Фильм не найден")
                        .font(AppFont.ui(17, .semibold))
                        .foregroundStyle(Theme.text)
                    Button("Назад") { dismiss() }
                        .buttonStyle(SecondaryButtonStyle())
                        .frame(width: 160)
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
            }
        }
        .background(Theme.background.ignoresSafeArea())
        .toolbar(.visible, for: .navigationBar)
        .toolbarBackground(Theme.background, for: .navigationBar)
        .navigationBarTitleDisplayMode(.inline)
        .fullScreenCover(item: $surveyFilm) { item in
            SurveyView(film: item)
        }
    }

    private func content(_ film: FilmItem) -> some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 22) {
                CoverView(film: film, cornerRadius: 18)
                    .frame(width: 210)
                    .frame(maxWidth: .infinity)
                    .padding(.top, 8)

                VStack(alignment: .leading, spacing: 8) {
                    Text(film.title)
                        .font(AppFont.serif(36, relativeTo: .title))
                        .foregroundStyle(Theme.text)
                        .fixedSize(horizontal: false, vertical: true)
                    if let original = film.originalTitle, !original.isEmpty {
                        Text(original)
                            .font(AppFont.ui(14))
                            .foregroundStyle(Theme.muted)
                    }
                    if !film.fullMeta.isEmpty {
                        Text(film.fullMeta)
                            .font(AppFont.ui(14))
                            .foregroundStyle(Theme.muted)
                    }
                    if !film.originMeta.isEmpty {
                        Text(film.originMeta)
                            .font(AppFont.ui(14))
                            .foregroundStyle(Theme.muted)
                    }
                }

                if let synopsis = film.synopsis, !synopsis.isEmpty {
                    Text(synopsis)
                        .font(AppFont.ui(16))
                        .foregroundStyle(Theme.textSecondary)
                        .lineSpacing(3)
                        .fixedSize(horizontal: false, vertical: true)
                }

                actions(film)

                if let survey {
                    surveySummary(survey, film: film)
                }

                if film.isCustom {
                    Button(role: .destructive) {
                        confirmDelete = true
                    } label: {
                        Text("Удалить фильм")
                            .font(AppFont.ui(15, .medium))
                            .foregroundStyle(Theme.muted)
                            .frame(maxWidth: .infinity, minHeight: 44)
                    }
                    .buttonStyle(.plain)
                    .confirmationDialog("Удалить «\(film.title)»?", isPresented: $confirmDelete, titleVisibility: .visible) {
                        Button("Удалить", role: .destructive) { deleteCustom() }
                        Button("Отмена", role: .cancel) {}
                    } message: {
                        Text("Фильм, его статус и ответы на опрос будут удалены с этого iPhone.")
                    }
                }
            }
            .padding(.horizontal, 20)
            .padding(.bottom, 32)
        }
    }

    @ViewBuilder
    private func actions(_ film: FilmItem) -> some View {
        let status = entry?.status
        VStack(spacing: 10) {
            switch status {
            case .some(.seen):
                if survey == nil {
                    Button("Рассказать, как вам") { surveyFilm = film }
                        .buttonStyle(PrimaryButtonStyle())
                }
                Button {
                    CollectionActions.setStatus(.want, for: film.id, in: context)
                } label: {
                    Text("Хочу пересмотреть")
                }
                .buttonStyle(SecondaryButtonStyle())
                Text(seenCaption)
                    .font(AppFont.ui(13))
                    .foregroundStyle(Theme.muted)
                    .frame(maxWidth: .infinity)
            case .some(.want):
                Button("Посмотрел") { markSeen(film) }
                    .buttonStyle(PrimaryButtonStyle())
                Button {
                    CollectionActions.setStatus(nil, for: film.id, in: context)
                } label: {
                    Label("В списке «Хочу посмотреть»", systemImage: "checkmark")
                }
                .buttonStyle(SecondaryButtonStyle(highlighted: true))
            case .none:
                Button("Посмотрел") { markSeen(film) }
                    .buttonStyle(PrimaryButtonStyle())
                Button("Хочу посмотреть") {
                    CollectionActions.setStatus(.want, for: film.id, in: context)
                }
                .buttonStyle(SecondaryButtonStyle())
            }
        }
        .sensoryFeedback(.success, trigger: entry?.statusRaw)
    }

    private var seenCaption: String {
        guard let date = entry?.seenAt else { return "Отмечен как просмотренный" }
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "ru_RU")
        formatter.dateFormat = "d MMMM yyyy"
        return "Просмотрен \(formatter.string(from: date))"
    }

    private func surveySummary(_ survey: SurveyEntry, film: FilmItem) -> some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("Ваш отзыв")
                .font(AppFont.ui(13, .semibold))
                .foregroundStyle(Theme.accent)
            if !survey.word.isEmpty {
                Text("«\(survey.word)»")
                    .font(AppFont.serif(30, relativeTo: .title2))
                    .foregroundStyle(Theme.text)
            }
            let feel = SurveyOptions.titles(for: survey.emotions, in: SurveyOptions.emotions)
                + SurveyOptions.titles(for: survey.hooks, in: SurveyOptions.hooks)
            if !feel.isEmpty {
                Text(feel.joined(separator: " · "))
                    .font(AppFont.ui(15))
                    .foregroundStyle(Theme.textSecondary)
                    .fixedSize(horizontal: false, vertical: true)
            }
            if let rewatch = SurveyOptions.rewatchShort[survey.rewatch] {
                Text(rewatch)
                    .font(AppFont.ui(14))
                    .foregroundStyle(Theme.muted)
            }
            Button("Пройти опрос заново") { surveyFilm = film }
                .font(AppFont.ui(15, .semibold))
                .foregroundStyle(Theme.text)
                .frame(minHeight: 44)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(.top, 20)
        .overlay(alignment: .top) { Rectangle().fill(Theme.line).frame(height: 1) }
    }

    private func markSeen(_ film: FilmItem) {
        CollectionActions.setStatus(.seen, for: film.id, in: context)
        if survey == nil {
            surveyFilm = film
        }
    }

    private func deleteCustom() {
        guard let own = customFilms.first(where: { $0.filmID == filmID }) else { return }
        CollectionActions.deleteCustomFilm(own, in: context)
        dismiss()
    }
}
