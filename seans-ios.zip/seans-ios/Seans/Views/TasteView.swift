import SwiftUI
import SwiftData

/// Вкладка «Вкусы»: профиль зрителя по ответам на опросы.
struct TasteView: View {
    @Environment(Library.self) private var library
    @Query private var surveys: [SurveyEntry]
    @Query private var items: [CollectionItem]
    @Query private var customFilms: [CustomFilm]

    private var profile: TasteProfile {
        let seen = items.filter { $0.status == .seen }
            .compactMap { library.film(id: $0.filmID, custom: customFilms) }
        return TasteProfile(surveys: surveys, seenFilms: seen)
    }

    var body: some View {
        let p = profile
        ScrollView {
            VStack(alignment: .leading, spacing: 24) {
                ScreenTitle("Вкусы")
                    .padding(.top, 8)

                if p.surveyCount == 0 {
                    emptyState(p)
                } else {
                    typeSection(p)
                    stats(p)
                    barsSection(p)
                    if !p.feelings.isEmpty { feelingsSection(p) }
                    if !p.words.isEmpty { wordsSection(p) }
                }
            }
            .padding(.horizontal, 20)
            .padding(.bottom, 24)
        }
        .background(Theme.background.ignoresSafeArea())
    }

    private func emptyState(_ p: TasteProfile) -> some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Ваш киновкус появится здесь")
                .font(AppFont.serif(28, relativeTo: .title2))
                .foregroundStyle(Theme.text)
                .fixedSize(horizontal: false, vertical: true)
            Text("Отметьте фильм как просмотренный и ответьте на пять коротких вопросов. Чем больше опросов, тем точнее портрет.")
                .font(AppFont.ui(15))
                .foregroundStyle(Theme.muted)
                .fixedSize(horizontal: false, vertical: true)
            if p.seenCount > 0 {
                Text("Просмотрено фильмов: \(p.seenCount)")
                    .font(AppFont.ui(14))
                    .foregroundStyle(Theme.textSecondary)
                    .padding(.top, 4)
            }
        }
    }

    private func typeSection(_ p: TasteProfile) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("Ваш тип зрителя")
                .font(AppFont.ui(13))
                .foregroundStyle(Theme.muted)
            Text(p.viewerType ?? "Зритель без шаблона")
                .font(AppFont.serif(32, relativeTo: .title))
                .foregroundStyle(Theme.text)
            Text(p.viewerDescription ?? "Отмечайте в опросах, что зацепило в фильме, — и мы поймём, что для вас главное.")
                .font(AppFont.ui(15))
                .foregroundStyle(Theme.textSecondary)
                .lineSpacing(2)
                .fixedSize(horizontal: false, vertical: true)
        }
    }

    private func stats(_ p: TasteProfile) -> some View {
        HStack(alignment: .top, spacing: 8) {
            stat(value: "\(p.seenCount)", label: "фильмов")
            stat(value: "\(p.surveyCount)", label: "опросов")
            stat(value: p.favoriteDecade ?? "—", label: "любимое десятилетие")
        }
        .padding(.vertical, 18)
        .overlay(alignment: .top) { Rectangle().fill(Theme.line).frame(height: 1) }
        .overlay(alignment: .bottom) { Rectangle().fill(Theme.line).frame(height: 1) }
    }

    private func stat(value: String, label: String) -> some View {
        VStack(alignment: .leading, spacing: 2) {
            Text(value)
                .font(AppFont.serif(28, relativeTo: .title2))
                .foregroundStyle(Theme.text)
            Text(label)
                .font(AppFont.ui(12))
                .foregroundStyle(Theme.muted)
                .fixedSize(horizontal: false, vertical: true)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .accessibilityElement(children: .combine)
    }

    private func barsSection(_ p: TasteProfile) -> some View {
        VStack(alignment: .leading, spacing: 14) {
            VStack(alignment: .leading, spacing: 2) {
                Text("Что для вас важнее")
                    .font(AppFont.ui(16, .semibold))
                    .foregroundStyle(Theme.text)
                Text("Как часто вы отмечаете это в опросах")
                    .font(AppFont.ui(13))
                    .foregroundStyle(Theme.muted)
            }
            ForEach(Array(p.bars.enumerated()), id: \.element.id) { index, bar in
                VStack(alignment: .leading, spacing: 6) {
                    HStack {
                        Text(bar.title)
                            .font(AppFont.ui(14))
                            .foregroundStyle(Theme.text)
                        Spacer()
                        Text("\(bar.percent)%")
                            .font(AppFont.ui(14))
                            .foregroundStyle(Theme.muted)
                    }
                    GeometryReader { geo in
                        ZStack(alignment: .leading) {
                            Capsule().fill(Theme.surfaceRaised)
                            Capsule()
                                .fill(index == 0 ? Theme.accent : Theme.text)
                                .frame(width: geo.size.width * CGFloat(bar.percent) / 100)
                        }
                    }
                    .frame(height: 3)
                }
                .accessibilityElement(children: .combine)
            }
        }
    }

    private func feelingsSection(_ p: TasteProfile) -> some View {
        VStack(alignment: .leading, spacing: 0) {
            Text("Чувства, за которыми вы приходите")
                .font(AppFont.ui(16, .semibold))
                .foregroundStyle(Theme.text)
                .padding(.bottom, 8)
            ForEach(p.feelings) { feeling in
                HStack {
                    Text(feeling.title)
                        .font(AppFont.ui(15))
                        .foregroundStyle(Theme.text)
                    Spacer()
                    Text("\(feeling.count)")
                        .font(AppFont.ui(15))
                        .foregroundStyle(Theme.muted)
                }
                .frame(minHeight: 44)
                .overlay(alignment: .bottom) { Rectangle().fill(Theme.line).frame(height: 1) }
                .accessibilityElement(children: .combine)
            }
        }
    }

    private func wordsSection(_ p: TasteProfile) -> some View {
        let maxCount = p.words.map(\.count).max() ?? 1
        return VStack(alignment: .leading, spacing: 12) {
            Text("Ваши слова о кино")
                .font(AppFont.ui(16, .semibold))
                .foregroundStyle(Theme.text)
            FlowLayout(spacing: 14, lineSpacing: 6) {
                ForEach(Array(p.words.enumerated()), id: \.element.id) { index, word in
                    let weight = Double(word.count) / Double(maxCount)
                    Text(word.title)
                        .font(AppFont.serif(CGFloat(20 + 14 * weight) - CGFloat(min(index, 6)), relativeTo: .title3))
                        .foregroundStyle(index == 0 ? Theme.accent : (index % 3 == 1 ? Theme.textSecondary : Theme.text))
                }
            }
        }
    }
}
