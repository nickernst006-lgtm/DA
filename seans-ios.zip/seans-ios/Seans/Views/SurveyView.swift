import SwiftUI
import SwiftData

/// Опрос после просмотра: пять коротких шагов и карточка для соцсетей.
@MainActor
struct SurveyView: View {
    let film: FilmItem

    @Environment(\.modelContext) private var context
    @Environment(\.dismiss) private var dismiss

    @State private var step = 0
    @State private var emotions: Set<String> = []
    @State private var hooks: Set<String> = []
    @State private var rewatch = ""
    @State private var recommend: Set<String> = []
    @State private var word = ""
    @State private var shareImage: Image?
    @FocusState private var wordFocused: Bool

    private let stepCount = 5

    var body: some View {
        VStack(spacing: 0) {
            header
            ScrollView {
                VStack(alignment: .leading, spacing: 24) {
                    switch step {
                    case 0: emotionsStep
                    case 1: hooksStep
                    case 2: rewatchStep
                    case 3: recommendStep
                    case 4: wordStep
                    default: resultStep
                    }
                }
                .padding(.horizontal, 20)
                .padding(.top, 32)
                .padding(.bottom, 24)
                .frame(maxWidth: .infinity, alignment: .leading)
            }
            .scrollDismissesKeyboard(.interactively)
            footer
        }
        .background(Theme.background.ignoresSafeArea())
        .onAppear(perform: loadExisting)
        .animation(.easeInOut(duration: 0.2), value: step)
    }

    // MARK: Шапка и прогресс

    private var header: some View {
        VStack(spacing: 16) {
            HStack {
                CloseButton(label: "Закрыть опрос") { dismiss() }
                Spacer()
                Text(film.title)
                    .font(AppFont.ui(15, .semibold))
                    .foregroundStyle(Theme.text)
                    .lineLimit(1)
                Spacer()
                Text(step < stepCount ? "\(step + 1) из \(stepCount)" : "")
                    .font(AppFont.ui(13, .semibold))
                    .foregroundStyle(Theme.muted)
                    .frame(width: 44, alignment: .trailing)
            }
            HStack(spacing: 6) {
                ForEach(0..<stepCount, id: \.self) { i in
                    Capsule()
                        .fill(i <= step ? Theme.accent : Theme.lineStrong)
                        .frame(height: 3)
                }
            }
            .accessibilityHidden(true)
        }
        .padding(.horizontal, 20)
        .padding(.top, 12)
    }

    // MARK: Шаги

    private func question(_ title: String, hint: String? = nil) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(title)
                .font(AppFont.serif(34, relativeTo: .title))
                .foregroundStyle(Theme.text)
                .fixedSize(horizontal: false, vertical: true)
                .accessibilityAddTraits(.isHeader)
            if let hint {
                Text(hint)
                    .font(AppFont.ui(14))
                    .foregroundStyle(Theme.muted)
            }
        }
    }

    private var emotionsStep: some View {
        VStack(alignment: .leading, spacing: 24) {
            question("Какие чувства остались?", hint: "Можно выбрать несколько")
            FlowLayout(spacing: 8, lineSpacing: 8) {
                ForEach(SurveyOptions.emotions) { option in
                    Chip(title: option.title, isSelected: emotions.contains(option.id), height: 46) {
                        toggle(option.id, in: &emotions)
                    }
                }
            }
        }
    }

    private var hooksStep: some View {
        VStack(alignment: .leading, spacing: 24) {
            question("Что зацепило сильнее всего?", hint: "Одно или два — то, что запомнится через год")
            LazyVGrid(columns: [GridItem(.flexible(), spacing: 8), GridItem(.flexible(), spacing: 8)], spacing: 8) {
                ForEach(SurveyOptions.hooks) { option in
                    let isSelected = hooks.contains(option.id)
                    Button {
                        toggle(option.id, in: &hooks)
                    } label: {
                        Text(option.title)
                            .font(AppFont.ui(16, .semibold))
                            .foregroundStyle(isSelected ? Color.black : Theme.text)
                            .multilineTextAlignment(.leading)
                            .frame(maxWidth: .infinity, minHeight: 72, alignment: .leading)
                            .padding(.horizontal, 16)
                            .background(
                                RoundedRectangle(cornerRadius: 16, style: .continuous)
                                    .fill(isSelected ? Theme.text : Theme.surface)
                            )
                    }
                    .buttonStyle(.plain)
                    .accessibilityAddTraits(isSelected ? .isSelected : [])
                    .sensoryFeedback(.selection, trigger: isSelected)
                }
            }
        }
    }

    private var rewatchStep: some View {
        VStack(alignment: .leading, spacing: 24) {
            question("Пересмотрели бы?")
            VStack(spacing: 8) {
                ForEach(SurveyOptions.rewatch) { option in
                    let isSelected = rewatch == option.id
                    Button {
                        rewatch = option.id
                    } label: {
                        Text(option.title)
                            .font(AppFont.ui(16, .semibold))
                            .foregroundStyle(isSelected ? Color.black : Theme.text)
                            .frame(maxWidth: .infinity, minHeight: 60, alignment: .leading)
                            .padding(.horizontal, 20)
                            .background(
                                RoundedRectangle(cornerRadius: 16, style: .continuous)
                                    .fill(isSelected ? Theme.text : Theme.surface)
                            )
                    }
                    .buttonStyle(.plain)
                    .accessibilityAddTraits(isSelected ? .isSelected : [])
                    .sensoryFeedback(.selection, trigger: isSelected)
                }
            }
        }
    }

    private var recommendStep: some View {
        VStack(alignment: .leading, spacing: 24) {
            question("Кому бы посоветовали?", hint: "Можно выбрать несколько")
            FlowLayout(spacing: 8, lineSpacing: 8) {
                ForEach(SurveyOptions.recommend) { option in
                    Chip(title: option.title, isSelected: recommend.contains(option.id), height: 46) {
                        if option.id == "none" {
                            recommend = recommend.contains("none") ? [] : ["none"]
                        } else {
                            recommend.remove("none")
                            toggle(option.id, in: &recommend)
                        }
                    }
                }
            }
        }
    }

    private var wordStep: some View {
        VStack(alignment: .leading, spacing: 24) {
            question("Одно слово о фильме", hint: "Оно появится на вашей карточке")
            TextField("", text: $word, prompt: Text("Ваше слово").foregroundColor(Theme.muted))
                .font(AppFont.serif(24, relativeTo: .title2))
                .foregroundStyle(Theme.text)
                .focused($wordFocused)
                .submitLabel(.done)
                .padding(.horizontal, 16)
                .frame(minHeight: 58)
                .background(
                    RoundedRectangle(cornerRadius: 14, style: .continuous).fill(Theme.surface)
                )
                .overlay(
                    RoundedRectangle(cornerRadius: 14, style: .continuous).stroke(Theme.lineStrong, lineWidth: 1)
                )
                .accessibilityLabel("Одно слово о фильме")
                .onChange(of: word) { _, newValue in
                    if newValue.count > 24 { word = String(newValue.prefix(24)) }
                }
            FlowLayout(spacing: 8, lineSpacing: 8) {
                ForEach(SurveyOptions.wordSuggestions, id: \.self) { suggestion in
                    Chip(title: suggestion, isSelected: word == suggestion, height: 44) {
                        word = suggestion
                    }
                }
            }
        }
    }

    private var resultStep: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text("Ваша карточка")
                .font(AppFont.ui(13, .semibold))
                .foregroundStyle(Theme.accent)
            ShareCard(
                film: film,
                word: displayWord,
                feelings: feelingsLine,
                details: detailsLine
            )
        }
    }

    // MARK: Нижние кнопки

    private var footer: some View {
        HStack(spacing: 10) {
            if step > 0 && step < stepCount {
                Button {
                    step -= 1
                } label: {
                    Image(systemName: "chevron.left")
                        .font(.system(size: 17, weight: .semibold))
                        .foregroundStyle(Theme.text)
                        .frame(width: 52, height: 52)
                        .overlay(
                            RoundedRectangle(cornerRadius: 14, style: .continuous)
                                .stroke(Theme.lineStrong, lineWidth: 1)
                        )
                }
                .buttonStyle(.plain)
                .accessibilityLabel("Назад")
            }
            if step < stepCount {
                Button(step == stepCount - 1 ? "Готово" : "Дальше") {
                    wordFocused = false
                    if step == stepCount - 1 {
                        save()
                    }
                    step += 1
                }
                .buttonStyle(PrimaryButtonStyle())
            } else {
                if let shareImage {
                    ShareLink(
                        item: shareImage,
                        preview: SharePreview("«\(film.title)» в Сеансе", image: shareImage)
                    ) {
                        Text("Поделиться")
                    }
                    .buttonStyle(PrimaryButtonStyle())
                }
                Button("Закрыть") { dismiss() }
                    .buttonStyle(SecondaryButtonStyle())
            }
        }
        .padding(.horizontal, 20)
        .padding(.top, 10)
        .padding(.bottom, 12)
    }

    // MARK: Логика

    private var displayWord: String {
        let trimmed = word.trimmingCharacters(in: .whitespacesAndNewlines)
        return trimmed.isEmpty ? "" : trimmed
    }

    private var feelingsLine: String {
        (SurveyOptions.titles(for: Array(emotions), in: SurveyOptions.emotions)
            + SurveyOptions.titles(for: Array(hooks), in: SurveyOptions.hooks))
            .joined(separator: " · ")
    }

    private var detailsLine: String {
        var parts: [String] = []
        if let r = SurveyOptions.rewatchShort[rewatch] { parts.append(r) }
        let rec = SurveyOptions.titles(for: Array(recommend), in: SurveyOptions.recommend)
        if !rec.isEmpty {
            if recommend.contains("none") {
                parts.append("Никому не посоветую")
            } else {
                parts.append("Посоветую: " + rec.map { $0.lowercased() }.joined(separator: ", "))
            }
        }
        return parts.joined(separator: " · ")
    }

    private func toggle(_ id: String, in set: inout Set<String>) {
        if set.contains(id) { set.remove(id) } else { set.insert(id) }
    }

    private func loadExisting() {
        guard let existing = CollectionActions.survey(for: film.id, in: context) else { return }
        emotions = Set(existing.emotions)
        hooks = Set(existing.hooks)
        rewatch = existing.rewatch
        recommend = Set(existing.recommend)
        word = existing.word
    }

    private func save() {
        let entry = CollectionActions.survey(for: film.id, in: context) ?? {
            let created = SurveyEntry(filmID: film.id)
            context.insert(created)
            return created
        }()
        entry.date = Date()
        entry.emotions = SurveyOptions.emotions.map(\.id).filter { emotions.contains($0) }
        entry.hooks = SurveyOptions.hooks.map(\.id).filter { hooks.contains($0) }
        entry.rewatch = rewatch
        entry.recommend = SurveyOptions.recommend.map(\.id).filter { recommend.contains($0) }
        entry.word = displayWord
        // Если фильм ещё не отмечен как просмотренный — отмечаем.
        if CollectionActions.item(for: film.id, in: context)?.status != .seen {
            CollectionActions.setStatus(.seen, for: film.id, in: context)
        }
        try? context.save()
        renderShareImage()
    }

    private func renderShareImage() {
        let card = ShareCard(film: film, word: displayWord, feelings: feelingsLine, details: detailsLine)
            .frame(width: 360)
            .padding(24)
            .background(Color.black)
        let renderer = ImageRenderer(content: card)
        renderer.scale = 3
        if let uiImage = renderer.uiImage {
            shareImage = Image(uiImage: uiImage)
        }
    }
}

/// Карточка отзыва — показывается в приложении и отправляется в соцсети картинкой.
struct ShareCard: View {
    let film: FilmItem
    let word: String
    let feelings: String
    let details: String

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            HStack(alignment: .top, spacing: 16) {
                CoverView(film: film, cornerRadius: 10)
                    .frame(width: 96)
                VStack(alignment: .leading, spacing: 6) {
                    Text(film.title)
                        .font(AppFont.ui(16, .semibold))
                        .foregroundStyle(Theme.text)
                        .fixedSize(horizontal: false, vertical: true)
                    if !film.shortMeta.isEmpty {
                        Text(film.shortMeta)
                            .font(AppFont.ui(13))
                            .foregroundStyle(Theme.muted)
                    }
                }
                Spacer(minLength: 0)
            }
            .padding(20)

            VStack(alignment: .leading, spacing: 12) {
                if !word.isEmpty {
                    Text("«\(word)»")
                        .font(AppFont.serifFixed(40))
                        .foregroundStyle(Theme.text)
                        .fixedSize(horizontal: false, vertical: true)
                }
                if !feelings.isEmpty {
                    Text(feelings)
                        .font(AppFont.uiFixed(15))
                        .foregroundStyle(Theme.textSecondary)
                        .fixedSize(horizontal: false, vertical: true)
                }
                if !details.isEmpty {
                    Text(details)
                        .font(AppFont.uiFixed(14))
                        .foregroundStyle(Theme.muted)
                        .fixedSize(horizontal: false, vertical: true)
                }
                Text("Сеанс")
                    .font(AppFont.serifFixed(16))
                    .foregroundStyle(Theme.muted)
                    .padding(.top, 6)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .overlay(alignment: .top) {
                        Rectangle().fill(Theme.lineStrong).frame(height: 1).offset(y: -2)
                    }
            }
            .padding(.horizontal, 20)
            .padding(.bottom, 20)
        }
        .background(RoundedRectangle(cornerRadius: 22, style: .continuous).fill(Theme.surface))
    }
}
