import SwiftUI
import UIKit

/// Обложка в стиле «Титры». Рисуется приложением из трёх цветов —
/// никаких картинок в базе не хранится. Если пользователь выбрал своё фото,
/// показывается оно.
struct CoverView: View {
    let film: FilmItem
    var cornerRadius: CGFloat = 12
    var placeholderTitle: Bool = false

    var body: some View {
        GeometryReader { geo in
            let w = geo.size.width
            let h = geo.size.height
            ZStack(alignment: .topLeading) {
                if let data = film.photo, let image = UIImage(data: data) {
                    Image(uiImage: image)
                        .resizable()
                        .scaledToFill()
                        .frame(width: w, height: h)
                        .clipped()
                } else {
                    film.palette.deepColor

                    Circle()
                        .fill(film.palette.baseColor)
                        .frame(width: w * 0.22, height: w * 0.22)
                        .position(x: w * 0.79, y: h * 0.22 + w * 0.11)

                    VStack(alignment: .leading, spacing: 0) {
                        Rectangle()
                            .fill(film.palette.accentColor)
                            .frame(height: max(1, w * 0.006))
                        Text(film.year.map(String.init) ?? " ")
                            .font(AppFont.uiFixed(max(8, w * 0.075), .semibold))
                            .tracking(w * 0.006)
                            .foregroundStyle(film.palette.accentColor)
                            .padding(.top, h * 0.025)
                        Spacer(minLength: 0)
                        Text(film.title)
                            .font(AppFont.serifFixed(max(10, w * 0.145)))
                            .foregroundStyle(placeholderTitle ? Theme.muted : Theme.text)
                            .lineLimit(5)
                            .minimumScaleFactor(0.55)
                            .multilineTextAlignment(.leading)
                    }
                    .padding(.horizontal, w * 0.1)
                    .padding(.top, h * 0.11)
                    .padding(.bottom, h * 0.085)
                    .frame(width: w, height: h, alignment: .topLeading)
                }
            }
            .frame(width: w, height: h)
        }
        .aspectRatio(2.0 / 3.0, contentMode: .fit)
        .clipShape(RoundedRectangle(cornerRadius: cornerRadius, style: .continuous))
        .accessibilityHidden(true)
    }
}

/// Плитка фильма для сеток: обложка, название, подпись.
struct FilmTile: View {
    let film: FilmItem
    var subtitle: String? = nil
    var subtitleIsWord = false
    var titleSize: CGFloat = 15

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            CoverView(film: film, cornerRadius: titleSize < 15 ? 10 : 14)
            VStack(alignment: .leading, spacing: 3) {
                Text(film.title)
                    .font(AppFont.ui(titleSize, .semibold))
                    .foregroundStyle(Theme.text)
                    .lineLimit(2)
                    .multilineTextAlignment(.leading)
                if let subtitle, !subtitle.isEmpty {
                    if subtitleIsWord {
                        Text(subtitle)
                            .font(AppFont.serif(titleSize + 1, relativeTo: .subheadline))
                            .foregroundStyle(Theme.accent)
                            .lineLimit(1)
                    } else {
                        Text(subtitle)
                            .font(AppFont.ui(titleSize - 2))
                            .foregroundStyle(Theme.muted)
                            .lineLimit(1)
                    }
                }
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .contentShape(Rectangle())
        .accessibilityElement(children: .combine)
    }
}
