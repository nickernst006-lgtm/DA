import SwiftUI
import SwiftData

@main
struct SeansApp: App {
    @State private var library = Library()

    var body: some Scene {
        WindowGroup {
            RootView()
                .environment(library)
                .preferredColorScheme(.dark)
                .tint(Theme.text)
        }
        .modelContainer(for: [CollectionItem.self, SurveyEntry.self, CustomFilm.self, Friend.self,
                             JournalBlock.self, JournalPhoto.self, BoardItem.self])
    }
}
