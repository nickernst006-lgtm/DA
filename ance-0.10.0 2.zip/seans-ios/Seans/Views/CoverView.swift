import SwiftUI
import UIKit

/// Обложка фильма. Порядок выбора:
/// 1. фото, которое пользователь выбрал для своего фильма;
/// 2. картинка из папки Seans/Resources/Covers с именем, равным id фильма;
/// 3. нарисованная обложка: цветной фон и абстрактный круг.
struct CoverView: View {
    let film: FilmItem
    var cornerRadius: CGFloat = 12

    private var image: UIImage? {
        if let data = film.photo, let photo = UIImage(data: data) { return photo }
        return CoverImages.image(for: film.id)
    }

    var body: some View {
        GeometryReader { geo in
            let size = geo.size
            ZStack {
                if let image {
                    Image(uiImage: image)
                        .resizable()
                        .scaledToFill()
                        .frame(width: size.width, height: size.height)
                        .clipped()
                } else {
                    CoverArt(style: film.cover, seed: film.id, size: size)
                }
            }
            .frame(width: size.width, height: size.height)
        }
        .aspectRatio(2.0 / 3.0, contentMode: .fit)
        .clipShape(RoundedRectangle(cornerRadius: cornerRadius, style: .continuous))
        .accessibilityHidden(true)
    }
}

/// Готовые обложки, вложенные в приложение: файл «id фильма».jpg / .jpeg / .png / .webp.
enum CoverImages {
    private static let cache = NSCache<NSString, UIImage>()
    private static var missing = Set<String>()
    private static let lock = NSLock()
    private static let extensions = ["jpg", "jpeg", "png", "webp"]

    static func image(for filmID: String) -> UIImage? {
        if let cached = cache.object(forKey: filmID as NSString) { return cached }
        lock.lock()
        let knownMissing = missing.contains(filmID)
        lock.unlock()
        if knownMissing { return nil }

        for ext in extensions {
            if let url = Bundle.main.url(forResource: filmID, withExtension: ext),
               let image = UIImage(contentsOfFile: url.path) {
                cache.setObject(image, forKey: filmID as NSString)
                return image
            }
        }
        lock.lock()
        missing.insert(filmID)
        lock.unlock()
        return nil
    }
}

/// Сам рисунок обложки.
struct CoverArt: View {
    let style: CoverStyle
    let seed: String
    let size: CGSize

    var body: some View {
        let g = style.geometry(seed: seed)
        let diameter = size.width * CGFloat(g.size)
        ZStack(alignment: .topLeading) {
            style.bgColor
            Circle()
                .fill(style.accentColor)
                .frame(width: diameter, height: diameter)
                .position(x: size.width * CGFloat(g.x), y: size.height * CGFloat(g.y))
        }
        .frame(width: size.width, height: size.height)
        .clipped()
    }
}

/// Плитка фильма для сеток и подборок: обложка, название, год и фамилия режиссёра.
/// compact — для сетки в три колонки: название мелким стилем, скругление поменьше.
struct FilmTile: View {
    let film: FilmItem
    var subtitle: String? = nil
    var compact = false

    var body: some View {
        VStack(alignment: .leading, spacing: Space.s8) {
            // Обложка всегда 2:3 по ширине плитки и не сжимается,
            // даже если у соседней плитки название длиннее.
            CoverView(film: film, cornerRadius: compact ? Radius.small : Radius.medium)
                .fixedSize(horizontal: false, vertical: true)
            VStack(alignment: .leading, spacing: 0) {
                // Название — до двух строк; год и режиссёр сразу под ним.
                Text(film.title)
                    .textStyle(compact ? .caption : .sub, .medium)
                    .foregroundStyle(Theme.text)
                    .lineLimit(2)
                    .multilineTextAlignment(.leading)
                    .fixedSize(horizontal: false, vertical: true)
                if let subtitle, !subtitle.isEmpty {
                    Text(subtitle)
                        .textStyle(.caption)
                        .foregroundStyle(Theme.muted)
                        .lineLimit(1)
                        .padding(.top, Space.s4)
                }
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .contentShape(Rectangle())
        .accessibilityElement(children: .combine)
    }
}
