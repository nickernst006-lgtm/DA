import SwiftUI
import SwiftData
import PhotosUI
import UIKit
import CoreText

/// «Мой журнал» в карточке фильма: лента блоков, которую человек собирает сам.
/// Отступы по сетке: блоки через 24, подпись блока → содержимое 8, фото → подпись 4.
struct JournalSection: View {
    let filmID: String
    let essay: String
    /// Открыть редактор эссе (оно хранится в анкете).
    let onEditEssay: () -> Void

    @Environment(\.modelContext) private var context
    @Query private var blocks: [JournalBlock]

    @State private var editingMode = false
    @State private var showAdd = false
    @State private var editing: JournalBlock?
    @State private var boardBlock: JournalBlock?
    @State private var pickPhotos = false
    @State private var pickedItems: [PhotosPickerItem] = []
    @State private var pendingDelete: JournalBlock?

    init(filmID: String, essay: String, onEditEssay: @escaping () -> Void) {
        self.filmID = filmID
        self.essay = essay
        self.onEditEssay = onEditEssay
        let id = filmID
        _blocks = Query(filter: #Predicate<JournalBlock> { $0.filmID == id }, sort: \JournalBlock.order)
    }

    /// Блоки, которые есть что показать (место эссе без текста не показываем).
    private var visible: [JournalBlock] {
        blocks.filter { $0.kind != .essay || !essay.isEmpty }
    }

    var body: some View {
        VStack(alignment: .leading, spacing: Space.s16) {
            HStack(alignment: .firstTextBaseline) {
                Text("Мой журнал")
                    .textStyle(.h2)
                    .foregroundStyle(Theme.text)
                    .accessibilityAddTraits(.isHeader)
                Spacer()
                if !visible.isEmpty {
                    Button(editingMode ? "Готово" : "Править") {
                        withAnimation(.easeInOut(duration: 0.2)) { editingMode.toggle() }
                    }
                    .textStyle(.sub, .medium)
                    .foregroundStyle(editingMode ? Theme.accent : Theme.textSecondary)
                    .frame(minHeight: 44)
                }
            }

            if visible.isEmpty {
                Text("Соберите здесь всё о фильме: мысли, кадры, цитаты, факты и доску со связями.")
                    .textStyle(.sub)
                    .foregroundStyle(Theme.muted)
                    .fixedSize(horizontal: false, vertical: true)
            }

            VStack(alignment: .leading, spacing: Space.s24) {
                ForEach(Array(visible.enumerated()), id: \.element.id) { index, block in
                    blockView(block, index: index, count: visible.count)
                }
                addButton
            }
        }
        .onAppear { JournalActions.syncEssay(for: filmID, essay: essay, in: context) }
        .onChange(of: essay) { _, newValue in
            JournalActions.syncEssay(for: filmID, essay: newValue, in: context)
        }
        .sheet(isPresented: $showAdd) {
            AddBlockSheet { kind in
                showAdd = false
                add(kind)
            }
            .presentationDetents([.height(440)])
            .presentationDragIndicator(.visible)
        }
        .sheet(item: $editing) { block in
            BlockEditor(block: block)
        }
        .fullScreenCover(item: $boardBlock) { block in
            BoardEditor(block: block)
        }
        .photosPicker(isPresented: $pickPhotos, selection: $pickedItems, maxSelectionCount: 12, matching: .images)
        .onChange(of: pickedItems) { _, items in
            guard !items.isEmpty else { return }
            Task { await addPhotoBlock(items) }
        }
        .confirmationDialog("Удалить блок?", isPresented: Binding(
            get: { pendingDelete != nil }, set: { if !$0 { pendingDelete = nil } }
        ), titleVisibility: .visible) {
            Button("Удалить", role: .destructive) {
                if let block = pendingDelete { JournalActions.delete(block, in: context) }
                pendingDelete = nil
            }
            Button("Отмена", role: .cancel) { pendingDelete = nil }
        }
    }

    // MARK: Блок

    @ViewBuilder
    private func blockView(_ block: JournalBlock, index: Int, count: Int) -> some View {
        VStack(alignment: .leading, spacing: Space.s8) {
            if editingMode || block.kind.hasLabel {
                HStack(spacing: Space.s8) {
                    Text(block.kind.title.uppercased())
                        .textStyle(.caption, .medium)
                        .tracking(0.8)
                        .foregroundStyle(Theme.muted)
                    Spacer()
                    if editingMode {
                        controls(block, index: index, count: count)
                    }
                }
            }
            Button {
                open(block)
            } label: {
                BlockContent(block: block, essay: essay, onOpenBoard: { boardBlock = block })
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .contentShape(Rectangle())
            }
            .buttonStyle(.plain)
            .disabled(editingMode)
            .opacity(editingMode ? 0.6 : 1)
        }
    }

    private func controls(_ block: JournalBlock, index: Int, count: Int) -> some View {
        HStack(spacing: Space.s4) {
            iconButton("arrow.up", label: "Выше", enabled: index > 0) {
                withAnimation { JournalActions.move(block, by: -1, in: context) }
            }
            iconButton("arrow.down", label: "Ниже", enabled: index < count - 1) {
                withAnimation { JournalActions.move(block, by: 1, in: context) }
            }
            if block.kind != .essay {
                iconButton("trash", label: "Удалить", enabled: true) { pendingDelete = block }
            }
        }
    }

    private func iconButton(_ symbol: String, label: String, enabled: Bool, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Image(systemName: symbol)
                .font(.system(size: 14, weight: .semibold))
                .foregroundStyle(enabled ? Theme.text : Theme.lineStrong)
                .frame(width: 32, height: 32)
                .background(RoundedRectangle(cornerRadius: Radius.small, style: .continuous).fill(Theme.surfaceRaised))
        }
        .buttonStyle(.plain)
        .disabled(!enabled)
        .accessibilityLabel(label)
    }

    private var addButton: some View {
        Button {
            showAdd = true
        } label: {
            Label("Добавить блок", systemImage: "plus")
                .textStyle(.body, .bold)
                .foregroundStyle(Theme.textSecondary)
                .frame(maxWidth: .infinity, minHeight: Space.s48)
                .overlay(
                    Capsule().strokeBorder(Theme.lineStrong, style: StrokeStyle(lineWidth: 1.5, dash: [6, 5]))
                )
                .contentShape(Capsule())
        }
        .buttonStyle(.plain)
    }

    // MARK: Действия

    private func open(_ block: JournalBlock) {
        switch block.kind {
        case .essay: onEditEssay()
        case .board: boardBlock = block
        default: editing = block
        }
    }

    private func add(_ kind: JournalKind) {
        switch kind {
        case .photo:
            pickedItems = []
            // окно выбора открываем после того, как закроется «Добавить блок»
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.35) { pickPhotos = true }
        case .board:
            let block = JournalActions.add(.board, to: filmID, in: context)
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.35) { boardBlock = block }
        default:
            let block = JournalActions.add(kind, to: filmID, in: context)
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.35) { editing = block }
        }
    }

    private func addPhotoBlock(_ items: [PhotosPickerItem]) async {
        var datas: [Data] = []
        for item in items {
            if let data = try? await item.loadTransferable(type: Data.self) { datas.append(data) }
        }
        await MainActor.run {
            pickedItems = []
            guard !datas.isEmpty else { return }
            let block = JournalActions.add(.photo, to: filmID, in: context)
            JournalActions.addPhotos(datas, to: block, in: context)
        }
    }
}

extension JournalKind {
    /// Подпись над блоком в обычном режиме: у цитаты, факта и заголовка она не нужна — они говорят сами за себя.
    var hasLabel: Bool {
        switch self {
        case .text, .essay, .photo, .board: return true
        case .heading, .quote, .fact: return false
        }
    }
}

// MARK: - Содержимое блока

struct BlockContent: View {
    let block: JournalBlock
    let essay: String
    var onOpenBoard: () -> Void = {}

    var body: some View {
        switch block.kind {
        case .essay:
            paragraph(essay, style: .body, color: Theme.text)
        case .text:
            paragraph(block.text.isEmpty ? "Пустой текст — нажмите, чтобы написать" : block.text,
                      style: .body, color: block.text.isEmpty ? Theme.muted : Theme.text)
        case .heading:
            Text(block.text.isEmpty ? "Заголовок" : block.text)
                .textStyle(.h2)
                .foregroundStyle(block.text.isEmpty ? Theme.muted : Theme.text)
                .fixedSize(horizontal: false, vertical: true)
        case .quote:
            QuoteView(text: block.text, author: block.detail)
        case .fact:
            FactView(text: block.text)
        case .photo:
            VStack(alignment: .leading, spacing: Space.s4) {
                PhotoMosaic(photos: block.sortedPhotos)
                if !block.detail.isEmpty {
                    Text(block.detail)
                        .textStyle(.caption)
                        .foregroundStyle(Theme.muted)
                        .fixedSize(horizontal: false, vertical: true)
                }
            }
        case .board:
            BoardPreview(items: block.items, onOpen: onOpenBoard)
        }
    }

    private func paragraph(_ text: String, style: TextStyle, color: Color) -> some View {
        Text(text)
            .textStyle(style)
            .foregroundStyle(color)
            .multilineTextAlignment(.leading)
            .fixedSize(horizontal: false, vertical: true)
    }
}

/// Цитата: жёлтая черта слева, текст шрифтом логотипа, ниже — кто сказал.
struct QuoteView: View {
    let text: String
    let author: String

    var body: some View {
        HStack(alignment: .top, spacing: Space.s16) {
            Rectangle()
                .fill(Theme.accent)
                .frame(width: 4)
            VStack(alignment: .leading, spacing: Space.s8) {
                Text(text.isEmpty ? "Цитата" : "«\(text)»")
                    .textStyle(.quote)
                    .foregroundStyle(text.isEmpty ? Theme.muted : Theme.text)
                    .fixedSize(horizontal: false, vertical: true)
                if !author.isEmpty {
                    Text("— \(author)")
                        .textStyle(.sub)
                        .foregroundStyle(Theme.muted)
                }
            }
        }
        .fixedSize(horizontal: false, vertical: true)
    }
}

/// Факт: плашка с жёлтым «!».
struct FactView: View {
    let text: String

    var body: some View {
        HStack(alignment: .top, spacing: Space.s12) {
            Text("!")
                .textStyle(.h1)
                .foregroundStyle(Theme.accent)
                .accessibilityHidden(true)
            VStack(alignment: .leading, spacing: Space.s4) {
                Text("ФАКТ")
                    .textStyle(.caption, .medium)
                    .tracking(0.8)
                    .foregroundStyle(Theme.muted)
                Text(text.isEmpty ? "Короткий факт о фильме" : text)
                    .textStyle(.sub)
                    .foregroundStyle(text.isEmpty ? Theme.muted : Theme.textSecondary)
                    .fixedSize(horizontal: false, vertical: true)
            }
            Spacer(minLength: 0)
        }
        .padding(Space.s16)
        .background(RoundedRectangle(cornerRadius: Radius.large, style: .continuous).fill(Theme.surface))
    }
}

/// Подборка фото: 1 — во всю ширину, 2 — рядом, 3 и больше — большое слева и два справа.
struct PhotoMosaic: View {
    let photos: [JournalPhoto]
    var height: CGFloat = 200

    var body: some View {
        let images = photos.compactMap { p in PhotoCache.image(id: p.id, data: p.data).map { (p.id, $0) } }
        Group {
            switch images.count {
            case 0:
                RoundedRectangle(cornerRadius: Radius.medium, style: .continuous)
                    .fill(Theme.surface)
                    .frame(height: height)
                    .overlay(Text("Нет фото").textStyle(.sub).foregroundStyle(Theme.muted))
            case 1:
                tile(images[0].1)
                    .frame(height: height + 40)
            case 2:
                HStack(spacing: Space.s8) {
                    tile(images[0].1)
                    tile(images[1].1)
                }
                .frame(height: height)
            default:
                HStack(spacing: Space.s8) {
                    tile(images[0].1)
                        .frame(maxWidth: .infinity)
                        .layoutPriority(1)
                    VStack(spacing: Space.s8) {
                        tile(images[1].1)
                        tile(images[2].1)
                            .overlay {
                                if images.count > 3 {
                                    ZStack {
                                        Color.black.opacity(0.45)
                                        Text("+\(images.count - 3)")
                                            .textStyle(.h3)
                                            .foregroundStyle(Theme.text)
                                    }
                                    .clipShape(RoundedRectangle(cornerRadius: Radius.medium, style: .continuous))
                                }
                            }
                    }
                    .frame(width: 120)
                }
                .frame(height: height)
            }
        }
        .accessibilityLabel(Text(images.count == 1 ? String("Фото") : String("\(images.count) фото")))
    }

    private func tile(_ image: UIImage) -> some View {
        Color.clear
            .overlay(Image(uiImage: image).resizable().scaledToFill())
            .clipShape(RoundedRectangle(cornerRadius: Radius.medium, style: .continuous))
    }
}

// MARK: - «Добавить блок»

struct AddBlockSheet: View {
    let onPick: (JournalKind) -> Void

    private let columns = [
        GridItem(.flexible(), spacing: Space.s8),
        GridItem(.flexible(), spacing: Space.s8)
    ]

    var body: some View {
        VStack(alignment: .leading, spacing: Space.s16) {
            Text("Добавить блок")
                .textStyle(.h2)
                .foregroundStyle(Theme.text)
            LazyVGrid(columns: columns, spacing: Space.s8) {
                ForEach(JournalKind.addable) { kind in
                    Button {
                        onPick(kind)
                    } label: {
                        VStack(alignment: .leading, spacing: 0) {
                            Text(kind.glyph)
                                .font(Font(AppFont.uiFont(.h2) as CTFont))
                                .foregroundStyle(Theme.accent)
                            Spacer(minLength: Space.s8)
                            Text(kind.title)
                                .textStyle(.body, .bold)
                                .foregroundStyle(Theme.text)
                            Text(kind.hint)
                                .textStyle(.caption)
                                .foregroundStyle(Theme.muted)
                        }
                        .frame(maxWidth: .infinity, minHeight: 96, alignment: .leading)
                        .padding(Space.s16)
                        .background(RoundedRectangle(cornerRadius: Radius.large, style: .continuous).fill(Theme.surfaceRaised))
                    }
                    .buttonStyle(.plain)
                }
            }
            Spacer(minLength: 0)
        }
        .padding(.horizontal, Space.s20)
        .padding(.top, Space.s24)
        .background(Theme.background.ignoresSafeArea())
    }
}

// MARK: - Правка блока

struct BlockEditor: View {
    @Bindable var block: JournalBlock
    @Environment(\.modelContext) private var context
    @Environment(\.dismiss) private var dismiss
    @State private var pickedItems: [PhotosPickerItem] = []
    @State private var confirmDelete = false
    @FocusState private var focused: Bool

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: Space.s16) {
                    switch block.kind {
                    case .heading:
                        field("Заголовок", text: $block.text, style: .h2, multiline: false)
                    case .quote:
                        field("Слова героя", text: $block.text, style: .quote, multiline: true)
                        field("Кто сказал", text: $block.detail, style: .body, multiline: false, focus: false)
                    case .fact:
                        field("Например: фильм снимали семь лет", text: $block.text, style: .body, multiline: true)
                    case .photo:
                        photoEditor
                    default:
                        field("Что вы думаете о фильме?", text: $block.text, style: .body, multiline: true)
                    }

                    Button("Удалить блок", role: .destructive) { confirmDelete = true }
                        .textStyle(.body, .medium)
                        .foregroundStyle(Color(hex: 0xE5534B))
                        .frame(maxWidth: .infinity, minHeight: Space.s48)
                        .padding(.top, Space.s16)
                }
                .padding(.horizontal, Space.s20)
                .padding(.vertical, Space.s16)
            }
            .scrollDismissesKeyboard(.interactively)
            .background(Theme.background.ignoresSafeArea())
            .navigationTitle(block.kind.title)
            .navigationBarTitleDisplayMode(.inline)
            .toolbarBackground(Theme.background, for: .navigationBar)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("Готово") { finish() }
                        .fontWeight(.bold)
                }
            }
            .confirmationDialog("Удалить блок?", isPresented: $confirmDelete, titleVisibility: .visible) {
                Button("Удалить", role: .destructive) {
                    JournalActions.delete(block, in: context)
                    dismiss()
                }
            }
        }
        .onAppear { if block.kind != .photo { focused = true } }
        .onDisappear { cleanUp() }
    }

    /// Поле ввода. Фокус при открытии — только у главного поля блока.
    @ViewBuilder
    private func field(_ placeholder: String, text: Binding<String>, style: TextStyle, multiline: Bool, focus: Bool = true) -> some View {
        if focus {
            fieldBody(placeholder, text: text, style: style, multiline: multiline)
                .focused($focused)
        } else {
            fieldBody(placeholder, text: text, style: style, multiline: multiline)
        }
    }

    private func fieldBody(_ placeholder: String, text: Binding<String>, style: TextStyle, multiline: Bool) -> some View {
        Group {
            if multiline {
                TextField(placeholder, text: text, axis: .vertical)
                    .lineLimit(4...)
            } else {
                TextField(placeholder, text: text)
            }
        }
        .font(Font(AppFont.uiFont(style) as CTFont))
        .foregroundStyle(Theme.text)
        .padding(Space.s16)
        .background(RoundedRectangle(cornerRadius: Radius.medium, style: .continuous).fill(Theme.surface))
    }

    private var photoEditor: some View {
        VStack(alignment: .leading, spacing: Space.s16) {
            let photos = block.sortedPhotos
            LazyVGrid(columns: [GridItem(.adaptive(minimum: 96), spacing: Space.s8)], spacing: Space.s8) {
                ForEach(photos, id: \.id) { photo in
                    if let image = PhotoCache.image(id: photo.id, data: photo.data) {
                        Color.clear
                            .aspectRatio(1, contentMode: .fit)
                            .overlay(Image(uiImage: image).resizable().scaledToFill())
                            .clipShape(RoundedRectangle(cornerRadius: Radius.medium, style: .continuous))
                            .overlay(alignment: .topTrailing) {
                                Button {
                                    context.delete(photo)
                                    try? context.save()
                                } label: {
                                    Image(systemName: "xmark")
                                        .font(.system(size: 12, weight: .bold))
                                        .foregroundStyle(Theme.text)
                                        .frame(width: 28, height: 28)
                                        .background(Circle().fill(Color.black.opacity(0.6)))
                                }
                                .buttonStyle(.plain)
                                .padding(Space.s4)
                                .accessibilityLabel("Убрать фото")
                            }
                    }
                }
            }
            PhotosPicker(selection: $pickedItems, maxSelectionCount: 12, matching: .images) {
                Label("Добавить фото", systemImage: "photo.on.rectangle")
                    .frame(maxWidth: .infinity)
            }
            .buttonStyle(SecondaryButtonStyle())
            .onChange(of: pickedItems) { _, items in
                guard !items.isEmpty else { return }
                Task {
                    var datas: [Data] = []
                    for item in items {
                        if let data = try? await item.loadTransferable(type: Data.self) { datas.append(data) }
                    }
                    await MainActor.run {
                        JournalActions.addPhotos(datas, to: block, in: context)
                        pickedItems = []
                    }
                }
            }
            field("Подпись к фото", text: $block.detail, style: .sub, multiline: false, focus: false)
        }
    }

    private func finish() {
        try? context.save()
        dismiss()
    }

    /// Пустой текстовый блок не оставляем в ленте.
    private func cleanUp() {
        guard block.modelContext != nil, !block.isDeleted else { return }
        let empty: Bool
        switch block.kind {
        case .photo: empty = (block.photos ?? []).isEmpty
        case .board, .essay: empty = false
        default: empty = block.text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
        }
        if empty { JournalActions.delete(block, in: context) } else { try? context.save() }
    }
}
