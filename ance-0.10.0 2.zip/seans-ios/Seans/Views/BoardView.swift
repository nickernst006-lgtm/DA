import SwiftUI
import UIKit
import SwiftData
import PhotosUI
import CoreText

/// Доска 1600 × 1600 точек. Элементы стоят по центру своих координат.
enum BoardSpace {
    static let size: CGFloat = 1600
    static let center = CGPoint(x: 800, y: 800)

    /// Примерный размер элемента — для стрелок и уменьшенной копии.
    static func size(of item: BoardItem) -> CGSize {
        let w = CGFloat(item.width)
        switch item.kind {
        case .sticker: return CGSize(width: w, height: max(48, w * 0.5))
        case .text: return CGSize(width: w, height: 40)
        case .photo: return CGSize(width: w + 8, height: w * 0.75 + 28)
        case .arrow: return .zero
        }
    }

    /// Рамка, в которой лежат все элементы.
    static func bounds(of items: [BoardItem]) -> CGRect {
        let rects = items.filter { $0.kind != .arrow }.map { item -> CGRect in
            let s = size(of: item)
            return CGRect(x: item.x - s.width / 2, y: item.y - s.height / 2, width: s.width, height: s.height)
        }
        guard var union = rects.first else {
            return CGRect(x: 600, y: 650, width: 400, height: 300)
        }
        for r in rects.dropFirst() { union = union.union(r) }
        return union
    }
}

// MARK: - Холст

/// Доска: точки-сетка, стрелки и элементы. Используется и в редакторе, и в ленте.
struct BoardCanvas: View {
    let items: [BoardItem]
    var selectedID: UUID? = nil
    var arrowFrom: UUID? = nil
    /// Живое смещение перетаскиваемого элемента (в точках доски).
    var dragging: (id: UUID, offset: CGSize)? = nil

    var body: some View {
        ZStack {
            // точки сетки каждые 24
            Canvas { context, size in
                let step: CGFloat = 24
                var y: CGFloat = step
                while y < size.height {
                    var x: CGFloat = step
                    while x < size.width {
                        context.fill(Path(ellipseIn: CGRect(x: x - 1, y: y - 1, width: 2, height: 2)),
                                     with: .color(Color(hex: 0x2A2A2A)))
                        x += step
                    }
                    y += step
                }
            }
            // стрелки
            Canvas { context, _ in
                let byID = Dictionary(uniqueKeysWithValues: items.map { ($0.id, $0) })
                for arrow in items where arrow.kind == .arrow {
                    guard let fromID = arrow.fromID, let toID = arrow.toID,
                          let a = byID[fromID], let b = byID[toID] else { continue }
                    drawArrow(from: a, to: b, in: &context)
                }
            }
            ForEach(items.filter { $0.kind != .arrow }, id: \.id) { item in
                BoardItemView(item: item,
                              selected: item.id == selectedID || item.id == arrowFrom)
                    .position(position(of: item))
            }
        }
        .frame(width: BoardSpace.size, height: BoardSpace.size)
    }

    private func position(of item: BoardItem) -> CGPoint {
        var p = CGPoint(x: item.x, y: item.y)
        if let dragging, dragging.id == item.id {
            p.x += dragging.offset.width
            p.y += dragging.offset.height
        }
        return p
    }

    private func drawArrow(from a: BoardItem, to b: BoardItem, in context: inout GraphicsContext) {
        let pa = position(of: a), pb = position(of: b)
        let dx = pb.x - pa.x, dy = pb.y - pa.y
        let length = hypot(dx, dy)
        guard length > 1 else { return }
        // от края одного элемента до края другого
        func edge(_ size: CGSize) -> CGFloat {
            let tx = abs(dx) > 0.01 ? (size.width / 2) / abs(dx) : .infinity
            let ty = abs(dy) > 0.01 ? (size.height / 2) / abs(dy) : .infinity
            return min(tx, ty) * length
        }
        let startGap = edge(BoardSpace.size(of: a)) + 6
        let endGap = edge(BoardSpace.size(of: b)) + 10
        guard startGap + endGap < length else { return }
        let ux = dx / length, uy = dy / length
        let start = CGPoint(x: pa.x + ux * startGap, y: pa.y + uy * startGap)
        let end = CGPoint(x: pb.x - ux * endGap, y: pb.y - uy * endGap)
        // лёгкий изгиб — как от руки
        let mid = CGPoint(x: (start.x + end.x) / 2 - uy * length * 0.08,
                          y: (start.y + end.y) / 2 + ux * length * 0.08)
        var path = Path()
        path.move(to: start)
        path.addQuadCurve(to: end, control: mid)
        let color = Color(hex: 0xC8C8C8)
        context.stroke(path, with: .color(color), style: StrokeStyle(lineWidth: 2.5, lineCap: .round))
        // наконечник
        let angle = atan2(end.y - mid.y, end.x - mid.x)
        let head: CGFloat = 12
        var tip = Path()
        tip.move(to: end)
        tip.addLine(to: CGPoint(x: end.x - head * cos(angle - .pi / 7), y: end.y - head * sin(angle - .pi / 7)))
        tip.addLine(to: CGPoint(x: end.x - head * cos(angle + .pi / 7), y: end.y - head * sin(angle + .pi / 7)))
        tip.closeSubpath()
        context.fill(tip, with: .color(color))
    }
}

/// Один элемент доски: стикер, надпись или фото-полароид.
struct BoardItemView: View {
    let item: BoardItem
    var selected = false

    var body: some View {
        content
            .rotationEffect(.degrees(item.rotation))
            .overlay {
                if selected {
                    RoundedRectangle(cornerRadius: Radius.small, style: .continuous)
                        .stroke(Theme.accent, lineWidth: 2)
                        .padding(-6)
                        .rotationEffect(.degrees(item.rotation))
                }
            }
    }

    @ViewBuilder
    private var content: some View {
        let width = CGFloat(item.width)
        switch item.kind {
        case .sticker:
            Text(item.text.isEmpty ? "Стикер" : item.text)
                .textStyle(.sub, .bold, fixed: true)
                .foregroundStyle(Color(hex: 0x1A1A1A))
                .multilineTextAlignment(.leading)
                .padding(.horizontal, Space.s12)
                .padding(.vertical, Space.s8)
                .frame(width: width, alignment: .leading)
                .frame(minHeight: 48)
                .background(RoundedRectangle(cornerRadius: 4, style: .continuous)
                    .fill(Color(hex: StickerPalette.color(item.colorIndex))))
                .shadow(color: .black.opacity(0.45), radius: 7, y: 4)
        case .text:
            Text(item.text.isEmpty ? "Надпись" : item.text)
                .textStyle(.h2, fixed: true)
                .foregroundStyle(Theme.text)
                .multilineTextAlignment(.center)
                .frame(width: width)
        case .photo:
            VStack(alignment: .leading, spacing: Space.s4) {
                Color(hex: 0x2A2A2A)
                    .overlay {
                        if let image = PhotoCache.image(id: item.id, data: item.imageData) {
                            Image(uiImage: image).resizable().scaledToFill()
                        }
                    }
                    .frame(width: width, height: width * 0.75)
                    .clipped()
                Text(item.text)
                    .textStyle(.caption, fixed: true)
                    .foregroundStyle(Color(hex: 0x333333))
                    .lineLimit(1)
                    .frame(width: width, height: 16, alignment: .leading)
            }
            .padding(.horizontal, Space.s4)
            .padding(.top, Space.s4)
            .padding(.bottom, Space.s4)
            .background(Color(hex: 0xF2F2F2))
            .shadow(color: .black.opacity(0.5), radius: 9, y: 5)
        case .arrow:
            EmptyView()
        }
    }
}

// MARK: - Уменьшенная доска в ленте

struct BoardPreview: View {
    let items: [BoardItem]
    let onOpen: () -> Void

    var body: some View {
        GeometryReader { geo in
            let bounds = BoardSpace.bounds(of: items).insetBy(dx: -24, dy: -24)
            let scale = min(geo.size.width / bounds.width, geo.size.height / bounds.height, 0.8)
            BoardCanvas(items: items)
                .scaleEffect(scale, anchor: .topLeading)
                .offset(x: -bounds.minX * scale + (geo.size.width - bounds.width * scale) / 2,
                        y: -bounds.minY * scale + (geo.size.height - bounds.height * scale) / 2)
                .frame(width: geo.size.width, height: geo.size.height, alignment: .topLeading)
                .allowsHitTesting(false)
        }
        .frame(height: 224)
        .background(Color(hex: 0x0D0D0D))
        .clipShape(RoundedRectangle(cornerRadius: Radius.medium, style: .continuous))
        .overlay(alignment: .center) {
            if items.isEmpty {
                Text("Пустая доска")
                    .textStyle(.sub)
                    .foregroundStyle(Theme.muted)
            }
        }
        .overlay(alignment: .bottomTrailing) {
            Button(action: onOpen) {
                Text("Открыть доску")
                    .textStyle(.sub, .bold)
                    .foregroundStyle(Color.black)
                    .padding(.horizontal, Space.s12)
                    .frame(height: 32)
                    .background(Capsule().fill(Theme.text))
            }
            .buttonStyle(.plain)
            .padding(Space.s12)
        }
        .accessibilityElement(children: .combine)
        .accessibilityLabel("Доска: \(items.filter { $0.kind != .arrow }.count) элементов")
    }
}

// MARK: - Редактор доски на весь экран

struct BoardEditor: View {
    @Bindable var block: JournalBlock
    @Environment(\.modelContext) private var context
    @Environment(\.dismiss) private var dismiss

    @State private var scale: CGFloat = 0.9
    @State private var baseScale: CGFloat = 0.9
    @State private var pan: CGSize = .zero
    @State private var basePan: CGSize = .zero
    @State private var selectedID: UUID?
    @State private var arrowMode = false
    @State private var arrowFrom: UUID?
    @State private var dragging: (id: UUID, offset: CGSize)?
    @State private var editingText: BoardItem?
    @State private var draftText = ""
    @State private var pickedPhoto: PhotosPickerItem?
    @State private var pickPhoto = false

    private var items: [BoardItem] { block.items }
    private var selected: BoardItem? { items.first { $0.id == selectedID } }

    var body: some View {
        ZStack {
            Color(hex: 0x0B0B0B).ignoresSafeArea()

            // Доска 1600 × 1600 стоит по центру экрана; масштаб и сдвиг — эффектами,
            // поэтому центр экрана всегда = центр доски + сдвиг.
            BoardCanvas(items: items, selectedID: selectedID, arrowFrom: arrowFrom, dragging: dragging)
                .scaleEffect(scale)
                .offset(pan)
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                .clipped()
                .contentShape(Rectangle())
                .gesture(panAndZoom)
                .onTapGesture {
                    selectedID = nil
                    arrowFrom = nil
                }
                .overlay { itemHitAreas }
                .ignoresSafeArea()
        }
        .safeAreaInset(edge: .top, spacing: 0) { topBar }
        .safeAreaInset(edge: .bottom, spacing: 0) { bottomBars }
        .onAppear(perform: fitToContent)
        .onDisappear(perform: cleanUp)
        .alert("Текст", isPresented: Binding(get: { editingText != nil }, set: { if !$0 { editingText = nil } })) {
            TextField("Текст", text: $draftText)
            Button("Готово") {
                editingText?.text = draftText
                try? context.save()
                editingText = nil
            }
            Button("Отмена", role: .cancel) { editingText = nil }
        }
        .photosPicker(isPresented: $pickPhoto, selection: $pickedPhoto, matching: .images)
        .onChange(of: pickedPhoto) { _, item in
            guard let item else { return }
            Task {
                let data = try? await item.loadTransferable(type: Data.self)
                await MainActor.run {
                    pickedPhoto = nil
                    if let data, let prepared = ImagePrep.jpeg(from: data, maxSide: 1200) {
                        let added = add(.photo, width: 200)
                        added.imageData = prepared
                        try? context.save()
                    }
                }
            }
        }
    }

    // MARK: Касания элементов

    /// Над холстом — прозрачные области элементов в экранных координатах, чтобы ловить касания и перетаскивание.
    private var itemHitAreas: some View {
        GeometryReader { geo in
            let center = CGPoint(x: geo.size.width / 2, y: geo.size.height / 2)
            ForEach(items.filter { $0.kind != .arrow }, id: \.id) { item in
                let s = BoardSpace.size(of: item)
                Color.white.opacity(0.001)
                    .frame(width: s.width * scale, height: s.height * scale)
                    .position(screenPoint(item, center: center))
                    .onTapGesture { tap(item) }
                    .gesture(
                        DragGesture(minimumDistance: 3)
                            .onChanged { value in
                                selectedID = item.id
                                dragging = (item.id, CGSize(width: value.translation.width / scale,
                                                            height: value.translation.height / scale))
                            }
                            .onEnded { value in
                                item.x += Double(value.translation.width / scale)
                                item.y += Double(value.translation.height / scale)
                                item.x = min(max(item.x, 40), Double(BoardSpace.size) - 40)
                                item.y = min(max(item.y, 40), Double(BoardSpace.size) - 40)
                                dragging = nil
                                try? context.save()
                            }
                    )
            }
        }
    }

    private func screenPoint(_ item: BoardItem, center: CGPoint) -> CGPoint {
        var p = CGPoint(x: item.x, y: item.y)
        if let dragging, dragging.id == item.id {
            p.x += dragging.offset.width
            p.y += dragging.offset.height
        }
        return CGPoint(x: center.x + (p.x - BoardSpace.center.x) * scale + pan.width,
                       y: center.y + (p.y - BoardSpace.center.y) * scale + pan.height)
    }

    private var panAndZoom: some Gesture {
        SimultaneousGesture(
            DragGesture()
                .onChanged { value in
                    pan = CGSize(width: basePan.width + value.translation.width,
                                 height: basePan.height + value.translation.height)
                }
                .onEnded { _ in basePan = pan },
            MagnifyGesture()
                .onChanged { value in
                    scale = min(max(baseScale * value.magnification, 0.3), 2.5)
                }
                .onEnded { _ in baseScale = scale }
        )
    }

    private func tap(_ item: BoardItem) {
        if arrowMode {
            if let from = arrowFrom, from != item.id {
                let arrow = add(.arrow, width: 0)
                arrow.fromID = from
                arrow.toID = item.id
                try? context.save()
                arrowFrom = nil
                arrowMode = false
            } else {
                arrowFrom = item.id
            }
            return
        }
        if selectedID == item.id {
            startEditing(item)
        } else {
            selectedID = item.id
        }
    }

    // MARK: Панели

    private var topBar: some View {
        HStack {
            Text("Доска")
                .textStyle(.body, .bold)
                .foregroundStyle(Theme.text)
            Spacer()
            Button("Готово") {
                try? context.save()
                dismiss()
            }
            .textStyle(.body, .bold)
            .foregroundStyle(Theme.accent)
            .frame(minHeight: 44)
        }
        .padding(.horizontal, Space.s20)
        .background(Color.black.opacity(0.6).ignoresSafeArea(edges: .top))
    }

    private var bottomBars: some View {
        VStack(spacing: Space.s8) {
            if arrowMode {
                hint(arrowFrom == nil ? "Нажмите, откуда тянуть стрелку" : "Теперь — куда")
            } else if let selected {
                selectionBar(selected)
            }
            HStack(spacing: 0) {
                tool("Стикер", glyph: AnyView(RoundedRectangle(cornerRadius: 4).fill(Color(hex: 0xF2C14E)).frame(width: 24, height: 24))) {
                    let item = add(.sticker, width: 150)
                    item.colorIndex = items.count
                    startEditing(item)
                }
                tool("Текст", glyph: AnyView(Text("Аа").textStyle(.body, .bold).foregroundStyle(Theme.textSecondary))) {
                    startEditing(add(.text, width: 240))
                }
                tool("Фото", glyph: AnyView(Image(systemName: "photo").font(.system(size: 20)).foregroundStyle(Theme.textSecondary))) {
                    pickPhoto = true
                }
                tool(arrowMode ? "Отмена" : "Стрелка", glyph: AnyView(Image(systemName: "arrow.up.right").font(.system(size: 20, weight: .semibold)).foregroundStyle(arrowMode ? Theme.accent : Theme.textSecondary))) {
                    arrowMode.toggle()
                    arrowFrom = nil
                    selectedID = nil
                }
            }
            .frame(height: 64)
            .background(Capsule().fill(Color(hex: 0x262628).opacity(0.95)))
        }
        .padding(.horizontal, Space.s20)
        .padding(.bottom, Space.s8)
    }

    private func hint(_ text: String) -> some View {
        Text(text)
            .textStyle(.sub)
            .foregroundStyle(Theme.text)
            .padding(.horizontal, Space.s16)
            .frame(height: 40)
            .background(Capsule().fill(Theme.surfaceRaised))
    }

    private func selectionBar(_ item: BoardItem) -> some View {
        HStack(spacing: Space.s8) {
            if item.kind != .photo {
                barButton("Изменить") { startEditing(item) }
            } else {
                barButton("Подпись") { startEditing(item) }
            }
            if item.kind == .sticker {
                barButton("Цвет") {
                    item.colorIndex += 1
                    try? context.save()
                }
            }
            barButton("Наверх") {
                item.z = (items.map(\.z).max() ?? 0) + 1
                try? context.save()
            }
            barButton("Удалить", destructive: true) { remove(item) }
        }
    }

    private func barButton(_ title: String, destructive: Bool = false, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Text(title)
                .textStyle(.sub, .medium)
                .foregroundStyle(destructive ? Color(hex: 0xE5534B) : Theme.text)
                .padding(.horizontal, Space.s12)
                .frame(height: 40)
                .background(Capsule().fill(Theme.surfaceRaised))
        }
        .buttonStyle(.plain)
    }

    private func tool(_ title: String, glyph: AnyView, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            VStack(spacing: Space.s4) {
                glyph.frame(height: 24)
                Text(title)
                    .textStyle(.caption)
                    .foregroundStyle(Theme.textSecondary)
            }
            .frame(maxWidth: .infinity)
        }
        .buttonStyle(.plain)
    }

    // MARK: Действия

    /// Новый элемент в центре видимой части доски.
    @discardableResult
    private func add(_ kind: BoardItemKind, width: Double) -> BoardItem {
        let x = Double(BoardSpace.center.x - pan.width / scale) + Double.random(in: -30...30)
        let y = Double(BoardSpace.center.y - pan.height / scale) + Double.random(in: -30...30)
        let z = (items.map(\.z).max() ?? 0) + 1
        let item = BoardItem(kind: kind, x: x, y: y, width: width, z: z)
        context.insert(item)
        item.block = block
        try? context.save()
        if kind != .arrow { selectedID = item.id }
        return item
    }

    private func startEditing(_ item: BoardItem) {
        draftText = item.text
        editingText = item
    }

    private func remove(_ item: BoardItem) {
        // вместе с элементом уходят и его стрелки
        for arrow in items where arrow.kind == .arrow && (arrow.fromID == item.id || arrow.toID == item.id) {
            context.delete(arrow)
        }
        context.delete(item)
        selectedID = nil
        try? context.save()
    }

    /// Показать все элементы при открытии.
    private func fitToContent() {
        guard !items.isEmpty else { return }
        let bounds = BoardSpace.bounds(of: items)
        let screen = UIScreen.main.bounds.size
        let fit = min((screen.width - 40) / bounds.width, (screen.height - 260) / bounds.height)
        scale = min(max(fit, 0.3), 1.2)
        baseScale = scale
        pan = CGSize(width: (BoardSpace.center.x - bounds.midX) * scale,
                     height: (BoardSpace.center.y - bounds.midY) * scale)
        basePan = pan
    }

    /// Пустую доску не оставляем в ленте.
    private func cleanUp() {
        guard block.modelContext != nil, !block.isDeleted else { return }
        if (block.boardItems ?? []).isEmpty {
            JournalActions.delete(block, in: context)
        } else {
            try? context.save()
        }
    }
}
