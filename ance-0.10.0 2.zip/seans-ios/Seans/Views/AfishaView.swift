import SwiftUI
import SwiftData

/// Вкладка «Вселенная»: поиск, кнопки фильтров, «Выбрать фильм вдвоём»,
/// подборки «Рекомендации», «Русские», «Зарубежные» и случайные фильмы из базы.
struct AfishaView: View {
    @Environment(Library.self) private var library
    @Query private var surveys: [SurveyEntry]

    @State private var query = ""
    @State private var filter = FilmFilter()
    @State private var openSection: FilterSection?
    /// Сколько случайных фильмов уже показано — подгружаются по мере прокрутки.
    @State private var randomLimit = 60
    @State private var showEvening = false
    @State private var showScrollTop = false
    @Environment(\.dockClearance) private var dockClearance

    private let columns = [
        GridItem(.flexible(), spacing: Space.s12, alignment: .top),
        GridItem(.flexible(), spacing: Space.s12, alignment: .top)
    ]

    private var isSearching: Bool {
        !query.trimmingCharacters(in: .whitespaces).isEmpty
    }

    private var personal: [String: PersonalTags] {
        var result: [String: PersonalTags] = [:]
        for s in surveys { result[s.filmID] = PersonalTags(emotions: s.emotions, word: s.word) }
        return result
    }

    var body: some View {
        NavigationStack {
            ScrollViewReader { reader in
                ScrollView {
                    VStack(alignment: .leading, spacing: Space.s32) {
                        VStack(alignment: .leading, spacing: ScreenLayout.titleGap) {
                            // Метка прокрутки — фоном заголовка, а не отдельной строкой:
                            // иначе отступ стопки сдвигал заголовок ниже, чем на других вкладках.
                            ScreenTitle("Вселенная")
                                .padding(.top, Space.s12)
                                .background(alignment: .top) {
                                    GeometryReader { geo in
                                        Color.clear.preference(key: ScrollOffsetKey.self,
                                                               value: geo.frame(in: .named("universeScroll")).minY)
                                    }
                                }
                                .id("top")

                            VStack(alignment: .leading, spacing: Space.s12) {
                                // Поле поиска во всю ширину, как переключатель в «Коллекции».
                                SearchField(text: $query)
                                filterBar
                            }
                        }

                        if isSearching || !filter.isEmpty {
                            searchResults
                        } else {
                            eveningCard
                            shelf("Рекомендации", films: library.featured)
                            shelf("Русские", films: library.russian)
                            shelf("Зарубежные", films: library.foreign)
                            randomGrid
                        }
                    }
                    .padding(.horizontal, Space.s20)
                    .padding(.bottom, Space.s24)
                }
                .dockClearance()
                .coordinateSpace(name: "universeScroll")
                .onPreferenceChange(ScrollOffsetKey.self) { offset in
                    let shouldShow = offset < -700
                    if shouldShow != showScrollTop {
                        withAnimation(.easeInOut(duration: 0.2)) { showScrollTop = shouldShow }
                    }
                }
                .overlay(alignment: .bottomTrailing) {
                    if showScrollTop {
                        Button {
                            withAnimation(.easeInOut(duration: 0.35)) { reader.scrollTo("top", anchor: .top) }
                        } label: {
                            Image(systemName: "arrow.up")
                                .font(.system(size: 18, weight: .semibold))
                                .foregroundStyle(Color.black)
                                .frame(width: 48, height: 48)
                                .background(Circle().fill(Theme.text))
                                .shadow(color: .black.opacity(0.4), radius: 10, y: 4)
                        }
                        .buttonStyle(.plain)
                        .padding(.trailing, Space.s20)
                        // Кнопка — над доком: отступ под док без «воздуха» плюс 14 pt.
                        .padding(.bottom, max(14, dockClearance - 10))
                        .transition(.scale(scale: 0.6).combined(with: .opacity))
                        .accessibilityLabel("Наверх")
                    }
                }
            }
            .scrollDismissesKeyboard(.immediately)
            .background(Theme.background.ignoresSafeArea())
            .toolbar(.hidden, for: .navigationBar)
            .navigationDestination(for: FilmRoute.self) { route in
                FilmDetailView(filmID: route.id)
            }
        }
        .sheet(item: $openSection) { section in
            let detents: Set<PresentationDetent> = section == .director || section == .country ? [.large] : [.medium, .large]
            FilterSheet(filter: $filter, section: section)
                .presentationDetents(detents)
        }
        .fullScreenCover(isPresented: $showEvening) {
            EveningView()
        }
    }

    /// Кнопки фильтров под строкой поиска. Выбранный фильтр — белый.
    private var filterBar: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: Space.s8) {
                ForEach(FilterSection.allCases) { section in
                    let active = filter.isActive(section)
                    Button {
                        openSection = section
                    } label: {
                        HStack(spacing: Space.s8) {
                            Text(filter.label(section))
                                .lineLimit(1)
                            Image(systemName: "chevron.down")
                                .font(.system(size: 11, weight: .semibold))
                        }
                        .textStyle(.sub, .medium)
                        .foregroundStyle(active ? Color.black : Theme.text)
                        .padding(.horizontal, Space.s16)
                        .frame(height: 40)
                        .background(Capsule().fill(active ? Theme.text : Theme.surface))
                    }
                    .buttonStyle(.plain)
                    .accessibilityLabel(active ? "\(section.title): \(filter.selectedTitles(section).joined(separator: ", "))" : section.title)
                }
                if !filter.isEmpty {
                    Button("Сбросить") { filter = FilmFilter() }
                        .textStyle(.sub, .medium)
                        .foregroundStyle(Theme.textSecondary)
                        .frame(height: 40)
                        .padding(.horizontal, Space.s8)
                }
            }
            .padding(.horizontal, Space.s20)
        }
        .padding(.horizontal, -20)
    }

    private var eveningCard: some View {
        Button {
            showEvening = true
        } label: {
            HStack(spacing: Space.s12) {
                Image(systemName: "person.2.fill")
                    .font(.system(size: 17))
                    .foregroundStyle(Color.black)
                    .frame(width: 44, height: 44)
                    .background(Circle().fill(Theme.text))
                    .accessibilityHidden(true)
                VStack(alignment: .leading, spacing: Space.s4) {
                    Text("Выбрать фильм вдвоём")
                        .textStyle(.body, .bold)
                        .foregroundStyle(Theme.text)
                    Text("Что посмотрим вечером?")
                        .textStyle(.sub)
                        .foregroundStyle(Theme.muted)
                }
                Spacer(minLength: 0)
                Image(systemName: "arrow.right")
                    .font(.system(size: 15, weight: .medium))
                    .foregroundStyle(Theme.muted)
                    .accessibilityHidden(true)
            }
            .padding(Space.s16)
            .background(RoundedRectangle(cornerRadius: Radius.large, style: .continuous).fill(Theme.surface))
        }
        .buttonStyle(.plain)
    }

    @ViewBuilder
    private var searchResults: some View {
        let results: [FilmItem] = {
            if isSearching {
                let found = library.search(query, limit: 400)
                return filter.isEmpty ? found : found.filter { filter.matches($0, personal: personal[$0.id]) }
            }
            return library.filter(filter, personal: personal)
        }()
        if results.isEmpty {
            VStack(alignment: .leading, spacing: Space.s8) {
                Text("Ничего не нашлось")
                    .textStyle(.h3)
                    .foregroundStyle(Theme.text)
                Text(isSearching
                     ? "Этого фильма пока нет в базе ance или он не подходит под фильтры."
                     : "Под такие фильтры фильмов нет. Попробуйте убрать часть фильтров.")
                    .textStyle(.sub)
                    .foregroundStyle(Theme.muted)
                    .fixedSize(horizontal: false, vertical: true)
                if !filter.isEmpty {
                    Button("Сбросить фильтры") { filter = FilmFilter() }
                        .buttonStyle(SecondaryButtonStyle())
                        .padding(.top, Space.s8)
                }
            }
            .padding(.top, Space.s8)
        } else {
            filmGrid(title: "Найдено: \(results.count)", films: results)
        }
    }

    /// Ширина плитки в подборках: на экране видно две с половиной обложки.
    private let shelfTileWidth: CGFloat = 160

    /// Подборка — горизонтальная лента обложек.
    @ViewBuilder
    private func shelf(_ title: String, films: [FilmItem]) -> some View {
        if !films.isEmpty {
            VStack(alignment: .leading, spacing: Space.s16) {
                SectionTitle(title)
                ScrollView(.horizontal, showsIndicators: false) {
                    LazyHStack(alignment: .top, spacing: Space.s12) {
                        ForEach(films) { film in
                            NavigationLink(value: FilmRoute(id: film.id)) {
                                FilmTile(film: film, subtitle: film.shortMeta)
                                    .frame(width: shelfTileWidth)
                            }
                            .buttonStyle(.plain)
                        }
                    }
                    .padding(.horizontal, Space.s20)
                }
                .padding(.horizontal, -20)
            }
        }
    }

    /// Случайные фильмы из базы — сеткой, подгружаются при прокрутке.
    private var randomGrid: some View {
        VStack(alignment: .leading, spacing: Space.s16) {
            SectionTitle("Случайные фильмы")
            LazyVGrid(columns: columns, alignment: .leading, spacing: Space.s24) {
                ForEach(library.shuffled.prefix(randomLimit)) { film in
                    NavigationLink(value: FilmRoute(id: film.id)) {
                        FilmTile(film: film, subtitle: film.shortMeta)
                    }
                    .buttonStyle(.plain)
                    .onAppear {
                        if film.id == library.shuffled.prefix(randomLimit).last?.id && randomLimit < library.shuffled.count {
                            randomLimit += 60
                        }
                    }
                }
            }
        }
    }

    private func filmGrid(title: String, films: [FilmItem]) -> some View {
        VStack(alignment: .leading, spacing: Space.s16) {
            SectionTitle(title)
            LazyVGrid(columns: columns, alignment: .leading, spacing: Space.s24) {
                ForEach(films) { film in
                    NavigationLink(value: FilmRoute(id: film.id)) {
                        FilmTile(film: film, subtitle: film.shortMeta)
                    }
                    .buttonStyle(.plain)
                }
            }
        }
    }
}

/// Положение верха прокрутки — чтобы показать кнопку «Наверх».
private struct ScrollOffsetKey: PreferenceKey {
    static let defaultValue: CGFloat = 0
    static func reduce(value: inout CGFloat, nextValue: () -> CGFloat) {
        value = nextValue()
    }
}
