import SwiftUI
import SwiftData
import UIKit

/// Вкладка «Друзья»: личная ссылка-приглашение и список добавленных друзей.
struct FriendsView: View {
    @Environment(\.modelContext) private var context
    @AppStorage("myFriendCode") private var myCode = ""
    @AppStorage("myDisplayName") private var myName = ""
    @Query(sort: \Friend.addedAt, order: .reverse) private var friends: [Friend]

    @State private var showAdd = false
    @State private var copied = false
    @State private var friendToDelete: Friend?

    private var invite: FriendInvite {
        FriendInvite(code: myCode, name: myName.trimmingCharacters(in: .whitespacesAndNewlines))
    }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: Space.s32) {
                VStack(alignment: .leading, spacing: ScreenLayout.titleGap) {
                    ScreenTitle("Друзья")
                        .padding(.top, Space.s12)

                    inviteCard
                }

                Button {
                    showAdd = true
                } label: {
                    Label("Добавить по коду или ссылке", systemImage: "plus")
                }
                .buttonStyle(SecondaryButtonStyle())

                friendsList
            }
            .padding(.horizontal, Space.s20)
            .padding(.bottom, Space.s32)
        }
        .dockClearance()
        .scrollDismissesKeyboard(.interactively)
        .background(Theme.background.ignoresSafeArea())
        .onAppear {
            if myCode.isEmpty { myCode = FriendInvite.makeCode() }
        }
        .sheet(isPresented: $showAdd) {
            AddFriendSheet(myCode: myCode)
        }
        .confirmationDialog(
            "Удалить из друзей?",
            isPresented: Binding(get: { friendToDelete != nil }, set: { if !$0 { friendToDelete = nil } }),
            titleVisibility: .visible,
            presenting: friendToDelete
        ) { friend in
            Button("Удалить «\(friend.name)»", role: .destructive) {
                context.delete(friend)
                try? context.save()
            }
            Button("Отмена", role: .cancel) {}
        }
    }

    // MARK: Ссылка-приглашение

    private var inviteCard: some View {
        VStack(alignment: .leading, spacing: Space.s16) {
            VStack(alignment: .leading, spacing: Space.s4) {
                Text("Ваша ссылка")
                    .textStyle(.h3)
                    .foregroundStyle(Theme.text)
                Text("Отправьте её другу: он откроет ссылку в ance — и вы появитесь у него в друзьях. Попросите его прислать свою ссылку в ответ.")
                    .textStyle(.sub)
                    .foregroundStyle(Theme.muted)
                    .fixedSize(horizontal: false, vertical: true)
            }

            VStack(alignment: .leading, spacing: Space.s8) {
                Text("Ваше имя для друзей")
                    .textStyle(.caption)
                    .foregroundStyle(Theme.muted)
                TextField("", text: $myName, prompt: Text("Как вас подписать").foregroundColor(Theme.muted))
                    .textStyle(.body)
                    .foregroundStyle(Theme.text)
                    .textContentType(.givenName)
                    .submitLabel(.done)
                    .padding(.horizontal, Space.s12)
                    .frame(minHeight: 48)
                    .background(RoundedRectangle(cornerRadius: Radius.medium, style: .continuous).fill(Theme.surfaceRaised))
                    .accessibilityLabel("Ваше имя для друзей")
                    .onChange(of: myName) { _, newValue in
                        if newValue.count > 30 { myName = String(newValue.prefix(30)) }
                    }
            }

            VStack(alignment: .leading, spacing: Space.s4) {
                Text("Ваш код")
                    .textStyle(.caption)
                    .foregroundStyle(Theme.muted)
                Text(myCode)
                    .textStyle(.h1)
                    .foregroundStyle(Theme.text)
                    .textSelection(.enabled)
                    .accessibilityLabel("Ваш код: \(myCode.map { String($0) }.joined(separator: " "))")
            }

            HStack(spacing: Space.s8) {
                ShareLink(item: invite.message) {
                    Label("Отправить", systemImage: "square.and.arrow.up")
                }
                .buttonStyle(PrimaryButtonStyle())

                Button {
                    UIPasteboard.general.string = invite.url?.absoluteString ?? myCode
                    copied = true
                    Task {
                        try? await Task.sleep(nanoseconds: 1_600_000_000)
                        copied = false
                    }
                } label: {
                    Label(copied ? "Скопировано" : "Копировать", systemImage: copied ? "checkmark" : "doc.on.doc")
                }
                .buttonStyle(SecondaryButtonStyle(highlighted: copied))
                .sensoryFeedback(.success, trigger: copied) { _, new in new }
            }

            // Заметка про iCloud прижата к низу: плашка той же высоты, что во «Вкусах».
            Spacer(minLength: 0)

            HStack(alignment: .top, spacing: Space.s8) {
                Image(systemName: "icloud")
                    .font(.system(size: 15))
                    .foregroundStyle(Theme.muted)
                    .padding(.top, 1)
                    .accessibilityHidden(true)
                Text("Когда в ance появится iCloud, друзья смогут видеть коллекции друг друга и выбирать фильм на вечер с двух телефонов. Сейчас список друзей хранится только на этом iPhone.")
                    .textStyle(.caption)
                    .foregroundStyle(Theme.muted)
                    .fixedSize(horizontal: false, vertical: true)
            }
        }
        .padding(ScreenLayout.cardPadding)
        .frame(maxWidth: .infinity, minHeight: ScreenLayout.cardMinHeight, alignment: .topLeading)
        .background(RoundedRectangle(cornerRadius: ScreenLayout.cardRadius, style: .continuous).fill(Theme.surface))
    }

    // MARK: Список друзей

    @ViewBuilder
    private var friendsList: some View {
        VStack(alignment: .leading, spacing: Space.s12) {
            SectionTitle(friends.isEmpty ? "Ваши друзья" : "Ваши друзья · \(friends.count)")
            if friends.isEmpty {
                Text("Пока никого. Отправьте ссылку другу или добавьте его по коду.")
                    .textStyle(.sub)
                    .foregroundStyle(Theme.muted)
                    .fixedSize(horizontal: false, vertical: true)
            } else {
                VStack(spacing: 0) {
                    ForEach(friends) { friend in
                        friendRow(friend)
                        if friend.id != friends.last?.id {
                            Rectangle().fill(Theme.line).frame(height: 1).padding(.leading, 66)
                        }
                    }
                }
                .background(RoundedRectangle(cornerRadius: Radius.large, style: .continuous).fill(Theme.surface))
            }
        }
    }

    private func friendRow(_ friend: Friend) -> some View {
        HStack(spacing: Space.s12) {
            Text(String(friend.name.prefix(1)).uppercased())
                .textStyle(.h3)
                .foregroundStyle(Color.black)
                .frame(width: 40, height: 40)
                .background(Circle().fill(Theme.text))
                .accessibilityHidden(true)
            VStack(alignment: .leading, spacing: Space.s4) {
                Text(friend.name)
                    .textStyle(.body, .medium)
                    .foregroundStyle(Theme.text)
                Text("Код \(friend.code) · с \(FriendsView.dateText(friend.addedAt))")
                    .textStyle(.caption)
                    .foregroundStyle(Theme.muted)
            }
            Spacer(minLength: 0)
            Menu {
                Button(role: .destructive) {
                    friendToDelete = friend
                } label: {
                    Label("Удалить из друзей", systemImage: "person.badge.minus")
                }
            } label: {
                Image(systemName: "ellipsis")
                    .font(.system(size: 16, weight: .semibold))
                    .foregroundStyle(Theme.textSecondary)
                    .frame(width: 44, height: 44)
            }
            .accessibilityLabel("Действия с другом \(friend.name)")
        }
        .padding(.leading, Space.s12)
        .padding(.trailing, Space.s4)
        .padding(.vertical, Space.s8)
    }

    private static func dateText(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "ru_RU")
        formatter.dateFormat = "d MMMM yyyy"
        return formatter.string(from: date)
    }
}

/// Добавление друга по коду или вставленной ссылке.
struct AddFriendSheet: View {
    let myCode: String

    @Environment(\.modelContext) private var context
    @Environment(\.dismiss) private var dismiss

    @State private var codeText = ""
    @State private var name = ""
    @State private var message: String?

    private var invite: FriendInvite? { FriendInvite(text: codeText) }

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            HStack {
                Button("Отмена") { dismiss() }
                    .textStyle(.body)
                    .foregroundStyle(Theme.textSecondary)
                    .frame(minWidth: 44, minHeight: 44, alignment: .leading)
                Spacer()
                Text("Добавить друга")
                    .textStyle(.body, .bold)
                    .foregroundStyle(Theme.text)
                Spacer()
                Color.clear.frame(width: 64, height: 44)
            }
            .padding(.horizontal, Space.s16)
            .padding(.top, Space.s8)

            VStack(alignment: .leading, spacing: Space.s16) {
                field(label: "Код или ссылка друга", text: $codeText, prompt: "ABCD-EF23")
                    .onChange(of: codeText) { _, _ in
                        message = nil
                        if name.isEmpty, let parsed = invite, !parsed.name.isEmpty { name = parsed.name }
                    }
                field(label: "Имя друга", text: $name, prompt: "Как его подписать")

                Button {
                    if let text = UIPasteboard.general.string { codeText = text }
                } label: {
                    Label("Вставить из буфера", systemImage: "doc.on.clipboard")
                        .textStyle(.sub, .medium)
                        .foregroundStyle(Theme.textSecondary)
                        .frame(minHeight: 44)
                }
                .buttonStyle(.plain)

                if let message {
                    Text(message)
                        .textStyle(.sub)
                        .foregroundStyle(Theme.accent)
                        .fixedSize(horizontal: false, vertical: true)
                }
                Spacer(minLength: 0)
                Button("Добавить", action: add)
                    .buttonStyle(PrimaryButtonStyle())
                    .disabled(invite == nil)
                    .opacity(invite == nil ? 0.4 : 1)
                    .padding(.bottom, Space.s12)
            }
            .padding(.horizontal, Space.s20)
            .padding(.top, Space.s16)
        }
        .background(Theme.background.ignoresSafeArea())
        .presentationBackground(Theme.background)
        .presentationDetents([.medium, .large])
    }

    private func field(label: String, text: Binding<String>, prompt: String) -> some View {
        VStack(alignment: .leading, spacing: Space.s8) {
            Text(label)
                .textStyle(.caption)
                .foregroundStyle(Theme.muted)
            TextField("", text: text, prompt: Text(prompt).foregroundColor(Theme.muted))
                .textStyle(.body)
                .foregroundStyle(Theme.text)
                .autocorrectionDisabled()
                .padding(.horizontal, Space.s12)
                .frame(minHeight: 50)
                .background(RoundedRectangle(cornerRadius: Radius.medium, style: .continuous).fill(Theme.surface))
                .accessibilityLabel(label)
        }
    }

    private func add() {
        guard let parsed = invite else { return }
        let finalName = name.trimmingCharacters(in: .whitespacesAndNewlines)
        let result = FriendActions.add(FriendInvite(code: parsed.code, name: finalName.isEmpty ? parsed.name : finalName),
                                       myCode: myCode, in: context)
        switch result {
        case .isSelf:
            message = "Это ваш собственный код."
        case .added, .updated:
            dismiss()
        }
    }
}
