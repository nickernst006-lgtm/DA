import SwiftUI
import UIKit
import CoreText

/// Цвета приложения. Все экраны — на чистом чёрном фоне.
enum Theme {
    static let background = Color.black
    static let surface = Color(hex: 0x141414)
    static let surfaceRaised = Color(hex: 0x1F1F1F)
    static let dock = Color(hex: 0x141414)
    static let dockButton = Color(hex: 0x262626)
    static let line = Color(hex: 0x1C1C1C)
    static let lineStrong = Color(hex: 0x2C2C2C)

    static let text = Color(hex: 0xF5F5F5)
    static let textSecondary = Color(hex: 0xC8C8C8)
    static let muted = Color(hex: 0x8E8E8E)

    /// Тёплый акцент — только точечно.
    static let accent = Color(hex: 0xE8B04B)
}

/// Шрифт приложения — Helvetica Neue (встроена в iOS).
/// Все размеры масштабируются вместе с системным размером текста.
enum AppFont {
    private static func name(_ weight: Font.Weight) -> String {
        switch weight {
        case .bold, .heavy, .black, .semibold: return "HelveticaNeue-Bold"
        case .medium: return "HelveticaNeue-Medium"
        case .light, .thin, .ultraLight: return "HelveticaNeue-Light"
        default: return "HelveticaNeue"
        }
    }

    private static func isAvailable(_ name: String) -> Bool {
        UIFont(name: name, size: 12) != nil
    }

    /// Крупные заголовки.
    static func title(_ size: CGFloat, _ weight: Font.Weight = .bold, relativeTo style: Font.TextStyle = .largeTitle) -> Font {
        ui(size, weight, relativeTo: style)
    }

    /// Заголовок фиксированного размера (для картинок, которые отправляются в соцсети).
    static func titleFixed(_ size: CGFloat, _ weight: Font.Weight = .bold) -> Font {
        uiFixed(size, weight)
    }

    /// Текст интерфейса.
    static func ui(_ size: CGFloat, _ weight: Font.Weight = .regular, relativeTo style: Font.TextStyle = .body) -> Font {
        let fontName = name(weight)
        if isAvailable(fontName) {
            return .custom(fontName, size: size, relativeTo: style)
        }
        return .system(size: size, weight: weight)
    }

    static func uiFixed(_ size: CGFloat, _ weight: Font.Weight = .regular) -> Font {
        let fontName = name(weight)
        if isAvailable(fontName) {
            return .custom(fontName, fixedSize: size)
        }
        return .system(size: size, weight: weight)
    }
}

// MARK: - Сетка: все отступы, размеры и скругления кратны 4 pt

/// Отступы — только эти восемь значений.
enum Space {
    /// Название ↔ год и режиссёр; фото ↔ подпись.
    static let s4: CGFloat = 4
    /// Внутри группы: чипы, фото в подборке, квадрат оценки ↔ слово.
    static let s8: CGFloat = 8
    /// Между группами в карточке; между карточками; обложка ↔ текст.
    static let s12: CGFloat = 12
    /// Поля карточек и плашек; заголовок раздела → содержимое.
    static let s16: CGFloat = 16
    /// Поля экрана; заголовок экрана → первый элемент.
    static let s20: CGFloat = 20
    /// Между блоками журнала.
    static let s24: CGFloat = 24
    /// Между разделами страницы.
    static let s32: CGFloat = 32
    /// Высота кнопок, поиска и переключателя.
    static let s48: CGFloat = 48
}

/// Скругления — три. Вложенное = внешнее − поле: 28 − 16 = 12.
enum Radius {
    /// Чипы, малый квадрат оценки.
    static let small: CGFloat = 8
    /// Обложки, фото, большой квадрат оценки.
    static let medium: CGFloat = 12
    /// Карточки и плашки.
    static let large: CGFloat = 28
}

// MARK: - Шкала шрифтов: восемь стилей, межстрочный интервал кратен 4

enum TextStyle {
    /// 34/40, жирный — заголовки вкладок.
    case screen
    /// 28/32, жирный — название в карточке фильма и оценка со словом рядом с ним.
    case h1
    /// 22/28, жирный — разделы страницы, заголовок в журнале, окна.
    case h2
    /// 19/24, жирный — название в списках и карточках и оценка со словом рядом.
    case h3
    /// 17/24 — тексты, эссе, кнопки.
    case body
    /// 15/20 — год, режиссёр, чувства, отрывки, фильтры.
    case sub
    /// 13/16 — метки, подписи, чипы.
    case caption
    /// 21/28, DM Serif Display курсив — только цитаты.
    case quote

    var size: CGFloat {
        switch self {
        case .screen: return 34
        case .h1: return 28
        case .h2: return 22
        case .h3: return 19
        case .body: return 17
        case .sub: return 15
        case .caption: return 13
        case .quote: return 21
        }
    }

    var lineHeight: CGFloat {
        switch self {
        case .screen: return 40
        case .h1: return 32
        case .h2: return 28
        case .h3: return 24
        case .body: return 24
        case .sub: return 20
        case .caption: return 16
        case .quote: return 28
        }
    }

    var weight: Font.Weight {
        switch self {
        case .screen, .h1, .h2, .h3: return .bold
        default: return .regular
        }
    }

    var tracking: CGFloat {
        switch self {
        case .screen: return -0.8
        case .h1: return -0.6
        case .h2: return -0.3
        case .h3: return -0.2
        default: return 0
        }
    }

    /// С каким системным стилем масштабируется при крупном тексте.
    var uiTextStyle: UIFont.TextStyle {
        switch self {
        case .screen: return .largeTitle
        case .h1: return .title1
        case .h2: return .title2
        case .h3: return .title3
        case .body: return .body
        case .sub: return .subheadline
        case .caption: return .footnote
        case .quote: return .title3
        }
    }
}

extension AppFont {
    /// Шрифт стиля шкалы нужного размера. Цитаты — DM Serif Display курсив.
    static func uiFont(_ style: TextStyle, weight: Font.Weight? = nil, size: CGFloat? = nil) -> UIFont {
        let pointSize = size ?? style.size
        if style == .quote, let font = UIFont(name: "DMSerifDisplay-Italic", size: pointSize) {
            return font
        }
        let w = weight ?? style.weight
        let name: String
        switch w {
        case .bold, .heavy, .black, .semibold: name = "HelveticaNeue-Bold"
        case .medium: name = "HelveticaNeue-Medium"
        case .light, .thin, .ultraLight: name = "HelveticaNeue-Light"
        default: name = "HelveticaNeue"
        }
        if let font = UIFont(name: name, size: pointSize) { return font }
        let uiWeight: UIFont.Weight
        switch w {
        case .bold, .heavy, .black, .semibold: uiWeight = .bold
        case .medium: uiWeight = .medium
        default: uiWeight = .regular
        }
        return .systemFont(ofSize: pointSize, weight: uiWeight)
    }
}

/// Применяет стиль шкалы: шрифт, трекинг и межстрочный интервал.
/// Строка занимает ровно lineHeight: недостающее до интервала делится поровну
/// сверху и снизу, как в вёрстке, — поэтому все строки стоят на сетке 4 pt.
private struct TextStyleModifier: ViewModifier {
    let style: TextStyle
    let weight: Font.Weight?
    let fixed: Bool
    @Environment(\.dynamicTypeSize) private var dynamicTypeSize

    func body(content: Content) -> some View {
        let scale: CGFloat = fixed ? 1 : UIFontMetrics(forTextStyle: style.uiTextStyle)
            .scaledValue(for: 1, compatibleWith: UITraitCollection(
                preferredContentSizeCategory: UIContentSizeCategory(dynamicTypeSize)))
        let font = AppFont.uiFont(style, weight: weight, size: style.size * scale)
        let extra = max(0, style.lineHeight * scale - font.lineHeight)
        return content
            .font(Font(font as CTFont))
            .tracking(style.tracking)
            .lineSpacing(extra)
            .padding(.vertical, extra / 2)
    }
}

extension View {
    /// Стиль из шкалы шрифтов. weight — только для выделения внутри стиля (кнопки, чипы).
    /// fixed — без масштабирования, для картинок, которые уходят в соцсети.
    func textStyle(_ style: TextStyle, _ weight: Font.Weight? = nil, fixed: Bool = false) -> some View {
        modifier(TextStyleModifier(style: style, weight: weight, fixed: fixed))
    }
}

extension Color {
    init(hex: UInt32) {
        let r = Double((hex >> 16) & 0xFF) / 255
        let g = Double((hex >> 8) & 0xFF) / 255
        let b = Double(hex & 0xFF) / 255
        self.init(.sRGB, red: r, green: g, blue: b, opacity: 1)
    }

    /// Цвет из строки вида "#33402F".
    init(hexString: String, fallback: Color = .gray) {
        var cleaned = hexString.trimmingCharacters(in: .whitespacesAndNewlines)
        if cleaned.hasPrefix("#") { cleaned.removeFirst() }
        if cleaned.count == 6, let value = UInt32(cleaned, radix: 16) {
            self.init(hex: value)
        } else {
            self = fallback
        }
    }
}
