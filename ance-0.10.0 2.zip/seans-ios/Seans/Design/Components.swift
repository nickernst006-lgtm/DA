import SwiftUI
import UIKit
import CoreText

/// Общая разметка верха экранов: заголовок и первый элемент под ним стоят
/// на одной высоте на всех вкладках, а поле поиска и переключатель — одного размера.
enum ScreenLayout {
    /// Отступ от заголовка до первого элемента.
    static let titleGap: CGFloat = Space.s20
    /// Высота поля поиска, переключателя и кнопок.
    static let controlHeight: CGFloat = Space.s48
    /// Поля экрана слева и справа.
    static let sideMargin: CGFloat = Space.s20
    /// Большие плашки под заголовком («Вкусы», «Друзья»): скругление, поля, высота.
    static let cardRadius: CGFloat = Radius.large
    static let cardPadding: CGFloat = Space.s16
    static let cardMinHeight: CGFloat = 440
}

/// Заголовок вкладки: «Вселенная», «Коллекция», «Вкусы», «Друзья».
struct ScreenTitle: View {
    let text: String

    init(_ text: String) { self.text = text }

    var body: some View {
        Text(text)
            .textStyle(.screen)
            .foregroundStyle(Theme.text)
            .frame(maxWidth: .infinity, alignment: .leading)
            .accessibilityAddTraits(.isHeader)
    }
}

/// Подзаголовок раздела внутри экрана.
struct SectionTitle: View {
    let text: String
    var hint: String? = nil

    init(_ text: String, hint: String? = nil) {
        self.text = text
        self.hint = hint
    }

    var body: some View {
        VStack(alignment: .leading, spacing: Space.s4) {
            Text(text)
                .textStyle(.h2)
                .foregroundStyle(Theme.text)
                .accessibilityAddTraits(.isHeader)
            if let hint {
                Text(hint)
                    .textStyle(.caption)
                    .foregroundStyle(Theme.muted)
                    .fixedSize(horizontal: false, vertical: true)
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }
}

/// Белая основная кнопка.
struct PrimaryButtonStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .textStyle(.body, .bold)
            .foregroundStyle(Color.black)
            .frame(maxWidth: .infinity, minHeight: Space.s48)
            .padding(.horizontal, Space.s16)
            .background(
                Capsule().fill(Theme.text.opacity(configuration.isPressed ? 0.8 : 1))
            )
    }
}

/// Тёмная второстепенная кнопка.
struct SecondaryButtonStyle: ButtonStyle {
    var highlighted = false

    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .textStyle(.body, .medium)
            .foregroundStyle(highlighted ? Theme.accent : Theme.text)
            .frame(maxWidth: .infinity, minHeight: Space.s48)
            .padding(.horizontal, Space.s16)
            .background(
                Capsule().fill(configuration.isPressed ? Theme.surfaceRaised : Theme.surface)
            )
    }
}

/// Чип выбора: настроение, вариант ответа в анкете.
struct Chip: View {
    let title: String
    let isSelected: Bool
    var height: CGFloat = 44
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            Text(title)
                .textStyle(.sub, .medium)
                .foregroundStyle(isSelected ? Color.black : Theme.text)
                .padding(.horizontal, Space.s16)
                .frame(minHeight: height)
                .background(
                    Capsule().fill(isSelected ? Theme.text : Theme.surface)
                )
        }
        .buttonStyle(.plain)
        .accessibilityAddTraits(isSelected ? .isSelected : [])
        .sensoryFeedback(.selection, trigger: isSelected)
    }
}

/// Сегментированный переключатель в стиле приложения.
struct SegmentOption<Value: Hashable>: Identifiable {
    let value: Value
    let title: String
    var id: Value { value }
}

struct SegmentedControl<Value: Hashable>: View {
    let options: [SegmentOption<Value>]
    @Binding var selection: Value

    var body: some View {
        HStack(spacing: 4) {
            ForEach(options) { option in
                let isSelected = option.value == selection
                Button {
                    selection = option.value
                } label: {
                    Text(option.title)
                        .textStyle(.sub, .bold)
                        .lineLimit(1)
                        .minimumScaleFactor(0.8)
                        .foregroundStyle(isSelected ? Color.black : Theme.muted)
                        .frame(maxWidth: .infinity, maxHeight: .infinity)
                        .background(
                            Capsule().fill(isSelected ? Theme.text : Color.clear)
                        )
                }
                .buttonStyle(.plain)
                .accessibilityAddTraits(isSelected ? .isSelected : [])
            }
        }
        .padding(4)
        .frame(height: ScreenLayout.controlHeight)
        .background(Capsule().fill(Theme.surface))
        .sensoryFeedback(.selection, trigger: selection)
    }
}

/// Раскладка «в строку с переносом» — для чипов.
struct FlowLayout: Layout {
    var spacing: CGFloat = 8
    var lineSpacing: CGFloat = 8

    func sizeThatFits(proposal: ProposedViewSize, subviews: Subviews, cache: inout ()) -> CGSize {
        let maxWidth = proposal.width ?? .infinity
        var x: CGFloat = 0
        var y: CGFloat = 0
        var rowHeight: CGFloat = 0
        var widest: CGFloat = 0
        for view in subviews {
            let size = view.sizeThatFits(.unspecified)
            if x > 0 && x + size.width > maxWidth {
                x = 0
                y += rowHeight + lineSpacing
                rowHeight = 0
            }
            x += size.width
            widest = max(widest, x)
            x += spacing
            rowHeight = max(rowHeight, size.height)
        }
        let width = proposal.width ?? widest
        return CGSize(width: width, height: y + rowHeight)
    }

    func placeSubviews(in bounds: CGRect, proposal: ProposedViewSize, subviews: Subviews, cache: inout ()) {
        var x = bounds.minX
        var y = bounds.minY
        var rowHeight: CGFloat = 0
        for view in subviews {
            let size = view.sizeThatFits(.unspecified)
            if x > bounds.minX && x + size.width > bounds.maxX {
                x = bounds.minX
                y += rowHeight + lineSpacing
                rowHeight = 0
            }
            view.place(at: CGPoint(x: x, y: y), anchor: .topLeading, proposal: ProposedViewSize(size))
            x += size.width + spacing
            rowHeight = max(rowHeight, size.height)
        }
    }
}

/// Поле поиска.
struct SearchField<Accessory: View>: View {
    @Binding var text: String
    var placeholder = "Фильм, режиссёр или год"
    /// Кнопка справа внутри поля (например, фильтры).
    @ViewBuilder var accessory: () -> Accessory

    var body: some View {
        HStack(spacing: Space.s8) {
            Image(systemName: "magnifyingglass")
                .font(.system(size: 16, weight: .medium))
                .foregroundStyle(Theme.muted)
                .accessibilityHidden(true)
            TextField("", text: $text, prompt: Text(placeholder).foregroundColor(Theme.muted))
                .font(Font(AppFont.uiFont(.body) as CTFont))
                .foregroundStyle(Theme.text)
                .autocorrectionDisabled()
                .submitLabel(.search)
                .accessibilityLabel("Поиск фильма")
            if !text.isEmpty {
                Button {
                    text = ""
                } label: {
                    Image(systemName: "xmark.circle.fill")
                        .foregroundStyle(Theme.muted)
                        .frame(width: 32, height: 32)
                }
                .buttonStyle(.plain)
                .accessibilityLabel("Очистить поиск")
            }
            accessory()
        }
        .padding(.leading, Space.s16)
        .padding(.trailing, Space.s4)
        .frame(height: ScreenLayout.controlHeight)
        .background(Capsule().fill(Theme.surface))
    }
}

extension SearchField where Accessory == EmptyView {
    init(text: Binding<String>, placeholder: String = "Фильм, режиссёр или год") {
        self.init(text: text, placeholder: placeholder, accessory: { EmptyView() })
    }
}

/// Круглая кнопка закрытия.
struct CloseButton: View {
    var systemImage = "xmark"
    var label = "Закрыть"
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            Image(systemName: systemImage)
                .font(.system(size: 15, weight: .semibold))
                .foregroundStyle(Theme.text)
                .frame(width: 44, height: 44)
                .background(Circle().fill(Theme.surface))
        }
        .buttonStyle(.plain)
        .accessibilityLabel(label)
    }
}

// MARK: - Оценка: жёлтый квадрат с цифрой и слово рядом

/// Метрики шрифта стиля — чтобы выравнивать по контуру знаков, а не по строке.
enum TextMetrics {
    static func font(_ style: TextStyle, _ dynamicTypeSize: DynamicTypeSize, weight: Font.Weight? = nil, fixed: Bool = false) -> UIFont {
        let scale: CGFloat = fixed ? 1 : UIFontMetrics(forTextStyle: style.uiTextStyle)
            .scaledValue(for: 1, compatibleWith: UITraitCollection(
                preferredContentSizeCategory: UIContentSizeCategory(dynamicTypeSize)))
        return AppFont.uiFont(style, weight: weight, size: style.size * scale)
    }

    /// Контур строки относительно её начала на базовой линии (y — вверх).
    static func inkBounds(_ text: String, font: UIFont) -> CGRect {
        let line = CTLineCreateWithAttributedString(
            NSAttributedString(string: text, attributes: [.font: font]))
        return CTLineGetBoundsWithOptions(line, .useGlyphPathBounds)
    }
}

/// Оценка в жёлтом квадрате со скруглёнными углами, без «/10».
/// Цифра стоит по центру своего контура — ровно и для «1», и для «7», и для «10».
/// Размер — по названию фильма рядом: .h3 в списках (квадрат 32), .h1 в карточке фильма (44).
struct RatingBadge: View {
    let value: Int
    var style: TextStyle = .h3
    var fixed = false
    @Environment(\.dynamicTypeSize) private var dynamicTypeSize

    var side: CGFloat { style == .h1 ? 44 : 32 }

    var body: some View {
        let font = TextMetrics.font(style, dynamicTypeSize, weight: .bold, fixed: fixed)
        let text = "\(value)"
        let ink = TextMetrics.inkBounds(text, font: font)
        let scale = font.pointSize / style.size
        ZStack {
            RoundedRectangle(cornerRadius: style == .h1 ? Radius.medium : Radius.small, style: .continuous)
                .fill(Theme.accent)
                .frame(width: side * scale, height: side * scale)
            Text(text)
                .font(Font(font as CTFont))
                .foregroundStyle(Color.black)
                .fixedSize()
                // центр контура цифры — в центр квадрата
                .alignmentGuide(HorizontalAlignment.center) { _ in ink.midX }
                .alignmentGuide(VerticalAlignment.center) { d in d[.firstTextBaseline] - ink.midY }
        }
        .accessibilityElement(children: .ignore)
        .accessibilityLabel("Оценка \(value) из 10")
    }
}

/// Квадрат оценки и слово о фильме рядом. Середина заглавных букв слова —
/// на уровне центра квадрата (хвосты «р», «у» не учитываются).
struct RatingRow: View {
    let rating: Int
    let word: String
    var style: TextStyle = .h3
    var fixed = false
    @Environment(\.dynamicTypeSize) private var dynamicTypeSize

    var body: some View {
        let font = TextMetrics.font(style, dynamicTypeSize, fixed: fixed)
        HStack(alignment: .center, spacing: Space.s8) {
            if rating > 0 {
                RatingBadge(value: rating, style: style, fixed: fixed)
            }
            if !word.isEmpty {
                Text(word)
                    .textStyle(style, fixed: fixed)
                    .foregroundStyle(Theme.accent)
                    .lineLimit(1)
                    .alignmentGuide(VerticalAlignment.center) { d in d[.firstTextBaseline] - font.capHeight / 2 }
            }
        }
        .accessibilityElement(children: .combine)
    }
}

/// Маленький прямоугольник с подписью: «2 текста», «24 октября».
struct InfoChip: View {
    let text: String

    var body: some View {
        Text(text)
            .textStyle(.caption)
            .foregroundStyle(Theme.textSecondary)
            .lineLimit(1)
            .padding(.horizontal, Space.s8)
            .frame(height: 28)
            .background(RoundedRectangle(cornerRadius: Radius.small, style: .continuous).fill(Theme.surfaceRaised))
    }
}
