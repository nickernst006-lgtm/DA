import SwiftUI
import UIKit

/// Логотип «ance»: шрифт DM Serif Display (встроен в приложение, лицензия OFL),
/// над «а» — жёлтая точка. На заставке точка выпрыгивает справа и скачет
/// по буквам e → c → n → a, как лампа в заставке Pixar.
///
/// Все размеры — в долях кегля (em); y отсчитывается вверх от базовой линии,
/// x — от левого края слова. Числа сняты со шрифта и совпадают с видео-черновиком.
enum AnceMark {
    static let fontName = "DMSerifDisplay-Regular"

    struct Letter { let ch: String; let x: CGFloat; let inkCenter: CGFloat }
    /// Левый край каждой буквы (с кернингом) и центр её «чернил».
    static let letters: [Letter] = [
        Letter(ch: "a", x: 0.000, inkCenter: 0.2730),
        Letter(ch: "n", x: 0.518, inkCenter: 0.8075),
        Letter(ch: "c", x: 1.094, inkCenter: 1.3400),
        Letter(ch: "e", x: 1.588, inkCenter: 1.8385)
    ]
    static let width: CGFloat = 2.089      // ширина слова
    static let xTop: CGFloat = 0.496       // верх строчных букв над базовой линией
    static let radius: CGFloat = 0.069     // радиус точки — как на иконке
    static let gap: CGFloat = 0.056        // зазор между точкой и «а» в покое
    static let descent: CGFloat = 0.02     // низ букв под базовой линией

    static var sitY: CGFloat { xTop + radius }          // точка стоит на букве
    static var restY: CGFloat { xTop + gap + radius }   // точка парит над «а»
    /// Верх логотипа над базовой линией — верх точки в покое.
    static var top: CGFloat { restY + radius }

    struct Hop { let to: Int; let duration: Double; let height: CGFloat; let contact: Double; let squash: CGFloat }
    static let delay = 0.30
    static let hops: [Hop] = [
        Hop(to: 3, duration: 0.58, height: 1.05, contact: 0.15, squash: 0.38),  // из-за края экрана на «e»
        Hop(to: 2, duration: 0.36, height: 0.50, contact: 0.12, squash: 0.32),  // на «c»
        Hop(to: 1, duration: 0.36, height: 0.50, contact: 0.12, squash: 0.32),  // на «n»
        Hop(to: 0, duration: 0.42, height: 0.62, contact: 0.17, squash: 0.46)   // на «а»
    ]
    static let settle = 0.42
    /// Насколько буква проседает под точкой (доля высоты при полном сплющивании точки).
    static let letterSquash: CGFloat = 0.40
    static let startY: CGFloat = -0.2

    /// Длительность всей анимации.
    static var duration: Double {
        delay + hops.reduce(0) { $0 + $1.duration + $1.contact } + settle
    }

    struct Dot { var x: CGFloat; var y: CGFloat; var sx: CGFloat = 1; var sy: CGFloat = 1; var rotation: Double = 0; var visible = true }
    struct Frame { var dot: Dot; var letterScale: [CGFloat] }

    /// Итоговое положение — точка над «а».
    static var finalFrame: Frame {
        Frame(dot: Dot(x: letters[0].inkCenter, y: restY), letterScale: [1, 1, 1, 1])
    }

    /// Кадр анимации в момент t. startX — откуда выпрыгивает точка (в em от начала слова).
    static func frame(at t: Double, startX: CGFloat) -> Frame {
        var scale: [CGFloat] = [1, 1, 1, 1]
        var time = t - delay
        guard time >= 0 else {
            return Frame(dot: Dot(x: startX, y: startY, visible: false), letterScale: scale)
        }
        var px = startX, py = startY
        for (i, hop) in hops.enumerated() {
            let tx = letters[hop.to].inkCenter, ty = sitY
            // Полёт по параболе: вершина на hop.height выше более высокого из концов.
            if time < hop.duration {
                let u = CGFloat(time / hop.duration)
                let top = max(py, ty) + hop.height
                let d0 = top - py, d1 = top - ty
                let us = d0.squareRoot() / (d0.squareRoot() + d1.squareRoot())
                let a = -d0 / (us * us), b = -2 * a * us
                let y = a * u * u + b * u + py
                let vy = (2 * a * u + b) / CGFloat(hop.duration)
                let vx = (tx - px) / CGFloat(hop.duration)
                let x = px + (tx - px) * u
                // Растяжение вдоль скорости, плавно включается у начала и конца полёта.
                let stretch = 1 + min(max(hypot(vx, vy) * 0.045, 0), 0.32)
                let ramp = min(max(min(1, u / 0.12, (1 - u) / 0.12 + 0.35), 0), 1)
                let s = 1 + (stretch - 1) * ramp
                return Frame(dot: Dot(x: x, y: y, sx: 1 / s.squareRoot(), sy: s,
                                      rotation: Double(atan2(vx, vy))),
                             letterScale: scale)
            }
            time -= hop.duration
            let last = i == hops.count - 1
            // Касание: точка сплющивается, буква под ней проседает.
            if time < hop.contact {
                let u = CGFloat(time / hop.contact)
                let q = sin(.pi * u) * hop.squash
                scale[hop.to] = 1 - q * letterSquash
                let letterTop = xTop * scale[hop.to]
                return Frame(dot: Dot(x: tx, y: letterTop + radius * (1 - q), sx: 1 + q * 0.9, sy: 1 - q),
                             letterScale: scale)
            }
            time -= hop.contact
            if last {
                // Финал: всплывает на место над «а» с лёгким перелётом и затухающим покачиванием.
                let v = CGFloat(min(max(time / settle, 0), 1))
                let back = 1 + 2.2 * pow(v - 1, 3) + 1.2 * pow(v - 1, 2)
                let y = sitY + (restY - sitY) * back
                let wobble = sin(v * .pi * 2.2) * (1 - v) * 0.10
                return Frame(dot: Dot(x: tx, y: y, sx: 1 - wobble * 0.7, sy: 1 + wobble), letterScale: scale)
            }
            px = tx; py = sitY
        }
        return finalFrame
    }

    /// Рисует слово и точку. origin — левый край слова на базовой линии.
    static func draw(_ frame: Frame, in context: GraphicsContext, origin: CGPoint, size: CGFloat) {
        let font: Font = UIFont(name: fontName, size: size) != nil
            ? .custom(fontName, fixedSize: size)
            : .system(size: size, weight: .bold, design: .serif)
        for (i, letter) in letters.enumerated() {
            let text = context.resolve(Text(letter.ch).font(font).foregroundColor(Theme.text))
            let box = text.measure(in: CGSize(width: size * 2, height: size * 2))
            let baseline = text.firstBaseline(in: box)
            var c = context
            c.translateBy(x: origin.x + letter.x * size, y: origin.y)
            c.scaleBy(x: 1, y: frame.letterScale[i])   // проседание — от базовой линии
            c.draw(text, at: CGPoint(x: 0, y: -baseline), anchor: .topLeading)
        }
        let dot = frame.dot
        guard dot.visible else { return }
        var c = context
        c.translateBy(x: origin.x + dot.x * size, y: origin.y - dot.y * size)
        c.rotate(by: .radians(dot.rotation))
        c.scaleBy(x: dot.sx, y: dot.sy)
        let r = radius * size
        c.fill(Path(ellipseIn: CGRect(x: -r, y: -r, width: r * 2, height: r * 2)), with: .color(Theme.accent))
    }
}

/// Неподвижный логотип «ance» с точкой над «а» — для первого экрана и карточки для соцсетей.
struct AnceLogo: View {
    let size: CGFloat

    var body: some View {
        Canvas { context, _ in
            AnceMark.draw(AnceMark.finalFrame, in: context,
                          origin: CGPoint(x: 0, y: AnceMark.top * size), size: size)
        }
        .frame(width: AnceMark.width * size, height: (AnceMark.top + AnceMark.descent) * size)
        .accessibilityElement(children: .ignore)
        .accessibilityLabel("ance")
    }
}

/// Заставка: точка выпрыгивает из-за правого края экрана и скачет по буквам.
struct AnceSplashMark: View {
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @State private var start = Date()

    var body: some View {
        GeometryReader { geo in
            let size = geo.size.width * 92 / 440          // как на видео: 92 pt на экране 440 pt
            let origin = CGPoint(x: (geo.size.width - AnceMark.width * size) / 2,
                                 y: geo.size.height / 2 + 0.20 * size)
            let startX = (geo.size.width + 20 - origin.x) / size
            TimelineView(.animation(paused: reduceMotion)) { timeline in
                let t = timeline.date.timeIntervalSince(start)
                let frame = reduceMotion || t >= AnceMark.duration
                    ? AnceMark.finalFrame
                    : AnceMark.frame(at: t, startX: startX)
                Canvas { context, _ in
                    AnceMark.draw(frame, in: context, origin: origin, size: size)
                }
            }
        }
        .onAppear { start = Date() }
        .accessibilityElement(children: .ignore)
        .accessibilityLabel("ance")
    }
}
