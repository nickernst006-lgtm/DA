import XCTest

// UI-тесты: запускают приложение в симуляторе iPhone в облаке, «нажимают»
// кнопки как человек и сохраняют скриншоты каждого экрана.
// Приёмы и грабли — из N Finance (N_Apps_11): поиск по опознавательным
// знакам, прокрутка до элемента, понятные сообщения об ошибках.

final class DocumentsAppUITests: XCTestCase {

    private let password = "test1234"

    override func setUpWithError() throws {
        continueAfterFailure = false
    }

    @MainActor
    private func snap(_ app: XCUIApplication, _ name: String) {
        let a = XCTAttachment(screenshot: app.screenshot())
        a.name = name
        a.lifetime = .keepAlways
        add(a)
    }

    /// Создаёт пароль при первом запуске или входит, если пароль уже есть
    @MainActor
    private func unlock(_ app: XCUIApplication, screenshotPrefix: String? = nil) {
        let setup1 = app.secureTextFields["setupPassword1"]
        let login = app.secureTextFields["loginPassword"]
        let appeared = setup1.waitForExistence(timeout: 10) || login.waitForExistence(timeout: 2)
        XCTAssertTrue(appeared, "не появился экран пароля")

        if setup1.exists {
            if let p = screenshotPrefix { snap(app, "\(p)_Создание_пароля") }
            setup1.tap()
            setup1.typeText(password)
            let setup2 = app.secureTextFields["setupPassword2"]
            setup2.tap()
            setup2.typeText(password)
            app.buttons["setupSubmit"].tap()
        } else {
            if let p = screenshotPrefix { snap(app, "\(p)_Вход") }
            login.tap()
            login.typeText(password)
            app.buttons["loginSubmit"].tap()
        }
        XCTAssertTrue(app.tabBars.firstMatch.waitForExistence(timeout: 60), "не открылся главный экран")
    }

    /// Тест 1: проходит по всем вкладкам и делает скриншоты
    @MainActor
    func test1_AllScreensScreenshots() throws {
        let app = XCUIApplication()
        app.launchArguments = ["-uiTestDemo"]
        app.launch()
        unlock(app, screenshotPrefix: "01")

        XCTAssertEqual(app.tabBars.buttons.count, 5,
                       "вкладок должно быть пять, а их \(app.tabBars.buttons.count)")

        tab(app, 0)
        sleep(1)
        snap(app, "02_Форма")

        tab(app, 1)
        sleep(1)
        snap(app, "03_История")

        tab(app, 2)
        let person = app.descendants(matching: .any).matching(identifier: "person_Я").firstMatch
        XCTAssertTrue(person.waitForExistence(timeout: 10),
                      "в хранилище нет демо-человека «Я» — демо-данные не засеялись")
        snap(app, "04_Хранилище")

        tab(app, 3)
        sleep(1)
        snap(app, "05_Справочники")

        tab(app, 4)
        sleep(1)
        snap(app, "06_О_приложении")
        app.swipeUp()
        snap(app, "07_О_приложении_ниже")
        app.swipeDown()

        // Блокировка вручную и повторный вход
        let lockButton = app.buttons["Заблокировать сейчас"]
        XCTAssertTrue(reveal(app, lockButton), "нет кнопки «Заблокировать сейчас»")
        lockButton.tap()
        XCTAssertTrue(app.secureTextFields["loginPassword"].waitForExistence(timeout: 5), "не заблокировалось")
        snap(app, "08_Заблокировано")
        let login = app.secureTextFields["loginPassword"]
        login.tap()
        login.typeText("wrong-password")
        app.buttons["loginSubmit"].tap()
        XCTAssertTrue(app.staticTexts["Неверный пароль. Попробуйте снова."].waitForExistence(timeout: 30),
                      "нет сообщения о неверном пароле")
        snap(app, "09_Неверный_пароль")
        login.tap()
        login.typeText(password)
        app.buttons["loginSubmit"].tap()
        XCTAssertTrue(app.tabBars.firstMatch.waitForExistence(timeout: 60), "не удалось войти повторно")
    }

    /// Тест 2: окно смены пароля и окно сброса открываются и закрываются
    @MainActor
    func test2_ChangePasswordAndResetSheets() throws {
        let app = XCUIApplication()
        app.launch()
        unlock(app)

        tab(app, 4)
        let change = app.buttons["Сменить пароль"]
        XCTAssertTrue(reveal(app, change), "нет кнопки «Сменить пароль»")
        change.tap()
        let changeBar = app.navigationBars["Смена пароля"]
        XCTAssertTrue(changeBar.waitForExistence(timeout: 5), "не открылось окно смены пароля")
        snap(app, "10_Смена_пароля")
        changeBar.buttons["Отмена"].tap()
        XCTAssertFalse(changeBar.waitForExistence(timeout: 3), "окно смены пароля не закрылось")

        let reset = app.buttons["Сбросить приложение"]
        XCTAssertTrue(reveal(app, reset), "нет кнопки сброса")
        reset.tap()
        let resetBar = app.navigationBars["Сброс"]
        XCTAssertTrue(resetBar.waitForExistence(timeout: 5), "не открылось окно сброса")
        let confirm = app.buttons["Удалить всё"]
        XCTAssertTrue(confirm.waitForExistence(timeout: 5), "нет кнопки «Удалить всё»")
        XCTAssertFalse(confirm.isEnabled, "удаление доступно без ввода слова УДАЛИТЬ")
        snap(app, "11_Сброс")
        resetBar.buttons["Отмена"].tap()
        XCTAssertFalse(resetBar.waitForExistence(timeout: 3), "окно сброса не закрылось")
    }

    /// Прокручивает экран, пока элемент не окажется видимым и нажимаемым.
    ///
    /// SwiftUI-список создаёт только видимые строки: то, что ушло за нижний край,
    /// в дереве доступности просто отсутствует, и `waitForExistence` ждёт его зря.
    /// Поэтому листаем сами — сначала вниз, потом, если не нашли, вверх.
    @MainActor
    @discardableResult
    private func reveal(_ app: XCUIApplication, _ element: XCUIElement, swipes: Int = 6) -> Bool {
        if hittable(element, within: 2) { return true }
        for _ in 0..<swipes {
            app.swipeUp()
            if hittable(element, within: 1) { return true }
        }
        for _ in 0..<(swipes * 2) {
            app.swipeDown()
            if hittable(element, within: 1) { return true }
        }
        return hittable(element, within: 1)
    }

    /// `isHittable` на долю секунды бывает ложным, пока список доезжает после
    /// прокрутки. Даём ему это время, иначе пролистнём мимо нужной строки.
    @MainActor
    private func hittable(_ element: XCUIElement, within seconds: TimeInterval) -> Bool {
        let deadline = Date().addingTimeInterval(seconds)
        while Date() < deadline {
            if element.exists && element.isHittable { return true }
            usleep(150_000)
        }
        return element.exists && element.isHittable
    }

    /// Вкладки без подписей — нажимаем по порядку:
    /// 0 Форма, 1 История, 2 Хранилище, 3 Справочники, 4 О приложении
    @MainActor
    private func tab(_ app: XCUIApplication, _ index: Int) {
        let button = app.tabBars.buttons.element(boundBy: index)
        XCTAssertTrue(button.waitForExistence(timeout: 10), "нет вкладки \(index)")
        button.tap()
    }
}
