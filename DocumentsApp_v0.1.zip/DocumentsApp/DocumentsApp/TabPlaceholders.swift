import SwiftUI

// Заготовки четырёх рабочих вкладок (этап 1 — каркас).
// Каждая уже устроена по дизайн-коду: заголовок экрана первой строкой
// списка, скрытая системная шапка, пустое состояние строкой списка.
// Наполняются на этапах 3–6 (ТЗ, раздел 12).

/// Вкладка 1 — создание и правка карточки (этап 4).
struct FormView: View {
    @EnvironmentObject var appState: AppState
    @Binding var editState: EditState?
    var onSaved: () -> Void

    var body: some View {
        List {
            Section {
                ScreenHeader(title: "Новая карточка")
            }
            .plainRow()

            Section {
                EmptyStateRow(symbol: "doc.badge.plus",
                              title: "Форма карточки",
                              text: "Здесь появится создание карточки документа: тип, член семьи, папка, поля и файлы.")
            }
            .plainRow()
        }
        .themedScreen()
    }
}

/// Вкладка 2 — история изменений (этап 6).
struct HistoryView: View {
    @EnvironmentObject var appState: AppState

    var body: some View {
        List {
            Section {
                ScreenHeader(title: "История")
            }
            .plainRow()

            Section {
                EmptyStateRow(symbol: "clock.arrow.circlepath",
                              title: "Изменений пока нет",
                              text: "Каждое действие с документами будет записано здесь с датой и подробностями.")
                    .accessibilityIdentifier("historyEmpty")
            }
            .plainRow()
        }
        .themedScreen()
    }
}

/// Вкладка 3 — хранилище: члены семьи → папки → карточки (этап 3).
struct StorageView: View {
    @EnvironmentObject var appState: AppState
    @Binding var editState: EditState?
    var goToForm: () -> Void

    var body: some View {
        List {
            Section {
                ScreenHeader(title: "Хранилище")
            }
            .plainRow()

            if appState.data.persons.isEmpty {
                Section {
                    EmptyStateRow(symbol: "archivebox",
                                  title: "Хранилище пусто",
                                  text: "Добавьте члена семьи, затем папки и карточки документов.")
                }
                .plainRow()
            } else {
                // Предпросмотр структуры: полноценные экраны — на этапе 3.
                Section(header: SectionTitle("Члены семьи")) {
                    ForEach(activePersons) { person in
                        DirectoryRow(name: person.name,
                                     detail: folderCountText(for: person))
                            .accessibilityElement(children: .combine)
                            .accessibilityIdentifier("person_\(person.name)")
                    }
                }
            }
        }
        .themedScreen()
    }

    private var activePersons: [Person] {
        let alive: [Person] = appState.data.persons.filter { $0.deletion == nil }
        return alive.sorted { $0.order < $1.order }
    }

    private func folderCountText(for person: Person) -> String {
        var count = 0
        for folder in appState.data.folders where folder.personId == person.id && folder.deletion == nil {
            count += 1
        }
        return Plural.folders(count)
    }
}

/// Вкладка 4 — справочники: теги, цвета, типы карточек (этап 3).
struct DirectoriesView: View {
    @EnvironmentObject var appState: AppState

    var body: some View {
        List {
            Section {
                ScreenHeader(title: "Справочники")
            }
            .plainRow()

            Section {
                DirectoryRow(name: "Теги", detail: "\(appState.data.tags.count)")
                DirectoryRow(name: "Цвета", detail: "\(appState.data.colors.count)")
                DirectoryRow(name: "Типы карточек", detail: "6")
            }
        }
        .themedScreen()
    }
}

/// Склонение числительных для подписей
nonisolated enum Plural {
    /// 1 папка, 2 папки, 5 папок, 11 папок, 21 папка
    static func folders(_ n: Int) -> String {
        "\(n) " + form(n, one: "папка", few: "папки", many: "папок")
    }

    static func form(_ n: Int, one: String, few: String, many: String) -> String {
        let mod100 = abs(n) % 100
        let mod10 = abs(n) % 10
        if mod100 >= 11 && mod100 <= 14 { return many }
        if mod10 == 1 { return one }
        if mod10 >= 2 && mod10 <= 4 { return few }
        return many
    }
}
