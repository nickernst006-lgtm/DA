#if DEBUG
import Foundation

/// Демо-данные для облачных скриншот-тестов. Засеваются только при запуске
/// с аргументом `-uiTestDemo` и только в отладочной сборке — в приложении,
/// которое ставится на телефон, этого файла нет.
nonisolated enum DemoData {
    static func make() -> AppData {
        var d = AppData()

        let red = NamedColor(name: "Важное", paletteIndex: 8)
        let blue = NamedColor(name: "Обычное", paletteIndex: 0)
        let green = NamedColor(name: "Медицина", paletteIndex: 6)
        d.colors = [red, blue, green]

        let tagId = Tag(name: "Удостоверения")
        let tagTrip = Tag(name: "Поездки")
        d.tags = [tagId, tagTrip]

        let me = Person(name: "Я", order: 0)
        let wife = Person(name: "Жена", order: 1)
        let son = Person(name: "Сын", order: 2)
        d.persons = [me, wife, son]

        let myId = Folder(personId: me.id, number: "1", name: "Удостоверения личности",
                          colorId: red.id, tagIds: [tagId.id], order: 0)
        let myMed = Folder(personId: me.id, number: "2", name: "Медицина",
                           colorId: green.id, order: 1)
        let wifeId = Folder(personId: wife.id, number: "1", name: "Документы",
                            colorId: red.id, tagIds: [tagId.id], order: 0)
        d.folders = [myId, myMed, wifeId]

        d.cards = [
            DocumentCard(folderId: myId.id, typeId: "passportRF", title: "Паспорт РФ",
                         fields: ["series": "4512", "number": "345678"]),
            DocumentCard(folderId: myId.id, typeId: "foreignPassport", title: "Загранпаспорт"),
            DocumentCard(folderId: myMed.id, typeId: "oms", title: "Полис ОМС"),
            DocumentCard(folderId: wifeId.id, typeId: "passportRF", title: "Паспорт РФ",
                         status: .inactive),
        ]
        return d
    }
}
#endif
