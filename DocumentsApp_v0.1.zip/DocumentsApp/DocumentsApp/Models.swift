import Foundation

// Модель данных N Documents (ТЗ, раздел 4).
//
// Правила миграций те же, что в N Finance: каждое новое поле — необязательное,
// разбирается через decodeIfPresent, поля из модели НЕ удаляются. Иначе файл,
// записанный прошлой версией, перестанет открываться.

/// Пометка «в корзине». Всё удалённое одним действием получает один batchId
/// и восстанавливается одним действием.
nonisolated struct Deletion: Codable, Equatable {
    var date: Date
    var batchId: UUID
}

/// Член семьи — первый уровень хранилища.
nonisolated struct Person: Identifiable, Codable, Equatable {
    var id: UUID = UUID()
    var name: String
    var order: Int = 0
    var deletion: Deletion? = nil
}

/// Папка второго уровня. У каждого человека свой набор.
nonisolated struct Folder: Identifiable, Codable, Equatable {
    var id: UUID = UUID()
    var personId: UUID
    /// Номер — строкой: «1», «1.2», «А-3» — как удобно пользователю.
    var number: String = ""
    var name: String
    var colorId: UUID? = nil
    var tagIds: [UUID] = []
    var order: Int = 0
    var deletion: Deletion? = nil
}

nonisolated enum CardStatus: String, Codable, CaseIterable {
    case active
    case inactive

    var title: String {
        switch self {
        case .active: return "Действующий"
        case .inactive: return "Не действующий"
        }
    }
}

nonisolated enum FileSource: String, Codable {
    case camera
    case photos
    case files
}

/// Прикреплённый файл. Сам файл лежит на диске отдельным зашифрованным
/// блобом с именем `blobName` (случайный UUID) — см. ТЗ, раздел 3.
nonisolated struct StoredFile: Identifiable, Codable, Equatable {
    var id: UUID = UUID()
    var displayName: String
    var originalName: String
    /// Тип файла (UTI), например «com.adobe.pdf» или «public.jpeg»
    var typeIdentifier: String
    var size: Int
    var pageCount: Int? = nil
    var blobName: String
    var addedAt: Date = Date()
    var source: FileSource
    var deletion: Deletion? = nil
}

/// Карточка документа. Лежит ровно в одной папке.
nonisolated struct DocumentCard: Identifiable, Codable, Equatable {
    var id: UUID = UUID()
    var folderId: UUID
    /// Тип карточки: «basic» или один из шаблонов (зашиты в код, раздел 6 ТЗ)
    var typeId: String = "basic"
    var title: String
    var status: CardStatus = .active
    /// Значения полей шаблона по стабильному ключу поля
    var fields: [String: String] = [:]
    var note: String = ""
    var files: [StoredFile] = []
    var createdAt: Date = Date()
    var updatedAt: Date = Date()
    var deletion: Deletion? = nil
}

/// Тег для папок
nonisolated struct Tag: Identifiable, Codable, Equatable {
    var id: UUID = UUID()
    var name: String
}

/// Именованный цвет из палитры Theme.palette («Срочное — красный»)
nonisolated struct NamedColor: Identifiable, Codable, Equatable {
    var id: UUID = UUID()
    var name: String
    var paletteIndex: Int
}

/// Строка подробностей в записи истории: поле, было → стало.
nonisolated struct HistoryDetail: Codable, Equatable {
    var field: String
    var old: String? = nil
    var new: String? = nil
}

/// Запись истории изменений. Названия хранятся строками, чтобы запись
/// читалась и после окончательного удаления объекта.
nonisolated struct HistoryEvent: Identifiable, Codable, Equatable {
    var id: UUID = UUID()
    var date: Date = Date()
    /// Вид действия: «cardCreated», «cardEdited», «exportArchive» и т. д.
    var action: String
    /// Объект — как он назывался в момент действия
    var object: String
    var summary: String = ""
    var details: [HistoryDetail] = []
    /// Пароль архива — только у записи «Экспорт в архив»
    var exportPassword: String? = nil
    /// Причина — только у окончательного удаления
    var reason: String? = nil
}

/// Все данные приложения. Шифруются целиком в один файл data.bin.
/// Сами сканы в этот файл не входят — они лежат отдельными блобами.
nonisolated struct AppData: Codable, Equatable {
    var persons: [Person] = []
    var folders: [Folder] = []
    var cards: [DocumentCard] = []
    var tags: [Tag] = []
    var colors: [NamedColor] = []
    var history: [HistoryEvent] = []
}

extension AppData {
    /// Свой декодер: старый файл не знает о новых полях, и синтезированный
    /// декодер упал бы на нём целиком.
    init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: CodingKeys.self)
        persons = try c.decodeIfPresent([Person].self, forKey: .persons) ?? []
        folders = try c.decodeIfPresent([Folder].self, forKey: .folders) ?? []
        cards = try c.decodeIfPresent([DocumentCard].self, forKey: .cards) ?? []
        tags = try c.decodeIfPresent([Tag].self, forKey: .tags) ?? []
        colors = try c.decodeIfPresent([NamedColor].self, forKey: .colors) ?? []
        history = try c.decodeIfPresent([HistoryEvent].self, forKey: .history) ?? []
    }

    /// Пусто ли хранилище: ни людей, ни папок, ни карточек, ни справочников
    var isEmpty: Bool {
        persons.isEmpty && folders.isEmpty && cards.isEmpty && tags.isEmpty && colors.isEmpty
    }
}
