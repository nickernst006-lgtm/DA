#!/usr/bin/env python3
"""Закачка каталога фильмов из ПоискКино (данные Кинопоиска) в библиотеку ance на Supabase.

Бесплатный (демо) ключ ПоискКино — 200 запросов в сутки, по 250 фильмов в запросе,
и у одного запроса доступны только страницы 1–10. Поэтому каталог режется на «срезы» —
вид (фильм, мультфильм, аниме) × год — и в каждом срезе берутся самые известные фильмы.

Порядок «вширь»: сначала первая страница каждого среза (самые известные фильмы каждого года),
потом вторые страницы и так далее. За запуск — до 190 запросов (~47 000 фильмов),
прогресс запоминается в базе; за несколько запусков в разные дни набирается ~100 000.
Когда всё собрано, каждый запуск обновляет только последние два года.

У скрипта нет доступа к базе: только публичный ключ приложения и CATALOG_TOKEN —
ключ «почтовой щели», которым можно лишь добавить или обновить фильмы.

Переменные окружения:
  POISKKINO_API_KEY  — ключ ПоискКино
  SUPABASE_URL       — https://<проект>.supabase.co
  SUPABASE_ANON_KEY  — публичный ключ (тот же, что в приложении)
  CATALOG_TOKEN      — ключ щели (выдаёт SQL-скрипт схемы)
"""
import json
import os
import sys
import time
import urllib.error
import urllib.parse
import urllib.request

API = "https://api.poiskkino.dev/v1.4/movie"
PAGE_SIZE = 250
KINDS = ["movie", "cartoon", "anime"]  # полнометражные: фильмы, мультфильмы, аниме
MAX_PAGE = 10                          # дальше 10-й страницы демо-ключ не пускает
FIRST_YEAR = {"movie": 1910, "cartoon": 1930, "anime": 1960}
MIN_VOTES = {"movie": 300, "cartoon": 200, "anime": 200}  # только фильмы, которые кто-то смотрел
BUDGET = 190                           # из 200 запросов в сутки — с запасом
LIMIT = 100_000                        # потолок библиотеки: бесплатная база Supabase — 500 МБ


class QuotaExceeded(Exception):
    """Суточный лимит ПоискКино исчерпан — продолжим в следующий раз."""

# Жанры Кинопоиска → наши жанры (как в приложении: Archetype.genreWeights, FilmTags).
GENRE_RULES = [
    (("мульт", "аниме"), "Анимация"),
    (("фантастик",), "Фантастика"),
    (("фэнтези",), "Фэнтези"),
    (("ужас",), "Ужасы"),
    (("триллер",), "Триллер"),
    (("боевик",), "Боевик"),
    (("приключен",), "Приключения"),
    (("комеди",), "Комедия"),
    (("мелодрам",), "Мелодрама"),
    (("мюзикл", "музык"), "Мюзикл"),
    (("криминал",), "Криминал"),
    (("детектив",), "Детектив"),
    (("военн",), "Военный"),
    (("вестерн",), "Вестерн"),
    (("биограф",), "Биография"),
    (("истори",), "Исторический"),
    (("документ",), "Документальный"),
    (("семейн", "детск"), "Семейный"),
    (("спорт",), "Спорт"),
    (("нуар",), "Нуар"),
    (("драм",), "Драма"),
]


def log(message):
    print(message, flush=True)


def env(name, default=None):
    value = os.environ.get(name, default)
    if value is None or value == "":
        sys.exit(f"Нет переменной {name}")
    return value


def map_genres(names):
    result = []
    for name in names:
        low = name.lower()
        for keys, genre in GENRE_RULES:
            if any(k in low for k in keys) and genre not in result:
                result.append(genre)
                break
    return result


def http(method, url, headers, body=None, retries=4):
    data = json.dumps(body).encode() if body is not None else None
    for attempt in range(retries):
        request = urllib.request.Request(url, data=data, method=method, headers=headers)
        try:
            with urllib.request.urlopen(request, timeout=120) as response:
                raw = response.read()
                return json.loads(raw) if raw else None
        except urllib.error.HTTPError as error:
            text = error.read().decode(errors="replace")[:300]
            if error.code in (401, 403) and "poiskkino" in url:
                low = text.lower()
                if "страниц" in low:
                    return {"docs": [], "pages": 0}  # дальше 10-й страницы нельзя — срез закончен
                if "лимит" in low or "limit" in low:
                    raise QuotaExceeded(text)
            if error.code in (401, 403):
                sys.exit(f"Доступ запрещён ({error.code}) к {url.split('?')[0]}: {text}")
            if error.code == 429 or error.code >= 500:
                log(f"  {error.code}, повтор через {5 * (attempt + 1)} с: {text}")
                time.sleep(5 * (attempt + 1))
                continue
            sys.exit(f"Ошибка {error.code} {url.split('?')[0]}: {text}")
        except urllib.error.URLError as error:
            log(f"  сеть: {error}, повтор")
            time.sleep(5 * (attempt + 1))
    sys.exit(f"Не удалось обратиться к {url.split('?')[0]}")


class Library:
    """Работа с библиотекой только через функции «почтовой щели»."""

    def __init__(self, url, anon_key, token):
        # Берём только адрес проекта: если в секрет вставили ссылку с /rest/v1/ или другим хвостом — отбрасываем его.
        parts = urllib.parse.urlsplit(url.strip())
        self.base = f"{parts.scheme or 'https'}://{parts.netloc or parts.path.split('/')[0]}/rest/v1/rpc"
        anon_key = anon_key.strip()
        self.headers = {"apikey": anon_key, "Content-Type": "application/json"}
        # Старый ключ anon — это JWT, его же передаём как Bearer.
        # Новый publishable (sb_publishable_…) достаточно передать в apikey.
        if anon_key.startswith("eyJ"):
            self.headers["Authorization"] = f"Bearer {anon_key}"
        self.token = token

    def rpc(self, name, **args):
        return http("POST", f"{self.base}/{name}", self.headers, dict(token=self.token, **args))

    def progress(self):
        data = self.rpc("catalog_progress") or {}
        return int(data.get("films") or 0), data.get("state") or {}

    def set_state(self, key, value):
        self.rpc("set_catalog_state", k=key, v=str(value))

    def load(self, rows):
        return self.rpc("load_films", rows=rows)


def fetch_page(key, kind, year, page):
    params = [("page", page), ("limit", PAGE_SIZE), ("type", kind), ("year", year),
              ("votes.kp", f"{MIN_VOTES[kind]}-100000000"),
              ("sortField", "votes.kp"), ("sortType", "-1"),
              ("notNullFields", "name"), ("notNullFields", "poster.url")]
    for field in ["id", "name", "alternativeName", "enName", "year", "description", "shortDescription",
                  "movieLength", "countries", "genres", "poster", "rating", "votes", "persons", "type"]:
        params.append(("selectFields", field))
    url = API + "?" + urllib.parse.urlencode(params)
    return http("GET", url, {"X-API-KEY": key, "Accept": "application/json"})


def to_row(doc, kind):
    rating = doc.get("rating") or {}
    votes = doc.get("votes") or {}
    poster = doc.get("poster") or {}
    directors = [p.get("name") or p.get("enName") for p in (doc.get("persons") or [])
                 if p.get("enProfession") == "director" and (p.get("name") or p.get("enName"))]
    original = doc.get("alternativeName") or doc.get("enName")
    def num(v):
        try:
            return round(float(v), 1) if v not in (None, "", 0) else None
        except (TypeError, ValueError):
            return None
    return {
        "id": doc["id"],
        "title": doc.get("name") or original or "Без названия",
        "original_title": original if original and original != doc.get("name") else None,
        "year": doc.get("year"),
        "description": doc.get("description"),
        "short_description": doc.get("shortDescription"),
        "minutes": doc.get("movieLength"),
        "countries": [c["name"] for c in (doc.get("countries") or []) if c.get("name")],
        "genres": map_genres([g["name"] for g in (doc.get("genres") or []) if g.get("name")]),
        "directors": directors[:3],
        "poster_url": poster.get("url"),
        "poster_preview_url": poster.get("previewUrl"),
        "rating_kp": num(rating.get("kp")),
        "rating_imdb": num(rating.get("imdb")),
        "votes_kp": int(votes.get("kp") or 0),
        "kind": kind,
    }


def main():
    key = env("POISKKINO_API_KEY")
    library = Library(env("SUPABASE_URL"), env("SUPABASE_ANON_KEY"), env("CATALOG_TOKEN"))
    this_year = time.gmtime().tm_year

    total, state = library.progress()
    # Срез — вид × год. В состоянии хранится следующая страница среза; MAX_PAGE + 1 — срез собран.
    slices = [(kind, year) for kind in KINDS for year in range(this_year, FIRST_YEAR[kind] - 1, -1)]
    next_page = {s: int(state.get(f"slice:{s[0]}:{s[1]}", "1")) for s in slices}
    filling = total < LIMIT and any(p <= MAX_PAGE for p in next_page.values())
    log(f"В библиотеке {total} фильмов. "
        + ("Собираем: до 190 запросов." if filling else "Всё собрано: обновляем последние два года."))

    used = 0
    added = 0

    def take(kind, year, page):
        """Одна страница среза. Возвращает следующую страницу (или MAX_PAGE + 1, если срез кончился)."""
        nonlocal used, added
        data = fetch_page(key, kind, year, page)
        used += 1
        docs = data.get("docs") or []
        rows = [to_row(d, kind) for d in docs if d.get("id") and (d.get("name") or d.get("alternativeName"))]
        if rows:
            library.load(rows)
            added += len(rows)
        log(f"{kind} {year}: страница {page} — {len(rows)} фильмов")
        last = data.get("pages") or MAX_PAGE
        return MAX_PAGE + 1 if len(docs) < PAGE_SIZE or page >= min(MAX_PAGE, last) else page + 1

    try:
        if filling:
            # Вширь: сначала первые страницы всех срезов, затем вторые…
            for round_page in range(1, MAX_PAGE + 1):
                for s in slices:
                    if used >= BUDGET or total + added >= LIMIT:
                        break
                    if next_page[s] != round_page:
                        continue
                    next_page[s] = take(s[0], s[1], round_page)
                    library.set_state(f"slice:{s[0]}:{s[1]}", next_page[s])
        else:
            # Свежие фильмы: за последние два года набегают новые оценки и новинки.
            for kind in KINDS:
                for year in (this_year, this_year - 1):
                    page = 1
                    while page <= 3 and used < 30:
                        nxt = take(kind, year, page)
                        if nxt > MAX_PAGE:
                            break
                        page = nxt
        # Новый год — новый срез: его состояние появится само (страница 1).
    except QuotaExceeded as error:
        log(f"Суточный лимит ПоискКино исчерпан — продолжим при следующей загрузке. ({error})")

    total, _ = library.progress()
    left = sum(1 for p in next_page.values() if p <= MAX_PAGE)
    log(f"Готово: запросов к ПоискКино {used}, в библиотеке {total} фильмов"
        + (f", осталось срезов: {left}" if left else ", всё собрано"))


if __name__ == "__main__":
    main()
