#!/usr/bin/env python3
"""Вшивает в приложение адрес сервера и публичный ключ — из секретов GitHub.

Запускается при сборке до xcodegen. Пишет Seans/Resources/server.json:
  {"url": "https://<проект>.supabase.co", "key": "<publishable или anon key>"}
Файл в репозиторий не попадает (.gitignore). Если секретов нет — файл не создаётся,
и адрес можно будет ввести в приложении: «Настройки сервера» на экране входа.
Публичный ключ и так виден любому, у кого есть приложение; защищают данные замки RLS и закрытая регистрация.
"""
import base64
import json
import os
import urllib.parse


def is_secret(key):
    """Секретный ключ в приложение класть нельзя — проверяем на всякий случай."""
    if key.startswith("sb_secret_"):
        return True
    if key.startswith("eyJ") and key.count(".") == 2:
        payload = key.split(".")[1]
        try:
            data = json.loads(base64.urlsafe_b64decode(payload + "=" * (-len(payload) % 4)))
            return data.get("role") == "service_role"
        except Exception:
            return False
    return False

PATH = "Seans/Resources/server.json"

url = (os.environ.get("SUPABASE_URL") or "").strip()
key = (os.environ.get("SUPABASE_ANON_KEY") or "").strip()

if not url or not key:
    print("::warning::Нет секретов SUPABASE_URL / SUPABASE_ANON_KEY — адрес сервера не вшит.")
else:
    parts = urllib.parse.urlsplit(url if "://" in url else "https://" + url)
    clean = f"{parts.scheme or 'https'}://{parts.netloc}"
    if is_secret(key):
        raise SystemExit("В SUPABASE_ANON_KEY лежит секретный ключ — замените его на publishable / anon.")
    with open(PATH, "w", encoding="utf-8") as f:
        json.dump({"url": clean, "key": key}, f)
    print(f"Адрес сервера и публичный ключ вшиты в приложение (ключ {len(key)} знаков).")
