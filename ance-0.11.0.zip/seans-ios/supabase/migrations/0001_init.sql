-- ance: схема базы на Supabase (Postgres).
-- Вставляется один раз в Supabase → SQL Editor → Run. В конце покажет «ключ для почтовой щели» —
-- его нужно положить в секрет GitHub CATALOG_TOKEN.
--
-- Квартира (этот проект) — 5 комнат:
--   библиотека (films) — читают только четверо вошедших; пополняется только через «почтовую щель» load_films;
--   четыре личные комнаты — строки каждого пользователя: своё видит и меняет только владелец,
--   остальным троим — только то, что владелец открыл в настройках.
-- Хозяин (вы) видит и меняет всё через панель Supabase. У GitHub доступа к базе нет —
-- только «щель», через которую можно добавить или обновить фильмы, и больше ничего.

create extension if not exists pg_trgm;

-- ───────────────────────── Каталог ─────────────────────────

create table if not exists public.films (
    id                  bigint primary key,          -- id фильма на Кинопоиске
    title               text not null,
    original_title      text,
    year                int,
    description         text,
    short_description   text,
    minutes             int,
    countries           text[] not null default '{}',
    genres              text[] not null default '{}', -- наши жанры: «Драма», «Комедия»…
    directors           text[] not null default '{}',
    poster_url          text,
    poster_preview_url  text,
    rating_kp           numeric(3,1),
    rating_imdb         numeric(3,1),
    votes_kp            int not null default 0,
    kind                text not null default 'movie', -- movie / cartoon / anime
    updated_at          timestamptz not null default now()
);

create index if not exists films_votes_idx     on public.films (votes_kp desc);
create index if not exists films_year_idx      on public.films (year);
create index if not exists films_title_trgm    on public.films using gin (title gin_trgm_ops);
create index if not exists films_original_trgm on public.films using gin (original_title gin_trgm_ops);
create index if not exists films_genres_idx    on public.films using gin (genres);
create index if not exists films_countries_idx on public.films using gin (countries);
create index if not exists films_directors_idx on public.films using gin (directors);

alter table public.films enable row level security;
drop policy if exists "Каталог открыт всем" on public.films;
drop policy if exists "Библиотека — для своих" on public.films;
create policy "Библиотека — для своих" on public.films for select to authenticated using (true);

-- Состояние закачки каталога (страница, на которой остановились).
create table if not exists public.catalog_state (
    key   text primary key,
    value text not null,
    updated_at timestamptz not null default now()
);
alter table public.catalog_state enable row level security; -- закрыта; работа только через функции щели

-- Поиск: название, оригинальное название, год, режиссёр. Сначала точные совпадения, потом известные.
create or replace function public.search_films(q text, lim int default 60)
returns setof public.films
language sql stable as $$
    with t as (select trim(q) as q)
    select f.* from public.films f, t
    where length(t.q) > 0 and (
          f.title ilike '%' || t.q || '%'
       or f.original_title ilike '%' || t.q || '%'
       or (t.q ~ '^\d{4}$' and f.year = t.q::int)
       or exists (select 1 from unnest(f.directors) d where d ilike '%' || t.q || '%')
    )
    order by (lower(f.title) = lower(t.q) or lower(coalesce(f.original_title, '')) = lower(t.q)) desc,
             f.votes_kp desc
    limit lim;
$$;

-- Случайные фильмы для «Вселенной»: только известные, чтобы случай был приятным.
create or replace function public.random_films(lim int default 60, min_votes int default 5000)
returns setof public.films
language sql volatile as $$
    select * from public.films where votes_kp >= min_votes order by random() limit lim;
$$;

-- ───────────────────────── Пользователи ─────────────────────────

create table if not exists public.profiles (
    id               uuid primary key references auth.users on delete cascade,
    name             text not null default '',
    share_collection boolean not null default true,  -- друзья видят «Хочу» и «Посмотрел» с оценками
    share_journal    boolean not null default true,  -- друзья видят журналы и анкеты
    created_at       timestamptz not null default now()
);
alter table public.profiles enable row level security;

-- Профиль создаётся сам при регистрации.
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
begin
    insert into public.profiles (id, name)
    values (new.id, coalesce(new.raw_user_meta_data ->> 'name', ''))
    on conflict (id) do nothing;
    return new;
end $$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
    for each row execute function public.handle_new_user();
-- Профили для тех, кого создали в панели до этого скрипта.
insert into public.profiles (id) select id from auth.users on conflict (id) do nothing;

-- Друзья: все участники квартиры (их четверо, регистрация закрыта) видят друг друга автоматически.
create or replace function public.is_friend(owner uuid)
returns boolean language sql stable security definer set search_path = public as $$
    select auth.uid() is not null and owner <> auth.uid()
       and exists (select 1 from public.profiles where id = owner);
$$;

create or replace function public.shares(owner uuid, what text)
returns boolean language sql stable security definer set search_path = public as $$
    select case what
        when 'collection' then coalesce((select share_collection from public.profiles where id = owner), false)
        when 'journal'    then coalesce((select share_journal    from public.profiles where id = owner), false)
        else false end;
$$;

drop policy if exists "Свой профиль" on public.profiles;
create policy "Свой профиль" on public.profiles for all to authenticated using (id = auth.uid()) with check (id = auth.uid());
drop policy if exists "Профили друзей" on public.profiles;
create policy "Профили друзей" on public.profiles for select to authenticated using (public.is_friend(id));

-- ───────────────────────── Коллекция, анкеты, журналы ─────────────────────────

create table if not exists public.collection_items (
    user_id    uuid not null default auth.uid() references auth.users on delete cascade,
    film_id    bigint not null references public.films,
    status     text not null check (status in ('want', 'seen')),
    added_at   timestamptz not null default now(),
    seen_at    timestamptz,
    updated_at timestamptz not null default now(),
    primary key (user_id, film_id)
);

create table if not exists public.surveys (
    user_id    uuid not null default auth.uid() references auth.users on delete cascade,
    film_id    bigint not null references public.films,
    date       timestamptz not null default now(),
    rating     int not null default 0,
    emotions   text[] not null default '{}',
    aspects    text not null default '',   -- "plot:4,cast:5"
    scales     text not null default '',   -- "tempo:-1,tone:2"
    ending     text not null default '',
    company    text not null default '',
    place      text not null default '',
    rewatch    text not null default '',
    recommend  text[] not null default '{}',
    word       text not null default '',
    essay      text not null default '',
    updated_at timestamptz not null default now(),
    primary key (user_id, film_id)
);

create table if not exists public.journal_blocks (
    id         uuid primary key,
    user_id    uuid not null default auth.uid() references auth.users on delete cascade,
    film_id    bigint not null references public.films,
    kind       text not null,
    ord        double precision not null default 0,
    text       text not null default '',
    detail     text not null default '',
    created_at timestamptz not null default now(),
    updated_at timestamptz not null default now()
);
create index if not exists journal_blocks_owner_idx on public.journal_blocks (user_id, film_id);

create table if not exists public.journal_photos (
    id       uuid primary key,
    block_id uuid not null references public.journal_blocks on delete cascade,
    user_id  uuid not null default auth.uid() references auth.users on delete cascade,
    ord      int not null default 0,
    path     text not null                 -- путь в хранилище: <user>/<id>.jpg
);
create index if not exists journal_photos_block_idx on public.journal_photos (block_id);

create table if not exists public.board_items (
    id          uuid primary key,
    block_id    uuid not null references public.journal_blocks on delete cascade,
    user_id     uuid not null default auth.uid() references auth.users on delete cascade,
    kind        text not null,
    x           double precision not null default 800,
    y           double precision not null default 800,
    width       double precision not null default 160,
    rotation    double precision not null default 0,
    color_index int not null default 0,
    text        text not null default '',
    z           double precision not null default 0,
    image_path  text,
    from_id     uuid,
    to_id       uuid
);
create index if not exists board_items_block_idx on public.board_items (block_id);

-- Права: своё — полностью; чужое — только чтение и только у друзей, которые это открыли.
do $$
declare t text; what text;
begin
    foreach t in array array['collection_items', 'surveys', 'journal_blocks', 'journal_photos', 'board_items'] loop
        execute format('alter table public.%I enable row level security', t);
        execute format('drop policy if exists "Своё" on public.%I', t);
        execute format('create policy "Своё" on public.%I for all to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid())', t);
        what := case when t = 'collection_items' then 'collection' else 'journal' end;
        execute format('drop policy if exists "Друзьям" on public.%I', t);
        execute format('create policy "Друзьям" on public.%I for select to authenticated using (public.is_friend(user_id) and public.shares(user_id, %L))', t, what);
    end loop;
end $$;

-- Время изменения — для синхронизации.
create or replace function public.touch_updated_at()
returns trigger language plpgsql as $$
begin new.updated_at := now(); return new; end $$;
do $$
declare t text;
begin
    foreach t in array array['collection_items', 'surveys', 'journal_blocks'] loop
        execute format('drop trigger if exists touch on public.%I', t);
        execute format('create trigger touch before update on public.%I for each row execute function public.touch_updated_at()', t);
    end loop;
end $$;

-- ───────────────────────── Фото ─────────────────────────

insert into storage.buckets (id, name, public)
values ('journal', 'journal', false)
on conflict (id) do nothing;

drop policy if exists "Свои фото" on storage.objects;
create policy "Свои фото" on storage.objects for all to authenticated
    using (bucket_id = 'journal' and (storage.foldername(name))[1] = auth.uid()::text)
    with check (bucket_id = 'journal' and (storage.foldername(name))[1] = auth.uid()::text);
drop policy if exists "Фото друзей" on storage.objects;
create policy "Фото друзей" on storage.objects for select to authenticated
    using (bucket_id = 'journal'
           and public.is_friend(((storage.foldername(name))[1])::uuid)
           and public.shares(((storage.foldername(name))[1])::uuid, 'journal'));

-- ───────────────────────── Удаление аккаунта ─────────────────────────
-- Стирает пользователя и все его строки (каскадом). Фото приложение удаляет из хранилища перед вызовом.
create or replace function public.delete_account()
returns void language sql security definer set search_path = public, auth as $$
    delete from auth.users where id = auth.uid();
$$;

-- ───────────────────────── Явные разрешения ─────────────────────────
-- Проект создан с выключенным «Automatically expose new tables»: таблицы по умолчанию закрыты,
-- поэтому доступ выдаём явно и только вошедшим. Гостям (anon) — ничего, кроме «почтовой щели» ниже.
-- Что именно видно внутри таблиц — решают замки RLS выше.
-- Если проект создан с включённым «expose new tables» — сначала забираем всё, что выдано автоматически,
-- и отключаем автоматическую выдачу на будущее. При выключенной галочке эти строки ничего не меняют.
revoke all on all tables    in schema public from anon, authenticated;
revoke all on all sequences in schema public from anon, authenticated;
revoke execute on all functions in schema public from public, anon, authenticated;
alter default privileges in schema public revoke all on tables    from anon, authenticated;
alter default privileges in schema public revoke all on sequences from anon, authenticated;
alter default privileges in schema public revoke execute on functions from public, anon, authenticated;
grant usage on schema public to anon, authenticated;  -- anon — только чтобы дойти до «почтовой щели»
grant select                         on public.films            to authenticated;
grant select, update                 on public.profiles         to authenticated;
grant select, insert, update, delete on public.collection_items to authenticated;
grant select, insert, update, delete on public.surveys          to authenticated;
grant select, insert, update, delete on public.journal_blocks   to authenticated;
grant select, insert, update, delete on public.journal_photos   to authenticated;
grant select, insert, update, delete on public.board_items      to authenticated;
revoke all on public.catalog_state from anon, authenticated;
grant execute on function public.is_friend(uuid)    to authenticated;
grant execute on function public.shares(uuid, text) to authenticated;

revoke execute on function public.search_films(text, int) from public, anon;
revoke execute on function public.random_films(int, int)  from public, anon;
revoke execute on function public.delete_account()        from public, anon;
grant execute on function public.search_films(text, int)  to authenticated;
grant execute on function public.random_films(int, int)   to authenticated;
grant execute on function public.delete_account()         to authenticated;

-- ───────────────────────── «Почтовая щель» библиотеки ─────────────────────────
-- GitHub не знает ни пароля базы, ни сервисного ключа. У него есть только CATALOG_TOKEN:
-- с ним можно вызвать три функции ниже — добавить/обновить фильмы и записать, на какой странице
-- закачка остановилась. Ни прочитать, ни удалить, ни заглянуть в личные комнаты он не может.
-- Если ключ утечёт — выполните «select public.new_catalog_token();» ещё раз: старый перестанет работать.

create table if not exists public.catalog_token (
    id   int primary key default 1 check (id = 1),
    hash text not null
);
alter table public.catalog_token enable row level security; -- без политик: недоступна никому, кроме функций
revoke all on public.catalog_token from anon, authenticated;

create or replace function public.check_catalog_token(token text)
returns void language plpgsql stable security definer set search_path = public as $$
begin
    if not exists (select 1 from public.catalog_token
                   where hash = encode(sha256(convert_to(coalesce(token, ''), 'UTF8')), 'hex')) then
        raise exception 'Неверный ключ каталога';
    end if;
end $$;

create or replace function public.new_catalog_token()
returns text language plpgsql security definer set search_path = public as $$
declare token text := replace(gen_random_uuid()::text || gen_random_uuid()::text, '-', '');
begin
    insert into public.catalog_token (id, hash) values (1, encode(sha256(convert_to(token, 'UTF8')), 'hex'))
    on conflict (id) do update set hash = excluded.hash;
    return token;
end $$;
revoke execute on function public.new_catalog_token() from public, anon, authenticated;

-- Добавить или обновить фильмы (только эта таблица, только добавление и обновление).
create or replace function public.load_films(token text, rows jsonb)
returns int language plpgsql security definer set search_path = public as $$
declare n int;
begin
    perform public.check_catalog_token(token);
    insert into public.films as f (id, title, original_title, year, description, short_description, minutes,
                                   countries, genres, directors, poster_url, poster_preview_url,
                                   rating_kp, rating_imdb, votes_kp, kind, updated_at)
    select r.id, r.title, r.original_title, r.year, r.description, r.short_description, r.minutes,
           coalesce(r.countries, '{}'), coalesce(r.genres, '{}'), coalesce(r.directors, '{}'),
           r.poster_url, r.poster_preview_url, r.rating_kp, r.rating_imdb, coalesce(r.votes_kp, 0),
           coalesce(r.kind, 'movie'), now()
    from jsonb_to_recordset(rows) as r(id bigint, title text, original_title text, year int, description text,
         short_description text, minutes int, countries text[], genres text[], directors text[],
         poster_url text, poster_preview_url text, rating_kp numeric, rating_imdb numeric, votes_kp int, kind text)
    where r.id is not null and r.title is not null
    on conflict (id) do update set
        title = excluded.title, original_title = excluded.original_title, year = excluded.year,
        description = excluded.description, short_description = excluded.short_description,
        minutes = excluded.minutes, countries = excluded.countries, genres = excluded.genres,
        directors = excluded.directors, poster_url = excluded.poster_url,
        poster_preview_url = excluded.poster_preview_url, rating_kp = excluded.rating_kp,
        rating_imdb = excluded.rating_imdb, votes_kp = excluded.votes_kp, kind = excluded.kind,
        updated_at = now();
    get diagnostics n = row_count;
    return n;
end $$;

create or replace function public.catalog_progress(token text)
returns jsonb language plpgsql stable security definer set search_path = public as $$
begin
    perform public.check_catalog_token(token);
    return jsonb_build_object(
        'films', (select count(*) from public.films),
        'state', coalesce((select jsonb_object_agg(key, value) from public.catalog_state), '{}'::jsonb));
end $$;

create or replace function public.set_catalog_state(token text, k text, v text)
returns void language plpgsql security definer set search_path = public as $$
begin
    perform public.check_catalog_token(token);
    insert into public.catalog_state (key, value, updated_at) values (k, v, now())
    on conflict (key) do update set value = excluded.value, updated_at = now();
end $$;

revoke execute on function public.check_catalog_token(text) from public, anon, authenticated;
grant execute on function public.load_films(text, jsonb)                 to anon;
grant execute on function public.catalog_progress(text)                  to anon;
grant execute on function public.set_catalog_state(text, text, text)     to anon;

-- Ключ для GitHub: скопируйте значение из результата в секрет CATALOG_TOKEN.
select public.new_catalog_token() as "Скопируйте в секрет GitHub CATALOG_TOKEN";
