import Foundation
import SwiftData
import UIKit

/// Вид блока в журнале фильма.
enum JournalKind: String, CaseIterable, Identifiable {
    case text, heading, photo, quote, fact, board
    /// Эссе из анкеты: текст хранится в анкете, а в журнале — его место в ленте.
    case essay

    var id: String { rawValue }

    /// Что можно добавить вручную (эссе пишется в анкете).
    static let addable: [JournalKind] = [.text, .heading, .photo, .quote, .fact, .board]

    var title: String {
        switch self {
        case .text: return "Текст"
        case .heading: return "Заголовок"
        case .photo: return "Фото"
        case .quote: return "Цитата"
        case .fact: return "Факт"
        case .board: return "Доска"
        case .essay: return "Эссе"
        }
    }

    var hint: String {
        switch self {
        case .text: return "мысли, разбор"
        case .heading: return "разделить журнал"
        case .photo: return "одно или подборка"
        case .quote: return "реплика и кто сказал"
        case .fact: return "короткая карточка"
        case .board: return "стикеры, фото, стрелки"
        case .essay: return "из анкеты"
        }
    }

    /// Значок из системного набора Apple — все в одном стиле.
    var symbol: String {
        switch self {
        case .text, .essay: return "text.alignleft"
        case .heading: return "h.square"
        case .photo: return "photo"
        case .quote: return "quote.opening"
        case .fact: return "lightbulb"
        case .board: return "point.3.connected.trianglepath.dotted"
        }
    }

    /// Значок в окне «Добавить блок» (старый, текстом).
    var glyph: String {
        switch self {
        case .text: return "Аа"
        case .heading: return "H"
        case .photo: return "▣"
        case .quote: return "“"
        case .fact: return "!"
        case .board: return "✣"
        case .essay: return "Аа"
        }
    }
}

/// Блок журнала: текст, заголовок, подборка фото, цитата, факт, доска или место эссе.
@Model
final class JournalBlock {
    var id: UUID = UUID()
    var filmID: String = ""
    var kindRaw: String = JournalKind.text.rawValue
    /// Порядок в ленте — по возрастанию.
    var order: Double = 0
    /// Текст, заголовок, цитата или факт.
    var text: String = ""
    /// Подпись к фото или кто сказал цитату.
    var detail: String = ""
    var createdAt: Date = Date()
    @Relationship(deleteRule: .cascade, inverse: \JournalPhoto.block) var photos: [JournalPhoto]? = []
    @Relationship(deleteRule: .cascade, inverse: \BoardItem.block) var boardItems: [BoardItem]? = []

    init(filmID: String, kind: JournalKind, order: Double) {
        self.id = UUID()
        self.filmID = filmID
        self.kindRaw = kind.rawValue
        self.order = order
        self.createdAt = Date()
    }

    var kind: JournalKind { JournalKind(rawValue: kindRaw) ?? .text }

    var sortedPhotos: [JournalPhoto] { (photos ?? []).sorted { $0.order < $1.order } }
    var items: [BoardItem] { (boardItems ?? []).sorted { $0.z < $1.z } }
}

/// Фото в блоке. Хранится в отдельном файле рядом с базой, а не в ней самой.
@Model
final class JournalPhoto {
    var id: UUID = UUID()
    var order: Int = 0
    @Attribute(.externalStorage) var data: Data?
    var block: JournalBlock?

    init(data: Data, order: Int) {
        self.id = UUID()
        self.data = data
        self.order = order
    }
}

/// Вид элемента доски.
enum BoardItemKind: String {
    case sticker, text, photo, arrow
}

/// Элемент доски. Координаты — центр элемента в точках доски (доска 1600 × 1600).
@Model
final class BoardItem {
    var id: UUID = UUID()
    var kindRaw: String = BoardItemKind.sticker.rawValue
    var x: Double = 800
    var y: Double = 800
    var width: Double = 160
    var rotation: Double = 0
    var colorIndex: Int = 0
    var text: String = ""
    /// Порядок наложения: больше — выше.
    var z: Double = 0
    @Attribute(.externalStorage) var imageData: Data?
    /// Стрелка: откуда и куда (id элементов).
    var fromID: UUID?
    var toID: UUID?
    var block: JournalBlock?

    init(kind: BoardItemKind, x: Double, y: Double, width: Double, z: Double) {
        self.id = UUID()
        self.kindRaw = kind.rawValue
        self.x = x
        self.y = y
        self.width = width
        self.z = z
        // лёгкий случайный наклон — как у настоящих стикеров
        self.rotation = kind == .arrow ? 0 : Double.random(in: -4...4)
    }

    var kind: BoardItemKind { BoardItemKind(rawValue: kindRaw) ?? .sticker }
}

/// Цвета стикеров — те же, что у архетипов: приглушённые и различимые на тёмном.
enum StickerPalette {
    static let colors: [UInt32] = [0xF2C14E, 0xF4A6C6, 0x8EC5E8, 0xB9A8F2, 0x4FBF8B, 0xF5F5F5]
    static func color(_ index: Int) -> UInt32 { colors[((index % colors.count) + colors.count) % colors.count] }
}

/// Операции с журналом.
enum JournalActions {
    static func blocks(for filmID: String, in context: ModelContext) -> [JournalBlock] {
        let descriptor = FetchDescriptor<JournalBlock>(
            predicate: #Predicate { $0.filmID == filmID },
            sortBy: [SortDescriptor(\.order)])
        return (try? context.fetch(descriptor)) ?? []
    }

    /// Новый блок в конце ленты.
    @discardableResult
    static func add(_ kind: JournalKind, to filmID: String, in context: ModelContext) -> JournalBlock {
        let last = blocks(for: filmID, in: context).last?.order ?? 0
        let block = JournalBlock(filmID: filmID, kind: kind, order: last + 1)
        context.insert(block)
        try? context.save()
        return block
    }

    static func delete(_ block: JournalBlock, in context: ModelContext) {
        context.delete(block)
        try? context.save()
    }

    /// Сдвинуть блок вверх (−1) или вниз (+1).
    static func move(_ block: JournalBlock, by step: Int, in context: ModelContext) {
        var list = blocks(for: block.filmID, in: context)
        guard let index = list.firstIndex(where: { $0.id == block.id }) else { return }
        let target = index + step
        guard list.indices.contains(target) else { return }
        list.swapAt(index, target)
        for (i, item) in list.enumerated() { item.order = Double(i + 1) }
        try? context.save()
    }

    /// Эссе из анкеты получает своё место в ленте: в начале, если места ещё нет.
    /// Если эссе стёрли — место убирается.
    static func syncEssay(for filmID: String, essay: String, in context: ModelContext) {
        let list = blocks(for: filmID, in: context)
        let existing = list.first { $0.kind == .essay }
        let hasEssay = !essay.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
        if hasEssay && existing == nil {
            let first = list.first?.order ?? 1
            context.insert(JournalBlock(filmID: filmID, kind: .essay, order: first - 1))
            try? context.save()
        } else if !hasEssay, let existing {
            context.delete(existing)
            try? context.save()
        }
    }

    /// Добавить фото к блоку: уменьшаем до 2048 точек по длинной стороне, чтобы не раздувать память телефона.
    static func addPhotos(_ datas: [Data], to block: JournalBlock, in context: ModelContext) {
        var next = (block.photos ?? []).map(\.order).max() ?? -1
        for data in datas {
            guard let prepared = ImagePrep.jpeg(from: data) else { continue }
            next += 1
            let photo = JournalPhoto(data: prepared, order: next)
            context.insert(photo)
            photo.block = block
        }
        try? context.save()
    }
}

/// Подготовка фото перед сохранением.
enum ImagePrep {
    static func jpeg(from data: Data, maxSide: CGFloat = 2048) -> Data? {
        guard let image = UIImage(data: data) else { return nil }
        let size = image.size
        let longest = max(size.width, size.height)
        guard longest > maxSide else { return image.jpegData(compressionQuality: 0.85) }
        let factor = maxSide / longest
        let target = CGSize(width: (size.width * factor).rounded(), height: (size.height * factor).rounded())
        let format = UIGraphicsImageRendererFormat.default()
        format.scale = 1
        let resized = UIGraphicsImageRenderer(size: target, format: format).image { _ in
            image.draw(in: CGRect(origin: .zero, size: target))
        }
        return resized.jpegData(compressionQuality: 0.85)
    }
}

/// Кэш картинок из базы, чтобы не декодировать фото при каждой перерисовке.
enum PhotoCache {
    private static let cache = NSCache<NSString, UIImage>()

    static func image(id: UUID, data: Data?) -> UIImage? {
        let key = id.uuidString as NSString
        if let cached = cache.object(forKey: key) { return cached }
        guard let data, let image = UIImage(data: data) else { return nil }
        cache.setObject(image, forKey: key)
        return image
    }
}
