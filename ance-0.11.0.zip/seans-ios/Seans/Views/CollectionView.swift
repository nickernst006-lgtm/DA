import SwiftUI
import SwiftData

/// Вкладка «Коллекция»: «Хочу посмотреть» — сеткой обложек,
/// «Посмотрел» — крупными карточками-журналами.
struct CollectionView: View {
    var onBrowse: () -> Void = {}

    @Environment(Library.self) private var library
    @Query(sort: \CollectionItem.addedAt, order: .reverse) private var items: [CollectionItem]
    @Query private var surveys: [SurveyEntry]
    @Query(sort: \JournalBlock.order) private var blocks: [JournalBlock]

    @State private var list: CollectionStatus = .want
    @State private var surveyFilm: FilmItem?

    private let columns = [
        GridItem(.flexible(), spacing: Space.s12, alignment: .top),
        GridItem(.flexible(), spacing: Space.s12, alignment: .top),
        GridItem(.flexible(), spacing: Space.s12, alignment: .top)
    ]

    private var wantFilms: [FilmItem] {
        items.filter { $0.status == .want }
            .compactMap { library.film(id: $0.filmID) }
    }

    private struct SeenEntry: Identifiable {
        let item: CollectionItem
        let film: FilmItem
        var id: String { film.id }
    }

    private var seenItems: [SeenEntry] {
        items.filter { $0.status == .seen }
            .sorted { ($0.seenAt ?? $0.addedAt) > ($1.seenAt ?? $1.addedAt) }
            .compactMap { item in library.film(id: item.filmID).map { SeenEntry(item: item, film: $0) } }
    }

    /// Последний просмотренный фильм без анкеты.
    private var pendingSurveyFilm: FilmItem? {
        seenItems.map(\.film).first { film in !surveys.contains { $0.filmID == film.id } }
    }

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 0) {
                    VStack(alignment: .leading, spacing: ScreenLayout.titleGap) {
                        ScreenTitle("Коллекция")
                            .padding(.top, Space.s12)

                        SegmentedControl(
                            options: [
                                SegmentOption(value: CollectionStatus.want, title: "Хочу посмотреть · \(wantFilms.count)"),
                                SegmentOption(value: CollectionStatus.seen, title: "Посмотрел · \(seenItems.count)")
                            ],
                            selection: $list
                        )
                    }

                    // Напоминание об анкете — под переключателем, чтобы тот всегда стоял на месте.
                    if let pending = pendingSurveyFilm {
                        reminder(pending)
                            .padding(.top, Space.s20)
                    }

                    Group {
                        if list == .want {
                            wantGrid
                        } else {
                            seenList
                        }
                    }
                    .padding(.top, Space.s20)
                }
                .padding(.horizontal, ScreenLayout.sideMargin)
                .padding(.bottom, Space.s24)
            }
            .dockClearance()
            .background(Theme.background.ignoresSafeArea())
            .toolbar(.hidden, for: .navigationBar)
            .navigationDestination(for: FilmRoute.self) { route in
                FilmDetailView(filmID: route.id)
            }
        }
        .fullScreenCover(item: $surveyFilm) { film in
            SurveyView(film: film)
        }
    }

    // MARK: Хочу посмотреть

    @ViewBuilder
    private var wantGrid: some View {
        if wantFilms.isEmpty {
            emptyState
        } else {
            LazyVGrid(columns: columns, alignment: .leading, spacing: Space.s24) {
                ForEach(wantFilms) { film in
                    NavigationLink(value: FilmRoute(id: film.id)) {
                        FilmTile(film: film, subtitle: film.shortMeta, compact: true)
                    }
                    .buttonStyle(.plain)
                }
            }
        }
    }

    // MARK: Посмотрел

    @ViewBuilder
    private var seenList: some View {
        if seenItems.isEmpty {
            emptyState
        } else {
            let byFilm = Dictionary(grouping: blocks, by: \.filmID)
            LazyVStack(alignment: .leading, spacing: Space.s12) {
                ForEach(seenItems) { pair in
                    NavigationLink(value: FilmRoute(id: pair.film.id)) {
                        JournalCard(
                            film: pair.film,
                            survey: surveys.first { $0.filmID == pair.film.id },
                            blocks: byFilm[pair.film.id] ?? [],
                            seenAt: pair.item.seenAt ?? pair.item.addedAt
                        )
                    }
                    .buttonStyle(.plain)
                }
            }
        }
    }

    private func reminder(_ film: FilmItem) -> some View {
        Button {
            surveyFilm = film
        } label: {
            HStack(spacing: Space.s12) {
                CoverView(film: film, cornerRadius: Radius.small)
                    .frame(width: 48)
                VStack(alignment: .leading, spacing: Space.s4) {
                    Text("Как вам «\(film.title)»?")
                        .textStyle(.sub, .bold)
                        .foregroundStyle(Theme.text)
                        .lineLimit(2)
                    Text("Короткая анкета — и ance лучше поймёт ваш вкус")
                        .textStyle(.caption)
                        .foregroundStyle(Theme.muted)
                        .fixedSize(horizontal: false, vertical: true)
                }
                Spacer(minLength: 0)
                Image(systemName: "arrow.right")
                    .font(.system(size: 15, weight: .medium))
                    .foregroundStyle(Theme.muted)
                    .accessibilityHidden(true)
            }
            .padding(Space.s16)
            .background(RoundedRectangle(cornerRadius: Radius.large, style: .continuous).fill(Theme.surface))
        }
        .buttonStyle(.plain)
    }

    private var emptyState: some View {
        VStack(alignment: .leading, spacing: Space.s8) {
            Text(list == .want ? "Список пока пуст" : "Вы ещё ничего не отметили")
                .textStyle(.h3)
                .foregroundStyle(Theme.text)
            Text(list == .want
                 ? "Найдите фильм во «Вселенной» и нажмите «Хочу посмотреть»."
                 : "Отметьте фильм как просмотренный и заполните анкету.")
                .textStyle(.sub)
                .foregroundStyle(Theme.muted)
                .fixedSize(horizontal: false, vertical: true)
            Button("Открыть Вселенную", action: onBrowse)
                .buttonStyle(SecondaryButtonStyle())
                .padding(.top, Space.s8)
        }
    }
}

// MARK: - Карточка-журнал

/// Фильм в «Посмотрел»: обложка, название и режиссёр сверху, оценка со словом снизу —
/// верх заглавных названия вровень с верхом обложки, низ квадрата — с её низом.
/// Ниже — начало первого текста, первые фото, что ещё есть в журнале, и дата просмотра.
struct JournalCard: View {
    let film: FilmItem
    let survey: SurveyEntry?
    let blocks: [JournalBlock]
    let seenAt: Date

    @Environment(\.dynamicTypeSize) private var dynamicTypeSize

    private let coverSize = CGSize(width: 72, height: 108)

    /// Есть ли что показать под шапкой: отрывок, фото или состав журнала.
    private var hasBody: Bool { excerpt != nil || !photos.isEmpty || !chips.isEmpty }

    var body: some View {
        VStack(alignment: .leading, spacing: Space.s12) {
            header
            if let excerpt {
                Text(excerpt)
                    .textStyle(.sub)
                    .foregroundStyle(Theme.textSecondary)
                    .lineLimit(3)
                    .multilineTextAlignment(.leading)
            }
            if !photos.isEmpty {
                photoStrip
            }
            if hasBody {
                footer
            }
        }
        .padding(Space.s16)
        .background(RoundedRectangle(cornerRadius: Radius.large, style: .continuous).fill(Theme.surface))
        .contentShape(RoundedRectangle(cornerRadius: Radius.large, style: .continuous))
        .accessibilityElement(children: .combine)
    }

    /// Шапка: обложка слева; название и режиссёр — от верха обложки;
    /// квадрат оценки — в правом верхнем углу, вровень с верхом обложки,
    /// справа от него столько же, сколько слева от обложки (поле карточки 16).
    /// Если под шапкой ничего нет, дата — в её правом нижнем углу, вровень с низом обложки.
    private var header: some View {
        HStack(alignment: .top, spacing: Space.s12) {
            CoverView(film: film, cornerRadius: Radius.medium)
                .frame(width: coverSize.width, height: coverSize.height)
            VStack(alignment: .leading, spacing: Space.s4) {
                Text(film.title)
                    .textStyle(.h3)
                    .foregroundStyle(Theme.text)
                    .lineLimit(2)
                    .multilineTextAlignment(.leading)
                if !film.shortMeta.isEmpty {
                    Text(film.shortMeta)
                        .textStyle(.sub)
                        .foregroundStyle(Theme.muted)
                        .lineLimit(1)
                }
            }
            // место под квадрат оценки, чтобы название под него не заходило
            .padding(.trailing, survey.map { $0.rating > 0 } == true ? 32 + Space.s12 : 0)
            .frame(maxWidth: .infinity, alignment: .leading)
        }
        .frame(height: coverSize.height, alignment: .top)
        .overlay(alignment: .topTrailing) {
            if let survey, survey.rating > 0 {
                RatingBadge(value: survey.rating, style: .h3)
            }
        }
        .overlay(alignment: .bottomTrailing) {
            if !hasBody {
                InfoChip(text: dateText)
            }
        }
    }

    /// Одно фото — во всю ширину, два — в пропорции 2 : 1.
    private var photoStrip: some View {
        GeometryReader { geo in
            let shown = Array(photos.prefix(2))
            let first = shown.count > 1 ? (geo.size.width - Space.s8) * 2 / 3 : geo.size.width
            HStack(spacing: Space.s8) {
                ForEach(Array(shown.enumerated()), id: \.element.id) { index, photo in
                    photoTile(photo)
                        .frame(width: index == 0 ? first : geo.size.width - first - Space.s8)
                }
            }
        }
        .frame(height: 120)
    }

    private func photoTile(_ photo: JournalPhoto) -> some View {
        Color(hex: 0x1F1F1F)
            .overlay {
                if let image = PhotoCache.image(id: photo.id, data: photo.data) {
                    Image(uiImage: image).resizable().scaledToFill()
                }
            }
            .clipShape(RoundedRectangle(cornerRadius: Radius.medium, style: .continuous))
    }

    private var footer: some View {
        HStack(alignment: .top, spacing: Space.s8) {
            FlowLayout(spacing: Space.s8, lineSpacing: Space.s8) {
                ForEach(chips, id: \.self) { InfoChip(text: $0) }
            }
            Spacer(minLength: 0)
            InfoChip(text: dateText)
        }
    }

    // MARK: Данные

    /// Начало первого текста ленты: эссе или текстовый блок.
    private var excerpt: String? {
        var found: String?
        for block in blocks.sorted(by: { $0.order < $1.order }) {
            switch block.kind {
            case .essay:
                if let essay = survey?.essay, !essay.isEmpty { found = essay }
            case .text:
                if !block.text.isEmpty { found = block.text }
            default: break
            }
            if found != nil { break }
        }
        if found == nil, let essay = survey?.essay, !essay.isEmpty { found = essay }
        // сплошным текстом: переносы и пустые строки — в пробелы
        return found.map { $0.split(whereSeparator: { $0.isWhitespace || $0.isNewline }).joined(separator: " ") }
    }

    private var photos: [JournalPhoto] {
        blocks.sorted { $0.order < $1.order }
            .filter { $0.kind == .photo }
            .flatMap(\.sortedPhotos)
    }

    private var chips: [String] {
        func count(_ kinds: [JournalKind]) -> Int { blocks.filter { kinds.contains($0.kind) }.count }
        let hasEssay = !(survey?.essay.isEmpty ?? true)
        let texts = blocks.filter { $0.kind == .text }.count + (hasEssay ? 1 : 0)
        var result: [String] = []
        if texts > 0 {
            result.append(texts == 1 && hasEssay ? "эссе" : "\(texts) \(TasteProfile.plural(texts, "текст", "текста", "текстов"))")
        }
        if !photos.isEmpty { result.append("\(photos.count) фото") }
        let quotes = count([.quote])
        if quotes > 0 { result.append(quotes == 1 ? "цитата" : "\(quotes) \(TasteProfile.plural(quotes, "цитата", "цитаты", "цитат"))") }
        let facts = count([.fact])
        if facts > 0 { result.append(facts == 1 ? "факт" : "\(facts) \(TasteProfile.plural(facts, "факт", "факта", "фактов"))") }
        let boards = count([.board])
        if boards > 0 { result.append(boards == 1 ? "доска" : "\(boards) \(TasteProfile.plural(boards, "доска", "доски", "досок"))") }
        return result
    }

    private var dateText: String {
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "ru_RU")
        let sameYear = Calendar.current.isDate(seenAt, equalTo: Date(), toGranularity: .year)
        formatter.dateFormat = sameYear ? "d MMMM" : "d MMMM yyyy"
        return formatter.string(from: seenAt)
    }
}
