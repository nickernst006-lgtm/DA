import SwiftUI

/// Иконка архетипа в плитке со скруглёнными углами — как маленькое приложение.
struct ArchetypeTile: View {
    let archetype: Archetype
    var size: CGFloat = 64

    var body: some View {
        Image(archetype.iconAsset)
            .renderingMode(.template)
            .resizable()
            .scaledToFit()
            .frame(width: size * 0.56, height: size * 0.56)
            .foregroundStyle(archetype.color)
            .frame(width: size, height: size)
            .background(
                RoundedRectangle(cornerRadius: size >= 56 ? Radius.medium : Radius.small, style: .continuous)
                    .fill(Theme.surfaceRaised)
            )
            .accessibilityHidden(true)
    }
}

/// Архетипы фильма внизу карточки — плитками во всю ширину страницы, без заголовка.
/// Нажатие — описание архетипа.
struct ArchetypeBadges: View {
    let archetypes: [Archetype]
    @State private var selected: Archetype?

    var body: some View {
        HStack(spacing: Space.s12) {
            ForEach(archetypes) { archetype in
                Button {
                    selected = archetype
                } label: {
                    VStack(spacing: Space.s8) {
                        Image(archetype.iconAsset)
                            .renderingMode(.template)
                            .resizable()
                            .scaledToFit()
                            .frame(width: 40, height: 40)
                            .foregroundStyle(archetype.color)
                            .accessibilityHidden(true)
                        Text(archetype.title)
                            .textStyle(.caption, .bold)
                            .foregroundStyle(Theme.textSecondary)
                            .lineLimit(1)
                            .minimumScaleFactor(0.8)
                    }
                    .frame(maxWidth: .infinity)
                    .frame(height: 112)
                    .background(RoundedRectangle(cornerRadius: Radius.large, style: .continuous).fill(Theme.surface))
                    .contentShape(RoundedRectangle(cornerRadius: Radius.large, style: .continuous))
                }
                .buttonStyle(.plain)
                .accessibilityLabel("Архетип: \(archetype.title)")
                .accessibilityHint("Показать описание")
            }
        }
        .sheet(item: $selected) { archetype in
            ArchetypeInfoSheet(archetype: archetype)
                .presentationDetents([.medium])
        }
    }
}

/// Описание архетипа.
struct ArchetypeInfoSheet: View {
    let archetype: Archetype
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        VStack(alignment: .leading, spacing: Space.s16) {
            HStack {
                Spacer()
                CloseButton { dismiss() }
            }
            ArchetypeTile(archetype: archetype, size: 72)
            VStack(alignment: .leading, spacing: Space.s8) {
                Text(archetype.title)
                    .textStyle(.h1)
                    .foregroundStyle(Theme.text)
                Text("«\(archetype.motto)»")
                    .textStyle(.sub, .medium)
                    .foregroundStyle(Theme.accent)
            }
            Text(archetype.description)
                .textStyle(.body)
                .foregroundStyle(Theme.textSecondary)
                .fixedSize(horizontal: false, vertical: true)
            Spacer(minLength: 0)
        }
        .padding(Space.s20)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Theme.background.ignoresSafeArea())
        .presentationBackground(Theme.background)
    }
}
