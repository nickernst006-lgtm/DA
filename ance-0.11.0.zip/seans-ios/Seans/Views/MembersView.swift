import SwiftUI
import UIKit
import CoreText

/// Вкладка «Друзья»: все участники ance — без кодов и приглашений.
/// Аккаунты создаёт владелец на сервере; новый участник появляется здесь сам.
/// Пока имя не задано — «Участник N».
struct FriendsView: View {
    @Environment(Server.self) private var server

    @State private var profiles: [Profile] = []
    @State private var loaded = false
    @State private var failed = false
    @State private var myName = ""
    @State private var savedName = ""
    @State private var savingName = false
    @State private var libraryCount: Int?
    @State private var confirmSignOut = false
    @FocusState private var nameFocused: Bool

    private var me: Profile? { profiles.first { $0.id == server.userID } }
    private var others: [Profile] { profiles.filter { $0.id != server.userID } }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: Space.s32) {
                VStack(alignment: .leading, spacing: ScreenLayout.titleGap) {
                    ScreenTitle("Друзья")
                        .padding(.top, Space.s12)
                    meCard
                }
                membersSection
            }
            .padding(.horizontal, Space.s20)
            .padding(.bottom, Space.s32)
        }
        .dockClearance()
        .scrollDismissesKeyboard(.interactively)
        .background(Theme.background.ignoresSafeArea())
        .refreshable { await load() }
        .task { if !loaded { await load() } }
        .confirmationDialog("Выйти из аккаунта?", isPresented: $confirmSignOut, titleVisibility: .visible) {
            Button("Выйти", role: .destructive) { server.signOut() }
            Button("Отмена", role: .cancel) {}
        } message: {
            Text("Коллекция и журналы останутся на телефоне. Чтобы вернуться, понадобятся почта и пароль.")
        }
    }

    // MARK: Вы

    private var meCard: some View {
        VStack(alignment: .leading, spacing: 0) {
            HStack(alignment: .center, spacing: Space.s12) {
                MemberAvatar(name: myName, number: 1, isMe: true)
                VStack(alignment: .leading, spacing: 0) {
                    TextField("", text: $myName, prompt: Text("Ваше имя").foregroundColor(Theme.muted))
                        .font(Font(AppFont.uiFont(.h3) as CTFont))
                        .foregroundStyle(Theme.text)
                        .submitLabel(.done)
                        .focused($nameFocused)
                        .onSubmit { Task { await saveName() } }
                    Text(server.email ?? "")
                        .textStyle(.caption)
                        .foregroundStyle(Theme.muted)
                        .lineLimit(1)
                }
                Spacer(minLength: 0)
                if savingName {
                    ProgressView().tint(Theme.muted)
                } else if nameFocused || myName != savedName {
                    Button("Готово") {
                        nameFocused = false
                        Task { await saveName() }
                    }
                    .textStyle(.sub, .medium)
                    .foregroundStyle(Theme.accent)
                    .touchArea()
                }
            }

            Text(statusLine)
                .textStyle(.sub)
                .foregroundStyle(failed ? Theme.accent : Theme.textSecondary)
                .fixedSize(horizontal: false, vertical: true)
                .padding(.top, Space.s16)

            Button("Выйти из аккаунта") { confirmSignOut = true }
                .buttonStyle(SecondaryButtonStyle())
                .padding(.top, Space.s16)
        }
        .padding(ScreenLayout.cardPadding)
        .background(RoundedRectangle(cornerRadius: Radius.large, style: .continuous).fill(Theme.surface))
    }

    private var statusLine: String {
        if failed { return "Нет связи с сервером — показываю то, что есть на телефоне." }
        guard let libraryCount else { return "Подключаюсь к серверу…" }
        let films = TasteProfile.plural(libraryCount, "фильм", "фильма", "фильмов")
        return "Сервер на связи · в библиотеке \(libraryCount.formatted()) \(films)"
    }

    // MARK: Участники

    private var membersSection: some View {
        VStack(alignment: .leading, spacing: Space.s16) {
            SectionTitle("Участники")
            if loaded && others.isEmpty {
                Text("Пока здесь только вы. Когда владелец создаст аккаунты друзьям, они появятся здесь сами.")
                    .textStyle(.sub)
                    .foregroundStyle(Theme.muted)
                    .fixedSize(horizontal: false, vertical: true)
            } else {
                VStack(spacing: Space.s8) {
                    ForEach(others) { profile in
                        memberRow(profile)
                    }
                }
            }
        }
    }

    private func number(of profile: Profile) -> Int {
        (profiles.firstIndex { $0.id == profile.id } ?? 0) + 1
    }

    private func displayName(_ profile: Profile) -> String {
        let name = profile.name.trimmingCharacters(in: .whitespacesAndNewlines)
        return name.isEmpty ? "Участник \(number(of: profile))" : name
    }

    private func memberRow(_ profile: Profile) -> some View {
        let named = !profile.name.trimmingCharacters(in: .whitespaces).isEmpty
        return HStack(spacing: Space.s12) {
            MemberAvatar(name: profile.name, number: number(of: profile), isMe: false)
            VStack(alignment: .leading, spacing: Space.s4) {
                Text(displayName(profile))
                    .textStyle(.body, .bold)
                    .foregroundStyle(named ? Theme.text : Theme.textSecondary)
                Text(named ? "Скоро здесь будут коллекция и журналы" : "Аккаунт ещё никому не отдан")
                    .textStyle(.caption)
                    .foregroundStyle(Theme.muted)
            }
            Spacer(minLength: 0)
        }
        .padding(Space.s16)
        .background(RoundedRectangle(cornerRadius: Radius.large, style: .continuous).fill(Theme.surface))
        .accessibilityElement(children: .combine)
    }

    // MARK: Загрузка

    private func load() async {
        do {
            let list = try await server.profiles()
            profiles = list
            failed = false
            if !nameFocused {
                myName = list.first { $0.id == server.userID }?.name ?? ""
                savedName = myName
            }
            libraryCount = try? await server.libraryCount()
        } catch {
            failed = true
        }
        loaded = true
    }

    private func saveName() async {
        let name = myName.trimmingCharacters(in: .whitespacesAndNewlines)
        guard name != savedName, !savingName else { return }
        savingName = true
        defer { savingName = false }
        do {
            try await server.setMyName(name)
            myName = name
            savedName = name
        } catch {
            failed = true
        }
    }
}

/// Кружок участника: первая буква имени или номер, если имени ещё нет.
private struct MemberAvatar: View {
    let name: String
    let number: Int
    let isMe: Bool

    private var letter: String {
        let trimmed = name.trimmingCharacters(in: .whitespacesAndNewlines)
        return trimmed.first.map { String($0).uppercased() } ?? "\(number)"
    }

    var body: some View {
        Text(letter)
            .textStyle(.body, .bold)
            .foregroundStyle(isMe ? Color.black : Theme.text)
            .frame(width: Space.s48, height: Space.s48)
            .background(Circle().fill(isMe ? Theme.accent : Theme.surfaceRaised))
            .accessibilityHidden(true)
    }
}
