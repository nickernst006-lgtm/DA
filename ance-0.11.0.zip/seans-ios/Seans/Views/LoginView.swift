import SwiftUI
import UIKit
import CoreText

/// Вход в ance: почта и пароль. Регистрации нет — аккаунты выдаёт владелец.
struct LoginView: View {
    @Environment(Server.self) private var server

    @State private var email = ""
    @State private var password = ""
    @State private var error: String?
    @State private var busy = false
    @State private var showServerSettings = false
    @FocusState private var focus: Field?

    private enum Field { case email, password }

    private var canSubmit: Bool {
        email.contains("@") && !password.isEmpty && !busy
    }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 0) {
                AnceLogo(size: 64)
                    .frame(maxWidth: .infinity)
                    .padding(.top, Space.s48 + Space.s32)
                    .padding(.bottom, Space.s48)

                Text("Вход")
                    .textStyle(.h1)
                    .foregroundStyle(Theme.text)
                    .padding(.bottom, Space.s8)
                Text("Аккаунты в ance выдаёт владелец. Если у вас его ещё нет — попросите почту и пароль.")
                    .textStyle(.sub)
                    .foregroundStyle(Theme.muted)
                    .fixedSize(horizontal: false, vertical: true)
                    .padding(.bottom, Space.s24)

                VStack(spacing: Space.s12) {
                    field {
                        TextField("", text: $email, prompt: Text("Почта").foregroundColor(Theme.muted))
                            .keyboardType(.emailAddress)
                            .textContentType(.username)
                            .textInputAutocapitalization(.never)
                            .autocorrectionDisabled()
                            .submitLabel(.next)
                            .focused($focus, equals: .email)
                            .onSubmit { focus = .password }
                    }
                    field {
                        SecureField("", text: $password, prompt: Text("Пароль").foregroundColor(Theme.muted))
                            .textContentType(.password)
                            .submitLabel(.go)
                            .focused($focus, equals: .password)
                            .onSubmit { submit() }
                    }
                }

                if let error {
                    Text(error)
                        .textStyle(.sub)
                        .foregroundStyle(Theme.accent)
                        .fixedSize(horizontal: false, vertical: true)
                        .padding(.top, Space.s12)
                }

                Button {
                    submit()
                } label: {
                    if busy {
                        ProgressView().tint(Color.black)
                    } else {
                        Text("Войти")
                    }
                }
                .buttonStyle(PrimaryButtonStyle())
                .disabled(!canSubmit)
                .opacity(canSubmit || busy ? 1 : 0.5)
                .padding(.top, Space.s24)

                Button("Настройки сервера") { showServerSettings = true }
                    .textStyle(.sub, .medium)
                    .foregroundStyle(Theme.muted)
                    .frame(maxWidth: .infinity)
                    .touchArea()
                    .padding(.top, Space.s24)
            }
            .padding(.horizontal, Space.s20)
            .padding(.bottom, Space.s32)
        }
        .scrollDismissesKeyboard(.interactively)
        .background(Theme.background.ignoresSafeArea())
        .sheet(isPresented: $showServerSettings) {
            ServerSettingsView()
                .presentationDetents([.medium, .large])
        }
        .onAppear {
            if server.config == nil { error = ServerError.notConfigured.errorDescription }
        }
    }

    private func field<Content: View>(@ViewBuilder _ content: () -> Content) -> some View {
        content()
            .font(Font(AppFont.uiFont(.body) as CTFont))
            .foregroundStyle(Theme.text)
            .padding(.horizontal, Space.s16)
            .frame(height: Space.s48)
            .background(Capsule().fill(Theme.surface))
    }

    private func submit() {
        guard canSubmit else { return }
        busy = true
        error = nil
        focus = nil
        Task {
            do {
                try await server.signIn(email: email, password: password)
            } catch {
                self.error = (error as? LocalizedError)?.errorDescription ?? error.localizedDescription
            }
            busy = false
        }
    }
}

/// Адрес сервера и публичный ключ. Обычно вшиты в приложение при сборке;
/// здесь их можно заменить — например, если адрес заблокировали и сервер переехал.
struct ServerSettingsView: View {
    @Environment(Server.self) private var server
    @Environment(\.dismiss) private var dismiss

    @State private var url = ""
    @State private var key = ""

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: Space.s12) {
                Text("Настройки сервера")
                    .textStyle(.h2)
                    .foregroundStyle(Theme.text)
                    .padding(.top, Space.s32)
                Text(ServerConfig.bundledValues().url.isEmpty
                     ? "В эту сборку адрес не вшит. Введите адрес проекта Supabase и публичный ключ (publishable или anon)."
                     : "Адрес уже вшит в приложение. Меняйте, только если сервер переехал. Пустые поля — вернуть вшитый.")
                    .textStyle(.sub)
                    .foregroundStyle(Theme.muted)
                    .fixedSize(horizontal: false, vertical: true)
                    .padding(.bottom, Space.s12)

                input("https://xxxx.supabase.co", text: $url)
                    .keyboardType(.URL)
                input("Публичный ключ", text: $key)

                Button("Сохранить") {
                    if url.trimmingCharacters(in: .whitespaces).isEmpty {
                        ServerConfig.clearManual()
                    } else {
                        ServerConfig.saveManual(url: url, key: key)
                    }
                    server.reloadConfig()
                    dismiss()
                }
                .buttonStyle(PrimaryButtonStyle())
                .padding(.top, Space.s12)
            }
            .padding(.horizontal, Space.s20)
            .padding(.bottom, Space.s32)
        }
        .background(Theme.surface.ignoresSafeArea())
        .presentationBackground(Theme.surface)
        .onAppear {
            url = UserDefaults.standard.string(forKey: ServerConfig.manualURLKey) ?? ""
            key = UserDefaults.standard.string(forKey: ServerConfig.manualKeyKey) ?? ""
        }
    }

    private func input(_ placeholder: String, text: Binding<String>) -> some View {
        TextField("", text: text, prompt: Text(placeholder).foregroundColor(Theme.muted))
            .textInputAutocapitalization(.never)
            .autocorrectionDisabled()
            .font(Font(AppFont.uiFont(.body) as CTFont))
            .foregroundStyle(Theme.text)
            .padding(.horizontal, Space.s16)
            .frame(height: Space.s48)
            .background(Capsule().fill(Theme.surfaceRaised))
    }
}
