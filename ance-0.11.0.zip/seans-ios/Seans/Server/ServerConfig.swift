import Foundation
import Security

/// Адрес сервера и публичный ключ приложения.
/// Вшиваются при сборке (файл server.json, его пишет GitHub из секретов),
/// но их можно заменить вручную на экране входа — например, если адрес заблокировали.
struct ServerConfig: Equatable {
    var url: URL
    var key: String

    static let manualURLKey = "serverURLManual"
    static let manualKeyKey = "serverKeyManual"

    /// Сначала то, что введено вручную, затем вшитое при сборке.
    static func current() -> ServerConfig? {
        let defaults = UserDefaults.standard
        let manualURL = (defaults.string(forKey: manualURLKey) ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
        let manualKey = (defaults.string(forKey: manualKeyKey) ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
        let bundled = bundledValues()
        let urlString = manualURL.isEmpty ? bundled.url : manualURL
        let key = manualKey.isEmpty ? bundled.key : manualKey
        guard let url = normalize(urlString), !key.isEmpty else { return nil }
        return ServerConfig(url: url, key: key)
    }

    /// Значения из server.json внутри приложения.
    static func bundledValues() -> (url: String, key: String) {
        guard let file = Bundle.main.url(forResource: "server", withExtension: "json"),
              let data = try? Data(contentsOf: file),
              let object = try? JSONSerialization.jsonObject(with: data),
              let dict = object as? [String: Any] else { return ("", "") }
        let url = (dict["url"] as? String ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
        let key = (dict["key"] as? String ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
        return (url, key)
    }

    static var hasManual: Bool {
        !(UserDefaults.standard.string(forKey: manualURLKey) ?? "").isEmpty
    }

    static func saveManual(url: String, key: String) {
        UserDefaults.standard.set(url.trimmingCharacters(in: .whitespacesAndNewlines), forKey: manualURLKey)
        UserDefaults.standard.set(key.trimmingCharacters(in: .whitespacesAndNewlines), forKey: manualKeyKey)
    }

    static func clearManual() {
        UserDefaults.standard.removeObject(forKey: manualURLKey)
        UserDefaults.standard.removeObject(forKey: manualKeyKey)
    }

    /// Только схема и адрес: хвосты вроде /rest/v1/ отбрасываются.
    static func normalize(_ string: String) -> URL? {
        var text = string.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !text.isEmpty else { return nil }
        if !text.contains("://") { text = "https://" + text }
        guard let parts = URLComponents(string: text), let host = parts.host, !host.isEmpty else { return nil }
        var clean = URLComponents()
        clean.scheme = parts.scheme ?? "https"
        clean.host = host
        clean.port = parts.port
        return clean.url
    }
}

/// Связка ключей iOS — здесь хранится вход, чтобы не вводить пароль при каждом запуске.
/// Если связка недоступна (так бывает у приложений, установленных в обход App Store),
/// вход хранится в настройках приложения.
enum Keychain {
    private static let service = "ance"

    private static func baseQuery(_ key: String) -> [String: Any] {
        [kSecClass as String: kSecClassGenericPassword,
         kSecAttrService as String: service,
         kSecAttrAccount as String: key]
    }

    static func save(_ data: Data, for key: String) {
        SecItemDelete(baseQuery(key) as CFDictionary)
        var add = baseQuery(key)
        add[kSecValueData as String] = data
        add[kSecAttrAccessible as String] = kSecAttrAccessibleAfterFirstUnlock
        let status = SecItemAdd(add as CFDictionary, nil)
        if status == errSecSuccess {
            UserDefaults.standard.removeObject(forKey: "fallback." + key)
        } else {
            UserDefaults.standard.set(data, forKey: "fallback." + key)
        }
    }

    static func load(_ key: String) -> Data? {
        var query = baseQuery(key)
        query[kSecReturnData as String] = true
        query[kSecMatchLimit as String] = kSecMatchLimitOne
        var result: AnyObject?
        if SecItemCopyMatching(query as CFDictionary, &result) == errSecSuccess, let data = result as? Data {
            return data
        }
        return UserDefaults.standard.data(forKey: "fallback." + key)
    }

    static func delete(_ key: String) {
        SecItemDelete(baseQuery(key) as CFDictionary)
        UserDefaults.standard.removeObject(forKey: "fallback." + key)
    }
}
