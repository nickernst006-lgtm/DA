import Foundation
import Observation

/// Вход в аккаунт: хранится в связке ключей, обновляется сам.
struct AuthSession: Codable, Equatable {
    var accessToken: String
    var refreshToken: String
    var expiresAt: Date
    var userID: String
    var email: String
}

enum ServerError: LocalizedError {
    case notConfigured
    case wrongCredentials
    case offline
    case sessionExpired
    case http(Int, String)

    var errorDescription: String? {
        switch self {
        case .notConfigured:
            return "Не задан адрес сервера. Откройте «Настройки сервера» внизу экрана."
        case .wrongCredentials:
            return "Неверная почта или пароль."
        case .offline:
            return "Нет связи с сервером. Проверьте интернет — или адрес сервера, если его заблокировали."
        case .sessionExpired:
            return "Вход устарел. Войдите ещё раз."
        case .http(let code, _):
            return "Сервер ответил ошибкой \(code). Попробуйте позже."
        }
    }
}

/// Участник ance — одна из комнат в «квартире».
struct Profile: Codable, Identifiable, Hashable {
    let id: String
    var name: String
    var shareCollection: Bool
    var shareJournal: Bool
    let createdAt: String?
}

/// Связь с сервером ance (Supabase): вход по почте и паролю и запросы к базе.
/// Работает через обычный REST — без сторонних библиотек.
@MainActor
@Observable
final class Server {
    private(set) var session: AuthSession?
    private(set) var config: ServerConfig?
    /// Удалось ли последнее обращение к серверу.
    private(set) var isReachable = true

    @ObservationIgnored private var refreshTask: Task<Void, Error>?
    private let urlSession: URLSession

    private static let sessionKey = "session"

    static let decoder: JSONDecoder = {
        let decoder = JSONDecoder()
        decoder.keyDecodingStrategy = .convertFromSnakeCase
        return decoder
    }()

    init() {
        let configuration = URLSessionConfiguration.default
        configuration.timeoutIntervalForRequest = 20
        configuration.timeoutIntervalForResource = 60
        urlSession = URLSession(configuration: configuration)
        config = ServerConfig.current()
        if let data = Keychain.load(Server.sessionKey),
           let saved = try? JSONDecoder().decode(AuthSession.self, from: data) {
            session = saved
        }
    }

    var isSignedIn: Bool { session != nil }
    var userID: String? { session?.userID }
    var email: String? { session?.email }

    /// Перечитать адрес и ключ (после изменения в «Настройках сервера»).
    func reloadConfig() {
        config = ServerConfig.current()
    }

    // MARK: Вход и выход

    func signIn(email: String, password: String) async throws {
        let cleanEmail = email.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        let (data, _) = try await perform("auth/v1/token",
                                          query: [URLQueryItem(name: "grant_type", value: "password")],
                                          method: "POST",
                                          json: ["email": cleanEmail, "password": password],
                                          token: nil)
        try store(data, fallbackEmail: cleanEmail)
    }

    func signOut() {
        let token = session?.accessToken
        session = nil
        Keychain.delete(Server.sessionKey)
        // Сообщаем серверу, что вход больше не нужен; ответ не важен.
        if let token {
            Task { _ = try? await self.perform("auth/v1/logout", method: "POST", json: nil, token: token) }
        }
    }

    private struct TokenUser: Decodable {
        let id: String
        let email: String?
    }

    private struct TokenResponse: Decodable {
        let accessToken: String
        let refreshToken: String
        let expiresIn: Double?
        let expiresAt: Double?
        let user: TokenUser?
    }

    private func store(_ data: Data, fallbackEmail: String) throws {
        let response = try Server.decoder.decode(TokenResponse.self, from: data)
        let expires = response.expiresAt.map { Date(timeIntervalSince1970: $0) }
            ?? Date().addingTimeInterval(response.expiresIn ?? 3600)
        let new = AuthSession(accessToken: response.accessToken,
                              refreshToken: response.refreshToken,
                              expiresAt: expires,
                              userID: response.user?.id ?? session?.userID ?? "",
                              email: response.user?.email ?? fallbackEmail)
        session = new
        if let encoded = try? JSONEncoder().encode(new) {
            Keychain.save(encoded, for: Server.sessionKey)
        }
    }

    /// Обновить вход. Если сразу несколько запросов увидели, что вход устарел, обновляем один раз.
    private func refresh() async throws {
        if let running = refreshTask {
            try await running.value
            return
        }
        let task = Task { try await self.performRefresh() }
        refreshTask = task
        defer { refreshTask = nil }
        try await task.value
    }

    private func performRefresh() async throws {
        guard let current = session else { throw ServerError.sessionExpired }
        do {
            let (data, _) = try await perform("auth/v1/token",
                                              query: [URLQueryItem(name: "grant_type", value: "refresh_token")],
                                              method: "POST",
                                              json: ["refresh_token": current.refreshToken],
                                              token: nil)
            try store(data, fallbackEmail: current.email)
        } catch ServerError.wrongCredentials {
            // Вход отозван (например, аккаунт удалён) — просим войти заново.
            signOut()
            throw ServerError.sessionExpired
        }
    }

    // MARK: Запросы

    private func makeRequest(_ config: ServerConfig, path: String, query: [URLQueryItem], method: String,
                             json: Any?, token: String?, headers: [String: String]) throws -> URLRequest {
        guard var parts = URLComponents(url: config.url.appendingPathComponent(path), resolvingAgainstBaseURL: false) else {
            throw ServerError.notConfigured
        }
        if !query.isEmpty { parts.queryItems = query }
        guard let url = parts.url else { throw ServerError.notConfigured }
        var request = URLRequest(url: url)
        request.httpMethod = method
        request.setValue(config.key, forHTTPHeaderField: "apikey")
        if let token {
            request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        } else if config.key.hasPrefix("eyJ") {
            // Старый ключ anon — это JWT, его передают и как Bearer.
            request.setValue("Bearer \(config.key)", forHTTPHeaderField: "Authorization")
        }
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        for (name, value) in headers { request.setValue(value, forHTTPHeaderField: name) }
        if let json {
            request.httpBody = try JSONSerialization.data(withJSONObject: json)
            request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        }
        return request
    }

    private func perform(_ path: String, query: [URLQueryItem] = [], method: String = "GET", json: Any? = nil,
                         token: String?, headers: [String: String] = [:]) async throws -> (Data, HTTPURLResponse) {
        guard let config else { throw ServerError.notConfigured }
        let request = try makeRequest(config, path: path, query: query, method: method,
                                      json: json, token: token, headers: headers)
        let result: (Data, URLResponse)
        do {
            result = try await urlSession.data(for: request)
        } catch {
            isReachable = false
            throw ServerError.offline
        }
        isReachable = true
        let data = result.0
        guard let http = result.1 as? HTTPURLResponse else { throw ServerError.http(0, "") }
        guard (200..<300).contains(http.statusCode) else {
            let text = String(data: data, encoding: .utf8) ?? ""
            if path == "auth/v1/token" && (http.statusCode == 400 || http.statusCode == 401) {
                throw ServerError.wrongCredentials
            }
            throw ServerError.http(http.statusCode, text)
        }
        return (data, http)
    }

    /// Запрос от имени вошедшего: вход обновляется сам, когда устаревает.
    private func authorized(_ path: String, query: [URLQueryItem] = [], method: String = "GET",
                            json: Any? = nil, headers: [String: String] = [:]) async throws -> (Data, HTTPURLResponse) {
        guard let current = session else { throw ServerError.sessionExpired }
        if current.expiresAt.timeIntervalSinceNow < 60 {
            try await refresh()
        }
        do {
            return try await perform(path, query: query, method: method, json: json,
                                     token: session?.accessToken, headers: headers)
        } catch ServerError.http(let code, _) where code == 401 {
            try await refresh()
            return try await perform(path, query: query, method: method, json: json,
                                     token: session?.accessToken, headers: headers)
        }
    }

    /// Функция базы (RPC).
    func rpc<T: Decodable>(_ name: String, _ params: [String: Any] = [:]) async throws -> T {
        let (data, _) = try await authorized("rest/v1/rpc/\(name)", method: "POST", json: params)
        return try Server.decoder.decode(T.self, from: data)
    }

    /// Чтение таблицы: фильтры в формате PostgREST (id=eq.5, order=created_at.asc).
    func select<T: Decodable>(_ table: String, _ query: [URLQueryItem]) async throws -> T {
        let (data, _) = try await authorized("rest/v1/\(table)", query: query)
        return try Server.decoder.decode(T.self, from: data)
    }

    func update(_ table: String, match: [URLQueryItem], values: [String: Any]) async throws {
        _ = try await authorized("rest/v1/\(table)", query: match, method: "PATCH",
                                 json: values, headers: ["Prefer": "return=minimal"])
    }

    /// Сколько строк в таблице (видимых вошедшему).
    func count(_ table: String) async throws -> Int {
        let (_, response) = try await authorized("rest/v1/\(table)",
                                                 query: [URLQueryItem(name: "select", value: "id"),
                                                         URLQueryItem(name: "limit", value: "1")],
                                                 headers: ["Prefer": "count=exact"])
        let range = response.value(forHTTPHeaderField: "Content-Range") ?? ""
        return Int(range.split(separator: "/").last.map(String.init) ?? "") ?? 0
    }
}

// MARK: - Библиотека и участники

extension Server {
    func searchFilms(_ text: String, limit: Int = 80) async throws -> [ServerFilm] {
        try await rpc("search_films", ["q": text, "lim": limit])
    }

    /// Случайные известные фильмы.
    func randomFilms(limit: Int = 60, minVotes: Int = 20000) async throws -> [ServerFilm] {
        try await rpc("random_films", ["lim": limit, "min_votes": minVotes])
    }

    func libraryCount() async throws -> Int {
        try await count("films")
    }

    /// Все участники: свой профиль и профили друзей.
    func profiles() async throws -> [Profile] {
        try await select("profiles", [URLQueryItem(name: "select", value: "*"),
                                      URLQueryItem(name: "order", value: "created_at.asc")])
    }

    func setMyName(_ name: String) async throws {
        guard let id = userID else { throw ServerError.sessionExpired }
        try await update("profiles", match: [URLQueryItem(name: "id", value: "eq.\(id)")], values: ["name": name])
    }
}
