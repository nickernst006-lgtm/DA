import SwiftUI

// Вкладка «История» (ТЗ, раздел 5.2). Записи сгруппированы по дням,
// новые сверху; нажатие открывает подробности «было → стало».
// Записи нельзя удалить или изменить — только полный сброс.

nonisolated struct HistoryRoute: Hashable {
    let id: UUID
}

/// День истории: подзаголовок и записи этого дня
nonisolated struct HistoryDay: Identifiable {
    let id: String          // «2026-09-26»
    let events: [HistoryEvent]
}

extension AppData {
    /// Записи истории по дням, новые сверху — одним проходом после сортировки
    func historyDays(matching query: String = "") -> [HistoryDay] {
        let q = query.trimmingCharacters(in: .whitespacesAndNewlines)
        let sorted: [HistoryEvent] = history.sorted { $0.date > $1.date }
        var days: [HistoryDay] = []
        var currentKey = ""
        var bucket: [HistoryEvent] = []
        for event in sorted {
            if !q.isEmpty {
                var pieces: [String] = [event.actionTitle, event.object, event.summary]
                for d in event.details {
                    pieces.append(d.field)
                    if let old = d.old { pieces.append(old) }
                    if let new = d.new { pieces.append(new) }
                }
                let text: String = pieces.joined(separator: " ")
                if !text.localizedCaseInsensitiveContains(q) { continue }
            }
            let key = DateFmt.dayString(event.date)
            if key != currentKey {
                if !bucket.isEmpty { days.append(HistoryDay(id: currentKey, events: bucket)) }
                currentKey = key
                bucket = []
            }
            bucket.append(event)
        }
        if !bucket.isEmpty { days.append(HistoryDay(id: currentKey, events: bucket)) }
        return days
    }

    func historyEvent(_ id: UUID) -> HistoryEvent? {
        for e in history where e.id == id { return e }
        return nil
    }
}

struct HistoryView: View {
    @EnvironmentObject var appState: AppState
    @State private var query = ""

    var body: some View {
        let days = appState.data.historyDays(matching: query)
        List {
            Section {
                ScreenHeader(title: "История")
            }
            .plainRow()

            if !appState.data.history.isEmpty {
                Section {
                    SearchField(text: $query, prompt: "Поиск по истории")
                }
                .plainRow()
            }

            if days.isEmpty {
                Section {
                    if appState.data.history.isEmpty {
                        EmptyStateRow(symbol: "clock.arrow.circlepath",
                                      title: "Изменений пока нет",
                                      text: "Каждое действие с документами будет записано здесь с датой и подробностями.")
                            .accessibilityIdentifier("historyEmpty")
                    } else {
                        EmptyStateRow(symbol: "magnifyingglass", title: "Ничего не найдено",
                                      text: "Попробуйте другой запрос.")
                    }
                }
                .plainRow()
            } else {
                ForEach(days) { day in
                    Section(header: SectionTitle(DateFmt.display(day.id))) {
                        ForEach(day.events) { event in
                            NavigationLink(value: HistoryRoute(id: event.id)) {
                                HistoryRow(event: event)
                            }
                            .accessibilityIdentifier("historyRow")
                        }
                    }
                }
            }
        }
        .themedScreen()
        .navigationDestination(for: HistoryRoute.self) { route in
            HistoryDetailView(eventId: route.id)
        }
    }
}

struct HistoryRow: View {
    let event: HistoryEvent

    var body: some View {
        HStack(spacing: Theme.gap) {
            IconBadge(symbol: event.actionSymbol, color: event.actionColor)
            DirectoryRow(name: event.actionTitle, note: event.object, detail: DateFmt.timeString(event.date))
        }
    }
}

struct HistoryDetailView: View {
    @EnvironmentObject var appState: AppState
    let eventId: UUID

    var body: some View {
        List {
            if let event = appState.data.historyEvent(eventId) {
                Section {
                    IconRow(title: event.actionTitle, symbol: event.actionSymbol, color: event.actionColor)
                    DirectoryRow(name: "Когда", detail: DateFmt.stamp(event.date))
                    VStack(alignment: .leading, spacing: 2) {
                        Text("Объект").font(Theme.caption).foregroundStyle(.secondary)
                        Text(event.object).font(Theme.body)
                    }
                    if !event.summary.isEmpty {
                        Text(event.summary).font(Theme.body)
                    }
                }

                if !event.details.isEmpty {
                    Section(header: SectionTitle("Подробности")) {
                        ForEach(Array(event.details.enumerated()), id: \.offset) { item in
                            DetailChangeRow(detail: item.element)
                        }
                    }
                }

                if let reason = event.reason, !reason.isEmpty {
                    Section(header: SectionTitle("Причина")) {
                        Text(reason).font(Theme.body)
                    }
                }
            }
        }
        .themedList()
        .navigationTitle("Запись истории")
        .navigationBarTitleDisplayMode(.inline)
    }
}

/// Строка подробностей: поле сверху серым, ниже «было → стало»
struct DetailChangeRow: View {
    let detail: HistoryDetail

    var body: some View {
        VStack(alignment: .leading, spacing: 2) {
            Text(detail.field)
                .font(Theme.caption)
                .foregroundStyle(.secondary)
            if let old = detail.old, let new = detail.new {
                HStack(alignment: .firstTextBaseline, spacing: 6) {
                    Text(old).strikethrough().foregroundStyle(.secondary)
                    Image(systemName: "arrow.right").font(Theme.caption).foregroundStyle(.tertiary)
                    Text(new)
                }
                .font(Theme.body)
            } else if let new = detail.new {
                Text(new).font(Theme.body)
            } else if let old = detail.old {
                Text(old).font(Theme.body).strikethrough().foregroundStyle(.secondary)
            } else {
                Text("пусто").font(Theme.body).foregroundStyle(.tertiary)
            }
        }
        .textSelection(.enabled)
        .padding(.vertical, 4)
    }
}
