import SwiftUI

// Вкладка «Справочники» (ТЗ, раздел 5.4): лица и их папки, теги папок,
// именованные цвета, типы карточек (только просмотр — новые приходят
// с обновлениями; переименовать можно названия двух групп).

nonisolated enum DirectoryRoute: Hashable {
    case persons
    case person(UUID)
    case tags
    case colors
    case types
    case basicGroup
    case typedGroup
    case type(String)
}

struct DirectoriesView: View {
    @EnvironmentObject var appState: AppState

    var body: some View {
        List {
            Section {
                ScreenHeader(title: "Справочники")
            }
            .plainRow()

            Section {
                NavigationLink(value: DirectoryRoute.persons) {
                    HStack(spacing: Theme.gap) {
                        IconBadge(symbol: "person.2.fill", color: .blue)
                        DirectoryRow(name: "Лица", detail: "\(appState.data.activePersons.count)")
                    }
                }
                .accessibilityIdentifier("dir_persons")
                NavigationLink(value: DirectoryRoute.tags) {
                    HStack(spacing: Theme.gap) {
                        IconBadge(symbol: "tag.fill", color: .orange)
                        DirectoryRow(name: "Теги папок", detail: "\(appState.data.tags.count)")
                    }
                }
                .accessibilityIdentifier("dir_tags")
                NavigationLink(value: DirectoryRoute.colors) {
                    HStack(spacing: Theme.gap) {
                        IconBadge(symbol: "paintpalette.fill", color: .purple)
                        DirectoryRow(name: "Цвета папок", detail: "\(appState.data.colors.count)")
                    }
                }
                .accessibilityIdentifier("dir_colors")
                NavigationLink(value: DirectoryRoute.types) {
                    HStack(spacing: Theme.gap) {
                        IconBadge(symbol: "doc.on.doc.fill", color: .teal)
                        DirectoryRow(name: "Типы карточек", detail: "2 группы")
                    }
                }
                .accessibilityIdentifier("dir_types")
            }
        }
        .themedScreen()
        .navigationDestination(for: DirectoryRoute.self) { route in
            switch route {
            case .persons: PersonsDirectoryView()
            case .person(let id): PersonDirectoryView(personId: id)
            case .tags: TagsView()
            case .colors: ColorsView()
            case .types: TypesView()
            case .basicGroup: BasicGroupView()
            case .typedGroup: TypedGroupView()
            case .type(let id): TypeDetailView(template: CardTemplate.find(id))
            }
        }
    }
}

// MARK: - Теги

struct TagsView: View {
    @EnvironmentObject var appState: AppState
    @State private var pendingDelete: FolderTag? = nil

    var body: some View {
        List {
            if appState.data.tags.isEmpty {
                Section {
                    EmptyStateRow(symbol: "tag", title: "Тегов пока нет",
                                  text: "Теги помечают папки: «Удостоверения», «Поездки», «Работа». Добавьте первый ниже.")
                }
                .plainRow()
            } else {
                Section {
                    ForEach(appState.data.tags) { tag in
                        EditableRow(name: tag.name,
                                    onRename: { rename(tag, to: $0) },
                                    onDelete: { pendingDelete = tag })
                    }
                }
            }
            Section {
                AddRow(placeholder: "Новый тег") { add($0) }
            }
        }
        .themedList()
        .navigationTitle("Теги папок")
        .navigationBarTitleDisplayMode(.inline)
        .confirmationDialog("Удалить тег?", isPresented: Binding(
            get: { pendingDelete != nil },
            set: { if !$0 { pendingDelete = nil } }
        ), titleVisibility: .visible) {
            Button("Удалить", role: .destructive) {
                if let tag = pendingDelete { delete(tag) }
                pendingDelete = nil
            }
            Button("Отмена", role: .cancel) { pendingDelete = nil }
        } message: {
            Text("Тег снимется со всех папок. Сами папки не пострадают.")
        }
    }

    private func exists(_ name: String, except id: UUID? = nil) -> Bool {
        for tag in appState.data.tags where tag.id != id {
            if tag.name.compare(name, options: .caseInsensitive) == .orderedSame { return true }
        }
        return false
    }

    private func add(_ name: String) -> Bool {
        guard !exists(name) else { return false }
        appState.data.tags.append(FolderTag(name: name))
        appState.data.log(.directoryChanged, object: "Тег «\(name)»", summary: "Добавлен")
        appState.persist()
        return true
    }

    private func rename(_ tag: FolderTag, to name: String) {
        guard !exists(name, except: tag.id),
              let i = appState.data.tags.firstIndex(where: { $0.id == tag.id }) else { return }
        appState.data.tags[i].name = name
        appState.data.log(.directoryChanged, object: "Тег «\(name)»",
                          details: [HistoryDetail(field: "Название", old: tag.name, new: name)])
        appState.persist()
    }

    private func delete(_ tag: FolderTag) {
        appState.data.tags.removeAll { $0.id == tag.id }
        for i in appState.data.folders.indices {
            appState.data.folders[i].tagIds.removeAll { $0 == tag.id }
        }
        appState.data.log(.directoryChanged, object: "Тег «\(tag.name)»", summary: "Удалён, снят со всех папок")
        appState.persist()
    }
}

// MARK: - Цвета

struct ColorsView: View {
    @EnvironmentObject var appState: AppState
    @State private var newName = ""
    @State private var newIndex = 0
    @State private var pendingDelete: NamedColor? = nil

    var body: some View {
        List {
            if appState.data.colors.isEmpty {
                Section {
                    EmptyStateRow(symbol: "paintpalette", title: "Цветов пока нет",
                                  text: "Именованный цвет помечает папку: «Важное — красный», «Медицина — мятный».")
                }
                .plainRow()
            } else {
                Section {
                    ForEach(appState.data.colors) { named in
                        HStack(spacing: Theme.gap) {
                            IconBadge(symbol: "folder.fill", color: Theme.color(at: named.paletteIndex))
                            EditableRow(name: named.name,
                                        onRename: { rename(named, to: $0) },
                                        onDelete: { pendingDelete = named })
                        }
                    }
                }
            }

            Section {
                TextField("Название нового цвета", text: $newName)
                    .font(Theme.body)
                    .accessibilityIdentifier("newColorName")
                PaletteRow(selected: $newIndex)
                Button("Добавить цвет") { add() }
                    .font(Theme.body)
                    .disabled(newName.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
            } header: {
                SectionTitle("Новый цвет")
            }
        }
        .themedList()
        .navigationTitle("Цвета папок")
        .navigationBarTitleDisplayMode(.inline)
        .confirmationDialog("Удалить цвет?", isPresented: Binding(
            get: { pendingDelete != nil },
            set: { if !$0 { pendingDelete = nil } }
        ), titleVisibility: .visible) {
            Button("Удалить", role: .destructive) {
                if let named = pendingDelete { delete(named) }
                pendingDelete = nil
            }
            Button("Отмена", role: .cancel) { pendingDelete = nil }
        } message: {
            Text("Папки этого цвета станут серыми. Сами папки не пострадают.")
        }
    }

    private func add() {
        let name = newName.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !name.isEmpty else { return }
        appState.data.colors.append(NamedColor(name: name, paletteIndex: newIndex))
        appState.data.log(.directoryChanged, object: "Цвет «\(name)»", summary: "Добавлен")
        appState.persist()
        newName = ""
    }

    private func rename(_ named: NamedColor, to name: String) {
        guard let i = appState.data.colors.firstIndex(where: { $0.id == named.id }) else { return }
        appState.data.colors[i].name = name
        appState.data.log(.directoryChanged, object: "Цвет «\(name)»",
                          details: [HistoryDetail(field: "Название", old: named.name, new: name)])
        appState.persist()
    }

    private func delete(_ named: NamedColor) {
        appState.data.colors.removeAll { $0.id == named.id }
        for i in appState.data.folders.indices where appState.data.folders[i].colorId == named.id {
            appState.data.folders[i].colorId = nil
        }
        appState.data.log(.directoryChanged, object: "Цвет «\(named.name)»", summary: "Удалён")
        appState.persist()
    }
}

/// Ряд кружков системной палитры для выбора цвета
struct PaletteRow: View {
    @Binding var selected: Int

    var body: some View {
        HStack(spacing: 6) {
            ForEach(0..<Theme.palette.count, id: \.self) { index in
                Button {
                    selected = index
                } label: {
                    Circle()
                        .fill(Theme.color(at: index).gradient)
                        .frame(width: 26, height: 26)
                        .overlay {
                            if selected == index {
                                Image(systemName: "checkmark")
                                    .font(.system(size: 12, weight: .bold))
                                    .foregroundStyle(.white)
                            }
                        }
                }
                .buttonStyle(.plain)
                .accessibilityLabel("Цвет \(index + 1)")
                .accessibilityAddTraits(selected == index ? [.isSelected] : [])
            }
        }
        .frame(maxWidth: .infinity)
    }
}

// MARK: - Типы карточек

/// Первый уровень: две группы — базовые и типовые
struct TypesView: View {
    @EnvironmentObject var appState: AppState

    var body: some View {
        List {
            Section {
                NavigationLink(value: DirectoryRoute.basicGroup) {
                    HStack(spacing: Theme.gap) {
                        IconBadge(symbol: CardTemplate.basic.symbol, color: CardTemplate.basic.color)
                        DirectoryRow(name: appState.data.basicGroupName, detail: "без полей")
                    }
                }
                .accessibilityIdentifier("group_basic")
                NavigationLink(value: DirectoryRoute.typedGroup) {
                    HStack(spacing: Theme.gap) {
                        IconBadge(symbol: "person.text.rectangle.fill", color: .red)
                        DirectoryRow(name: appState.data.typedGroupName,
                                     detail: "\(CardTemplate.typed.count) типов")
                    }
                }
                .accessibilityIdentifier("group_typed")
            } footer: {
                Text("Новые типовые карточки появляются с обновлениями приложения. Названия групп можно изменить.")
            }
        }
        .themedList()
        .navigationTitle("Типы карточек")
        .navigationBarTitleDisplayMode(.inline)
    }
}

/// Поле названия группы: пишет в историю при изменении
struct GroupNameSection: View {
    @EnvironmentObject var appState: AppState
    let isBasic: Bool

    var body: some View {
        Section {
            NameField(initial: isBasic ? appState.data.basicGroupName : appState.data.typedGroupName,
                      placeholder: "Название группы") { rename($0) }
                .accessibilityIdentifier(isBasic ? "basicGroupName" : "typedGroupName")
        } header: {
            SectionTitle("Название группы")
        }
    }

    private func rename(_ name: String) {
        let old = isBasic ? appState.data.basicGroupName : appState.data.typedGroupName
        guard name != old else { return }
        if isBasic {
            appState.data.basicGroupTitle = name
        } else {
            appState.data.typedGroupTitle = name
        }
        appState.data.log(.directoryChanged, object: "Группа типов карточек",
                          details: [HistoryDetail(field: "Название", old: old, new: name)])
        appState.persist()
    }
}

struct BasicGroupView: View {
    @EnvironmentObject var appState: AppState

    var body: some View {
        List {
            GroupNameSection(isBasic: true)
            Section {
                DirectoryRow(name: "Название", detail: "Текст")
                DirectoryRow(name: "Лицо и папка", detail: "Выбор")
                DirectoryRow(name: "Статус", detail: "Меняется в правке")
                DirectoryRow(name: "Прикреплённые файлы", detail: "Любые")
                DirectoryRow(name: "Заметка", detail: "Текст")
            } header: {
                SectionTitle("Что есть в базовой карточке")
            } footer: {
                Text("Базовая карточка подходит для любого документа: договора, справки, чека.")
            }
        }
        .themedList()
        .navigationTitle(appState.data.basicGroupName)
        .navigationBarTitleDisplayMode(.inline)
    }
}

struct TypedGroupView: View {
    @EnvironmentObject var appState: AppState

    var body: some View {
        List {
            GroupNameSection(isBasic: false)
            Section {
                ForEach(CardTemplate.typed) { template in
                    NavigationLink(value: DirectoryRoute.type(template.id)) {
                        HStack(spacing: Theme.gap) {
                            IconBadge(symbol: template.symbol, color: template.color)
                            DirectoryRow(name: template.title, detail: Plural.fields(template.fields.count))
                        }
                    }
                }
            } header: {
                SectionTitle("Типы")
            }
        }
        .themedList()
        .navigationTitle(appState.data.typedGroupName)
        .navigationBarTitleDisplayMode(.inline)
    }
}

struct TypeDetailView: View {
    let template: CardTemplate

    var body: some View {
        List {
            Section {
                IconRow(title: template.title, symbol: template.symbol, color: template.color)
            }
            Section {
                DirectoryRow(name: "Название", detail: "Текст")
                DirectoryRow(name: "Лицо и папка", detail: "Выбор")
                DirectoryRow(name: "Статус", detail: "Меняется в правке")
                DirectoryRow(name: "Прикреплённые файлы", detail: "Любые")
                DirectoryRow(name: "Заметка", detail: "Текст")
            } header: {
                SectionTitle("Общая часть")
            }
            if !template.fields.isEmpty {
                Section {
                    ForEach(template.fields, id: \.key) { spec in
                        DirectoryRow(name: spec.title, detail: spec.kindTitle)
                    }
                } header: {
                    SectionTitle("Поля шаблона")
                } footer: {
                    Text("Все поля необязательные: можно заполнить только номер, остальное потом.")
                }
            }
        }
        .themedList()
        .navigationTitle(template.title)
        .navigationBarTitleDisplayMode(.inline)
    }
}

// MARK: - Лица

/// Справочник лиц: здесь и только здесь лица добавляются
struct PersonsDirectoryView: View {
    @EnvironmentObject var appState: AppState

    var body: some View {
        let persons = appState.data.activePersons
        let counts = appState.data.activeFolderCounts()
        List {
            if persons.isEmpty {
                Section {
                    EmptyStateRow(symbol: "person.2", title: "Лиц пока нет",
                                  text: "Лицо — это тот, чьи документы вы храните: вы сами, члены семьи или кто угодно ещё. Добавьте первое ниже.")
                }
                .plainRow()
            } else {
                Section {
                    ForEach(persons) { person in
                        NavigationLink(value: DirectoryRoute.person(person.id)) {
                            HStack(spacing: Theme.gap) {
                                IconBadge(symbol: "person.fill", color: .blue)
                                DirectoryRow(name: person.name, detail: Plural.folders(counts[person.id] ?? 0))
                            }
                        }
                        .accessibilityIdentifier("dirPerson_\(person.name)")
                    }
                }
            }
            Section {
                AddRow(placeholder: "Новое лицо") { add($0) }
            }
        }
        .themedList()
        .navigationTitle("Лица")
        .navigationBarTitleDisplayMode(.inline)
    }

    private func add(_ name: String) -> Bool {
        for p in appState.data.activePersons where p.name.compare(name, options: .caseInsensitive) == .orderedSame {
            return false
        }
        let person = Person(name: name, order: appState.data.nextPersonOrder())
        appState.data.persons.append(person)
        appState.data.log(.personCreated, object: name)
        appState.persist()
        return true
    }
}

/// Одно лицо в справочнике: имя, папки (создание и правка), удаление
struct PersonDirectoryView: View {
    @EnvironmentObject var appState: AppState
    @Environment(\.dismiss) private var dismiss
    let personId: UUID

    @State private var folderTarget: FolderEditTarget? = nil
    @State private var confirmDelete = false

    var body: some View {
        let person = appState.data.person(personId)
        List {
            if let person, person.deletion == nil {
                Section {
                    NameField(initial: person.name, placeholder: "Имя") { rename($0) }
                        .accessibilityIdentifier("personName")
                } header: {
                    SectionTitle("Имя")
                }
                foldersSection
                Section {
                    DestructiveRow(title: "Удалить лицо в корзину") { confirmDelete = true }
                }
            } else {
                Section {
                    EmptyStateRow(symbol: "trash", title: "В корзине",
                                  text: "Это лицо удалено. Его можно восстановить из корзины в хранилище.")
                }
                .plainRow()
            }
        }
        .themedList()
        .navigationTitle(person?.name ?? "")
        .navigationBarTitleDisplayMode(.inline)
        .sheet(item: $folderTarget) { target in
            FolderEditor(target: target)
                .environmentObject(appState)
        }
        .confirmationDialog("Удалить лицо?", isPresented: $confirmDelete, titleVisibility: .visible) {
            Button("Удалить в корзину", role: .destructive) { trash() }
            Button("Отмена", role: .cancel) {}
        } message: {
            Text("Вместе со всеми папками и карточками. Всё можно будет восстановить из корзины.")
        }
    }

    @ViewBuilder
    private var foldersSection: some View {
        let folders = appState.data.activeFolders(of: personId)
        let counts = appState.data.activeCardCounts()
        Section {
            ForEach(folders) { folder in
                Button {
                    folderTarget = .edit(folder.id)
                } label: {
                    FolderRow(folder: folder, cardCount: counts[folder.id] ?? 0)
                        .foregroundStyle(Color.primary)
                }
                .accessibilityIdentifier("dirFolder_\(folder.name)")
            }
            Button {
                folderTarget = .new(personId)
            } label: {
                IconRow(title: "Новая папка", symbol: "folder.badge.plus", color: .accentColor)
                    .foregroundStyle(Color.primary)
            }
            .accessibilityIdentifier("dirAddFolder")
        } header: {
            SectionTitle("Папки")
        } footer: {
            Text("Нажмите на папку, чтобы изменить номер, название, цвет или теги.")
        }
    }

    private func rename(_ name: String) {
        guard let i = appState.data.persons.firstIndex(where: { $0.id == personId }) else { return }
        let old = appState.data.persons[i].name
        guard old != name else { return }
        appState.data.persons[i].name = name
        appState.data.log(.personEdited, object: name,
                          details: [HistoryDetail(field: "Имя", old: old, new: name)])
        appState.persist()
    }

    private func trash() {
        guard let person = appState.data.person(personId) else { return }
        appState.data.trashPerson(personId, batch: UUID(), date: Date())
        appState.data.log(.trashed, object: "Лицо «\(person.name)»",
                          summary: "Вместе со всеми папками и карточками")
        appState.persist()
        dismiss()
    }
}
