import SwiftUI

// Поля шаблона в форме карточки: по одному виду строки на каждый FieldKind.
// Каждое поле — одна строка: подпись слева, ввод справа (как в «Настройках»
// iPhone). Длинная подпись вроде «Страховая медицинская организация»
// переносится на вторую строку, а не обрезается.

struct FieldEditorRow: View {
    let spec: FieldSpec
    @Binding var value: String

    var body: some View {
        switch spec.kind {
        case .text:
            LabeledField(title: spec.title) {
                TextField("Ввести", text: $value, axis: .vertical)
                    .font(Theme.body)
                    .lineLimit(1...4)
            }
        case .latin:
            LabeledField(title: spec.title) {
                TextField("LATIN", text: $value)
                    .font(Theme.body)
                    .keyboardType(.asciiCapable)
                    .textInputAutocapitalization(.characters)
                    .autocorrectionDisabled()
            }
        case .digits(let mask):
            LabeledField(title: spec.title, problem: spec.problem(in: value)) {
                MaskedField(mask: mask, value: $value)
            }
        case .date:
            DateFieldRow(title: spec.title, value: $value)
        case .choice(let options):
            Picker(spec.title, selection: $value) {
                Text("Не указано").tag("")
                ForEach(options, id: \.self) { option in
                    Text(option).tag(option)
                }
            }
            .pickerStyle(.menu)
            .font(Theme.body)
        case .multiChoice(let options):
            MultiChoiceRow(title: spec.title, options: options, value: $value)
        }
    }
}

/// Цифровое поле с маской: знаки («-», пробелы) встают прямо во время набора.
///
/// Почему отдельное состояние: если переформатировать значение в сеттере
/// привязки, поле ввода iOS не перерисовывает набранный текст, и знаки
/// появлялись бы только после ухода из поля. Поэтому поле держит свой текст
/// и само заменяет его отформатированным при каждом изменении.
struct MaskedField: View {
    let mask: String
    @Binding var value: String
    @State private var text = ""
    @State private var loaded = false

    var body: some View {
        TextField(mask, text: $text)
            .font(Theme.body)
            .monospacedDigit()
            .keyboardType(.numberPad)
            .onAppear {
                guard !loaded else { return }
                loaded = true
                text = value
            }
            .onChange(of: text) { _, typed in
                let formatted = Mask.apply(mask, to: typed)
                if formatted != typed { text = formatted }
                if value != formatted { value = formatted }
            }
            .onChange(of: value) { _, outside in
                // Значение сменили снаружи (очистка формы, открытие правки)
                if outside != text { text = outside }
            }
    }
}

/// Одна строка: подпись слева, поле справа; ошибка — красным под строкой
struct LabeledField<Content: View>: View {
    let title: String
    var problem: String? = nil
    @ViewBuilder var content: Content

    var body: some View {
        VStack(alignment: .trailing, spacing: 2) {
            HStack(alignment: .firstTextBaseline, spacing: Theme.gap) {
                Text(title)
                    .font(Theme.body)
                    .lineLimit(2)
                    .fixedSize(horizontal: false, vertical: true)
                    .frame(maxWidth: 190, alignment: .leading)
                content
                    .multilineTextAlignment(.trailing)
                    .frame(maxWidth: .infinity, alignment: .trailing)
            }
            if let problem {
                Text(problem)
                    .font(Theme.caption)
                    .foregroundStyle(.red)
                    .multilineTextAlignment(.trailing)
            }
        }
    }
}

/// Дата в поле шаблона. Хранится строкой «ГГГГ-ММ-ДД», показывается «ДД.ММ.ГГГГ».
/// Окно выбора то же, что в N Finance: закрывается само при выборе дня.
struct DateFieldRow: View {
    let title: String
    @Binding var value: String
    @State private var showPicker = false

    var body: some View {
        HStack(spacing: Theme.gap) {
            Text(title).font(Theme.body)
            Spacer(minLength: Theme.gap)
            if value.isEmpty {
                Button("Выбрать") { showPicker = true }
                    .font(Theme.body)
                    .buttonStyle(.borderless)
            } else {
                Button(DateFmt.display(value)) { showPicker = true }
                    .font(Theme.body)
                    .buttonStyle(.borderless)
                    .monospacedDigit()
                Button {
                    value = ""
                } label: {
                    Image(systemName: "xmark.circle.fill")
                        .foregroundStyle(.tertiary)
                        .imageScale(.large)
                }
                .buttonStyle(.plain)
                .accessibilityLabel("Очистить: \(title)")
            }
        }
        .sheet(isPresented: $showPicker) {
            DateTimeSheet(mode: .date, initial: DateFmt.day(from: value) ?? Date()) { picked in
                value = DateFmt.dayString(picked)
                showPicker = false
            }
            .presentationDetents([.height(470)])
            .presentationDragIndicator(.visible)
        }
    }
}

/// Выбор нескольких значений (категории прав). Хранится через запятую
/// в порядке списка вариантов, а не в порядке нажатий.
struct MultiChoiceRow: View {
    let title: String
    let options: [String]
    @Binding var value: String
    @State private var showSheet = false

    private var selected: Set<String> {
        var set: Set<String> = []
        for part in value.split(separator: ",") {
            let trimmed = part.trimmingCharacters(in: .whitespaces)
            if !trimmed.isEmpty { set.insert(trimmed) }
        }
        return set
    }

    var body: some View {
        Button {
            showSheet = true
        } label: {
            HStack(spacing: Theme.gap) {
                Text(title)
                    .font(Theme.body)
                    .foregroundStyle(Color.primary)
                Spacer(minLength: Theme.gap)
                Text(value.isEmpty ? "Выбрать" : value)
                    .font(Theme.body)
                    .foregroundStyle(value.isEmpty ? Color.accentColor : Color.secondary)
                    .multilineTextAlignment(.trailing)
            }
        }
        .buttonStyle(.plain)
        .sheet(isPresented: $showSheet) {
            NavigationStack {
                List {
                    ForEach(options, id: \.self) { option in
                        ChoiceRow(title: option, selected: selected.contains(option)) {
                            toggle(option)
                        }
                    }
                }
                .navigationTitle(title)
                .navigationBarTitleDisplayMode(.inline)
                .toolbar {
                    ToolbarItem(placement: .confirmationAction) {
                        Button("Готово") { showSheet = false }
                    }
                }
            }
            .presentationDetents([.medium, .large])
        }
    }

    private func toggle(_ option: String) {
        var set = selected
        if set.contains(option) { set.remove(option) } else { set.insert(option) }
        var ordered: [String] = []
        for o in options where set.contains(o) { ordered.append(o) }
        value = ordered.joined(separator: ", ")
    }
}
