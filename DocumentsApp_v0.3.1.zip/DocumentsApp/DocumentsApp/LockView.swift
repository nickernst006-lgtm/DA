import SwiftUI

/// Экран блокировки: создание пароля при первом запуске и вход дальше.
/// Перенесён из N Finance; изменено только название приложения.
struct LockView: View {
    @EnvironmentObject var appState: AppState
    @State private var pw1 = ""
    @State private var pw2 = ""
    @State private var loginPw = ""
    @State private var errorText = ""
    @State private var shake: CGFloat = 0

    private enum Field { case pw1, pw2, login }
    @FocusState private var focus: Field?

    var body: some View {
        ScrollView {
            VStack(spacing: Theme.sectionSpacing) {
                Spacer(minLength: 40)

                VStack(spacing: Theme.gap) {
                    AppBadge(size: 96)
                        .shadow(color: .black.opacity(0.18), radius: 16, y: 8)
                    Text("N Documents")
                        .font(Theme.subtitle)
                        .foregroundStyle(.secondary)
                }

                VStack(spacing: 8) {
                    Text(appState.hasAccount ? "Вход" : "Создайте пароль")
                        .font(Theme.title)
                    Text(appState.hasAccount
                         ? "Введите пароль, чтобы открыть документы"
                         : "Пароль шифрует все документы на этом iPhone.\nОн нигде не хранится.")
                        .font(Theme.caption)
                        .foregroundStyle(.secondary)
                        .multilineTextAlignment(.center)
                }

                if appState.hasAccount { loginFields } else { setupFields }

                if !errorText.isEmpty {
                    Text(errorText)
                        .font(Theme.caption)
                        .foregroundStyle(.red)
                        .multilineTextAlignment(.center)
                        .transition(.opacity)
                }

                Button(action: appState.hasAccount ? submitLogin : submitSetup) {
                    HStack(spacing: 8) {
                        if appState.isBusy { ProgressView().tint(.white) }
                        Text(buttonTitle).font(Theme.subtitle)
                    }
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 6)
                }
                .buttonStyle(.borderedProminent)
                .buttonBorderShape(.capsule)
                .controlSize(.large)
                .disabled(appState.isBusy || (appState.hasAccount && loginPw.isEmpty))
                .accessibilityIdentifier(appState.hasAccount ? "loginSubmit" : "setupSubmit")

                if !appState.hasAccount {
                    Label("Забытый пароль восстановить невозможно — документы будут потеряны.",
                          systemImage: "exclamationmark.triangle")
                        .font(Theme.caption)
                        .foregroundStyle(.secondary)
                        .multilineTextAlignment(.center)
                }
                Spacer(minLength: 20)
            }
            .padding(.horizontal, 28)
            .frame(maxWidth: 440)
            .frame(maxWidth: .infinity)
            .modifier(ShakeEffect(amount: shake))
        }
        .scrollBounceBehavior(.basedOnSize)
        .background(Color(.systemGroupedBackground).ignoresSafeArea())
        .onAppear {
            focus = appState.hasAccount ? .login : .pw1
        }
    }

    private var buttonTitle: String {
        if appState.isBusy { return appState.hasAccount ? "Проверка…" : "Шифрование…" }
        return appState.hasAccount ? "Открыть" : "Создать и войти"
    }

    private var setupFields: some View {
        VStack(spacing: 0) {
            SecureField("Новый пароль (от 4 символов)", text: $pw1)
                .focused($focus, equals: .pw1)
                .submitLabel(.next)
                .onSubmit { focus = .pw2 }
                .padding(Theme.gap + 4)
                .accessibilityIdentifier("setupPassword1")
            Divider().padding(.leading, Theme.gap + 4)
            SecureField("Повторите пароль", text: $pw2)
                .focused($focus, equals: .pw2)
                .submitLabel(.go)
                .onSubmit(submitSetup)
                .padding(Theme.gap + 4)
                .accessibilityIdentifier("setupPassword2")
        }
        .background(Color(.secondarySystemGroupedBackground),
                    in: RoundedRectangle(cornerRadius: 14, style: .continuous))
    }

    private var loginFields: some View {
        SecureField("Пароль", text: $loginPw)
            .focused($focus, equals: .login)
            .submitLabel(.go)
            .onSubmit(submitLogin)
            .padding(Theme.gap + 4)
            .background(Color(.secondarySystemGroupedBackground),
                        in: RoundedRectangle(cornerRadius: 14, style: .continuous))
            .accessibilityIdentifier("loginPassword")
    }

    private func fail(_ text: String) {
        errorText = text
        withAnimation(.default) { shake += 1 }
    }

    func submitSetup() {
        guard !appState.isBusy else { return }
        errorText = ""
        if pw1.count < 4 { fail("Пароль должен содержать минимум 4 символа."); return }
        if pw1 != pw2 { fail("Пароли не совпадают."); return }
        let password = pw1
        Task { @MainActor in
            if let err = await appState.createPassword(password) {
                fail(err)
            } else {
                pw1 = ""; pw2 = ""
            }
        }
    }

    func submitLogin() {
        guard !appState.isBusy, !loginPw.isEmpty else { return }
        errorText = ""
        let password = loginPw
        Task { @MainActor in
            if let err = await appState.login(password) {
                loginPw = ""
                fail(err)
                focus = .login
            } else {
                loginPw = ""
            }
        }
    }
}

/// Лёгкое «покачивание» при неверном пароле, как на экране блокировки iPhone
struct ShakeEffect: GeometryEffect {
    var amount: CGFloat
    var animatableData: CGFloat {
        get { amount }
        set { amount = newValue }
    }
    func effectValue(size: CGSize) -> ProjectionTransform {
        ProjectionTransform(CGAffineTransform(translationX: 8 * sin(amount * .pi * 4), y: 0))
    }
}
