import SwiftUI
import UIKit
import Combine

/// Корневой экран: замок или приложение. Попутно закрывает содержимое,
/// когда приложение неактивно. Перенесено из N Finance без изменений.
struct ContentView: View {
    @EnvironmentObject var appState: AppState
    @Environment(\.scenePhase) private var scenePhase

    var body: some View {
        ZStack {
            if appState.isUnlocked {
                MainTabView()
            } else {
                LockView()
            }
            // Закрываем содержимое, когда приложение неактивно — например,
            // в переключателе приложений данные не будут видны на миниатюре.
            if scenePhase != .active {
                PrivacyCover().transition(.opacity)
            }
        }
        .background(ActivityCatcher { appState.registerActivity() })
        .onReceive(NotificationCenter.default.publisher(for: UITextField.textDidChangeNotification)) { _ in
            appState.registerActivity()
        }
        .onReceive(NotificationCenter.default.publisher(for: UITextView.textDidChangeNotification)) { _ in
            appState.registerActivity()
        }
        .onChange(of: scenePhase) { _, phase in
            if phase == .active { appState.checkAutoLock() }
        }
        .alert("Ошибка", isPresented: Binding(
            get: { appState.saveError != nil },
            set: { if !$0 { appState.saveError = nil } }
        )) {
            Button("OK", role: .cancel) { appState.saveError = nil }
        } message: {
            Text(appState.saveError ?? "")
        }
    }
}

/// Пять вкладок N Documents (ТЗ, раздел 5): Форма, История, Хранилище,
/// Справочники, О приложении.
struct MainTabView: View {
    @EnvironmentObject var appState: AppState
    @State private var editState: EditState? = nil
    @State private var selectedTab: Int = 0
    /// Путь во вкладке «Хранилище» — чтобы после сохранения формы сразу
    /// открыть сохранённую карточку
    @State private var storagePath: [StorageRoute] = []

    var body: some View {
        TabView(selection: $selectedTab) {
            NavigationStack {
                FormView(editState: $editState, onSaved: { cardId in openCard(cardId) })
            }
            .tabItem { TabIcon(symbol: "plus.circle", title: "Форма") }
            .tag(0)

            NavigationStack {
                HistoryView()
            }
            .tabItem { TabIcon(symbol: "clock.arrow.circlepath", title: "История") }
            .tag(1)

            NavigationStack(path: $storagePath) {
                StorageView(editState: $editState, goToForm: { selectedTab = 0 })
            }
            .tabItem { TabIcon(symbol: "archivebox", title: "Хранилище") }
            .tag(2)

            NavigationStack {
                DirectoriesView()
            }
            .tabItem { TabIcon(symbol: "slider.horizontal.3", title: "Справочники") }
            .tag(3)

            NavigationStack {
                AboutView()
            }
            .tabItem { TabIcon(symbol: "lock.shield", title: "О приложении") }
            .tag(4)
        }
    }

    /// Хранилище → человек → папка → карточка
    private func openCard(_ id: UUID) {
        var route: [StorageRoute] = []
        if let card = appState.data.card(id), let folder = appState.data.folder(card.folderId) {
            route = [.person(folder.personId), .folder(folder.id), .card(id)]
        }
        storagePath = route
        selectedTab = 2
    }
}

/// Иконка вкладки без подписи. Название остаётся для VoiceOver.
struct TabIcon: View {
    let symbol: String
    let title: String
    var body: some View {
        Image(systemName: symbol)
            .accessibilityLabel(title)
    }
}
