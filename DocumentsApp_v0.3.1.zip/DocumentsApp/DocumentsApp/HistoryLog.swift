import SwiftUI

// Журнал истории (ТЗ, раздел 9). Каждое действие записывается сразу,
// с подробностями «было → стало». Названия хранятся строками, чтобы
// запись читалась и после удаления объекта.

nonisolated enum HistoryAction: String, CaseIterable {
    case cardCreated
    case cardEdited
    case cardMoved
    case statusChanged
    case personCreated
    case personEdited
    case folderCreated
    case folderEdited
    case trashed
    case restored
    case directoryChanged
    // Появятся в следующих версиях — названия заведены заранее,
    // чтобы старая сборка показывала их по-человечески.
    case purged
    case exportArchive
    case exportLocal

    var title: String {
        switch self {
        case .cardCreated: return "Создана карточка"
        case .cardEdited: return "Изменена карточка"
        case .cardMoved: return "Карточка перенесена"
        case .statusChanged: return "Изменён статус"
        case .personCreated: return "Добавлено лицо"
        case .personEdited: return "Изменено лицо"
        case .folderCreated: return "Создана папка"
        case .folderEdited: return "Изменена папка"
        case .trashed: return "Перемещено в корзину"
        case .restored: return "Восстановлено из корзины"
        case .directoryChanged: return "Изменён справочник"
        case .purged: return "Удалено окончательно"
        case .exportArchive: return "Экспорт в архив"
        case .exportLocal: return "Экспорт на iPhone"
        }
    }

    var symbol: String {
        switch self {
        case .cardCreated: return "doc.badge.plus"
        case .cardEdited: return "pencil"
        case .cardMoved: return "arrow.right.doc.on.clipboard"
        case .statusChanged: return "checkmark.seal"
        case .personCreated, .personEdited: return "person.fill"
        case .folderCreated, .folderEdited: return "folder.fill"
        case .trashed: return "trash.fill"
        case .restored: return "arrow.uturn.backward"
        case .directoryChanged: return "slider.horizontal.3"
        case .purged: return "xmark.bin.fill"
        case .exportArchive: return "lock.doc.fill"
        case .exportLocal: return "square.and.arrow.down.fill"
        }
    }

    var color: Color {
        switch self {
        case .cardCreated, .personCreated, .folderCreated: return .green
        case .cardEdited, .personEdited, .folderEdited, .statusChanged: return .blue
        case .cardMoved: return .indigo
        case .trashed, .purged: return .red
        case .restored: return .orange
        case .directoryChanged: return .gray
        case .exportArchive, .exportLocal: return .teal
        }
    }
}

extension HistoryEvent {
    var actionTitle: String { HistoryAction(rawValue: action)?.title ?? action }
    var actionSymbol: String { HistoryAction(rawValue: action)?.symbol ?? "clock" }
    var actionColor: Color { HistoryAction(rawValue: action)?.color ?? .gray }
}

extension AppData {

    mutating func log(_ action: HistoryAction, object: String, summary: String = "",
                      details: [HistoryDetail] = []) {
        history.append(HistoryEvent(action: action.rawValue, object: object,
                                    summary: summary, details: details))
    }

    /// Все заполненные данные карточки — для записи о создании
    /// и об окончательном удалении.
    func cardSnapshot(_ card: DocumentCard) -> [HistoryDetail] {
        let template = CardTemplate.find(card.typeId)
        var out: [HistoryDetail] = []
        out.append(HistoryDetail(field: "Тип", new: template.title))
        out.append(HistoryDetail(field: "Расположение", new: location(of: card)))
        out.append(HistoryDetail(field: "Статус", new: card.status.title))
        for spec in template.fields {
            let raw = card.fields[spec.key] ?? ""
            if !raw.isEmpty { out.append(HistoryDetail(field: spec.title, new: spec.display(raw))) }
        }
        if !card.note.isEmpty { out.append(HistoryDetail(field: "Заметка", new: card.note)) }
        for file in card.files where file.deletion == nil {
            out.append(HistoryDetail(field: "Файл", new: file.displayName))
        }
        return out
    }

    /// Что изменилось между двумя версиями карточки: по полю на строку.
    func cardChanges(old: DocumentCard, new: DocumentCard) -> [HistoryDetail] {
        var out: [HistoryDetail] = []
        if old.title != new.title {
            out.append(HistoryDetail(field: "Название", old: old.title, new: new.title))
        }
        let oldTemplate = CardTemplate.find(old.typeId)
        let newTemplate = CardTemplate.find(new.typeId)
        if old.typeId != new.typeId {
            out.append(HistoryDetail(field: "Тип", old: oldTemplate.title, new: newTemplate.title))
        }
        if old.folderId != new.folderId {
            out.append(HistoryDetail(field: "Расположение", old: location(of: old), new: location(of: new)))
        }
        if old.status != new.status {
            out.append(HistoryDetail(field: "Статус", old: old.status.title, new: new.status.title))
        }

        // Поля: сначала в порядке нового шаблона, потом исчезнувшие из старого
        var seen: Set<String> = []
        var specs: [FieldSpec] = newTemplate.fields
        for spec in oldTemplate.fields where !newTemplate.fields.contains(where: { $0.key == spec.key }) {
            specs.append(spec)
        }
        for spec in specs where !seen.contains(spec.key) {
            seen.insert(spec.key)
            let a = old.fields[spec.key] ?? ""
            let b = new.fields[spec.key] ?? ""
            if a != b {
                var line = HistoryDetail(field: spec.title)
                if !a.isEmpty { line.old = spec.display(a) }
                if !b.isEmpty { line.new = spec.display(b) }
                out.append(line)
            }
        }

        if old.note != new.note {
            var line = HistoryDetail(field: "Заметка")
            if !old.note.isEmpty { line.old = old.note }
            if !new.note.isEmpty { line.new = new.note }
            out.append(line)
        }

        // Файлы: добавленные, убранные в корзину, переименованные
        var oldActive: [UUID: StoredFile] = [:]
        for f in old.files where f.deletion == nil { oldActive[f.id] = f }
        var newActive: [UUID: StoredFile] = [:]
        for f in new.files where f.deletion == nil { newActive[f.id] = f }
        for f in new.files where f.deletion == nil {
            if let before = oldActive[f.id] {
                if before.displayName != f.displayName {
                    out.append(HistoryDetail(field: "Файл переименован", old: before.displayName, new: f.displayName))
                }
            } else {
                out.append(HistoryDetail(field: "Файл добавлен", new: f.displayName))
            }
        }
        for f in old.files where f.deletion == nil && newActive[f.id] == nil {
            out.append(HistoryDetail(field: "Файл в корзину", old: f.displayName))
        }
        return out
    }
}
