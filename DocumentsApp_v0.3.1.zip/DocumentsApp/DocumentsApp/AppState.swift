import Foundation
import CryptoKit
import Combine

/// Что открыть в форме: правку карточки или новую карточку в заданной папке.
nonisolated enum EditState: Equatable {
    case edit(UUID)
    case newIn(UUID)
}

/// Сердце приложения: хранилище, ключ шифрования, вход, автоблокировка,
/// сохранение и сброс. Перенесено из N Finance 3.7; отличия:
///   • своя папка хранилища (DocumentsData) и своя контрольная строка —
///     чтобы файлы разных приложений серии не путались;
///   • основной файл называется data.bin (ТЗ, раздел 3);
///   • рядом — папка files/: каждый файл документа — отдельный блоб AES-256-GCM
///     со случайным именем; при смене пароля файлы перешифровываются;
///   • полный сброс стирает и её.
@MainActor
final class AppState: ObservableObject {
    @Published var isUnlocked: Bool = false
    @Published var hasAccount: Bool = false
    @Published var data: AppData = AppData()
    @Published var isBusy: Bool = false
    /// Текст ошибки сохранения — показывается пользователю, а не теряется молча
    @Published var saveError: String? = nil

    private var cryptoKey: SymmetricKey? = nil
    private var lastActivity: Date = Date()
    private var autoLockTimer: Timer?
    private let iterations: Int
    let autoLockSeconds: TimeInterval = 5 * 60

    private static let verifierText = "DOCUMENTS_APP_OK_V1"

    /// Папка с данными. Application Support — внутренняя папка приложения,
    /// она не видна в приложении «Файлы» и через «Поделиться».
    let storageDir: URL
    private var metaURL: URL { storageDir.appendingPathComponent("meta.json") }
    private var dataURL: URL { storageDir.appendingPathComponent("data.bin") }
    /// Папка зашифрованных файлов: каждый скан — отдельный блоб со случайным именем.
    var filesDir: URL { storageDir.appendingPathComponent("files", isDirectory: true) }

    private nonisolated struct MetaFile: Codable {
        var salt: Data
        var verifier: EncryptedBlob
    }
    private nonisolated struct VerifierPayload: Codable { var check: String }

    /// storageDir и iterations можно подменить только в тестах
    init(storageDir: URL? = nil, iterations: Int = 250_000) {
        self.iterations = iterations
        if let storageDir {
            self.storageDir = storageDir
        } else {
            let base = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
            self.storageDir = base.appendingPathComponent("DocumentsData", isDirectory: true)
        }
        prepareStorageDir()
        hasAccount = FileManager.default.fileExists(atPath: metaURL.path)
        Self.cleanTemporaryExports()
        startAutoLockMonitor()
    }

    // MARK: - Хранилище

    private func prepareStorageDir() {
        let fm = FileManager.default
        for dir in [storageDir, filesDir] where !fm.fileExists(atPath: dir.path) {
            try? fm.createDirectory(at: dir, withIntermediateDirectories: true,
                                    attributes: [.protectionKey: FileProtectionType.complete])
        }
        excludeFromBackup(storageDir)
        excludeFromBackup(filesDir)
    }

    /// Данные НЕ попадают в резервные копии iCloud и компьютера:
    /// они физически существуют только на этом iPhone.
    private func excludeFromBackup(_ url: URL) {
        var u = url
        var values = URLResourceValues()
        values.isExcludedFromBackup = true
        try? u.setResourceValues(values)
    }

    /// Запись с шифрованием на уровне iOS (файл недоступен, пока телефон заблокирован)
    /// поверх нашего собственного AES-256.
    private func writeProtected(_ data: Data, to url: URL) throws {
        try data.write(to: url, options: [.atomic, .completeFileProtection])
        excludeFromBackup(url)
    }

    /// Префикс временных папок экспорта — по нему их находит уборка при запуске.
    nonisolated static let exportPrefix = "NDocExport"

    /// Удаляет остатки экспорта во временной папке: архивы, открытые папки
    /// и отдельные файлы. Вызывается при каждом запуске и при полном сбросе.
    static func cleanTemporaryExports() {
        let fm = FileManager.default
        let tmp = fm.temporaryDirectory
        guard let items = try? fm.contentsOfDirectory(at: tmp, includingPropertiesForKeys: nil) else { return }
        let extensions: Set<String> = ["zip", "pdf", "xlsx"]
        for item in items {
            let isExport = item.lastPathComponent.hasPrefix(exportPrefix)
            let isLeftover = extensions.contains(item.pathExtension.lowercased())
            if isExport || isLeftover {
                try? fm.removeItem(at: item)
            }
        }
    }

    // MARK: - Автоблокировка

    func registerActivity() {
        lastActivity = Date()
    }

    /// Проверка бездействия. Вызывается таймером и при возврате в приложение.
    func checkAutoLock() {
        if isUnlocked && Date().timeIntervalSince(lastActivity) > autoLockSeconds {
            lock()
        }
    }

    private func startAutoLockMonitor() {
        autoLockTimer = Timer.scheduledTimer(withTimeInterval: 10, repeats: true) { [weak self] _ in
            guard let self else { return }
            Task { @MainActor in
                self.checkAutoLock()
            }
        }
    }

    // MARK: - Ключ

    private func deriveKeyAsync(password: String, salt: Data) async -> SymmetricKey {
        let iterations = self.iterations
        return await withCheckedContinuation { continuation in
            DispatchQueue.global(qos: .userInitiated).async {
                let key = PBKDF2.deriveKey(password: password, salt: salt, iterations: iterations)
                continuation.resume(returning: key)
            }
        }
    }

    private static func randomSalt() -> Data {
        Data((0..<16).map { _ in UInt8.random(in: 0...255) })
    }

    private func writeMeta(salt: Data, key: SymmetricKey) throws {
        let verifier = try CryptoBox.encrypt(VerifierPayload(check: Self.verifierText), key: key)
        let metaData = try JSONEncoder().encode(MetaFile(salt: salt, verifier: verifier))
        try writeProtected(metaData, to: metaURL)
    }

    /// Проверяет пароль и возвращает ключ, либо nil если пароль неверный
    private func keyIfPasswordCorrect(_ password: String) async -> SymmetricKey? {
        guard let metaData = try? Data(contentsOf: metaURL),
              let meta = try? JSONDecoder().decode(MetaFile.self, from: metaData) else { return nil }
        let key = await deriveKeyAsync(password: password, salt: meta.salt)
        guard let payload = try? CryptoBox.decrypt(meta.verifier, key: key, as: VerifierPayload.self),
              payload.check == Self.verifierText else { return nil }
        return key
    }

    // MARK: - Вход / создание / смена пароля

    /// Возвращает nil при успехе, иначе — текст ошибки для показа пользователю
    func createPassword(_ password: String) async -> String? {
        guard password.count >= 4 else { return "Пароль должен содержать минимум 4 символа." }
        isBusy = true
        defer { isBusy = false }

        let salt = Self.randomSalt()
        let key = await deriveKeyAsync(password: password, salt: salt)
        do {
            try writeMeta(salt: salt, key: key)
            cryptoKey = key
            data = AppData()
            seedDemoDataIfRequested()
            try saveData()
            hasAccount = true
            isUnlocked = true
            registerActivity()
            return nil
        } catch {
            cryptoKey = nil
            return "Не удалось создать пароль: \(error.localizedDescription)"
        }
    }

    func login(_ password: String) async -> String? {
        isBusy = true
        defer { isBusy = false }
        guard let key = await keyIfPasswordCorrect(password) else {
            return "Неверный пароль. Попробуйте снова."
        }
        do {
            cryptoKey = key
            resolvePendingRekey(key: key)
            try loadData()
            cleanOrphanBlobs()
            // Тесты запускаются один за другим в одном симуляторе: пароль создаёт
            // самый первый из них, а дальше идёт вход. Если засевать демо-данные
            // только при создании пароля, остальные тесты увидят пустое приложение.
            if seedDemoDataIfRequested() { try? saveData() }
            isUnlocked = true
            registerActivity()
            return nil
        } catch {
            cryptoKey = nil
            return "Пароль верный, но файл данных повреждён или не читается."
        }
    }

    /// Демо-данные ТОЛЬКО для облачных скриншот-тестов (см. DemoData.swift).
    /// В обычной сборке этого кода нет вовсе.
    @discardableResult
    private func seedDemoDataIfRequested() -> Bool {
        #if DEBUG
        // Засеваем только в пустое хранилище: DemoData.make() заменяет данные
        // целиком, и заведённое вручную было бы затёрто.
        guard ProcessInfo.processInfo.arguments.contains("-uiTestDemo"),
              data.isEmpty else { return false }
        data = DemoData.make()
        return true
        #else
        return false
        #endif
    }

    /// Смена пароля: данные и все файлы перешифровываются новым ключом
    /// с новой «солью».
    ///
    /// Порядок записи защищает от сбоя посередине (выключился телефон):
    ///   1. все файлы пишутся рядом копиями «.new» на новом ключе;
    ///   2. рядом пишется data.bin.new на новом ключе;
    ///   3. пишется meta.json с новой солью — с этого момента верен новый пароль;
    ///   4. копии «.new» подменяют основные файлы.
    /// Если сбой случился до шага 3, при входе старым паролем data.bin.new
    /// не расшифруется — копии будут выброшены. Если после — при входе новым
    /// паролем расшифруется, и подмена будет доделана (resolvePendingRekey).
    func changePassword(old: String, new: String) async -> String? {
        guard new.count >= 4 else { return "Новый пароль должен содержать минимум 4 символа." }
        isBusy = true
        defer { isBusy = false }
        registerActivity()
        guard let verifiedOldKey = await keyIfPasswordCorrect(old) else { return "Текущий пароль введён неверно." }

        let newSalt = Self.randomSalt()
        let newKey = await deriveKeyAsync(password: new, salt: newSalt)
        let oldKey = cryptoKey ?? verifiedOldKey
        let dir = filesDir
        do {
            // 1. Файлы — в фоне: их может быть много и они большие.
            try await Task.detached(priority: .userInitiated) {
                try AppState.reencryptBlobs(in: dir, from: oldKey, to: newKey)
            }.value
            // 2. Данные — во временный файл.
            let tmpData = pendingDataURL
            let blob = try CryptoBox.encrypt(data, key: newKey)
            try writeProtected(try JSONEncoder().encode(blob), to: tmpData)
            // 3. Точка невозврата.
            try writeMeta(salt: newSalt, key: newKey)
            cryptoKey = newKey
            // 4. Подмена.
            try commitPendingRekey()
            registerActivity()
            return nil
        } catch {
            // Старый пароль ещё верен — meta.json не тронут: выбрасываем копии.
            // Уже не верен — точка невозврата пройдена: доделываем подмену.
            if await keyIfPasswordCorrect(old) != nil {
                cryptoKey = oldKey
                discardPendingRekey()
            } else {
                cryptoKey = newKey
                try? commitPendingRekey()
            }
            return "Не удалось сменить пароль: \(error.localizedDescription)"
        }
    }

    func lock() {
        cryptoKey = nil
        data = AppData()
        isUnlocked = false
    }

    // MARK: - Данные

    private func loadData() throws {
        guard let key = cryptoKey else { throw CryptoError.notUnlocked }
        if FileManager.default.fileExists(atPath: dataURL.path) {
            let fileData = try Data(contentsOf: dataURL)
            let blob = try JSONDecoder().decode(EncryptedBlob.self, from: fileData)
            data = try CryptoBox.decrypt(blob, key: key, as: AppData.self)
        } else {
            data = AppData()
        }
    }

    func saveData() throws {
        guard let key = cryptoKey else { throw CryptoError.notUnlocked }
        let blob = try CryptoBox.encrypt(data, key: key)
        try writeProtected(try JSONEncoder().encode(blob), to: dataURL)
    }

    /// Сохранить после любого изменения. При ошибке — сообщение на экране.
    func persist() {
        registerActivity()
        do {
            try saveData()
        } catch {
            saveError = "Не удалось сохранить данные: \(error.localizedDescription)"
        }
    }

    // MARK: - Файлы документов

    /// Шифрует файл и кладёт его в files/ под случайным именем.
    /// Возвращает имя блоба — его запоминает StoredFile.
    func storeFile(_ plain: Data) throws -> String {
        guard let key = cryptoKey else { throw CryptoError.notUnlocked }
        let sealed = try AES.GCM.seal(plain, using: key)
        guard let combined = sealed.combined else { throw CryptoError.sealFailed }
        let name = UUID().uuidString + ".bin"
        try writeProtected(combined, to: filesDir.appendingPathComponent(name))
        registerActivity()
        return name
    }

    /// Читает и расшифровывает файл — только в память, на диск ничего
    /// открытого не пишется. Работа идёт в фоне, чтобы не подвисал экран.
    func loadFile(_ blobName: String) async throws -> Data {
        guard let key = cryptoKey else { throw CryptoError.notUnlocked }
        let url = filesDir.appendingPathComponent(blobName)
        return try await Task.detached(priority: .userInitiated) {
            let raw = try Data(contentsOf: url)
            let box = try AES.GCM.SealedBox(combined: raw)
            return try AES.GCM.open(box, using: key)
        }.value
    }

    /// Стирает блоб с диска. Без ключа остатки на флеш-памяти — случайные байты.
    func deleteBlob(_ blobName: String) {
        try? FileManager.default.removeItem(at: filesDir.appendingPathComponent(blobName))
    }

    /// Удаляет блобы, на которые не ссылается ни одна карточка (в том числе
    /// лежащая в корзине). Такие остаются, если форму покинули без сохранения
    /// или приложение заблокировалось посреди заполнения.
    private func cleanOrphanBlobs() {
        var referenced: Set<String> = []
        for card in data.cards {
            for file in card.files { referenced.insert(file.blobName) }
        }
        let fm = FileManager.default
        guard let items = try? fm.contentsOfDirectory(at: filesDir, includingPropertiesForKeys: nil) else { return }
        for item in items where item.pathExtension == "bin" {
            if !referenced.contains(item.lastPathComponent) {
                try? fm.removeItem(at: item)
            }
        }
    }

    private var pendingDataURL: URL { storageDir.appendingPathComponent("data.bin.new") }

    /// Перешифровывает все блобы в копии «.new». Блоб, который не открывается
    /// старым ключом (повреждён), пропускается: иначе один испорченный файл
    /// навсегда запретил бы смену пароля.
    nonisolated static func reencryptBlobs(in dir: URL, from oldKey: SymmetricKey, to newKey: SymmetricKey) throws {
        let fm = FileManager.default
        let items = try fm.contentsOfDirectory(at: dir, includingPropertiesForKeys: nil)
        for url in items where url.pathExtension == "bin" {
            let raw = try Data(contentsOf: url)
            guard let box = try? AES.GCM.SealedBox(combined: raw),
                  let plain = try? AES.GCM.open(box, using: oldKey) else { continue }
            let sealed = try AES.GCM.seal(plain, using: newKey)
            guard let combined = sealed.combined else { throw CryptoError.sealFailed }
            let out = url.appendingPathExtension("new")
            try combined.write(to: out, options: [.atomic, .completeFileProtection])
        }
    }

    /// Подменяет основные файлы их копиями «.new» (шаг 4 смены пароля).
    private func commitPendingRekey() throws {
        let fm = FileManager.default
        let items = (try? fm.contentsOfDirectory(at: filesDir, includingPropertiesForKeys: nil)) ?? []
        for item in items where item.pathExtension == "new" {
            let target = item.deletingPathExtension()
            if fm.fileExists(atPath: target.path) {
                _ = try fm.replaceItemAt(target, withItemAt: item)
            } else {
                try fm.moveItem(at: item, to: target)
            }
            excludeFromBackup(target)
        }
        if fm.fileExists(atPath: pendingDataURL.path) {
            if fm.fileExists(atPath: dataURL.path) {
                _ = try fm.replaceItemAt(dataURL, withItemAt: pendingDataURL)
            } else {
                try fm.moveItem(at: pendingDataURL, to: dataURL)
            }
        }
        excludeFromBackup(dataURL)
    }

    /// Выбрасывает недописанные копии «.new».
    private func discardPendingRekey() {
        let fm = FileManager.default
        let items = (try? fm.contentsOfDirectory(at: filesDir, includingPropertiesForKeys: nil)) ?? []
        for item in items where item.pathExtension == "new" {
            try? fm.removeItem(at: item)
        }
        try? fm.removeItem(at: pendingDataURL)
    }

    /// Вызывается при входе. Если смена пароля оборвалась, решает по data.bin.new:
    /// открывается текущим ключом — доделать подмену, нет — выбросить копии.
    private func resolvePendingRekey(key: SymmetricKey) {
        let fm = FileManager.default
        guard fm.fileExists(atPath: pendingDataURL.path) else {
            discardPendingRekey()
            return
        }
        var opens = false
        if let raw = try? Data(contentsOf: pendingDataURL),
           let blob = try? JSONDecoder().decode(EncryptedBlob.self, from: raw),
           (try? CryptoBox.decrypt(blob, key: key, as: AppData.self)) != nil {
            opens = true
        }
        if opens {
            try? commitPendingRekey()
        } else {
            discardPendingRekey()
        }
    }

    /// Полный сброс: пароль, карточки, история и все зашифрованные файлы.
    func fullReset() {
        let fm = FileManager.default
        try? fm.removeItem(at: metaURL)
        try? fm.removeItem(at: dataURL)
        try? fm.removeItem(at: filesDir)
        Self.cleanTemporaryExports()
        prepareStorageDir()
        cryptoKey = nil
        data = AppData()
        isUnlocked = false
        hasAccount = false
    }
}
