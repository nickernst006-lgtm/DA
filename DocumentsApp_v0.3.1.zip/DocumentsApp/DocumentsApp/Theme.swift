import SwiftUI

/// Единая дизайн-система приложения. Файл перенесён из N Finance как есть;
/// убран только `AmountText` — денежных сумм в N Documents нет.
///
/// ТИПОГРАФИКА. Размеров текста ровно четыре, один шрифт (системный SF):
///   • `Theme.title`    — крупный: заголовки разделов;
///   • `Theme.subtitle` — средний: важные подзаголовки и названия строк;
///   • `Theme.body`     — малый: обычный текст;
///   • `Theme.caption`  — очень малый: уточнения и подписи серым.
/// Отдельно стоят `Theme.screenTitle` (имя экрана) и `Theme.display`
/// (крупные цифры) — это не текст, а навигация и табло.
///
/// СЕТКА. Один шаг `Theme.step` задаёт всё вертикальное дыхание: над
/// заголовком экрана, под ним, между блоками и между днями в истории.
/// Все строки списков одной высоты `Theme.rowHeight`. Благодаря этому
/// экраны совпадают друг с другом при перелистывании вкладок.
enum Theme {
    // MARK: - Типографика

    static let title: Font = .title2.weight(.semibold)
    static let subtitle: Font = .headline
    static let body: Font = .body
    static let caption: Font = .subheadline

    /// Имя экрана — вместо системного крупного заголовка, чтобы отступ
    /// над ним был под нашим контролем и одинаковым на всех вкладках.
    static let screenTitle: Font = .system(size: 32, weight: .bold)
    /// Табло для крупных чисел.
    static let display: Font = .system(size: 38, weight: .bold).monospacedDigit()

    // MARK: - Сетка

    /// Подзаголовок раздела: даты в истории, названия справочников,
    /// названия блоков. Один размер и одно место на всех вкладках.
    static let sectionHeader: Font = Theme.subtitle

    /// Высота шапки экрана равна высоте строки списка. Это и выравнивает
    /// заголовок на всех вкладках: там, где шапка одна в строке, список
    /// центрирует её в своей высоте, а там, где под ней ещё и поиск, —
    /// не центрирует. Совпадение высот убирает разницу.
    static let headerHeight: CGFloat = rowHeight

    /// Единый вертикальный шаг всего приложения.
    static let step: CGFloat = 16
    /// Отступ между элементами внутри одной строки.
    static let gap: CGFloat = 12
    /// Одинаковая высота строк во всех списках.
    static let rowHeight: CGFloat = 56
    /// Поле слева и справа внутри строки списка.
    static let rowInset: CGFloat = 16
    /// Скругление карточек — как у системного сгруппированного списка.
    static let cardRadius: CGFloat = 10
    /// Насколько карточки уже стандартных — по просьбе «совсем чуть-чуть».
    static let narrow: CGFloat = 5
    static let iconSize: CGFloat = 30

    /// Старое имя шага — используется на экране входа.
    static let sectionSpacing: CGFloat = step

    // MARK: - Цвета

    static let income = Color.green
    /// Светло-красный: мягче системного, но уже не оранжевый
    static let expense = Color(red: 0.91, green: 0.33, blue: 0.31)
    /// Красный для столбиков на графиках
    static let expenseBar = Color.red
    static let palette: [Color] = [.blue, .orange, .purple, .teal, .pink, .indigo, .mint, .yellow, .red, .cyan]
    static func color(at index: Int) -> Color { palette[index % palette.count] }
}

extension View {
    /// Общие правила списка: шаг между блоками, минимальная высота строки,
    /// чуть более узкие карточки. Для экранов, на которые проваливаются.
    func themedList() -> some View {
        self
            .listSectionSpacing(Theme.step)
            .contentMargins(.top, Theme.step, for: .scrollContent)
            .environment(\.defaultMinListRowHeight, Theme.rowHeight)
            .padding(.horizontal, Theme.narrow)
            .background(Color(.systemGroupedBackground).ignoresSafeArea())
    }

    /// Корневой экран вкладки: то же самое плюс скрытая системная шапка —
    /// заголовок рисуем сами, чтобы отступ над ним был везде одинаковым.
    func themedScreen() -> some View {
        self
            .themedList()
            .toolbar(.hidden, for: .navigationBar)
    }

    /// Строка без карточки — для заголовка экрана и подобных «прозрачных» блоков.
    func plainRow() -> some View {
        self
            .listRowInsets(EdgeInsets(top: 0, leading: 0, bottom: 0, trailing: 0))
            .listRowBackground(Color.clear)
            .listRowSeparator(.hidden)
    }
}

/// Заголовок экрана и всё, что стоит с ним на одной линии (фильтры, «Править»).
struct ScreenHeader<Trailing: View>: View {
    let title: String
    /// Чем выровнять соседа справа: кружки-кнопки — по центру,
    /// текстовую кнопку — по нижнему краю заголовка.
    var align: VerticalAlignment = .center
    @ViewBuilder var trailing: Trailing

    var body: some View {
        HStack(alignment: align, spacing: Theme.gap) {
            Text(title)
                .font(Theme.screenTitle)
                .lineLimit(1)
                .minimumScaleFactor(0.7)
                // Крупный жирный шрифт выходит за строчную высоту: без запаса
                // список срезает верхний угол первой буквы.
                .padding(.vertical, 3)
                .fixedSize(horizontal: false, vertical: true)
            Spacer(minLength: Theme.gap)
            trailing
        }
        .frame(minHeight: Theme.headerHeight)
    }
}

extension ScreenHeader where Trailing == EmptyView {
    init(title: String) {
        self.init(title: title, align: .center, trailing: { EmptyView() })
    }
}

/// Круглая кнопка в шапке экрана — на одной линии с заголовком.
struct HeaderButton: View {
    let symbol: String
    var label: String = ""
    var filled: Bool = false
    var action: () -> Void

    var body: some View {
        Button(action: action) {
            Image(systemName: symbol)
                .font(.system(size: 16, weight: .semibold))
                .frame(width: 36, height: 36)
                .background(Color(.secondarySystemGroupedBackground), in: Circle())
                .foregroundStyle(filled ? Color.accentColor : Color.primary)
        }
        .buttonStyle(.plain)
        .accessibilityLabel(label.isEmpty ? symbol : label)
    }
}

/// Поле поиска. Своё, а не системное: системное живёт в шапке навигации,
/// которую мы прячем, и отступ до заголовка задавался бы не нами.
struct SearchField: View {
    @Binding var text: String
    var prompt: String = "Поиск"

    var body: some View {
        HStack(alignment: .center, spacing: Theme.gap) {
            Image(systemName: "magnifyingglass")
                .font(.system(size: 17, weight: .regular))
                .foregroundStyle(.secondary)
            TextField(prompt, text: $text)
                .font(Theme.body)
                .submitLabel(.search)
                .autocorrectionDisabled()
                .textInputAutocapitalization(.never)
            if !text.isEmpty {
                Button {
                    text = ""
                } label: {
                    Image(systemName: "xmark.circle.fill").foregroundStyle(.tertiary)
                }
                .buttonStyle(.plain)
                .accessibilityLabel("Очистить поиск")
            }
        }
        // Тот же фон, та же высота и то же скругление, что у строк списка:
        // поиск должен читаться как ещё один блок, а не как инородная плашка.
        .padding(.horizontal, Theme.rowInset)
        .frame(height: Theme.rowHeight)
        .background(Color(.secondarySystemGroupedBackground),
                    in: RoundedRectangle(cornerRadius: Theme.cardRadius, style: .continuous))
    }
}

/// Цветной квадратик с иконкой — как в «Настройках» iPhone
struct IconBadge: View {
    let symbol: String
    let color: Color
    var size: CGFloat = Theme.iconSize

    var body: some View {
        Image(systemName: symbol)
            .font(.system(size: size * 0.5, weight: .semibold))
            .foregroundStyle(.white)
            .frame(width: size, height: size)
            .background(color.gradient, in: RoundedRectangle(cornerRadius: size * 0.24, style: .continuous))
            .accessibilityHidden(true)
    }
}

/// Строка «иконка + текст» — одинаковая во всех списках
struct IconRow: View {
    let title: String
    let symbol: String
    let color: Color

    var body: some View {
        HStack(spacing: Theme.gap) {
            IconBadge(symbol: symbol, color: color)
            Text(title).font(Theme.body)
        }
    }
}

/// Строка-пояснение с иконкой (для экрана «О приложении»)
struct FeatureRow: View {
    let symbol: String
    let color: Color
    let title: String
    let text: String

    var body: some View {
        HStack(alignment: .top, spacing: Theme.gap) {
            IconBadge(symbol: symbol, color: color)
            VStack(alignment: .leading, spacing: 2) {
                Text(title).font(Theme.body)
                Text(text).font(Theme.caption).foregroundStyle(.secondary)
                    .fixedSize(horizontal: false, vertical: true)
            }
        }
    }
}

/// Подзаголовок раздела. Везде один: размер, цвет и отступ слева.
/// Системный стиль пишет такие заголовки капслоком и мельче — поэтому
/// задаём свой и отключаем изменение регистра.
struct SectionTitle: View {
    let text: String

    init(_ text: String) { self.text = text }

    var body: some View {
        Text(text)
            .font(Theme.sectionHeader)
            .foregroundStyle(.secondary)
            .textCase(nil)
            .padding(.bottom, 2)
    }
}
