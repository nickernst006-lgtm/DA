import Foundation

/// Даты в данных хранятся строками «ГГГГ-ММ-ДД» (как в N Finance):
/// они сортируются как сами даты, не зависят от часового пояса и читаются
/// человеком. На экране — «ДД.ММ.ГГГГ».
nonisolated enum DateFmt {
    private static func formatter(_ format: String) -> DateFormatter {
        let f = DateFormatter()
        f.calendar = Calendar(identifier: .gregorian)
        f.locale = Locale(identifier: "en_US_POSIX")
        f.timeZone = TimeZone.current
        f.dateFormat = format
        return f
    }

    private static let dayFormatter = formatter("yyyy-MM-dd")
    private static let timeFormatter = formatter("HH:mm")
    private static let displayFormatter = formatter("dd.MM.yyyy")

    /// Дата → «2026-09-26»
    static func dayString(_ date: Date) -> String {
        dayFormatter.string(from: date)
    }

    /// «2026-09-26» → дата (nil для пустой или кривой строки)
    static func day(from key: String) -> Date? {
        guard !key.isEmpty else { return nil }
        return dayFormatter.date(from: key)
    }

    /// Время → «14:30»
    static func timeString(_ date: Date) -> String {
        timeFormatter.string(from: date)
    }

    /// «14:30» → время
    static func time(from key: String) -> Date? {
        guard !key.isEmpty else { return nil }
        return timeFormatter.date(from: key)
    }

    /// «2026-09-26» → «26.09.2026». Непонятную строку возвращает как есть.
    static func display(_ key: String) -> String {
        guard let d = day(from: key) else { return key }
        return displayFormatter.string(from: d)
    }

    /// Дата и время для строк истории: «26.09.2026, 14:30»
    static func stamp(_ date: Date) -> String {
        displayFormatter.string(from: date) + ", " + timeFormatter.string(from: date)
    }
}
