import SwiftUI
import PDFKit
import UniformTypeIdentifiers

// Прикреплённые файлы: строка в списке и экран просмотра.
// Просмотр расшифровывает файл только в память и отпускает его при уходе
// с экрана или при блокировке — на диск открытое содержимое не пишется.

nonisolated enum FileKindInfo {
    static func type(of file: StoredFile) -> UTType? {
        UTType(file.typeIdentifier)
    }

    static func isPDF(_ file: StoredFile) -> Bool {
        type(of: file)?.conforms(to: .pdf) ?? false
    }

    static func isImage(_ file: StoredFile) -> Bool {
        type(of: file)?.conforms(to: .image) ?? false
    }

    static func symbol(for file: StoredFile) -> String {
        if isPDF(file) { return "doc.richtext.fill" }
        if isImage(file) { return "photo.fill" }
        return "doc.fill"
    }

    static func sizeText(_ bytes: Int) -> String {
        ByteCountFormatter.string(fromByteCount: Int64(bytes), countStyle: .file)
    }

    /// «PDF · 3 стр. · 1,2 МБ»
    static func detail(for file: StoredFile) -> String {
        var parts: [String] = []
        if let ext = type(of: file)?.preferredFilenameExtension {
            parts.append(ext.uppercased())
        }
        if let pages = file.pageCount, pages > 0 { parts.append("\(pages) стр.") }
        parts.append(sizeText(file.size))
        return parts.joined(separator: " · ")
    }
}

extension FileKindInfo {
    static func color(for file: StoredFile) -> Color {
        if isPDF(file) { return .red }
        if isImage(file) { return .pink }
        return .gray
    }
}

/// Строка файла: значок по типу, имя, формат и размер справа
struct FileRow: View {
    let file: StoredFile

    var body: some View {
        HStack(spacing: Theme.gap) {
            IconBadge(symbol: FileKindInfo.symbol(for: file), color: FileKindInfo.color(for: file))
            DirectoryRow(name: file.displayName, detail: FileKindInfo.detail(for: file))
        }
    }
}

/// Экран просмотра файла
struct FileViewerView: View {
    @EnvironmentObject var appState: AppState
    let cardId: UUID
    let fileId: UUID

    @State private var content: Data? = nil
    @State private var failure: String? = nil
    @State private var loading = true

    private var file: StoredFile? {
        guard let card = appState.data.card(cardId) else { return nil }
        for f in card.files where f.id == fileId { return f }
        return nil
    }

    var body: some View {
        ZStack {
            Color(.systemGroupedBackground).ignoresSafeArea()
            viewer
        }
        .navigationTitle(file?.displayName ?? "Файл")
        .navigationBarTitleDisplayMode(.inline)
        .task { await load() }
        .onDisappear { content = nil }
    }

    @ViewBuilder
    private var viewer: some View {
        if loading {
            ProgressView("Расшифровка…")
        } else if let failure {
            EmptyStateRow(symbol: "exclamationmark.triangle", title: "Файл не открылся", text: failure)
        } else if let data = content, let file {
            if FileKindInfo.isPDF(file) {
                PDFKitView(data: data)
                    .ignoresSafeArea(edges: .bottom)
            } else if FileKindInfo.isImage(file), let image = UIImage(data: data) {
                ZoomableImage(image: image)
            } else {
                EmptyStateRow(symbol: "doc.fill",
                              title: "Просмотр этого формата пока недоступен",
                              text: "Файл надёжно хранится в карточке. Просмотр документов Word, Excel и других форматов появится в следующих версиях.")
            }
        }
    }

    private func load() async {
        guard let file else {
            failure = "Файл не найден."
            loading = false
            return
        }
        do {
            content = try await appState.loadFile(file.blobName)
        } catch {
            failure = "Не удалось расшифровать файл: \(error.localizedDescription)"
        }
        loading = false
    }
}

/// PDF на весь экран — системный просмотрщик PDFKit, документ из памяти
struct PDFKitView: UIViewRepresentable {
    let data: Data

    func makeUIView(context: Context) -> PDFView {
        let view = PDFView()
        view.autoScales = true
        view.displayMode = .singlePageContinuous
        view.displayDirection = .vertical
        view.backgroundColor = .systemGroupedBackground
        view.document = PDFDocument(data: data)
        return view
    }

    func updateUIView(_ uiView: PDFView, context: Context) {}
}

/// Картинка с увеличением щипком и двойным касанием
struct ZoomableImage: UIViewRepresentable {
    let image: UIImage

    @MainActor
    final class Coordinator: NSObject, UIScrollViewDelegate {
        var imageView: UIImageView?
        func viewForZooming(in scrollView: UIScrollView) -> UIView? { imageView }

        @objc func doubleTap(_ recognizer: UITapGestureRecognizer) {
            guard let scroll = recognizer.view as? UIScrollView else { return }
            let target: CGFloat = scroll.zoomScale > 1.01 ? 1 : 2.5
            scroll.setZoomScale(target, animated: true)
        }
    }

    func makeCoordinator() -> Coordinator { Coordinator() }

    func makeUIView(context: Context) -> UIScrollView {
        let scroll = UIScrollView()
        scroll.delegate = context.coordinator
        scroll.minimumZoomScale = 1
        scroll.maximumZoomScale = 6
        scroll.showsHorizontalScrollIndicator = false
        scroll.showsVerticalScrollIndicator = false
        scroll.backgroundColor = .systemGroupedBackground

        let imageView = UIImageView(image: image)
        imageView.contentMode = .scaleAspectFit
        imageView.translatesAutoresizingMaskIntoConstraints = false
        scroll.addSubview(imageView)
        NSLayoutConstraint.activate([
            imageView.leadingAnchor.constraint(equalTo: scroll.contentLayoutGuide.leadingAnchor),
            imageView.trailingAnchor.constraint(equalTo: scroll.contentLayoutGuide.trailingAnchor),
            imageView.topAnchor.constraint(equalTo: scroll.contentLayoutGuide.topAnchor),
            imageView.bottomAnchor.constraint(equalTo: scroll.contentLayoutGuide.bottomAnchor),
            imageView.widthAnchor.constraint(equalTo: scroll.frameLayoutGuide.widthAnchor),
            imageView.heightAnchor.constraint(equalTo: scroll.frameLayoutGuide.heightAnchor),
        ])
        context.coordinator.imageView = imageView

        let tap = UITapGestureRecognizer(target: context.coordinator, action: #selector(Coordinator.doubleTap(_:)))
        tap.numberOfTapsRequired = 2
        scroll.addGestureRecognizer(tap)
        return scroll
    }

    func updateUIView(_ uiView: UIScrollView, context: Context) {}
}
