import SwiftUI
import PhotosUI
import PDFKit
import UniformTypeIdentifiers

// Вкладка «Форма» (ТЗ, раздел 5.1): создание новой карточки и правка
// существующей. После сохранения — переход в «Хранилище» к этой карточке.
//
// Порядок полей: вид (базовая / типовая) → тип для типовой → лицо → папка →
// название → поля шаблона → прикреплённые файлы → заметка.
// Лица и папки здесь только выбираются: лица заводятся в справочнике «Лица»,
// папки — там же или в хранилище. Статус карточки меняется только при правке.
//
// Файлы шифруются и пишутся на диск сразу при добавлении, чтобы не держать
// в памяти десятки мегабайт. Если форму очистили — они стираются сразу;
// если приложение заблокировалось посреди заполнения — стираются при
// следующем входе как ни на что не ссылающиеся (AppState.cleanOrphanBlobs).

/// Черновик карточки в форме
struct CardDraft: Equatable {
    /// Типовая карточка (по шаблону) или базовая
    var isTyped: Bool = false
    /// Для базовой — «basic»; для типовой — id шаблона или "" пока не выбран
    var typeId: String = CardTemplate.basicId
    var personId: UUID? = nil
    var folderId: UUID? = nil
    var title: String = ""
    var status: CardStatus = .active
    var fields: [String: String] = [:]
    var note: String = ""
    /// Только файлы, которые остаются в карточке (без лежащих в корзине)
    var files: [StoredFile] = []
}

struct FormView: View {
    @EnvironmentObject var appState: AppState
    @Binding var editState: EditState?
    var onSaved: (UUID) -> Void

    @State private var draft = CardDraft()
    @State private var editingId: UUID? = nil
    /// Блобы, созданные в этом черновике и ещё не сохранённые в карточку
    @State private var newBlobs: Set<String> = []
    /// Пользователь сам правил название — тип его больше не перезаписывает
    @State private var titleEdited = false

    @State private var showUploadMenu = false
    @State private var showScanner = false
    @State private var showPhotoPicker = false
    @State private var photoItems: [PhotosPickerItem] = []
    @State private var showFileImporter = false
    @State private var cameraUnavailable = false
    @State private var isImporting = false
    @State private var importError: String? = nil

    @State private var renamingFileId: UUID? = nil
    @State private var renameText = ""
    @State private var confirmDiscard = false

    /// Выбранный шаблон; nil — типовая, но тип ещё не выбран
    private var chosenTemplate: CardTemplate? {
        if !draft.isTyped { return CardTemplate.basic }
        for t in CardTemplate.typed where t.id == draft.typeId { return t }
        return nil
    }

    private var hasContent: Bool {
        editingId != nil || !draft.title.isEmpty || !draft.files.isEmpty
            || !draft.fields.isEmpty || !draft.note.isEmpty
    }

    private var canSave: Bool {
        guard draft.folderId != nil, chosenTemplate != nil else { return false }
        return !draft.title.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
    }

    var body: some View {
        List {
            Section {
                ScreenHeader(title: editingId == nil ? "Новая карточка" : "Правка карточки") {
                    if hasContent {
                        HeaderButton(symbol: "xmark", label: "Очистить форму") { confirmDiscard = true }
                    }
                }
            }
            .plainRow()

            kindSection
            locationSection
            mainSection
            if let template = chosenTemplate, !template.fields.isEmpty {
                fieldsSection(template)
            }
            filesSection
            noteSection
            saveSection
        }
        .themedScreen()
        .onAppear { applyEditState() }
        .onChange(of: editState) { _, _ in applyEditState() }
        .onChange(of: photoItems) { _, items in importPhotos(items) }
        .confirmationDialog("Загрузить файл", isPresented: $showUploadMenu, titleVisibility: .visible) {
            Button("Сканировать") { openAfterMenu { openScanner() } }
            Button("Из Фото") { openAfterMenu { showPhotoPicker = true } }
            Button("Из Файлов") { openAfterMenu { showFileImporter = true } }
            Button("Отмена", role: .cancel) {}
        }
        .photosPicker(isPresented: $showPhotoPicker, selection: $photoItems,
                      maxSelectionCount: 20, matching: .images)
        .fileImporter(isPresented: $showFileImporter,
                      allowedContentTypes: [.item],
                      allowsMultipleSelection: true) { result in
            switch result {
            case .success(let urls): importFiles(urls)
            case .failure(let error): importError = "Не удалось открыть файл: \(error.localizedDescription)"
            }
        }
        .fullScreenCover(isPresented: $showScanner) {
            ScanFlowView(onDone: { pages in
                showScanner = false
                importScan(pages)
            }, onCancel: {
                showScanner = false
            })
        }
        .alert("Камера недоступна", isPresented: $cameraUnavailable) {
            Button("OK", role: .cancel) {}
        } message: {
            Text("На этом устройстве сканер документов не поддерживается. Загрузите снимок из Фото или файл.")
        }
        .alert("Имя файла", isPresented: Binding(
            get: { renamingFileId != nil },
            set: { if !$0 { renamingFileId = nil } }
        )) {
            TextField("Имя файла", text: $renameText)
            Button("Отмена", role: .cancel) { renamingFileId = nil }
            Button("Сохранить") { applyRename() }
        }
        .confirmationDialog("Очистить форму?", isPresented: $confirmDiscard, titleVisibility: .visible) {
            Button("Очистить", role: .destructive) { discardDraft() }
            Button("Отмена", role: .cancel) {}
        } message: {
            Text(editingId == nil
                 ? "Введённые данные и добавленные файлы будут удалены."
                 : "Правка будет отменена, карточка останется как была.")
        }
    }

    // MARK: - Разделы формы

    /// Базовая или типовая; для типовой — выбор типа
    private var kindSection: some View {
        Section {
            Picker("Вид карточки", selection: kindBinding) {
                Text("Базовая").tag(false)
                Text("Типовая").tag(true)
            }
            .pickerStyle(.segmented)
            .accessibilityIdentifier("cardKind")

            if draft.isTyped {
                Picker("Тип", selection: typeBinding) {
                    Text("Не выбран").tag("")
                    ForEach(CardTemplate.typed) { t in
                        Text(t.title).tag(t.id)
                    }
                }
                .pickerStyle(.menu)
                .font(Theme.body)
                .accessibilityIdentifier("cardType")
            }
        }
    }

    /// Лицо и папка — только выбор
    @ViewBuilder
    private var locationSection: some View {
        let persons = appState.data.activePersons
        Section {
            if persons.isEmpty {
                Text("Лиц пока нет. Добавьте лицо во вкладке «Справочники» → «Лица».")
                    .font(Theme.caption)
                    .foregroundStyle(.secondary)
            } else {
                Picker("Лицо", selection: personBinding) {
                    Text("Не выбрано").tag(UUID?.none)
                    ForEach(persons) { p in
                        Text(p.name).tag(Optional(p.id))
                    }
                }
                .pickerStyle(.menu)
                .font(Theme.body)
                .accessibilityIdentifier("cardPerson")
            }

            if let personId = draft.personId {
                let folders = appState.data.activeFolders(of: personId)
                if folders.isEmpty {
                    Text("У этого лица ещё нет папок. Создайте папку в справочнике «Лица» или в хранилище.")
                        .font(Theme.caption)
                        .foregroundStyle(.secondary)
                } else {
                    Picker("Папка", selection: $draft.folderId) {
                        Text("Не выбрана").tag(UUID?.none)
                        ForEach(folders) { f in
                            Text(appState.data.folderTitle(f)).tag(Optional(f.id))
                        }
                    }
                    .pickerStyle(.menu)
                    .font(Theme.body)
                    .accessibilityIdentifier("cardFolder")
                }
            }
        }
    }

    private var mainSection: some View {
        Section(header: SectionTitle("Карточка")) {
            LabeledField(title: "Название") {
                TextField("Договор аренды", text: titleBinding)
                    .font(Theme.body)
                    .accessibilityIdentifier("cardTitle")
            }
            // Статус меняется только в режиме правки: новая карточка всегда
            // создаётся действительной.
            if editingId != nil {
                Picker("Статус", selection: $draft.status) {
                    ForEach(CardStatus.allCases, id: \.self) { status in
                        Text(status.title).tag(status)
                    }
                }
                .pickerStyle(.segmented)
                .accessibilityIdentifier("cardStatusPicker")
            }
        }
    }

    private func fieldsSection(_ template: CardTemplate) -> some View {
        Section(header: SectionTitle(template.title)) {
            ForEach(template.fields, id: \.key) { spec in
                FieldEditorRow(spec: spec, value: fieldBinding(spec.key))
            }
        }
    }

    private var filesSection: some View {
        Section {
            ForEach(draft.files) { file in
                FileRow(file: file)
                    .swipeActions(edge: .trailing) {
                        Button(role: .destructive) {
                            removeFile(file)
                        } label: {
                            Label("Убрать", systemImage: "trash")
                        }
                        Button {
                            renameText = file.displayName
                            renamingFileId = file.id
                        } label: {
                            Label("Имя", systemImage: "pencil")
                        }
                        .tint(.blue)
                    }
            }
            Button {
                showUploadMenu = true
            } label: {
                IconRow(title: "Загрузить", symbol: "square.and.arrow.down.fill", color: .accentColor)
                    .foregroundStyle(Color.primary)
            }
            .disabled(isImporting)
            .accessibilityIdentifier("uploadFile")
            if isImporting {
                HStack(spacing: Theme.gap) {
                    ProgressView()
                    Text("Шифрование…").font(Theme.caption).foregroundStyle(.secondary)
                }
            }
            if let importError {
                Text(importError).font(Theme.caption).foregroundStyle(.red)
            }
        } header: {
            SectionTitle("Прикреплённые файлы")
        } footer: {
            if !draft.files.isEmpty {
                Text("Смахните файл влево, чтобы переименовать или убрать. Оригинал в Фото или «Файлах» остаётся на месте — при желании удалите его сами.")
            }
        }
    }

    private var noteSection: some View {
        Section {
            LabeledField(title: "Заметка") {
                TextField("Необязательно", text: $draft.note, axis: .vertical)
                    .font(Theme.body)
                    .lineLimit(1...8)
            }
        }
    }

    private var saveSection: some View {
        Section {
            Button {
                save()
            } label: {
                Text(editingId == nil ? "Сохранить карточку" : "Сохранить изменения")
                    .font(Theme.subtitle)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 6)
            }
            .buttonStyle(.borderedProminent)
            .buttonBorderShape(.capsule)
            .controlSize(.large)
            .disabled(!canSave || isImporting)
            .accessibilityIdentifier("saveCard")

            if !canSave {
                Text(saveHint)
                    .font(Theme.caption)
                    .foregroundStyle(.secondary)
                    .frame(maxWidth: .infinity)
                    .multilineTextAlignment(.center)
            }
        }
        .plainRow()
    }

    /// Что мешает сохранить — по первому незаполненному шагу
    private var saveHint: String {
        if chosenTemplate == nil { return "Чтобы сохранить, выберите тип карточки." }
        if draft.personId == nil { return "Чтобы сохранить, выберите лицо." }
        if draft.folderId == nil { return "Чтобы сохранить, выберите папку." }
        return "Чтобы сохранить, укажите название."
    }

    // MARK: - Привязки

    private var kindBinding: Binding<Bool> {
        Binding(get: { draft.isTyped }, set: { typed in
            guard typed != draft.isTyped else { return }
            let oldTitle = chosenTemplate?.title ?? ""
            draft.isTyped = typed
            draft.typeId = typed ? "" : CardTemplate.basicId
            if !titleEdited || draft.title == oldTitle {
                draft.title = ""
                titleEdited = false
            }
        })
    }

    private var typeBinding: Binding<String> {
        Binding(get: { draft.typeId }, set: { newValue in
            let oldTitle = chosenTemplate?.title ?? ""
            draft.typeId = newValue
            // Название следует за типом, пока пользователь его не менял
            if !titleEdited || draft.title == oldTitle || draft.title.isEmpty {
                let picked: CardTemplate = CardTemplate.find(newValue)
                draft.title = newValue.isEmpty ? "" : picked.title
                titleEdited = false
            }
        })
    }

    private var titleBinding: Binding<String> {
        Binding(get: { draft.title }, set: { newValue in
            draft.title = newValue
            titleEdited = true
        })
    }

    private var personBinding: Binding<UUID?> {
        Binding(get: { draft.personId }, set: { newValue in
            draft.personId = newValue
            // Папка другого лица здесь уже не подходит
            if let folderId = draft.folderId, appState.data.folder(folderId)?.personId != newValue {
                draft.folderId = nil
            }
        })
    }

    private func fieldBinding(_ key: String) -> Binding<String> {
        Binding(get: { draft.fields[key] ?? "" }, set: { newValue in
            if newValue.isEmpty {
                draft.fields.removeValue(forKey: key)
            } else {
                draft.fields[key] = newValue
            }
        })
    }

    // MARK: - Открытие правки

    private func applyEditState() {
        guard let state = editState else { return }
        editState = nil
        switch state {
        case .edit(let id):
            guard let card = appState.data.card(id) else { return }
            discardNewBlobs()
            var active: [StoredFile] = []
            for f in card.files where f.deletion == nil { active.append(f) }
            let folder = appState.data.folder(card.folderId)
            let typed = card.typeId != CardTemplate.basicId
            draft = CardDraft(isTyped: typed,
                              typeId: card.typeId,
                              personId: folder?.personId,
                              folderId: card.folderId,
                              title: card.title,
                              status: card.status,
                              fields: card.fields,
                              note: card.note,
                              files: active)
            editingId = id
            titleEdited = true
            importError = nil
        case .newIn(let folderId):
            if editingId != nil {
                discardNewBlobs()
                draft = CardDraft()
                editingId = nil
                titleEdited = false
            }
            draft.folderId = folderId
            draft.personId = appState.data.folder(folderId)?.personId
        }
    }

    // MARK: - Загрузка файлов

    /// Окно выбора открываем после того, как закроется меню «Загрузить»:
    /// два окна в одном кадре iOS не показывает.
    private func openAfterMenu(_ action: @escaping () -> Void) {
        Task { @MainActor in
            try? await Task.sleep(nanoseconds: 350_000_000)
            action()
        }
    }

    private func openScanner() {
        if DocumentCamera.isAvailable {
            showScanner = true
        } else {
            cameraUnavailable = true
        }
    }

    private func nextNumber(for source: FileSource) -> Int {
        var n = 0
        for f in draft.files where f.source == source { n += 1 }
        return n + 1
    }

    private func importScan(_ pages: [UIImage]) {
        guard !pages.isEmpty else { return }
        isImporting = true
        importError = nil
        let number = nextNumber(for: .camera)
        Task { @MainActor in
            // Сборка PDF — в фоне: на десятке страниц это заметные секунды
            let data: Data = await Task.detached(priority: .userInitiated) {
                ScanImages.makePDF(pages)
            }.value
            addFile(data: data, name: "Скан \(number).pdf", type: .pdf, source: .camera)
            isImporting = false
        }
    }

    private func importPhotos(_ items: [PhotosPickerItem]) {
        guard !items.isEmpty else { return }
        photoItems = []
        isImporting = true
        importError = nil
        Task { @MainActor in
            var number = nextNumber(for: .photos)
            for item in items {
                do {
                    guard let data = try await item.loadTransferable(type: Data.self) else { continue }
                    let type: UTType = item.supportedContentTypes.first ?? .jpeg
                    let ext = type.preferredFilenameExtension ?? "jpg"
                    addFile(data: data, name: "Фото \(number).\(ext)", type: type, source: .photos)
                    number += 1
                } catch {
                    importError = "Не удалось загрузить фото: \(error.localizedDescription)"
                }
            }
            isImporting = false
        }
    }

    private func importFiles(_ urls: [URL]) {
        importError = nil
        for url in urls {
            let access = url.startAccessingSecurityScopedResource()
            defer { if access { url.stopAccessingSecurityScopedResource() } }
            do {
                let data = try Data(contentsOf: url)
                let type: UTType = UTType(filenameExtension: url.pathExtension) ?? .data
                addFile(data: data, name: url.lastPathComponent, type: type, source: .files)
            } catch {
                importError = "Не удалось прочитать «\(url.lastPathComponent)»: \(error.localizedDescription)"
            }
        }
    }

    private func addFile(data: Data, name: String, type: UTType, source: FileSource) {
        do {
            let blob = try appState.storeFile(data)
            newBlobs.insert(blob)
            var pages: Int? = nil
            if type.conforms(to: .pdf) { pages = PDFDocument(data: data)?.pageCount }
            let file = StoredFile(displayName: name, originalName: name,
                                  typeIdentifier: type.identifier, size: data.count,
                                  pageCount: pages, blobName: blob, source: source)
            draft.files.append(file)
        } catch {
            importError = "Не удалось сохранить файл: \(error.localizedDescription)"
        }
    }

    /// Убрать файл из черновика. Только что добавленный стирается сразу;
    /// уже сохранённый уйдёт в корзину при сохранении карточки.
    private func removeFile(_ file: StoredFile) {
        if newBlobs.contains(file.blobName) {
            appState.deleteBlob(file.blobName)
            newBlobs.remove(file.blobName)
        }
        draft.files.removeAll { $0.id == file.id }
    }

    private func applyRename() {
        let name = renameText.trimmingCharacters(in: .whitespacesAndNewlines)
        defer { renamingFileId = nil }
        guard !name.isEmpty, let id = renamingFileId,
              let i = draft.files.firstIndex(where: { $0.id == id }) else { return }
        draft.files[i].displayName = name
    }

    private func discardNewBlobs() {
        for blob in newBlobs { appState.deleteBlob(blob) }
        newBlobs = []
    }

    /// Новый пустой черновик; выбор лица и папки сохраняется — так удобнее
    /// заводить подряд несколько документов в одну папку.
    private func resetDraft() {
        let keepPerson = draft.personId
        let keepFolder = draft.folderId
        draft = CardDraft()
        draft.personId = keepPerson
        draft.folderId = keepFolder
        editingId = nil
        titleEdited = false
        importError = nil
    }

    private func discardDraft() {
        discardNewBlobs()
        resetDraft()
    }

    // MARK: - Сохранение

    /// Только поля выбранного шаблона и только заполненные
    private func cleanedFields(_ template: CardTemplate) -> [String: String] {
        var out: [String: String] = [:]
        for spec in template.fields {
            let v = (draft.fields[spec.key] ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
            if !v.isEmpty { out[spec.key] = v }
        }
        return out
    }

    private func save() {
        guard canSave, let folderId = draft.folderId, let template = chosenTemplate else { return }
        let title = draft.title.trimmingCharacters(in: .whitespacesAndNewlines)
        let now = Date()
        let savedId: UUID

        if let id = editingId, let old = appState.data.card(id) {
            var card = old
            card.typeId = template.id
            card.folderId = folderId
            card.title = title
            card.status = draft.status
            card.fields = cleanedFields(template)
            card.note = draft.note
            // Файлы: оставшиеся в черновике + то, что уже было в корзине +
            // убранные сейчас (они уходят в корзину одним пакетом).
            let batch = UUID()
            var keptIds: Set<UUID> = []
            for f in draft.files { keptIds.insert(f.id) }
            var merged: [StoredFile] = draft.files
            for f in old.files {
                if f.deletion != nil {
                    merged.append(f)
                } else if !keptIds.contains(f.id) {
                    var trashed = f
                    trashed.deletion = Deletion(date: now, batchId: batch)
                    merged.append(trashed)
                }
            }
            card.files = merged
            card.updatedAt = now
            let changes = appState.data.cardChanges(old: old, new: card)
            appState.data.updateCard(card)
            if !changes.isEmpty {
                appState.data.log(.cardEdited, object: title, details: changes)
            }
            savedId = id
        } else {
            let card = DocumentCard(folderId: folderId, typeId: template.id, title: title,
                                    status: .active, fields: cleanedFields(template),
                                    note: draft.note, files: draft.files,
                                    createdAt: now, updatedAt: now)
            appState.data.cards.append(card)
            appState.data.log(.cardCreated, object: title, details: appState.data.cardSnapshot(card))
            savedId = card.id
        }

        appState.persist()
        guard appState.saveError == nil else { return }
        newBlobs = []
        resetDraft()
        onSaved(savedId)
    }
}
