import SwiftUI
import UIKit
import VisionKit

// Сканирование (ТЗ, раздел 7):
//   1. системная камера-сканер Apple — сама находит края листа, позволяет
//      переснять страницу и подвинуть углы; снимки нигде не сохраняются,
//      кроме памяти приложения;
//   2. экран проверки: просмотр, поворот, обрезка, порядок, удаление,
//      пересъёмка страницы, досъёмка новых;
//   3. «Готово» → один PDF на все страницы → шифрование → файл в карточке.

// MARK: - Камера

/// Обёртка над VNDocumentCameraViewController
struct DocumentCamera: UIViewControllerRepresentable {
    var onFinish: ([UIImage]) -> Void
    var onCancel: () -> Void

    static var isAvailable: Bool { VNDocumentCameraViewController.isSupported }

    func makeCoordinator() -> Coordinator { Coordinator(onFinish: onFinish, onCancel: onCancel) }

    func makeUIViewController(context: Context) -> VNDocumentCameraViewController {
        let vc = VNDocumentCameraViewController()
        vc.delegate = context.coordinator
        return vc
    }

    func updateUIViewController(_ uiViewController: VNDocumentCameraViewController, context: Context) {}

    final class Coordinator: NSObject, VNDocumentCameraViewControllerDelegate {
        let onFinish: ([UIImage]) -> Void
        let onCancel: () -> Void

        init(onFinish: @escaping ([UIImage]) -> Void, onCancel: @escaping () -> Void) {
            self.onFinish = onFinish
            self.onCancel = onCancel
        }

        func documentCameraViewController(_ controller: VNDocumentCameraViewController,
                                          didFinishWith scan: VNDocumentCameraScan) {
            var pages: [UIImage] = []
            for i in 0..<scan.pageCount { pages.append(scan.imageOfPage(at: i)) }
            onFinish(pages)
        }

        func documentCameraViewControllerDidCancel(_ controller: VNDocumentCameraViewController) {
            onCancel()
        }

        func documentCameraViewController(_ controller: VNDocumentCameraViewController,
                                          didFailWithError error: Error) {
            onCancel()
        }
    }
}

// MARK: - Обработка страниц

enum ScanImages {
    /// Поворот на 90° по часовой стрелке
    static func rotated(_ image: UIImage) -> UIImage {
        let size = CGSize(width: image.size.height, height: image.size.width)
        let format = UIGraphicsImageRendererFormat()
        format.scale = image.scale
        let renderer = UIGraphicsImageRenderer(size: size, format: format)
        return renderer.image { ctx in
            let c = ctx.cgContext
            c.translateBy(x: size.width / 2, y: size.height / 2)
            c.rotate(by: .pi / 2)
            let rect = CGRect(x: -image.size.width / 2, y: -image.size.height / 2,
                              width: image.size.width, height: image.size.height)
            image.draw(in: rect)
        }
    }

    /// Обрезка по прямоугольнику в долях (0…1) от размера картинки
    static func cropped(_ image: UIImage, to unit: CGRect) -> UIImage {
        let w = image.size.width
        let h = image.size.height
        let rect = CGRect(x: unit.minX * w, y: unit.minY * h, width: unit.width * w, height: unit.height * h)
        guard rect.width >= 1, rect.height >= 1 else { return image }
        let format = UIGraphicsImageRendererFormat()
        format.scale = image.scale
        let renderer = UIGraphicsImageRenderer(size: rect.size, format: format)
        return renderer.image { _ in
            image.draw(at: CGPoint(x: -rect.minX, y: -rect.minY))
        }
    }

    /// Уменьшение до разумного размера: больше 2200 точек по длинной стороне
    /// для документа не нужно, а файл растёт в разы.
    static func downscaled(_ image: UIImage, maxSide: CGFloat = 2200) -> UIImage {
        let longest = max(image.size.width, image.size.height)
        guard longest > maxSide else { return image }
        let k = maxSide / longest
        let size = CGSize(width: (image.size.width * k).rounded(), height: (image.size.height * k).rounded())
        let format = UIGraphicsImageRendererFormat()
        format.scale = 1
        let renderer = UIGraphicsImageRenderer(size: size, format: format)
        return renderer.image { _ in
            image.draw(in: CGRect(origin: .zero, size: size))
        }
    }

    /// Один PDF на все страницы. Ширина страницы — как у A4 (595 pt),
    /// высота — по пропорциям снимка. Картинки сжимаются в JPEG.
    static func makePDF(_ pages: [UIImage]) -> Data {
        let pageWidth: CGFloat = 595
        let renderer = UIGraphicsPDFRenderer(bounds: CGRect(x: 0, y: 0, width: 595, height: 842))
        return renderer.pdfData { ctx in
            for page in pages {
                let small = downscaled(page)
                var drawable = small
                if let jpeg = small.jpegData(compressionQuality: 0.75), let decoded = UIImage(data: jpeg) {
                    drawable = decoded
                }
                let ratio = drawable.size.height / max(drawable.size.width, 1)
                let bounds = CGRect(x: 0, y: 0, width: pageWidth, height: pageWidth * ratio)
                ctx.beginPage(withBounds: bounds, pageInfo: [:])
                drawable.draw(in: bounds)
            }
        }
    }
}

// MARK: - Экран сканирования и проверки

/// Одна страница с устойчивым идентификатором для списка
struct ScanPage: Identifiable {
    let id = UUID()
    var image: UIImage
}

/// Весь путь сканирования: камера → проверка → готовые страницы.
/// Открывается на весь экран; результат отдаётся в onDone.
struct ScanFlowView: View {
    var onDone: ([UIImage]) -> Void
    var onCancel: () -> Void

    @State private var pages: [ScanPage] = []
    @State private var showCamera = false
    @State private var cameraOpenedOnce = false
    /// Какую страницу переснимаем; nil — досъёмка в конец
    @State private var retakeId: UUID? = nil
    @State private var cropPage: ScanPage? = nil
    @State private var confirmCancel = false

    var body: some View {
        NavigationStack {
            List {
                if pages.isEmpty {
                    Section {
                        EmptyStateRow(symbol: "doc.viewfinder", title: "Страниц пока нет",
                                      text: "Отсканируйте документ кнопкой ниже.")
                    }
                    .plainRow()
                } else {
                    Section {
                        ForEach(Array(pages.enumerated()), id: \.element.id) { item in
                            pageRow(index: item.offset, page: item.element)
                        }
                    } header: {
                        SectionTitle("Проверьте страницы")
                    } footer: {
                        Text("Поверните, обрежьте, поменяйте порядок или переснимите страницу. Всё сохранится одним PDF.")
                    }
                }
                Section {
                    Button {
                        retakeId = nil
                        showCamera = true
                    } label: {
                        IconRow(title: pages.isEmpty ? "Сканировать" : "Досканировать страницы",
                                symbol: "doc.viewfinder", color: .accentColor)
                            .foregroundStyle(Color.primary)
                    }
                    .accessibilityIdentifier("scanMore")
                }
            }
            .themedList()
            .navigationTitle("Сканирование")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Отмена") {
                        if pages.isEmpty { onCancel() } else { confirmCancel = true }
                    }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Готово") { onDone(pages.map { $0.image }) }
                        .disabled(pages.isEmpty)
                        .accessibilityIdentifier("scanDone")
                }
            }
            .confirmationDialog("Выбросить отсканированное?", isPresented: $confirmCancel, titleVisibility: .visible) {
                Button("Выбросить", role: .destructive) { onCancel() }
                Button("Продолжить проверку", role: .cancel) {}
            }
        }
        // Камеру открываем сразу, но после того, как сам этот экран
        // досмотрит своё появление: два показа в одном кадре iOS не принимает.
        .task {
            guard !cameraOpenedOnce else { return }
            cameraOpenedOnce = true
            try? await Task.sleep(nanoseconds: 450_000_000)
            if pages.isEmpty { showCamera = true }
        }
        .fullScreenCover(isPresented: $showCamera) {
            DocumentCamera(onFinish: { images in
                receive(images)
                showCamera = false
            }, onCancel: {
                showCamera = false
                retakeId = nil
            })
            .ignoresSafeArea()
        }
        .fullScreenCover(item: $cropPage) { page in
            CropView(image: page.image, onDone: { cropped in
                replace(page.id, with: cropped)
                cropPage = nil
            }, onCancel: {
                cropPage = nil
            })
        }
    }

    private func pageRow(index: Int, page: ScanPage) -> some View {
        VStack(alignment: .leading, spacing: Theme.gap) {
            HStack(alignment: .top, spacing: Theme.gap) {
                Image(uiImage: page.image)
                    .resizable()
                    .scaledToFit()
                    .frame(maxWidth: 110, maxHeight: 150)
                    .clipShape(RoundedRectangle(cornerRadius: 6, style: .continuous))
                    .overlay(RoundedRectangle(cornerRadius: 6, style: .continuous)
                        .stroke(Color(.separator), lineWidth: 0.5))
                VStack(alignment: .leading, spacing: 4) {
                    Text("Страница \(index + 1)").font(Theme.subtitle)
                    Text("из \(pages.count)").font(Theme.caption).foregroundStyle(.secondary)
                }
                Spacer(minLength: 0)
            }
            HStack(spacing: 0) {
                pageButton("rotate.right", "Повернуть") { rotate(page.id) }
                pageButton("crop", "Обрезать") { cropPage = page }
                pageButton("arrow.triangle.2.circlepath.camera", "Переснять") {
                    retakeId = page.id
                    showCamera = true
                }
                pageButton("arrow.up", "Выше") { move(page.id, by: -1) }
                    .disabled(index == 0)
                pageButton("arrow.down", "Ниже") { move(page.id, by: 1) }
                    .disabled(index == pages.count - 1)
                pageButton("trash", "Удалить") { remove(page.id) }
                    .foregroundStyle(.red)
            }
        }
        .padding(.vertical, 6)
    }

    private func pageButton(_ symbol: String, _ label: String, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Image(systemName: symbol)
                .font(.system(size: 17, weight: .regular))
                .frame(maxWidth: .infinity, minHeight: 36)
        }
        .buttonStyle(.borderless)
        .accessibilityLabel(label)
    }

    private func receive(_ images: [UIImage]) {
        var incoming: [ScanPage] = []
        for image in images { incoming.append(ScanPage(image: image)) }
        guard !incoming.isEmpty else { retakeId = nil; return }
        if let id = retakeId, let i = pages.firstIndex(where: { $0.id == id }) {
            pages.remove(at: i)
            pages.insert(contentsOf: incoming, at: i)
        } else {
            pages.append(contentsOf: incoming)
        }
        retakeId = nil
    }

    private func replace(_ id: UUID, with image: UIImage) {
        guard let i = pages.firstIndex(where: { $0.id == id }) else { return }
        pages[i].image = image
    }

    private func rotate(_ id: UUID) {
        guard let i = pages.firstIndex(where: { $0.id == id }) else { return }
        pages[i].image = ScanImages.rotated(pages[i].image)
    }

    private func move(_ id: UUID, by delta: Int) {
        guard let i = pages.firstIndex(where: { $0.id == id }) else { return }
        let j = i + delta
        guard j >= 0, j < pages.count else { return }
        pages.swapAt(i, j)
    }

    private func remove(_ id: UUID) {
        pages.removeAll { $0.id == id }
    }
}

// MARK: - Обрезка

/// Обрезка прямоугольником: тянуть за четыре угла
struct CropView: View {
    let image: UIImage
    var onDone: (UIImage) -> Void
    var onCancel: () -> Void

    /// Прямоугольник обрезки в долях от картинки
    @State private var unit = CGRect(x: 0.04, y: 0.04, width: 0.92, height: 0.92)

    private enum Corner: CaseIterable, Identifiable {
        case topLeft, topRight, bottomLeft, bottomRight
        var id: Int {
            switch self {
            case .topLeft: return 0
            case .topRight: return 1
            case .bottomLeft: return 2
            case .bottomRight: return 3
            }
        }
    }

    var body: some View {
        NavigationStack {
            GeometryReader { geo in
                let fit = fitRect(for: image.size, in: geo.size)
                ZStack {
                    Color.black
                    Image(uiImage: image)
                        .resizable()
                        .frame(width: fit.width, height: fit.height)
                        .position(x: fit.midX, y: fit.midY)
                    Rectangle()
                        .stroke(Color.white, lineWidth: 2)
                        .frame(width: unit.width * fit.width, height: unit.height * fit.height)
                        .position(x: fit.minX + unit.midX * fit.width, y: fit.minY + unit.midY * fit.height)
                    ForEach(Corner.allCases) { corner in
                        Circle()
                            .fill(Color.white)
                            .frame(width: 26, height: 26)
                            .shadow(radius: 2)
                            .position(point(of: corner, in: fit))
                            .gesture(
                                DragGesture(coordinateSpace: .named("crop"))
                                    .onChanged { value in drag(corner, to: value.location, in: fit) }
                            )
                    }
                }
                .coordinateSpace(name: "crop")
            }
            .ignoresSafeArea(edges: .bottom)
            .navigationTitle("Обрезка")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Отмена") { onCancel() }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Обрезать") { onDone(ScanImages.cropped(image, to: unit)) }
                }
                ToolbarItem(placement: .bottomBar) {
                    Button("Сбросить") { unit = CGRect(x: 0, y: 0, width: 1, height: 1) }
                }
            }
        }
    }

    /// Где картинка лежит на экране при вписывании с сохранением пропорций
    private func fitRect(for size: CGSize, in box: CGSize) -> CGRect {
        let padding: CGFloat = 24
        let availW = max(box.width - padding * 2, 1)
        let availH = max(box.height - padding * 2, 1)
        let k = min(availW / max(size.width, 1), availH / max(size.height, 1))
        let w = size.width * k
        let h = size.height * k
        return CGRect(x: (box.width - w) / 2, y: (box.height - h) / 2, width: w, height: h)
    }

    private func point(of corner: Corner, in fit: CGRect) -> CGPoint {
        let x: CGFloat
        let y: CGFloat
        switch corner {
        case .topLeft: x = unit.minX; y = unit.minY
        case .topRight: x = unit.maxX; y = unit.minY
        case .bottomLeft: x = unit.minX; y = unit.maxY
        case .bottomRight: x = unit.maxX; y = unit.maxY
        }
        return CGPoint(x: fit.minX + x * fit.width, y: fit.minY + y * fit.height)
    }

    private func drag(_ corner: Corner, to location: CGPoint, in fit: CGRect) {
        let nx = min(max((location.x - fit.minX) / max(fit.width, 1), 0), 1)
        let ny = min(max((location.y - fit.minY) / max(fit.height, 1), 0), 1)
        let minSide: CGFloat = 0.1
        var left = unit.minX
        var top = unit.minY
        var right = unit.maxX
        var bottom = unit.maxY
        switch corner {
        case .topLeft:
            left = min(nx, right - minSide)
            top = min(ny, bottom - minSide)
        case .topRight:
            right = max(nx, left + minSide)
            top = min(ny, bottom - minSide)
        case .bottomLeft:
            left = min(nx, right - minSide)
            bottom = max(ny, top + minSide)
        case .bottomRight:
            right = max(nx, left + minSide)
            bottom = max(ny, top + minSide)
        }
        unit = CGRect(x: left, y: top, width: right - left, height: bottom - top)
    }
}
