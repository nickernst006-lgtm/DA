import XCTest

// UI-тесты: запускают приложение в симуляторе iPhone в облаке, «нажимают»
// кнопки как человек и сохраняют скриншоты каждого экрана.
// Приёмы и грабли — из N Finance (N_Apps_11): поиск по опознавательным
// знакам, прокрутка до элемента, понятные сообщения об ошибках.

final class DocumentsAppUITests: XCTestCase {

    private let password = "test1234"

    override func setUpWithError() throws {
        continueAfterFailure = false
    }

    @MainActor
    private func snap(_ app: XCUIApplication, _ name: String) {
        let a = XCTAttachment(screenshot: app.screenshot())
        a.name = name
        a.lifetime = .keepAlways
        add(a)
    }

    /// Создаёт пароль при первом запуске или входит, если пароль уже есть
    @MainActor
    private func unlock(_ app: XCUIApplication, screenshotPrefix: String? = nil) {
        let setup1 = app.secureTextFields["setupPassword1"]
        let login = app.secureTextFields["loginPassword"]
        let appeared = setup1.waitForExistence(timeout: 10) || login.waitForExistence(timeout: 2)
        XCTAssertTrue(appeared, "не появился экран пароля")

        if setup1.exists {
            if let p = screenshotPrefix { snap(app, "\(p)_Создание_пароля") }
            setup1.tap()
            setup1.typeText(password)
            let setup2 = app.secureTextFields["setupPassword2"]
            setup2.tap()
            setup2.typeText(password)
            app.buttons["setupSubmit"].tap()
        } else {
            if let p = screenshotPrefix { snap(app, "\(p)_Вход") }
            login.tap()
            login.typeText(password)
            app.buttons["loginSubmit"].tap()
        }
        XCTAssertTrue(app.tabBars.firstMatch.waitForExistence(timeout: 60), "не открылся главный экран")
    }

    /// Тест 1: проходит по всем вкладкам и делает скриншоты
    @MainActor
    func test1_AllScreensScreenshots() throws {
        let app = XCUIApplication()
        app.launchArguments = ["-uiTestDemo"]
        app.launch()
        unlock(app, screenshotPrefix: "01")

        XCTAssertEqual(app.tabBars.buttons.count, 5,
                       "вкладок должно быть пять, а их \(app.tabBars.buttons.count)")

        tab(app, 0)
        sleep(1)
        snap(app, "02_Форма")

        tab(app, 1)
        sleep(1)
        snap(app, "03_История")

        tab(app, 2)
        let person = app.descendants(matching: .any).matching(identifier: "person_Я").firstMatch
        XCTAssertTrue(person.waitForExistence(timeout: 10),
                      "в хранилище нет демо-человека «Я» — демо-данные не засеялись")
        snap(app, "04_Хранилище")

        tab(app, 3)
        sleep(1)
        snap(app, "05_Справочники")

        tab(app, 4)
        sleep(1)
        snap(app, "06_О_приложении")
        app.swipeUp()
        snap(app, "07_О_приложении_ниже")
        app.swipeDown()

        // Блокировка вручную и повторный вход
        let lockButton = app.buttons["Заблокировать сейчас"]
        XCTAssertTrue(reveal(app, lockButton), "нет кнопки «Заблокировать сейчас»")
        lockButton.tap()
        XCTAssertTrue(app.secureTextFields["loginPassword"].waitForExistence(timeout: 5), "не заблокировалось")
        snap(app, "08_Заблокировано")
        let login = app.secureTextFields["loginPassword"]
        login.tap()
        login.typeText("wrong-password")
        app.buttons["loginSubmit"].tap()
        XCTAssertTrue(app.staticTexts["Неверный пароль. Попробуйте снова."].waitForExistence(timeout: 30),
                      "нет сообщения о неверном пароле")
        snap(app, "09_Неверный_пароль")
        login.tap()
        login.typeText(password)
        app.buttons["loginSubmit"].tap()
        XCTAssertTrue(app.tabBars.firstMatch.waitForExistence(timeout: 60), "не удалось войти повторно")
    }

    /// Тест 2: окно смены пароля и окно сброса открываются и закрываются
    @MainActor
    func test2_ChangePasswordAndResetSheets() throws {
        let app = XCUIApplication()
        app.launch()
        unlock(app)

        tab(app, 4)
        let change = app.buttons["Сменить пароль"]
        XCTAssertTrue(reveal(app, change), "нет кнопки «Сменить пароль»")
        change.tap()
        let changeBar = app.navigationBars["Смена пароля"]
        XCTAssertTrue(changeBar.waitForExistence(timeout: 5), "не открылось окно смены пароля")
        snap(app, "10_Смена_пароля")
        changeBar.buttons["Отмена"].tap()
        XCTAssertFalse(changeBar.waitForExistence(timeout: 3), "окно смены пароля не закрылось")

        let reset = app.buttons["Сбросить приложение"]
        XCTAssertTrue(reveal(app, reset), "нет кнопки сброса")
        reset.tap()
        let resetBar = app.navigationBars["Сброс"]
        XCTAssertTrue(resetBar.waitForExistence(timeout: 5), "не открылось окно сброса")
        let confirm = app.buttons["Удалить всё"]
        XCTAssertTrue(confirm.waitForExistence(timeout: 5), "нет кнопки «Удалить всё»")
        XCTAssertFalse(confirm.isEnabled, "удаление доступно без ввода слова УДАЛИТЬ")
        snap(app, "11_Сброс")
        resetBar.buttons["Отмена"].tap()
        XCTAssertFalse(resetBar.waitForExistence(timeout: 3), "окно сброса не закрылось")
    }

    /// Тест 3: хранилище вглубь по демо-данным — человек, папка, карточка,
    /// правка; корзина и справочники
    @MainActor
    func test3_StorageDrillDown() throws {
        let app = XCUIApplication()
        app.launchArguments = ["-uiTestDemo"]
        app.launch()
        unlock(app)

        tab(app, 2)
        let person = app.buttons.matching(identifier: "person_Я").firstMatch
        XCTAssertTrue(reveal(app, person), "нет строки человека «Я»")
        person.tap()
        let folder = app.buttons.matching(identifier: "folder_Удостоверения личности").firstMatch
        XCTAssertTrue(folder.waitForExistence(timeout: 10), "не открылся экран человека: нет папки")
        snap(app, "12_Папки_человека")
        folder.tap()

        let card = app.buttons.matching(identifier: "card_Паспорт РФ").firstMatch
        XCTAssertTrue(card.waitForExistence(timeout: 10), "не открылась папка: нет карточки паспорта")
        snap(app, "13_Карточки_папки")
        card.tap()

        XCTAssertTrue(app.navigationBars["Карточка"].waitForExistence(timeout: 10), "не открылась карточка")
        snap(app, "14_Карточка")
        app.swipeUp()
        snap(app, "15_Карточка_ниже")

        let edit = app.buttons["editCard"]
        XCTAssertTrue(edit.waitForExistence(timeout: 5), "нет кнопки «Править»")
        edit.tap()
        XCTAssertTrue(app.staticTexts["Правка карточки"].waitForExistence(timeout: 10),
                      "кнопка «Править» не открыла форму")
        snap(app, "16_Форма_правка")
        app.swipeUp()
        snap(app, "17_Форма_поля_шаблона")

        tab(app, 2)
        // Возвращаемся к корню хранилища, если стек остался открытым
        for _ in 0..<4 {
            let back = app.navigationBars.buttons.element(boundBy: 0)
            if app.buttons.matching(identifier: "trashRow").firstMatch.exists || !back.exists { break }
            back.tap()
        }
        let trash = app.buttons.matching(identifier: "trashRow").firstMatch
        XCTAssertTrue(reveal(app, trash), "нет строки корзины")
        trash.tap()
        XCTAssertTrue(app.navigationBars["Корзина"].waitForExistence(timeout: 5), "не открылась корзина")
        snap(app, "18_Корзина")

        tab(app, 3)
        let types = app.buttons.matching(identifier: "dir_types").firstMatch
        XCTAssertTrue(types.waitForExistence(timeout: 5), "нет строки типов карточек")
        snap(app, "19_Справочники")
        types.tap()
        XCTAssertTrue(app.navigationBars["Типы карточек"].waitForExistence(timeout: 5), "не открылись типы")
        snap(app, "20_Типы_карточек")

        tab(app, 1)
        let row = app.descendants(matching: .any).matching(identifier: "historyRow").firstMatch
        XCTAssertTrue(row.waitForExistence(timeout: 10), "в истории нет записей демо-данных")
        snap(app, "21_История")
    }

    /// Тест 4: путь пользователя — лицо и папка в справочнике, карточка через форму,
    /// переход к сохранённой карточке и запись в истории
    @MainActor
    func test4_CreatePersonFolderCard() throws {
        let app = XCUIApplication()
        app.launch()
        unlock(app)

        // Лица заводятся только в справочнике «Лица»
        tab(app, 3)
        let persons = app.buttons.matching(identifier: "dir_persons").firstMatch
        XCTAssertTrue(persons.waitForExistence(timeout: 10), "нет справочника «Лица»")
        persons.tap()
        let nameField = app.textFields["Новое лицо"]
        XCTAssertTrue(reveal(app, nameField), "нет поля добавления лица")
        nameField.tap()
        nameField.typeText("Тестовый")
        app.buttons["Добавить"].tap()
        snap(app, "22_Справочник_лиц")

        let dirPerson = app.buttons.matching(identifier: "dirPerson_Тестовый").firstMatch
        XCTAssertTrue(reveal(app, dirPerson), "новое лицо не появилось в справочнике")
        dirPerson.tap()

        let addFolder = app.buttons["dirAddFolder"]
        XCTAssertTrue(reveal(app, addFolder), "нет кнопки новой папки у лица")
        addFolder.tap()
        let folderName = app.textFields["folderName"]
        XCTAssertTrue(folderName.waitForExistence(timeout: 5), "не открылось окно папки")
        folderName.tap()
        folderName.typeText("Договоры")
        snap(app, "23_Новая_папка")
        app.buttons["folderSave"].tap()
        XCTAssertTrue(app.buttons.matching(identifier: "dirFolder_Договоры").firstMatch.waitForExistence(timeout: 10),
                      "папка не появилась у лица в справочнике")

        // Карточка создаётся из папки в хранилище
        tab(app, 2)
        let person = app.buttons.matching(identifier: "person_Тестовый").firstMatch
        XCTAssertTrue(reveal(app, person), "новое лицо не появилось в хранилище")
        person.tap()

        let folder = app.buttons.matching(identifier: "folder_Договоры").firstMatch
        XCTAssertTrue(folder.waitForExistence(timeout: 10), "папка не появилась у человека")
        folder.tap()

        let newCard = app.buttons["Новая карточка в этой папке"]
        XCTAssertTrue(reveal(app, newCard), "нет кнопки новой карточки в папке")
        newCard.tap()

        let title = app.textFields["cardTitle"]
        XCTAssertTrue(reveal(app, title), "форма не открылась: нет поля названия")
        title.tap()
        title.typeText("Договор аренды")
        snap(app, "24_Форма_заполнена")

        // Меню «Загрузить»: три способа
        let upload = app.buttons["uploadFile"]
        XCTAssertTrue(reveal(app, upload), "нет кнопки «Загрузить»")
        upload.tap()
        XCTAssertTrue(app.buttons["Сканировать"].waitForExistence(timeout: 5), "в меню нет «Сканировать»")
        XCTAssertTrue(app.buttons["Из Фото"].exists, "в меню нет «Из Фото»")
        XCTAssertTrue(app.buttons["Из Файлов"].exists, "в меню нет «Из Файлов»")
        snap(app, "25_Меню_загрузки")
        app.buttons["Отмена"].firstMatch.tap()

        let save = app.buttons["saveCard"]
        XCTAssertTrue(reveal(app, save), "нет кнопки сохранения")
        XCTAssertTrue(save.isEnabled, "кнопка сохранения недоступна — не подставились лицо и папка")
        save.tap()

        XCTAssertTrue(app.navigationBars["Карточка"].waitForExistence(timeout: 10),
                      "после сохранения не открылась карточка в хранилище")
        XCTAssertTrue(app.staticTexts["Договор аренды"].waitForExistence(timeout: 5),
                      "на экране карточки нет её названия")
        snap(app, "26_Сохранённая_карточка")

        tab(app, 1)
        let created = app.descendants(matching: .any)
            .matching(NSPredicate(format: "label CONTAINS %@", "Договор аренды")).firstMatch
        XCTAssertTrue(created.waitForExistence(timeout: 10), "в истории нет записи о новой карточке")
        snap(app, "27_История_после_создания")
    }

    /// Прокручивает экран, пока элемент не окажется видимым и нажимаемым.
    ///
    /// SwiftUI-список создаёт только видимые строки: то, что ушло за нижний край,
    /// в дереве доступности просто отсутствует, и `waitForExistence` ждёт его зря.
    /// Поэтому листаем сами — сначала вниз, потом, если не нашли, вверх.
    @MainActor
    @discardableResult
    private func reveal(_ app: XCUIApplication, _ element: XCUIElement, swipes: Int = 6) -> Bool {
        if hittable(element, within: 2) { return true }
        for _ in 0..<swipes {
            app.swipeUp()
            if hittable(element, within: 1) { return true }
        }
        for _ in 0..<(swipes * 2) {
            app.swipeDown()
            if hittable(element, within: 1) { return true }
        }
        return hittable(element, within: 1)
    }

    /// `isHittable` на долю секунды бывает ложным, пока список доезжает после
    /// прокрутки. Даём ему это время, иначе пролистнём мимо нужной строки.
    @MainActor
    private func hittable(_ element: XCUIElement, within seconds: TimeInterval) -> Bool {
        let deadline = Date().addingTimeInterval(seconds)
        while Date() < deadline {
            if element.exists && element.isHittable { return true }
            usleep(150_000)
        }
        return element.exists && element.isHittable
    }

    /// Вкладки без подписей — нажимаем по порядку:
    /// 0 Форма, 1 История, 2 Хранилище, 3 Справочники, 4 О приложении
    @MainActor
    private func tab(_ app: XCUIApplication, _ index: Int) {
        let button = app.tabBars.buttons.element(boundBy: index)
        XCTAssertTrue(button.waitForExistence(timeout: 10), "нет вкладки \(index)")
        button.tap()
    }
}
