#!/bin/bash
# Итоговая таблица на странице запуска. Статусы шагов приходят через переменные окружения.
st() { case "$1" in success) echo "✅";; failure) echo "❌ ОШИБКА";; skipped|"") echo "— не выполнялось";; *) echo "$1";; esac; }
# UI-тесты сборку не задерживают: приложение уже собрано и .ipa лежит в Artifacts.
# Поэтому их падение — замечание, а не ошибка.
ui() { case "$1" in success) echo "✅";; failure) echo "⚠️ есть замечания (на приложение не влияет)";; skipped|"") echo "— не выполнялось";; *) echo "$1";; esac; }
{
  echo "## Результат"
  echo "| Шаг | Итог |"
  echo "|---|---|"
  echo "| Файлы на месте | $(st "$S_PREP") |"
  echo "| Принципы серии (сеть, биометрия, связка ключей) | $(st "$S_RULES") |"
  echo "| Xcode | $(st "$S_XCODE") |"
  echo "| Проект Xcode | $(st "$S_GEN") |"
  echo "| Компиляция для iPhone | $(st "$S_COMPILE") |"
  echo "| Юнит-тесты | $(st "$S_UNIT") |"
  echo "| UI-тесты и скриншоты | $(ui "$S_UI") |"
  echo ""
  if [ "$S_COMPILE" = "success" ] && [ "$S_UNIT" = "success" ]; then
    echo "**Приложение собрано.** Файл \`DocumentsApp-ipa\` внизу страницы можно ставить на телефон"
    echo "независимо от того, что показала последняя строка таблицы."
    echo ""
  fi
  if ls *.log >/dev/null 2>&1; then
    ERR=$(grep -hE "error:|: error|XCTAssert|Failed to|failed -|\) failed" *.log | grep -vE "^\s*$|Test Suite|TEST FAILED|^[0-9]{4}-[0-9]{2}-[0-9]{2} " | sort -u | head -30)
    if [ -n "$ERR" ]; then
      echo "### Ошибки"
      echo '```'
      echo "$ERR" | cut -c1-300
      echo '```'
    fi
  fi
  N=$(ls screenshots 2>/dev/null | grep -ciE '\.(png|jpe?g)$')
  echo "Скриншотов: ${N:-0}. Файлы — внизу страницы, в разделе **Artifacts**."
} >> "$GITHUB_STEP_SUMMARY"
