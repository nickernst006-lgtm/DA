#!/bin/bash
# Шаг облачной сборки (вызывается из .github/workflows/build.yml)
set -o pipefail
FMT=cat; command -v xcbeautify >/dev/null && FMT=xcbeautify
xcodebuild build \
  -project DocumentsApp.xcodeproj -scheme DocumentsApp \
  -configuration Release -sdk iphoneos -destination 'generic/platform=iOS' \
  -derivedDataPath build \
  CODE_SIGNING_ALLOWED=NO CODE_SIGNING_REQUIRED=NO CODE_SIGN_IDENTITY="" \
  2>&1 | tee build-release.log | $FMT
