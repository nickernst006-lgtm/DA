#!/bin/bash
# Проверка принципов серии N Apps (N_Apps_01): три поиска по исходникам
# приложения должны вернуть пустой ответ. Любое совпадение — ошибка сборки.
FAIL=0
check() {
  local title="$1" pattern="$2" flags="$3"
  local hits
  hits=$(grep -rn $flags -E "$pattern" DocumentsApp --include='*.swift' || true)
  if [ -n "$hits" ]; then
    echo "::error::$title"
    echo "$hits"
    FAIL=1
  else
    echo "✅ $title — пусто"
  fi
}
check "Сетевые вызовы" "URLSession|URLRequest|NSURLConnection|WKWebView|NWConnection|CFNetwork|https?://" ""
check "Биометрия" "LocalAuthentication|LAContext|FaceID|TouchID" "-i"
check "Связка ключей и облако" "keychain|SecItem|UserDefaults|CloudKit" "-i"
exit $FAIL
