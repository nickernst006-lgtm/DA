#!/bin/bash
# Шаг облачной сборки (вызывается из .github/workflows/build.yml)
UDID=$(xcrun simctl list devices available -j | python3 -c '
import json, sys, re
devs = json.load(sys.stdin)["devices"]
best = None
for runtime, items in devs.items():
    m = re.search(r"iOS-(\d+)-(\d+)", runtime)
    if not m: continue
    ver = (int(m.group(1)), int(m.group(2)))
    for d in items:
        if d["name"].startswith("iPhone") and d.get("isAvailable", True):
            if best is None or ver > best[0]:
                best = (ver, d["udid"], d["name"])
if best:
    print(best[1])
    print("Симулятор:", best[2], "iOS %d.%d" % best[0], file=sys.stderr)
')
if [ -z "$UDID" ]; then
  echo "Симулятор не найден — скачиваю платформу iOS"
  xcodebuild -downloadPlatform iOS
  UDID=$(xcrun simctl create "iPhone-CI" "iPhone 16" | tail -1)
fi
echo "udid=$UDID" >> "$GITHUB_OUTPUT"
xcrun simctl boot "$UDID" || true
