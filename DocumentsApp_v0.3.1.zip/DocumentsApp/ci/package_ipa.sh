#!/bin/bash
# Шаг облачной сборки (вызывается из .github/workflows/build.yml)
mkdir -p Payload
cp -R build/Build/Products/Release-iphoneos/DocumentsApp.app Payload/
zip -qry DocumentsApp-unsigned.ipa Payload
ls -la DocumentsApp-unsigned.ipa
