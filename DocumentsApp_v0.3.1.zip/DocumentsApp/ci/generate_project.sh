#!/bin/bash
# Шаг облачной сборки (вызывается из .github/workflows/build.yml)
brew install xcodegen
xcodegen generate
ls -la
