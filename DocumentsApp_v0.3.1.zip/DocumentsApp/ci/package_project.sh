#!/bin/bash
# Шаг облачной сборки (вызывается из .github/workflows/build.yml)
zip -qry DocumentsApp-Xcode-project.zip DocumentsApp DocumentsApp.xcodeproj DocumentsAppTests DocumentsAppUITests project.yml README.md ci || true
