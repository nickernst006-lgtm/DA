#!/bin/bash
# Шаг облачной сборки (вызывается из .github/workflows/build.yml)
set -o pipefail
FMT=cat; command -v xcbeautify >/dev/null && FMT=xcbeautify
xcodebuild test \
  -project DocumentsApp.xcodeproj -scheme DocumentsApp \
  -destination "id=$SIM_UDID" \
  -only-testing:DocumentsAppTests \
  -resultBundlePath results/unit.xcresult \
  2>&1 | tee unit-tests.log | $FMT
