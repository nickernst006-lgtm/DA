#!/bin/bash
# Шаг облачной сборки (вызывается из .github/workflows/build.yml)
XCODE=$(ls -d /Applications/Xcode_*.app | grep -viE 'beta|release_candidate|rc' | sort -V | tail -1)
echo "Выбран: $XCODE"
sudo xcode-select -s "$XCODE/Contents/Developer"
xcodebuild -version
swift --version
sw_vers
