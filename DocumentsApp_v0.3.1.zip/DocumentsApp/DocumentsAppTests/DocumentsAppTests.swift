import XCTest
import CryptoKit
@testable import DocumentsApp

// Юнит-тесты логики N Documents. Запускаются в облаке (GitHub Actions)
// на настоящем Mac с Xcode — без iPhone и без установки.
// Криптографические тесты перенесены из N Finance без изменений.

final class CryptoTests: XCTestCase {

    private func hex(_ data: Data) -> String {
        data.map { String(format: "%02x", $0) }.joined()
    }

    /// Официальный тестовый вектор RFC 7914 (раздел 11) для PBKDF2-HMAC-SHA256
    func testPBKDF2_RFC7914Vector() {
        let out = PBKDF2.deriveBytes(password: "passwd", salt: Data("salt".utf8), iterations: 1, keyLength: 64)
        XCTAssertEqual(hex(out), "55ac046e56e3089fec1691c22544b605f94185216dde0465e68b9d57c20dacbc49ca9cccf179b645991664b39d77ef317c71b845b1e30bd509112041d3a19783")
    }

    /// Широко известный вектор: "password" / "salt" / 4096 итераций
    func testPBKDF2_4096Iterations() {
        let out = PBKDF2.deriveBytes(password: "password", salt: Data("salt".utf8), iterations: 4096, keyLength: 32)
        XCTAssertEqual(hex(out), "c5e478d59288c841aa530db6845c4c8d962893a001ce4e11a4963873aa98134a")
    }

    /// Кириллический пароль — сверено с Python hashlib.pbkdf2_hmac
    func testPBKDF2_Cyrillic() {
        let out = PBKDF2.deriveBytes(password: "Пароль_кириллица", salt: Data("salt_kir".utf8), iterations: 5000, keyLength: 32)
        XCTAssertEqual(hex(out), "f0e1588eadc8344e4d660a6f1cbebbfb889f09a918006a93618171c54657cf55")
    }

    /// Сколько реально длится вывод ключа с боевыми параметрами (для информации)
    func testPBKDF2_ProductionSpeed() {
        let start = Date()
        _ = PBKDF2.deriveKey(password: "test1234", salt: Data(repeating: 7, count: 16), iterations: 250_000)
        let seconds = Date().timeIntervalSince(start)
        print("PBKDF2 250 000 итераций: \(String(format: "%.2f", seconds)) с")
        XCTAssertLessThan(seconds, 30)
    }

    func testEncryptDecryptRoundTrip() throws {
        let key = SymmetricKey(size: .bits256)
        var data = AppData()
        let person = Person(name: "Иванов Иван")
        let folder = Folder(personId: person.id, number: "1", name: "Удостоверения")
        data.persons = [person]
        data.folders = [folder]
        data.cards = [DocumentCard(folderId: folder.id, typeId: "passportRF", title: "Паспорт РФ",
                                   fields: ["series": "4512", "number": "345678"],
                                   note: "тест \"&<>'")]
        let blob = try CryptoBox.encrypt(data, key: key)
        let back = try CryptoBox.decrypt(blob, key: key, as: AppData.self)
        XCTAssertEqual(back, data)

        // Зашифрованный блоб не содержит открытого текста
        let asText = String(decoding: blob.combined, as: UTF8.self)
        XCTAssertNil(asText.range(of: "Иванов"))
        XCTAssertNil(asText.range(of: "345678"))
    }

    func testDecryptWithWrongKeyFails() throws {
        let blob = try CryptoBox.encrypt(AppData(), key: SymmetricKey(size: .bits256))
        XCTAssertThrowsError(try CryptoBox.decrypt(blob, key: SymmetricKey(size: .bits256), as: AppData.self))
    }

    func testTamperedDataFails() throws {
        let key = SymmetricKey(size: .bits256)
        var blob = try CryptoBox.encrypt(AppData(), key: key)
        var bytes = [UInt8](blob.combined)
        bytes[bytes.count - 1] ^= 0xFF
        blob.combined = Data(bytes)
        XCTAssertThrowsError(try CryptoBox.decrypt(blob, key: key, as: AppData.self))
    }
}

final class ModelTests: XCTestCase {

    /// Пустой или старый файл без новых разделов обязан открыться
    func testEmptyFileOpens() throws {
        let d = try JSONDecoder().decode(AppData.self, from: Data("{}".utf8))
        XCTAssertTrue(d.persons.isEmpty)
        XCTAssertTrue(d.cards.isEmpty)
        XCTAssertTrue(d.history.isEmpty)
        XCTAssertTrue(d.isEmpty)
    }

    /// Файл, где есть только люди (как будто записан ранней версией), открывается,
    /// остальные разделы становятся пустыми, а не роняют разбор
    func testPartialFileOpens() throws {
        let id = UUID().uuidString
        let json = """
        {"persons":[{"id":"\(id)","name":"Я","order":0}]}
        """
        let d = try JSONDecoder().decode(AppData.self, from: Data(json.utf8))
        XCTAssertEqual(d.persons.count, 1)
        XCTAssertEqual(d.persons.first?.name, "Я")
        XCTAssertTrue(d.folders.isEmpty)
        XCTAssertFalse(d.isEmpty)
    }

    /// Запись и чтение сохраняют всё, включая пометку корзины и историю
    func testRoundTripKeepsEverything() throws {
        var d = AppData()
        let batch = UUID()
        let p = Person(name: "Жена", order: 1, deletion: Deletion(date: Date(timeIntervalSince1970: 1_000), batchId: batch))
        d.persons = [p]
        d.history = [HistoryEvent(action: "exportArchive", object: "Паспорт РФ",
                                  details: [HistoryDetail(field: "Номер", old: nil, new: "345678")],
                                  exportPassword: "Ab3kQ7xZ")]
        let encoded = try JSONEncoder().encode(d)
        let back = try JSONDecoder().decode(AppData.self, from: encoded)
        XCTAssertEqual(back, d)
        XCTAssertEqual(back.persons.first?.deletion?.batchId, batch)
        XCTAssertEqual(back.history.first?.exportPassword, "Ab3kQ7xZ")
    }

    func testStatusTitles() {
        XCTAssertEqual(CardStatus.active.title, "Действительный")
        XCTAssertEqual(CardStatus.inactive.title, "Недействительный")
    }

    func testPlural() {
        XCTAssertEqual(Plural.folders(0), "0 папок")
        XCTAssertEqual(Plural.folders(1), "1 папка")
        XCTAssertEqual(Plural.folders(2), "2 папки")
        XCTAssertEqual(Plural.folders(5), "5 папок")
        XCTAssertEqual(Plural.folders(11), "11 папок")
        XCTAssertEqual(Plural.folders(21), "21 папка")
        XCTAssertEqual(Plural.folders(104), "104 папки")
    }

    func testDateFormat() {
        let d = DateFmt.day(from: "2026-09-26")
        XCTAssertNotNil(d)
        XCTAssertEqual(DateFmt.dayString(d!), "2026-09-26")
        XCTAssertEqual(DateFmt.display("2026-09-26"), "26.09.2026")
        XCTAssertEqual(DateFmt.display("мусор"), "мусор")
        XCTAssertNil(DateFmt.day(from: ""))
    }
}

@MainActor
final class AppStateTests: XCTestCase {

    private func makeTempDir() -> URL {
        FileManager.default.temporaryDirectory.appendingPathComponent("DocumentsTest-\(UUID().uuidString)")
    }

    func testFullLifecycle() async throws {
        let dir = makeTempDir()
        defer { try? FileManager.default.removeItem(at: dir) }
        // 1. Первый запуск — пароля нет, папки хранилища уже созданы
        let s1 = AppState(storageDir: dir, iterations: 1000)
        XCTAssertFalse(s1.hasAccount)
        XCTAssertTrue(FileManager.default.fileExists(atPath: s1.filesDir.path), "нет папки files/")

        // 2. Слишком короткий пароль отклоняется
        let short = await s1.createPassword("123")
        XCTAssertNotNil(short)

        // 3. Создание пароля и сохранение данных
        let created = await s1.createPassword("secret1")
        XCTAssertNil(created)
        XCTAssertTrue(s1.isUnlocked)
        s1.data.persons.append(Person(name: "Я"))
        s1.persist()
        XCTAssertNil(s1.saveError)

        // 4. Файл и папки исключены из резервных копий
        let dataFile = dir.appendingPathComponent("data.bin")
        for url in [dataFile, dir, s1.filesDir] {
            let values = try url.resourceValues(forKeys: [.isExcludedFromBackupKey])
            XCTAssertEqual(values.isExcludedFromBackup, true, "\(url.lastPathComponent) попадёт в резервную копию")
        }

        // 5. В файле на диске нет открытого текста
        let raw = try Data(contentsOf: dataFile)
        XCTAssertNil(String(decoding: raw, as: UTF8.self).range(of: "\"name\""))

        // 6. Блокировка стирает данные из памяти
        s1.lock()
        XCTAssertFalse(s1.isUnlocked)
        XCTAssertTrue(s1.data.persons.isEmpty)

        // 7. «Перезапуск» приложения: неверный пароль не пускает
        let s2 = AppState(storageDir: dir, iterations: 1000)
        XCTAssertTrue(s2.hasAccount)
        let wrong = await s2.login("wrong")
        XCTAssertNotNil(wrong)
        XCTAssertFalse(s2.isUnlocked)

        // 8. Верный пароль восстанавливает данные
        let ok = await s2.login("secret1")
        XCTAssertNil(ok)
        XCTAssertEqual(s2.data.persons.map(\.name), ["Я"])

        // 9. Смена пароля: старый больше не подходит, данные целы
        let badOld = await s2.changePassword(old: "nope", new: "newpass")
        XCTAssertNotNil(badOld)
        let changed = await s2.changePassword(old: "secret1", new: "newpass")
        XCTAssertNil(changed)
        s2.data.persons.append(Person(name: "Жена"))
        s2.persist()

        let s3 = AppState(storageDir: dir, iterations: 1000)
        let oldFails = await s3.login("secret1")
        XCTAssertNotNil(oldFails)
        let newWorks = await s3.login("newpass")
        XCTAssertNil(newWorks)
        XCTAssertEqual(s3.data.persons.map(\.name), ["Я", "Жена"])

        // 10. Полный сброс удаляет всё, включая файлы документов
        let leftover = s3.filesDir.appendingPathComponent("blob.bin")
        try Data([1, 2, 3]).write(to: leftover)
        s3.fullReset()
        XCTAssertFalse(s3.hasAccount)
        XCTAssertFalse(FileManager.default.fileExists(atPath: leftover.path), "файл документа пережил сброс")
        XCTAssertFalse(FileManager.default.fileExists(atPath: dataFile.path))
        let s4 = AppState(storageDir: dir, iterations: 1000)
        XCTAssertFalse(s4.hasAccount)
    }

    func testAutoLockAfterInactivity() async throws {
        let dir = makeTempDir()
        defer { try? FileManager.default.removeItem(at: dir) }
        let s = AppState(storageDir: dir, iterations: 1000)
        _ = await s.createPassword("secret1")
        XCTAssertTrue(s.isUnlocked)
        s.checkAutoLock()
        XCTAssertTrue(s.isUnlocked, "сразу после активности блокироваться не должно")
    }

    /// Остатки экспорта во временной папке подчищаются при запуске
    func testTemporaryExportsAreCleaned() throws {
        let tmp = FileManager.default.temporaryDirectory
        let zip = tmp.appendingPathComponent("\(AppState.exportPrefix)_test.zip")
        let folder = tmp.appendingPathComponent("\(AppState.exportPrefix)_folder", isDirectory: true)
        try Data([0]).write(to: zip)
        try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
        AppState.cleanTemporaryExports()
        XCTAssertFalse(FileManager.default.fileExists(atPath: zip.path))
        XCTAssertFalse(FileManager.default.fileExists(atPath: folder.path))
    }
}
