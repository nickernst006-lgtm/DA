import XCTest
import UIKit
import PDFKit
@testable import DocumentsApp

// Тесты обработки сканов: поворот, обрезка, уменьшение, сборка PDF.

final class ScanTests: XCTestCase {

    private func image(_ w: CGFloat, _ h: CGFloat) -> UIImage {
        let format = UIGraphicsImageRendererFormat()
        format.scale = 1
        return UIGraphicsImageRenderer(size: CGSize(width: w, height: h), format: format).image { ctx in
            UIColor.red.setFill()
            ctx.fill(CGRect(x: 0, y: 0, width: w, height: h))
        }
    }

    func testRotateSwapsSides() {
        let r = ScanImages.rotated(image(300, 100))
        XCTAssertEqual(r.size.width, 100, accuracy: 0.5)
        XCTAssertEqual(r.size.height, 300, accuracy: 0.5)
    }

    func testCropUsesUnitRect() {
        let c = ScanImages.cropped(image(400, 200), to: CGRect(x: 0.25, y: 0, width: 0.5, height: 0.5))
        XCTAssertEqual(c.size.width, 200, accuracy: 0.5)
        XCTAssertEqual(c.size.height, 100, accuracy: 0.5)
    }

    func testDownscaleKeepsProportions() {
        let d = ScanImages.downscaled(image(4400, 1100))
        XCTAssertEqual(d.size.width, 2200, accuracy: 1)
        XCTAssertEqual(d.size.height, 550, accuracy: 1)
        let small = ScanImages.downscaled(image(800, 600))
        XCTAssertEqual(small.size.width, 800, accuracy: 0.5, "маленькая картинка не трогается")
    }

    func testPDFHasPagePerScan() {
        let data = ScanImages.makePDF([image(300, 400), image(400, 300), image(500, 500)])
        let doc = PDFDocument(data: data)
        XCTAssertEqual(doc?.pageCount, 3)
        // Ширина страницы — как у A4, высота — по пропорциям снимка
        let first = doc?.page(at: 0)?.bounds(for: .mediaBox)
        XCTAssertEqual(first?.width ?? 0, 595, accuracy: 1)
        XCTAssertEqual(first?.height ?? 0, 595 * 4 / 3, accuracy: 2)
    }
}
