import XCTest
import CryptoKit
@testable import DocumentsApp

// Тесты версии 0.2: шаблоны, маски, СНИЛС, корзина, поиск, журнал
// изменений и зашифрованное хранилище файлов.

final class TemplateTests: XCTestCase {

    func testTemplateIdsAndKeysAreUnique() {
        var ids: Set<String> = []
        for t in CardTemplate.all {
            XCTAssertTrue(ids.insert(t.id).inserted, "повтор идентификатора шаблона \(t.id)")
            var keys: Set<String> = []
            for f in t.fields {
                XCTAssertTrue(keys.insert(f.key).inserted, "повтор ключа \(f.key) в шаблоне \(t.id)")
            }
        }
        XCTAssertEqual(CardTemplate.all.count, 6, "базовая и пять типовых")
        XCTAssertEqual(CardTemplate.typed.map(\.title),
                       ["Паспорт", "СНИЛС", "Водительское удостоверение", "Медицинский полис", "Заграничный паспорт"],
                       "порядок и названия типов — как в списке выбора формы")
        XCTAssertFalse(CardTemplate.typed.contains { $0.id == CardTemplate.basicId })
    }

    func testGroupNamesDefaultAndRename() throws {
        var d = AppData()
        XCTAssertEqual(d.basicGroupName, "Базовые")
        XCTAssertEqual(d.typedGroupName, "Типовые")
        d.typedGroupTitle = "Государственные"
        d.basicGroupTitle = "   "
        XCTAssertEqual(d.typedGroupName, "Государственные")
        XCTAssertEqual(d.basicGroupName, "Базовые", "пустое название — значит по умолчанию")
        let back = try JSONDecoder().decode(AppData.self, from: JSONEncoder().encode(d))
        XCTAssertEqual(back.typedGroupName, "Государственные")
    }

    func testUnknownTemplateFallsBackToBasic() {
        XCTAssertEqual(CardTemplate.find("изБудущейВерсии").id, CardTemplate.basicId)
        XCTAssertEqual(CardTemplate.find("snils").title, "СНИЛС")
    }

    func testMask() {
        XCTAssertEqual(Mask.apply("000-000", to: "123456"), "123-456")
        XCTAssertEqual(Mask.apply("000-000", to: "123"), "123", "знак маски не ставится впереди цифр")
        XCTAssertEqual(Mask.apply("000-000", to: "1234"), "123-4")
        XCTAssertEqual(Mask.apply("0000", to: "12a34x5"), "1234", "буквы и лишние цифры отбрасываются")
        XCTAssertEqual(Mask.apply("000-000-000 00", to: "11223344595"), "112-233-445 95")
        XCTAssertEqual(Mask.apply("00 0000000", to: "75 1234567"), "75 1234567")
        XCTAssertEqual(Mask.apply("000-000", to: "123-456"), "123-456", "повторное применение не портит")
        XCTAssertEqual(Mask.apply("0000", to: ""), "")
    }

    func testSnilsChecksum() {
        XCTAssertTrue(Snils.isValid(Array("11223344595")), "сумма 95 → 95")
        XCTAssertFalse(Snils.isValid(Array("11223344596")))
        XCTAssertTrue(Snils.isValid(Array("00100199800")), "малые номера не проверяются")
        XCTAssertFalse(Snils.isValid(Array("123")))
        // Сумма больше 101: 999999999 → 9·45 = 405, 405 mod 101 = 1
        XCTAssertTrue(Snils.isValid(Array("99999999901")))
        XCTAssertFalse(Snils.isValid(Array("99999999900")))
    }

    func testSnilsProblemMessage() {
        let spec = CardTemplate.snils.fields.first { $0.key == "number" }!
        XCTAssertNil(spec.problem(in: "112-233-445 95"))
        XCTAssertNotNil(spec.problem(in: "112-233-445 96"))
        XCTAssertNil(spec.problem(in: "112-233"), "неполный номер не ругаем")
    }

    func testDateFieldDisplay() {
        let spec = CardTemplate.passportRF.fields.first { $0.key == "issueDate" }!
        XCTAssertEqual(spec.display("2020-03-15"), "15.03.2020")
    }
}

final class DataOpsTests: XCTestCase {

    /// Я → папка «1 · Удостоверения» → паспорт и СНИЛС; Жена → папка → полис
    private func sample() -> (AppData, Person, Folder, DocumentCard, DocumentCard) {
        var d = AppData()
        let me = Person(name: "Я", order: 0)
        let wife = Person(name: "Жена", order: 1)
        let tag = FolderTag(name: "Поездки")
        d.tags = [tag]
        let folder = Folder(personId: me.id, number: "1", name: "Удостоверения", tagIds: [tag.id])
        let wifeFolder = Folder(personId: wife.id, number: "1", name: "Медицина")
        let passport = DocumentCard(folderId: folder.id, typeId: "passportRF", title: "Паспорт РФ",
                                    fields: ["number": "345678", "lastName": "Иванов"])
        let snils = DocumentCard(folderId: folder.id, typeId: "snils", title: "СНИЛС")
        let oms = DocumentCard(folderId: wifeFolder.id, typeId: "oms", title: "Полис ОМС")
        d.persons = [me, wife]
        d.folders = [folder, wifeFolder]
        d.cards = [passport, snils, oms]
        return (d, me, folder, passport, snils)
    }

    func testTrashPersonCascadesAndRestores() {
        var (d, me, folder, passport, _) = sample()
        let batch = UUID()
        d.trashPerson(me.id, batch: batch, date: Date())
        XCTAssertEqual(d.activePersons.map(\.name), ["Жена"])
        XCTAssertNotNil(d.folder(folder.id)?.deletion, "папка должна уйти вместе с человеком")
        XCTAssertNotNil(d.card(passport.id)?.deletion, "карточка должна уйти вместе с папкой")

        let batches = d.trashBatches()
        XCTAssertEqual(batches.count, 1)
        XCTAssertEqual(batches.first?.titles, ["Лицо «Я»"], "вложенное не дублируется в заголовках")
        XCTAssertEqual(batches.first?.count, 4, "человек, папка и две карточки")

        d.restore(batch: batch)
        XCTAssertEqual(d.activePersons.count, 2)
        XCTAssertEqual(d.activeCards(in: folder.id).count, 2)
        XCTAssertTrue(d.trashBatches().isEmpty)
    }

    /// Карточку удалили раньше папки: восстановление папки её не возвращает,
    /// а восстановление карточки возвращает и папку-родителя.
    func testSeparateBatchesAndParentRestore() {
        var (d, _, folder, passport, snils) = sample()
        let cardBatch = UUID()
        d.trashCard(passport.id, batch: cardBatch, date: Date(timeIntervalSince1970: 100))
        let folderBatch = UUID()
        d.trashFolder(folder.id, batch: folderBatch, date: Date(timeIntervalSince1970: 200))
        XCTAssertEqual(d.card(passport.id)?.deletion?.batchId, cardBatch, "пометка не перезаписывается")
        XCTAssertEqual(d.card(snils.id)?.deletion?.batchId, folderBatch)
        XCTAssertEqual(d.trashBatches().count, 2)
        XCTAssertEqual(d.trashBatches().first?.id, folderBatch, "новые сверху")

        d.restore(batch: cardBatch)
        XCTAssertNil(d.card(passport.id)?.deletion)
        XCTAssertNil(d.folder(folder.id)?.deletion, "папка-родитель должна вернуться с карточкой")
        XCTAssertNotNil(d.card(snils.id)?.deletion, "соседняя карточка остаётся в корзине")
    }

    func testFileInTrashRestoresWithCard() {
        var (d, _, _, passport, _) = sample()
        var card = d.card(passport.id)!
        let batch = UUID()
        card.files = [StoredFile(displayName: "Разворот.pdf", originalName: "a.pdf",
                                 typeIdentifier: "com.adobe.pdf", size: 10, blobName: "x.bin",
                                 source: .files, deletion: Deletion(date: Date(), batchId: batch))]
        d.updateCard(card)
        XCTAssertEqual(d.trashBatches().first?.titles, ["Файл «Разворот.pdf» из «Паспорт РФ»"])
        d.restore(batch: batch)
        XCTAssertNil(d.card(passport.id)?.files.first?.deletion)
    }

    func testSearch() {
        let (d, _, _, _, _) = sample()
        XCTAssertEqual(d.search("345678").map(\.title), ["Паспорт РФ"], "по значению поля")
        XCTAssertEqual(d.search("иванов").map(\.title), ["Паспорт РФ"], "без учёта регистра")
        XCTAssertEqual(d.search("поездки").count, 2, "по тегу папки")
        XCTAssertEqual(d.search("жена").map(\.title), ["Полис ОМС"], "по имени лица")
        XCTAssertTrue(d.search("   ").isEmpty)
    }

    func testSearchSkipsTrash() {
        var (d, _, _, passport, _) = sample()
        d.trashCard(passport.id, batch: UUID(), date: Date())
        XCTAssertTrue(d.search("345678").isEmpty)
    }

    func testCounts() {
        let (d, me, folder, _, _) = sample()
        XCTAssertEqual(d.activeFolderCounts()[me.id], 1)
        XCTAssertEqual(d.activeCardCounts()[folder.id], 2)
        XCTAssertEqual(d.folderTitle(folder), "1 · Удостоверения")
        XCTAssertEqual(d.nextPersonOrder(), 2)
        XCTAssertEqual(Plural.cards(3), "3 карточки")
        XCTAssertEqual(Plural.files(1), "1 файл")
    }
}

final class HistoryTests: XCTestCase {

    func testCardChanges() {
        var d = AppData()
        let me = Person(name: "Я")
        let f1 = Folder(personId: me.id, number: "1", name: "Личное")
        let f2 = Folder(personId: me.id, number: "2", name: "Для визы")
        d.persons = [me]
        d.folders = [f1, f2]
        let fileA = StoredFile(displayName: "А.pdf", originalName: "А.pdf", typeIdentifier: "com.adobe.pdf",
                               size: 1, blobName: "a.bin", source: .files)
        let fileB = StoredFile(displayName: "Б.jpg", originalName: "Б.jpg", typeIdentifier: "public.jpeg",
                               size: 1, blobName: "b.bin", source: .photos)
        let old = DocumentCard(folderId: f1.id, typeId: "passportRF", title: "Паспорт РФ",
                               fields: ["number": "111111", "issueDate": "2020-03-15"], files: [fileA])
        var new = old
        new.folderId = f2.id
        new.status = .inactive
        new.fields["number"] = "222222"
        new.fields["issueDate"] = nil
        new.files = [fileB]

        let changes = d.cardChanges(old: old, new: new)
        func find(_ field: String) -> HistoryDetail? { changes.first { $0.field == field } }

        XCTAssertEqual(find("Номер")?.old, "111111")
        XCTAssertEqual(find("Номер")?.new, "222222")
        XCTAssertEqual(find("Дата выдачи")?.old, "15.03.2020", "даты — в человеческом виде")
        XCTAssertNil(find("Дата выдачи")?.new)
        XCTAssertEqual(find("Расположение")?.old, "Я → 1 · Личное")
        XCTAssertEqual(find("Расположение")?.new, "Я → 2 · Для визы")
        XCTAssertEqual(find("Статус")?.new, "Недействительный")
        XCTAssertEqual(find("Файл добавлен")?.new, "Б.jpg")
        XCTAssertEqual(find("Файл в корзину")?.old, "А.pdf")
        XCTAssertNil(find("Название"), "название не менялось — строки быть не должно")
    }

    func testNoChangesNoDetails() {
        let d = AppData()
        let card = DocumentCard(folderId: UUID(), title: "Договор")
        XCTAssertTrue(d.cardChanges(old: card, new: card).isEmpty)
    }

    func testSnapshotAndLog() {
        var d = AppData()
        let card = DocumentCard(folderId: UUID(), typeId: "snils", title: "СНИЛС",
                                fields: ["number": "112-233-445 95"], note: "оригинал в сейфе")
        let snapshot = d.cardSnapshot(card)
        XCTAssertTrue(snapshot.contains { $0.field == "Номер" && $0.new == "112-233-445 95" })
        XCTAssertTrue(snapshot.contains { $0.field == "Заметка" })
        d.log(.cardCreated, object: "СНИЛС", details: snapshot)
        XCTAssertEqual(d.history.count, 1)
        XCTAssertEqual(d.history.first?.actionTitle, "Создана карточка")
        XCTAssertEqual(d.historyDays().first?.events.count, 1)
    }

    func testUnknownActionStillReadable() {
        let e = HistoryEvent(action: "изБудущего", object: "x")
        XCTAssertEqual(e.actionTitle, "изБудущего")
    }
}

@MainActor
final class FileStorageTests: XCTestCase {

    private func makeTempDir() -> URL {
        FileManager.default.temporaryDirectory.appendingPathComponent("DocumentsFiles-\(UUID().uuidString)")
    }

    private func blobURLs(_ state: AppState) -> [URL] {
        let items = (try? FileManager.default.contentsOfDirectory(at: state.filesDir, includingPropertiesForKeys: nil)) ?? []
        return items.filter { $0.pathExtension == "bin" }
    }

    /// Карточка со ссылкой на блоб — чтобы уборка сирот его не тронула
    private func attach(_ blob: String, to state: AppState) {
        let person = Person(name: "Я")
        let folder = Folder(personId: person.id, name: "Папка")
        let file = StoredFile(displayName: "скан.pdf", originalName: "скан.pdf", typeIdentifier: "com.adobe.pdf",
                              size: 5, blobName: blob, source: .files)
        state.data.persons.append(person)
        state.data.folders.append(folder)
        state.data.cards.append(DocumentCard(folderId: folder.id, title: "Документ", files: [file]))
        state.persist()
    }

    func testStoreAndLoadRoundTrip() async throws {
        let dir = makeTempDir()
        defer { try? FileManager.default.removeItem(at: dir) }
        let s = AppState(storageDir: dir, iterations: 1000)
        _ = await s.createPassword("secret1")

        let secret = Data("ПАСПОРТ 4512 345678 ИВАНОВ".utf8)
        let blob = try s.storeFile(secret)
        XCTAssertTrue(blob.hasSuffix(".bin"))

        // На диске — не открытый текст
        let raw = try Data(contentsOf: s.filesDir.appendingPathComponent(blob))
        XCTAssertNil(String(decoding: raw, as: UTF8.self).range(of: "345678"))
        XCTAssertNotEqual(raw, secret)

        // Расшифровка возвращает исходное
        let back = try await s.loadFile(blob)
        XCTAssertEqual(back, secret)

        // Без ключа — ошибка, а не данные
        s.lock()
        do {
            _ = try await s.loadFile(blob)
            XCTFail("после блокировки файл не должен читаться")
        } catch {}
    }

    func testPasswordChangeReencryptsFiles() async throws {
        let dir = makeTempDir()
        defer { try? FileManager.default.removeItem(at: dir) }
        let s1 = AppState(storageDir: dir, iterations: 1000)
        _ = await s1.createPassword("secret1")
        let secret = Data(repeating: 0xAB, count: 300_000)
        let blob = try s1.storeFile(secret)
        attach(blob, to: s1)
        let before = try Data(contentsOf: s1.filesDir.appendingPathComponent(blob))

        let changed = await s1.changePassword(old: "secret1", new: "newpass")
        XCTAssertNil(changed)
        let after = try Data(contentsOf: s1.filesDir.appendingPathComponent(blob))
        XCTAssertNotEqual(before, after, "файл обязан быть перешифрован новым ключом")
        let leftovers = (try FileManager.default.contentsOfDirectory(atPath: s1.filesDir.path)).filter { $0.hasSuffix(".new") }
        XCTAssertTrue(leftovers.isEmpty, "остались копии: \(leftovers)")
        XCTAssertFalse(FileManager.default.fileExists(atPath: dir.appendingPathComponent("data.bin.new").path))

        let s2 = AppState(storageDir: dir, iterations: 1000)
        let ok = await s2.login("newpass")
        XCTAssertNil(ok)
        let back = try await s2.loadFile(blob)
        XCTAssertEqual(back, secret, "после смены пароля файл должен открываться новым ключом")
    }

    func testOrphanBlobsCleanedOnLogin() async throws {
        let dir = makeTempDir()
        defer { try? FileManager.default.removeItem(at: dir) }
        let s1 = AppState(storageDir: dir, iterations: 1000)
        _ = await s1.createPassword("secret1")
        let kept = try s1.storeFile(Data("нужный".utf8))
        attach(kept, to: s1)
        let orphan = try s1.storeFile(Data("брошенный в форме".utf8))
        XCTAssertEqual(blobURLs(s1).count, 2)
        s1.lock()

        let s2 = AppState(storageDir: dir, iterations: 1000)
        _ = await s2.login("secret1")
        let names = blobURLs(s2).map(\.lastPathComponent)
        XCTAssertEqual(names, [kept], "осиротевший блоб \(orphan) должен удалиться, нужный — остаться")
    }

    /// Смена пароля оборвалась до записи meta.json: при входе старым паролем
    /// недописанные копии выбрасываются, данные целы.
    func testInterruptedRekeyIsDiscarded() async throws {
        let dir = makeTempDir()
        defer { try? FileManager.default.removeItem(at: dir) }
        let s1 = AppState(storageDir: dir, iterations: 1000)
        _ = await s1.createPassword("secret1")
        let blob = try s1.storeFile(Data("скан".utf8))
        attach(blob, to: s1)
        s1.lock()

        // Имитация: копии на чужом ключе
        let foreign = try CryptoBox.encrypt(AppData(), key: SymmetricKey(size: .bits256))
        try JSONEncoder().encode(foreign).write(to: dir.appendingPathComponent("data.bin.new"))
        try Data([1, 2, 3]).write(to: s1.filesDir.appendingPathComponent(blob + ".new"))

        let s2 = AppState(storageDir: dir, iterations: 1000)
        let ok = await s2.login("secret1")
        XCTAssertNil(ok)
        XCTAssertEqual(s2.data.cards.count, 1, "данные не должны пострадать")
        XCTAssertFalse(FileManager.default.fileExists(atPath: dir.appendingPathComponent("data.bin.new").path))
        XCTAssertFalse(FileManager.default.fileExists(atPath: s2.filesDir.appendingPathComponent(blob + ".new").path))
        let back = try await s2.loadFile(blob)
        XCTAssertEqual(back, Data("скан".utf8))
    }

    /// Смена пароля оборвалась после записи meta.json: при входе новым паролем
    /// подмена доделывается.
    func testInterruptedRekeyIsCompleted() async throws {
        let dir = makeTempDir()
        defer { try? FileManager.default.removeItem(at: dir) }
        let s1 = AppState(storageDir: dir, iterations: 1000)
        _ = await s1.createPassword("secret1")
        let blob = try s1.storeFile(Data("скан".utf8))
        attach(blob, to: s1)
        let savedData = s1.data

        // Полноценная смена пароля во временной копии хранилища, затем
        // «откат» основных файлов к старым — как будто шаг 4 не успел.
        let changed = await s1.changePassword(old: "secret1", new: "newpass")
        XCTAssertNil(changed)
        let fm = FileManager.default
        let newBlob = try Data(contentsOf: s1.filesDir.appendingPathComponent(blob))
        let newData = try Data(contentsOf: dir.appendingPathComponent("data.bin"))
        try newBlob.write(to: s1.filesDir.appendingPathComponent(blob + ".new"))
        try newData.write(to: dir.appendingPathComponent("data.bin.new"))
        try Data([9, 9, 9]).write(to: s1.filesDir.appendingPathComponent(blob))   // «старый» блоб
        s1.lock()

        let s2 = AppState(storageDir: dir, iterations: 1000)
        let ok = await s2.login("newpass")
        XCTAssertNil(ok)
        XCTAssertEqual(s2.data.cards.map(\.title), savedData.cards.map(\.title))
        XCTAssertFalse(fm.fileExists(atPath: s2.filesDir.appendingPathComponent(blob + ".new").path))
        let back = try await s2.loadFile(blob)
        XCTAssertEqual(back, Data("скан".utf8), "подмена должна быть доделана при входе")
    }
}
