-- ance: актёры, подборки и фильтры «Вселенной» по библиотеке на сервере.
-- Вставить целиком в SQL Editor и нажать Run. Можно запускать повторно. Требует 0001–0005.

-- ───────────────────────── Актёры ─────────────────────────
alter table public.films add column if not exists actors text[] not null default '{}';

-- Закачка теперь сохраняет и актёров.
create or replace function public.load_films(token text, rows jsonb)
returns int language plpgsql security definer set search_path = public as $$
declare n int;
begin
    perform public.check_catalog_token(token);
    insert into public.films as f (id, title, original_title, year, description, short_description, minutes,
                                   countries, genres, directors, actors, poster_url, poster_preview_url,
                                   rating_kp, rating_imdb, votes_kp, kind, updated_at)
    select r.id, r.title, r.original_title, r.year, r.description, r.short_description, r.minutes,
           coalesce(r.countries, '{}'), coalesce(r.genres, '{}'), coalesce(r.directors, '{}'), coalesce(r.actors, '{}'),
           r.poster_url, r.poster_preview_url, r.rating_kp, r.rating_imdb, coalesce(r.votes_kp, 0),
           coalesce(r.kind, 'movie'), now()
    from jsonb_to_recordset(rows) as r(id bigint, title text, original_title text, year int, description text,
         short_description text, minutes int, countries text[], genres text[], directors text[], actors text[],
         poster_url text, poster_preview_url text, rating_kp numeric, rating_imdb numeric, votes_kp int, kind text)
    where r.id is not null and r.title is not null
    on conflict (id) do update set
        title = excluded.title, original_title = excluded.original_title, year = excluded.year,
        description = excluded.description, short_description = excluded.short_description,
        minutes = excluded.minutes, countries = excluded.countries, genres = excluded.genres,
        directors = excluded.directors,
        actors = case when cardinality(excluded.actors) > 0 then excluded.actors else f.actors end,
        poster_url = excluded.poster_url,
        poster_preview_url = excluded.poster_preview_url, rating_kp = excluded.rating_kp,
        rating_imdb = excluded.rating_imdb, votes_kp = excluded.votes_kp, kind = excluded.kind,
        updated_at = now();
    get diagnostics n = row_count;
    return n;
end $$;
revoke execute on function public.load_films(text, jsonb) from public, authenticated;
grant execute on function public.load_films(text, jsonb) to anon;

-- Пройти библиотеку заново, чтобы у уже загруженных фильмов появились актёры.
-- Метка ставится один раз: повторный запуск этого файла закачку не сбрасывает.
do $$
begin
    if not exists (select 1 from public.catalog_state where key = 'actors_rewalk') then
        delete from public.catalog_state where key like 'slice:%';
        insert into public.catalog_state (key, value) values ('actors_rewalk', 'started');
    end if;
end $$;

-- ───────────────────────── Подборки и фильтры ─────────────────────────
-- Фильтр «Вселенной»: внутри группы — «или», между группами — «и». Пустая группа не ограничивает.
-- Архетипы и чувства приложение переводит в жанры (any_genres) — у фильмов библиотеки они считаются по жанрам.
create or replace function public.filter_films(
    genres text[] default '{}',
    any_genres text[] default '{}',
    countries text[] default '{}',
    exclude_countries text[] default '{}',
    decades int[] default '{}',
    director text default '',
    min_votes int default 0,
    lim int default 60,
    skip int default 0)
returns setof public.films
language sql stable as $$
    select f.* from public.films f
    where (cardinality(filter_films.genres) = 0 or f.genres && filter_films.genres)
      and (cardinality(any_genres) = 0 or f.genres && any_genres)
      and (cardinality(filter_films.countries) = 0 or f.countries && filter_films.countries)
      and (cardinality(exclude_countries) = 0 or not (f.countries && exclude_countries))
      and (cardinality(decades) = 0 or (case when f.year < 1950 then 0 else (f.year / 10) * 10 end) = any(decades))
      and (coalesce(trim(director), '') = '' or exists (
            select 1 from unnest(f.directors) d where d ilike '%' || trim(filter_films.director) || '%'))
      and f.votes_kp >= min_votes
    order by f.votes_kp desc
    limit lim offset skip;
$$;

-- Страны для фильтра — по числу фильмов.
create or replace function public.country_facets(lim int default 60)
returns table (name text, films bigint)
language sql stable as $$
    select c, count(*) from public.films, unnest(countries) c
    group by c order by count(*) desc limit lim;
$$;

-- Подсказки режиссёров по началу имени или фамилии.
create or replace function public.director_suggestions(q text, lim int default 8)
returns table (name text, films bigint)
language sql stable as $$
    select d, count(*) from public.films, unnest(directors) d
    where length(trim(q)) > 0 and (d ilike trim(q) || '%' or d ilike '% ' || trim(q) || '%')
    group by d order by count(*) desc limit lim;
$$;

revoke execute on function public.filter_films(text[], text[], text[], text[], int[], text, int, int, int) from public, anon;
revoke execute on function public.country_facets(int) from public, anon;
revoke execute on function public.director_suggestions(text, int) from public, anon;
grant execute on function public.filter_films(text[], text[], text[], text[], int[], text, int, int, int) to authenticated;
grant execute on function public.country_facets(int) to authenticated;
grant execute on function public.director_suggestions(text, int) to authenticated;

select 'Готово: актёры и фильтры по библиотеке' as "Результат";
