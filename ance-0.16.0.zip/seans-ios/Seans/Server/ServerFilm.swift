import Foundation
import UIKit
import ImageIO

/// Фильм из библиотеки на сервере (данные Кинопоиска через ПоискКино).
/// Поля — как в таблице films; с сервера приходят в snake_case, на диске хранятся как есть.
struct ServerFilm: Codable, Hashable {
    let id: Int
    let title: String
    let originalTitle: String?
    let year: Int?
    let description: String?
    let shortDescription: String?
    let minutes: Int?
    let countries: [String]?
    let genres: [String]?
    let directors: [String]?
    let actors: [String]?
    let posterUrl: String?
    let posterPreviewUrl: String?
    let ratingKp: Double?
    let ratingImdb: Double?
    let votesKp: Int?
    let kind: String?
}

extension FilmItem {
    /// id фильма с сервера в приложении: «kp» + id Кинопоиска.
    static func serverID(_ kinopoiskID: Int) -> String { "kp\(kinopoiskID)" }

    init(server f: ServerFilm) {
        let filmGenres = f.genres ?? []
        let original = f.originalTitle?.trimmingCharacters(in: .whitespacesAndNewlines)
        self.init(
            id: FilmItem.serverID(f.id),
            title: f.title,
            originalTitle: (original?.isEmpty ?? true) || original == f.title ? nil : original,
            year: f.year,
            countries: f.countries ?? [],
            directors: f.directors ?? [],
            minutes: (f.minutes ?? 0) > 0 ? f.minutes : nil,
            genres: filmGenres,
            synopsis: f.description ?? f.shortDescription,
            moods: [],
            cover: CoverStyle.auto(seed: FilmItem.serverID(f.id)),
            photo: nil,
            isCustom: false,
            isRecommended: false,
            searchKey: FilmItem.makeSearchKey(title: f.title, original: original, year: f.year, directors: f.directors ?? []),
            feelings: FilmTags.feelings(genres: filmGenres, year: f.year),
            words: [],
            archetypes: Array(Archetype.forGenres(filmGenres).prefix(Archetype.maxPerFilm)),
            posterURL: f.posterUrl.flatMap { URL(string: $0) },
            posterPreviewURL: f.posterPreviewUrl.flatMap { URL(string: $0) },
            ratingKP: f.ratingKp,
            ratingIMDb: f.ratingImdb,
            actors: f.actors ?? []
        )
    }
}

/// Афиши с сервера: память → файл в кэше телефона → интернет.
/// Картинка уменьшается до нужного размера сразу при чтении, чтобы сетка из сотни афиш не съедала память.
enum PosterStore {
    private static let memory: NSCache<NSString, UIImage> = {
        let cache = NSCache<NSString, UIImage>()
        cache.countLimit = 240
        return cache
    }()

    private static let directory: URL = {
        let base = FileManager.default.urls(for: .cachesDirectory, in: .userDomainMask)[0]
        let dir = base.appendingPathComponent("posters", isDirectory: true)
        try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        return dir
    }()

    private static func key(_ url: URL, _ maxPixel: CGFloat) -> NSString {
        "\(Int(maxPixel))|\(url.absoluteString)" as NSString
    }

    private static func fileName(_ url: URL) -> String {
        var hash: UInt64 = 1469598103934665603
        for byte in url.absoluteString.utf8 {
            hash = (hash ^ UInt64(byte)) &* 1099511628211
        }
        return String(hash, radix: 16) + ".img"
    }

    static func cached(_ url: URL, maxPixel: CGFloat) -> UIImage? {
        memory.object(forKey: key(url, maxPixel))
    }

    static func load(_ url: URL, maxPixel: CGFloat) async -> UIImage? {
        let memoryKey = key(url, maxPixel)
        if let image = memory.object(forKey: memoryKey) { return image }
        let file = directory.appendingPathComponent(fileName(url))
        if let data = try? Data(contentsOf: file), let image = downsample(data, maxPixel: maxPixel) {
            memory.setObject(image, forKey: memoryKey)
            return image
        }
        guard let result = try? await URLSession.shared.data(from: url),
              (result.1 as? HTTPURLResponse)?.statusCode == 200,
              let image = downsample(result.0, maxPixel: maxPixel) else { return nil }
        try? result.0.write(to: file, options: .atomic)
        memory.setObject(image, forKey: memoryKey)
        return image
    }

    private static func downsample(_ data: Data, maxPixel: CGFloat) -> UIImage? {
        let sourceOptions = [kCGImageSourceShouldCache: false] as CFDictionary
        guard let source = CGImageSourceCreateWithData(data as CFData, sourceOptions) else { return nil }
        let options = [kCGImageSourceCreateThumbnailFromImageAlways: true,
                       kCGImageSourceShouldCacheImmediately: true,
                       kCGImageSourceCreateThumbnailWithTransform: true,
                       kCGImageSourceThumbnailMaxPixelSize: maxPixel] as CFDictionary
        guard let image = CGImageSourceCreateThumbnailAtIndex(source, 0, options) else { return nil }
        return UIImage(cgImage: image)
    }
}
