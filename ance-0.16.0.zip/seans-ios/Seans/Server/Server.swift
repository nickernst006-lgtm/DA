import Foundation
import Observation

/// Вход в аккаунт: хранится в связке ключей, обновляется сам.
struct AuthSession: Codable, Equatable {
    var accessToken: String
    var refreshToken: String
    var expiresAt: Date
    var userID: String
    var email: String
}

enum ServerError: LocalizedError {
    case notConfigured
    case wrongCredentials
    case offline
    case sessionExpired
    case wrongPassword
    case http(Int, String)

    var errorDescription: String? {
        switch self {
        case .notConfigured:
            return "Нет адреса сервера в этой сборке."
        case .wrongCredentials:
            return "Неверная почта или пароль."
        case .offline:
            return "Нет связи с сервером. Проверьте интернет — или адрес сервера, если его заблокировали."
        case .sessionExpired:
            return "Вход устарел. Войдите ещё раз."
        case .wrongPassword:
            return "Текущий пароль не подходит."
        case .http(let code, let text):
            if text.contains("email_exists") || text.contains("already been registered") {
                return "Эта почта уже занята другим аккаунтом."
            }
            if text.contains("profiles_username_key") || (code == 409 && text.contains("23505")) {
                return "Этот ID уже занят. Придумайте другой."
            }
            if text.contains("profiles_username_format") {
                return "ID — от 3 до 20 строчных латинских букв и цифр."
            }
            if text.contains("weak_password") || text.contains("Password should be") {
                return "Пароль слишком простой: нужно не меньше 6 знаков."
            }
            if text.contains("same_password") {
                return "Новый пароль совпадает с текущим."
            }
            return "Сервер ответил ошибкой \(code). Попробуйте позже."
        }
    }
}

/// Связь с сервером ance (Supabase): вход по почте и паролю и запросы к базе.
/// Работает через обычный REST — без сторонних библиотек.
@MainActor
@Observable
final class Server {
    private(set) var session: AuthSession?
    private(set) var config: ServerConfig?
    /// Удалось ли последнее обращение к серверу.
    private(set) var isReachable = true

    @ObservationIgnored private var refreshTask: Task<Void, Error>?
    private let urlSession: URLSession

    private static let sessionKey = "session"

    static let decoder: JSONDecoder = {
        let decoder = JSONDecoder()
        decoder.keyDecodingStrategy = .convertFromSnakeCase
        return decoder
    }()

    init() {
        let configuration = URLSessionConfiguration.default
        configuration.timeoutIntervalForRequest = 20
        configuration.timeoutIntervalForResource = 60
        urlSession = URLSession(configuration: configuration)
        config = ServerConfig.current()
        if let data = Keychain.load(Server.sessionKey),
           let saved = try? JSONDecoder().decode(AuthSession.self, from: data) {
            session = saved
        }
    }

    var isSignedIn: Bool { session != nil }
    var userID: String? { session?.userID }
    var email: String? { session?.email }

    /// Перечитать адрес и ключ (после изменения в «Настройках сервера»).
    func reloadConfig() {
        config = ServerConfig.current()
    }

    // MARK: Вход и выход

    func signIn(email: String, password: String) async throws {
        let cleanEmail = email.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        let (data, _) = try await perform("auth/v1/token",
                                          query: [URLQueryItem(name: "grant_type", value: "password")],
                                          method: "POST",
                                          json: ["email": cleanEmail, "password": password],
                                          token: nil)
        try store(data, fallbackEmail: cleanEmail)
    }

    func signOut() {
        let token = session?.accessToken
        session = nil
        Keychain.delete(Server.sessionKey)
        // Сообщаем серверу, что вход больше не нужен; ответ не важен.
        if let token {
            Task { _ = try? await self.perform("auth/v1/logout", method: "POST", json: nil, token: token) }
        }
    }

    private struct TokenUser: Decodable {
        let id: String
        let email: String?
    }

    private struct TokenResponse: Decodable {
        let accessToken: String
        let refreshToken: String
        let expiresIn: Double?
        let expiresAt: Double?
        let user: TokenUser?
    }

    private func store(_ data: Data, fallbackEmail: String) throws {
        let response = try Server.decoder.decode(TokenResponse.self, from: data)
        let expires = response.expiresAt.map { Date(timeIntervalSince1970: $0) }
            ?? Date().addingTimeInterval(response.expiresIn ?? 3600)
        let new = AuthSession(accessToken: response.accessToken,
                              refreshToken: response.refreshToken,
                              expiresAt: expires,
                              userID: response.user?.id ?? session?.userID ?? "",
                              email: response.user?.email ?? fallbackEmail)
        setSession(new)
    }

    fileprivate func setSession(_ new: AuthSession) {
        session = new
        if let encoded = try? JSONEncoder().encode(new) {
            Keychain.save(encoded, for: Server.sessionKey)
        }
    }

    /// Обновить вход. Если сразу несколько запросов увидели, что вход устарел, обновляем один раз.
    private func refresh() async throws {
        if let running = refreshTask {
            try await running.value
            return
        }
        let task = Task { try await self.performRefresh() }
        refreshTask = task
        defer { refreshTask = nil }
        try await task.value
    }

    private func performRefresh() async throws {
        guard let current = session else { throw ServerError.sessionExpired }
        do {
            let (data, _) = try await perform("auth/v1/token",
                                              query: [URLQueryItem(name: "grant_type", value: "refresh_token")],
                                              method: "POST",
                                              json: ["refresh_token": current.refreshToken],
                                              token: nil)
            try store(data, fallbackEmail: current.email)
        } catch ServerError.wrongCredentials {
            // Вход отозван (например, аккаунт удалён) — просим войти заново.
            signOut()
            throw ServerError.sessionExpired
        }
    }

    // MARK: Запросы

    private func makeRequest(_ config: ServerConfig, path: String, query: [URLQueryItem], method: String,
                             json: Any?, raw: Data?, token: String?, headers: [String: String]) throws -> URLRequest {
        guard var parts = URLComponents(url: config.url.appendingPathComponent(path), resolvingAgainstBaseURL: false) else {
            throw ServerError.notConfigured
        }
        if !query.isEmpty { parts.queryItems = query }
        guard let url = parts.url else { throw ServerError.notConfigured }
        var request = URLRequest(url: url)
        request.httpMethod = method
        request.setValue(config.key, forHTTPHeaderField: "apikey")
        if let token {
            request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        } else if config.key.hasPrefix("eyJ") {
            // Старый ключ anon — это JWT, его передают и как Bearer.
            request.setValue("Bearer \(config.key)", forHTTPHeaderField: "Authorization")
        }
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        for (name, value) in headers { request.setValue(value, forHTTPHeaderField: name) }
        if let json {
            request.httpBody = try JSONSerialization.data(withJSONObject: json)
            request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        } else if let raw {
            request.httpBody = raw
        }
        return request
    }

    private func perform(_ path: String, query: [URLQueryItem] = [], method: String = "GET", json: Any? = nil,
                         raw: Data? = nil, token: String?, headers: [String: String] = [:]) async throws -> (Data, HTTPURLResponse) {
        guard let config else { throw ServerError.notConfigured }
        let request = try makeRequest(config, path: path, query: query, method: method,
                                      json: json, raw: raw, token: token, headers: headers)
        let result: (Data, URLResponse)
        do {
            result = try await urlSession.data(for: request)
        } catch {
            isReachable = false
            throw ServerError.offline
        }
        isReachable = true
        let data = result.0
        guard let http = result.1 as? HTTPURLResponse else { throw ServerError.http(0, "") }
        guard (200..<300).contains(http.statusCode) else {
            let text = String(data: data, encoding: .utf8) ?? ""
            if path == "auth/v1/token" && (http.statusCode == 400 || http.statusCode == 401) {
                throw ServerError.wrongCredentials
            }
            throw ServerError.http(http.statusCode, text)
        }
        return (data, http)
    }

    /// Запрос от имени вошедшего: вход обновляется сам, когда устаревает.
    private func authorized(_ path: String, query: [URLQueryItem] = [], method: String = "GET",
                            json: Any? = nil, raw: Data? = nil,
                            headers: [String: String] = [:]) async throws -> (Data, HTTPURLResponse) {
        guard let current = session else { throw ServerError.sessionExpired }
        if current.expiresAt.timeIntervalSinceNow < 60 {
            try await refresh()
        }
        do {
            return try await perform(path, query: query, method: method, json: json, raw: raw,
                                     token: session?.accessToken, headers: headers)
        } catch ServerError.http(let code, _) where code == 401 {
            try await refresh()
            return try await perform(path, query: query, method: method, json: json, raw: raw,
                                     token: session?.accessToken, headers: headers)
        }
    }

    /// RPC без ответа (функция возвращает void).
    func call(_ name: String, _ params: [String: Any] = [:]) async throws {
        _ = try await authorized("rest/v1/rpc/\(name)", method: "POST", json: params)
    }

    /// Функция базы (RPC).
    func rpc<T: Decodable>(_ name: String, _ params: [String: Any] = [:]) async throws -> T {
        let (data, _) = try await authorized("rest/v1/rpc/\(name)", method: "POST", json: params)
        return try Server.decoder.decode(T.self, from: data)
    }

    /// Чтение таблицы: фильтры в формате PostgREST (id=eq.5, order=created_at.asc).
    func select<T: Decodable>(_ table: String, _ query: [URLQueryItem]) async throws -> T {
        let (data, _) = try await authorized("rest/v1/\(table)", query: query)
        return try Server.decoder.decode(T.self, from: data)
    }

    func update(_ table: String, match: [URLQueryItem], values: [String: Any]) async throws {
        _ = try await authorized("rest/v1/\(table)", query: match, method: "PATCH",
                                 json: values, headers: ["Prefer": "return=minimal"])
    }

    /// Сколько строк в таблице (видимых вошедшему).
    func count(_ table: String) async throws -> Int {
        let (_, response) = try await authorized("rest/v1/\(table)",
                                                 query: [URLQueryItem(name: "select", value: "id"),
                                                         URLQueryItem(name: "limit", value: "1")],
                                                 headers: ["Prefer": "count=exact"])
        let range = response.value(forHTTPHeaderField: "Content-Range") ?? ""
        return Int(range.split(separator: "/").last.map(String.init) ?? "") ?? 0
    }
}

// MARK: - Библиотека

extension Server {
    func searchFilms(_ text: String, limit: Int = 80) async throws -> [ServerFilm] {
        try await rpc("search_films", ["q": text, "lim": limit])
    }

    /// Случайные известные фильмы.
    func randomFilms(limit: Int = 60, minVotes: Int = 20000) async throws -> [ServerFilm] {
        try await rpc("random_films", ["lim": limit, "min_votes": minVotes])
    }

    /// Фильмы по фильтрам и подборкам «Вселенной» — по известности.
    func filterFilms(genres: [String] = [], anyGenres: [String] = [], countries: [String] = [],
                     excludeCountries: [String] = [], decades: [Int] = [], director: String = "",
                     minVotes: Int = 0, limit: Int = 60, skip: Int = 0) async throws -> [ServerFilm] {
        try await rpc("filter_films", ["genres": genres, "any_genres": anyGenres, "countries": countries,
                                       "exclude_countries": excludeCountries, "decades": decades,
                                       "director": director, "min_votes": minVotes, "lim": limit, "skip": skip])
    }

    struct Facet: Decodable { let name: String; let films: Int }

    func countryFacets() async throws -> [String] {
        let rows: [Facet] = try await rpc("country_facets", ["lim": 60])
        return rows.map(\.name)
    }

    func directorSuggestions(_ text: String) async throws -> [String] {
        let rows: [Facet] = try await rpc("director_suggestions", ["q": text, "lim": 8])
        return rows.map(\.name)
    }

    func libraryCount() async throws -> Int {
        try await count("films")
    }
}

// MARK: - Синхронизация и файлы

extension Server {
    /// Свои строки таблицы — сырой JSON (разбирает SyncEngine).
    func ownRows(_ table: String) async throws -> Data {
        guard let id = userID else { throw ServerError.sessionExpired }
        let (data, _) = try await authorized("rest/v1/\(table)",
                                             query: [URLQueryItem(name: "select", value: "*"),
                                                     URLQueryItem(name: "user_id", value: "eq.\(id)")])
        return data
    }

    /// Добавить или заменить строки (по первичному ключу).
    func upsert(_ table: String, rows: [[String: Any]]) async throws {
        guard !rows.isEmpty else { return }
        _ = try await authorized("rest/v1/\(table)", method: "POST", json: rows,
                                 headers: ["Prefer": "resolution=merge-duplicates,return=minimal"])
    }

    /// Удалить свои строки, у которых столбец равен одному из значений.
    func deleteRows(_ table: String, column: String, values: [String]) async throws {
        guard !values.isEmpty, let id = userID else { return }
        for chunk in stride(from: 0, to: values.count, by: 100).map({ Array(values[$0..<min($0 + 100, values.count)]) }) {
            let list = chunk.map { "\"\($0)\"" }.joined(separator: ",")
            _ = try await authorized("rest/v1/\(table)", query: [URLQueryItem(name: column, value: "in.(\(list))"),
                                                                URLQueryItem(name: "user_id", value: "eq.\(id)")],
                                     method: "DELETE", headers: ["Prefer": "return=minimal"])
        }
    }

    func uploadFile(bucket: String, path: String, data: Data, contentType: String = "image/jpeg") async throws {
        _ = try await authorized("storage/v1/object/\(bucket)/\(path)", method: "POST", raw: data,
                                 headers: ["Content-Type": contentType, "x-upsert": "true"])
    }

    func downloadFile(bucket: String, path: String) async throws -> Data {
        let (data, _) = try await authorized("storage/v1/object/authenticated/\(bucket)/\(path)")
        return data
    }

    func deleteFiles(bucket: String, paths: [String]) async {
        guard !paths.isEmpty else { return }
        _ = try? await authorized("storage/v1/object/\(bucket)", method: "DELETE", json: ["prefixes": paths])
    }

    /// Коллекция другого участника — если он её показывает.
    func collection(of userID: String) async throws -> Data {
        let (data, _) = try await authorized("rest/v1/collection_items",
                                             query: [URLQueryItem(name: "select", value: "film_id,status,added_at,seen_at"),
                                                     URLQueryItem(name: "user_id", value: "eq.\(userID)"),
                                                     URLQueryItem(name: "order", value: "added_at.desc")])
        return data
    }

    /// Анкеты других участников по фильму — те, что они показывают (замки RLS).
    func otherSurveys(filmID: String) async throws -> [OtherSurvey] {
        guard let me = userID else { throw ServerError.sessionExpired }
        let (data, _) = try await authorized("rest/v1/surveys",
                                             query: [URLQueryItem(name: "select", value: "*"),
                                                     URLQueryItem(name: "film_id", value: "eq.\(filmID)"),
                                                     URLQueryItem(name: "user_id", value: "neq.\(me)")])
        return try Server.decoder.decode([OtherSurvey].self, from: data)
    }

    /// Пути фото эссе другого участника к фильму.
    func essayPhotoPaths(user: String, filmID: String) async throws -> [String] {
        struct BlockID: Decodable { let id: String }
        struct PhotoPath: Decodable { let path: String; let ord: Int }
        let blocks: [BlockID] = try await select("journal_blocks", [
            URLQueryItem(name: "select", value: "id"),
            URLQueryItem(name: "user_id", value: "eq.\(user)"),
            URLQueryItem(name: "film_id", value: "eq.\(filmID)"),
            URLQueryItem(name: "kind", value: "eq.essay")])
        guard !blocks.isEmpty else { return [] }
        let list = blocks.map(\.id).joined(separator: ",")
        let photos: [PhotoPath] = try await select("journal_photos", [
            URLQueryItem(name: "select", value: "path,ord"),
            URLQueryItem(name: "block_id", value: "in.(\(list))"),
            URLQueryItem(name: "order", value: "ord.asc")])
        return photos.map(\.path)
    }

    /// Замены обложек от владельца: номер фильма → адрес картинки.
    func coverOverrides() async throws -> [String: String] {
        struct Row: Decodable { let filmId: String; let imageUrl: String }
        let rows: [Row] = try await select("cover_overrides", [URLQueryItem(name: "select", value: "film_id,image_url")])
        var map: [String: String] = [:]
        for row in rows { map[row.filmId] = row.imageUrl }
        return map
    }

    /// Фильмы библиотеки по номерам Кинопоиска.
    func films(ids: [Int]) async throws -> [ServerFilm] {
        guard !ids.isEmpty else { return [] }
        var result: [ServerFilm] = []
        for chunk in stride(from: 0, to: ids.count, by: 100).map({ Array(ids[$0..<min($0 + 100, ids.count)]) }) {
            let list = chunk.map(String.init).joined(separator: ",")
            let part: [ServerFilm] = try await select("films", [URLQueryItem(name: "select", value: "*"),
                                                               URLQueryItem(name: "id", value: "in.(\(list))")])
            result += part
        }
        return result
    }
}

// MARK: - Профиль и друзья

extension Server {
    /// Свой профиль целиком.
    func myProfile() async throws -> MyProfile {
        guard let id = userID else { throw ServerError.sessionExpired }
        let rows: [MyProfile] = try await select("profiles", [URLQueryItem(name: "select", value: "*"),
                                                              URLQueryItem(name: "id", value: "eq.\(id)")])
        guard let me = rows.first else { throw ServerError.http(404, "Профиль не найден") }
        return me
    }

    /// Изменить свой профиль: ключи — столбцы таблицы profiles.
    func updateMyProfile(_ values: [String: Any]) async throws {
        guard let id = userID else { throw ServerError.sessionExpired }
        try await update("profiles", match: [URLQueryItem(name: "id", value: "eq.\(id)")], values: values)
    }

    /// Свободен ли ID (свой текущий считается свободным).
    func usernameAvailable(_ candidate: String) async throws -> Bool {
        try await rpc("username_available", ["candidate": candidate])
    }

    /// Все остальные участники и ваше отношение к каждому.
    func people() async throws -> [Person] {
        try await rpc("people")
    }

    /// Отправить заявку. Возвращает новое отношение: outgoing или friend (если вас уже звали).
    func sendFriendRequest(to id: String) async throws -> Person.Relation {
        let result: String = try await rpc("send_friend_request", ["target": id])
        return Person.Relation(rawValue: result) ?? .outgoing
    }

    func respondToRequest(from id: String, accept: Bool) async throws {
        try await call("respond_friend_request", ["from_user": id, "accept": accept])
    }

    /// Отменить свою заявку или удалить из друзей.
    func removeFriend(_ id: String) async throws {
        try await call("remove_friend", ["other": id])
    }

    // MARK: Фото профиля

    /// Загрузить фото профиля (JPEG). Возвращает путь в хранилище.
    func uploadAvatar(_ jpeg: Data) async throws -> String {
        guard let id = userID else { throw ServerError.sessionExpired }
        let path = "\(id)/\(Int(Date().timeIntervalSince1970)).jpg"
        _ = try await authorized("storage/v1/object/avatars/\(path)", method: "POST", raw: jpeg,
                                 headers: ["Content-Type": "image/jpeg", "x-upsert": "true",
                                           "Cache-Control": "max-age=31536000"])
        return path
    }

    func deleteAvatar(_ path: String) async {
        _ = try? await authorized("storage/v1/object/avatars/\(path)", method: "DELETE")
    }

    func downloadAvatar(_ path: String) async throws -> Data {
        let (data, _) = try await authorized("storage/v1/object/authenticated/avatars/\(path)")
        return data
    }

    // MARK: Почта и пароль

    /// Сменить почту. Если в Supabase выключено подтверждение почты — меняется сразу.
    /// Возвращает true, если почта уже изменилась, false — если ждёт подтверждения письмом.
    func changeEmail(_ newEmail: String) async throws -> Bool {
        let clean = newEmail.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        let (data, _) = try await authorized("auth/v1/user", method: "PUT", json: ["email": clean])
        struct UserResponse: Decodable { let email: String? }
        let user = try? Server.decoder.decode(UserResponse.self, from: data)
        let changed = (user?.email ?? "").lowercased() == clean
        if changed, var current = session {
            current.email = clean
            setSession(current)
        }
        return changed
    }

    /// Сменить пароль: сначала проверяем текущий — входим им заново.
    func changePassword(current: String, new: String) async throws {
        guard let email else { throw ServerError.sessionExpired }
        do {
            try await signIn(email: email, password: current)
        } catch ServerError.wrongCredentials {
            throw ServerError.wrongPassword
        }
        _ = try await authorized("auth/v1/user", method: "PUT", json: ["password": new])
    }
}

/// Свой профиль — строка таблицы profiles.
struct MyProfile: Codable, Equatable {
    let id: String
    var username: String?
    var name: String
    var about: String
    var avatarPath: String?
    var shareCollection: Bool
    var shareJournal: Bool
    var friendsAbout: Bool
    var strangersAbout: Bool
    var strangersCollection: Bool
    var strangersJournal: Bool
}

/// Другой участник ance — как его видите вы.
struct Person: Codable, Identifiable, Hashable {
    enum Relation: String, Codable {
        case friend, incoming, outgoing, none
    }

    let id: String
    var username: String?
    var name: String
    var about: String
    var avatarPath: String?
    var relation: Relation
    var seesCollection: Bool
    var seesJournal: Bool
    var since: String?

    /// Имя для экрана: пустое — «Участник ance».
    var displayName: String {
        let trimmed = name.trimmingCharacters(in: .whitespacesAndNewlines)
        return trimmed.isEmpty ? "Участник ance" : trimmed
    }

    /// «nick» — или nil, если ID ещё не задан.
    var handle: String? {
        guard let username, !username.isEmpty else { return nil }
        return username
    }
}

/// ID пользователя: строчные латинские буквы и цифры, 3–20 знаков.
enum Username {
    static let allowed = Set("abcdefghijklmnopqrstuvwxyz0123456789")
    static let range = 3...20

    /// Оставить только разрешённые знаки: заглавные — в строчные, остальное — прочь.
    static func clean(_ text: String) -> String {
        String(text.lowercased().filter { allowed.contains($0) }.prefix(range.upperBound))
    }

    static func isValid(_ text: String) -> Bool {
        range.contains(text.count) && text.allSatisfy { allowed.contains($0) }
    }
}

/// Анкета другого участника — как её видит вошедший.
struct OtherSurvey: Decodable, Identifiable {
    let userId: String
    let filmId: String
    let rating: Int
    let emotions: [String]
    let aspects: String
    let scales: String
    let ending: String
    let place: String
    let rewatch: String
    let recommend: [String]
    let word: String
    let essay: String
    var id: String { userId }

    /// Та же анкета в виде записи приложения — чтобы показать её теми же пунктами.
    func entry() -> SurveyEntry {
        let e = SurveyEntry(filmID: filmId)
        e.rating = rating
        e.emotions = emotions
        e.aspectsRaw = aspects
        e.scalesRaw = scales
        e.ending = ending
        e.place = place
        e.rewatch = rewatch
        e.recommend = recommend
        e.word = word
        e.essay = essay
        return e
    }
}
