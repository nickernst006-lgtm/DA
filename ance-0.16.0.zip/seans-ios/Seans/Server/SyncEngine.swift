import Foundation
import Observation
import SwiftData
import UIKit

// MARK: - Строки сервера

/// Строки таблиц в том виде, как они лежат на сервере. По ним же считается «отпечаток» записи,
/// чтобы понять, что изменилось: на телефоне, на сервере или нигде.
struct CollectionRow: Codable, Equatable {
    var filmId: String
    var status: String
    var addedAt: Date
    var seenAt: Date?
}

struct SurveyRow: Codable, Equatable {
    var filmId: String
    var date: Date
    var rating: Int
    var emotions: [String]
    var aspects: String
    var scales: String
    var ending: String
    var company: String
    var place: String
    var rewatch: String
    var recommend: [String]
    var word: String
    var essay: String
}

struct BlockRow: Codable, Equatable {
    var id: UUID
    var filmId: String
    var kind: String
    var ord: Double
    var text: String
    var detail: String
    var createdAt: Date
}

struct PhotoRow: Codable, Equatable {
    var id: UUID
    var blockId: UUID
    var ord: Int
    var path: String
}

struct BoardRow: Codable, Equatable {
    var id: UUID
    var blockId: UUID
    var kind: String
    var x: Double
    var y: Double
    var width: Double
    var rotation: Double
    var colorIndex: Int
    var text: String
    var z: Double
    var imagePath: String?
    var fromId: UUID?
    var toId: UUID?
}

/// Даты — как в Postgres, с точностью до миллисекунды.
enum SyncCoding {
    private static let withFraction: ISO8601DateFormatter = {
        let f = ISO8601DateFormatter()
        f.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
        return f
    }()
    private static let plain: ISO8601DateFormatter = {
        let f = ISO8601DateFormatter()
        f.formatOptions = [.withInternetDateTime]
        return f
    }()

    static func parse(_ text: String) -> Date? {
        if let date = withFraction.date(from: text) ?? plain.date(from: text) { return date }
        // Postgres отдаёт до 6 знаков после запятой — обрезаем до 3.
        guard let dot = text.firstIndex(of: ".") else { return nil }
        var digits = ""
        var rest = text[text.index(after: dot)...]
        while let c = rest.first, c.isNumber { digits.append(c); rest = rest.dropFirst() }
        let trimmed = String(text[..<dot]) + "." + String((digits + "000").prefix(3)) + String(rest)
        return withFraction.date(from: trimmed)
    }

    static func format(_ date: Date) -> String {
        withFraction.string(from: date)
    }

    static let decoder: JSONDecoder = {
        let d = JSONDecoder()
        d.keyDecodingStrategy = .convertFromSnakeCase
        d.dateDecodingStrategy = .custom { decoder in
            let text = try decoder.singleValueContainer().decode(String.self)
            guard let date = parse(text) else {
                throw DecodingError.dataCorrupted(.init(codingPath: decoder.codingPath, debugDescription: "Дата: \(text)"))
            }
            return date
        }
        return d
    }()

    static let encoder: JSONEncoder = {
        let e = JSONEncoder()
        e.keyEncodingStrategy = .convertToSnakeCase
        e.outputFormatting = [.sortedKeys]
        e.dateEncodingStrategy = .custom { date, encoder in
            var container = encoder.singleValueContainer()
            try container.encode(format(date))
        }
        return e
    }()

    /// Отпечаток строки: одинаковое содержимое — одинаковый отпечаток.
    static func hash<T: Encodable>(_ row: T) -> String {
        guard let data = try? encoder.encode(row) else { return "" }
        var h: UInt64 = 1469598103934665603
        for byte in data { h = (h ^ UInt64(byte)) &* 1099511628211 }
        return String(h, radix: 16)
    }

    /// Необязательные столбцы: если значения нет, отправляем null — иначе сервер оставит старое.
    static let nullable = ["seen_at", "image_path", "from_id", "to_id"]

    /// Строка для отправки: JSON-объект с user_id.
    static func object<T: Encodable>(_ row: T, user: String) -> [String: Any]? {
        guard let data = try? encoder.encode(row),
              var object = (try? JSONSerialization.jsonObject(with: data)) as? [String: Any] else { return nil }
        object["user_id"] = user
        for key in nullable where object[key] == nil && SyncCoding.has(row, key) { object[key] = NSNull() }
        return object
    }

    /// Есть ли у строки такое поле (по названию в snake_case).
    static func has<T>(_ row: T, _ key: String) -> Bool {
        Mirror(reflecting: row).children.contains { child in
            guard let label = child.label else { return false }
            return label.replacingOccurrences(of: "([a-z])([A-Z])", with: "$1_$2", options: .regularExpression)
                .lowercased() == key
        }
    }
}

// MARK: - Сравнение трёх состояний

/// Что делать с одной таблицей: сравниваем телефон, сервер и то, что было при прошлой синхронизации.
private struct MergePlan<Local, Remote> {
    var push: [(key: String, local: Local)] = []
    var insertLocal: [(key: String, remote: Remote)] = []
    var updateLocal: [(key: String, local: Local, remote: Remote)] = []
    var deleteLocal: [(key: String, local: Local)] = []
    var deleteRemote: [String] = []
    var unchanged: [(key: String, hash: String)] = []
}

private func makePlan<Local, Remote>(locals: [String: (Local, String)], remotes: [String: (Remote, String)],
                                     base: [String: String]) -> MergePlan<Local, Remote> {
    var plan = MergePlan<Local, Remote>()
    let keys = Set(locals.keys).union(remotes.keys)
    for key in keys {
        let local = locals[key]
        let remote = remotes[key]
        let was = base[key]
        switch (local, remote) {
        case let ((l, lh)?, (r, rh)?):
            if lh == rh {
                plan.unchanged.append((key, lh))
            } else if lh != was {
                plan.push.append((key, l))            // изменено на телефоне — телефон главнее
            } else {
                plan.updateLocal.append((key, l, r))  // изменено на сервере (на другом устройстве)
            }
        case let ((l, lh)?, nil):
            if was == nil || lh != was {
                plan.push.append((key, l))            // новое или изменённое на телефоне
            } else {
                plan.deleteLocal.append((key, l))     // удалено на другом устройстве
            }
        case let (nil, (r, rh)?):
            if was == nil || rh != was {
                plan.insertLocal.append((key, r))     // новое с сервера
            } else {
                plan.deleteRemote.append(key)         // удалено на телефоне
            }
        case (nil, nil):
            break
        }
    }
    return plan
}

// MARK: - Синхронизация

/// Синхронизация коллекции, анкет, журналов, фото и досок с сервером.
/// Телефон остаётся главным хранилищем: всё работает и без сети, а при связи изменения уходят на сервер
/// и приходят с него (например, с другого телефона того же человека).
@MainActor
@Observable
final class SyncEngine {
    private let server: Server

    private(set) var isSyncing = false
    private(set) var lastError: String?
    private(set) var lastSync: Date?
    /// Пока синхронизация сама записывает в базу телефона — её сохранения не запускают новую синхронизацию.
    @ObservationIgnored private(set) var isApplying = false
    @ObservationIgnored private var again = false

    init(server: Server) {
        self.server = server
    }

    // Отпечатки прошлой синхронизации: таблица → ключ → отпечаток.
    private struct Base: Codable {
        var user: String
        var tables: [String: [String: String]] = [:]
    }

    private static var baseURL: URL {
        let dir = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
        try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        return dir.appendingPathComponent("sync-base.json")
    }

    private func loadBase(user: String) -> Base {
        if let data = try? Data(contentsOf: SyncEngine.baseURL),
           let base = try? JSONDecoder().decode(Base.self, from: data), base.user == user {
            return base
        }
        return Base(user: user)
    }

    private func saveBase(_ base: Base) {
        if let data = try? JSONEncoder().encode(base) {
            try? data.write(to: SyncEngine.baseURL, options: .atomic)
        }
    }

    /// Синхронизировать сейчас. Если уже идёт — повторить сразу после.
    @discardableResult
    func sync(_ context: ModelContext) async -> Bool {
        guard server.isSignedIn, let user = server.userID, !user.isEmpty else { return false }
        if isSyncing { again = true; return true }
        isSyncing = true
        defer { isSyncing = false }
        var ok = true
        repeat {
            again = false
            do {
                try await run(context, user: user)
                lastError = nil
                lastSync = Date()
            } catch {
                lastError = (error as? LocalizedError)?.errorDescription ?? error.localizedDescription
                ok = false
                again = false
            }
        } while again
        return ok
    }

    /// Перед выходом из аккаунта: стереть с телефона всё личное — оно уже на сервере.
    func eraseLocal(_ context: ModelContext) {
        isApplying = true
        defer { isApplying = false }
        try? context.delete(model: BoardItem.self)
        try? context.delete(model: JournalPhoto.self)
        try? context.delete(model: JournalBlock.self)
        try? context.delete(model: SurveyEntry.self)
        try? context.delete(model: CollectionItem.self)
        try? context.save()
        try? FileManager.default.removeItem(at: SyncEngine.baseURL)
    }

    /// Фильм из старой встроенной базы: у фильмов с сервера id начинается с «kp».
    static func isLegacy(_ filmID: String) -> Bool { !filmID.hasPrefix("kp") }

    /// Убрать с телефона анкеты, отметки и эссе фильмов из старой встроенной базы — этих фильмов больше нет.
    /// Следующая синхронизация удалит их и с сервера.
    static func purgeLegacy(_ context: ModelContext) {
        var changed = false
        for item in (try? context.fetch(FetchDescriptor<CollectionItem>())) ?? [] where isLegacy(item.filmID) {
            context.delete(item); changed = true
        }
        for survey in (try? context.fetch(FetchDescriptor<SurveyEntry>())) ?? [] where isLegacy(survey.filmID) {
            context.delete(survey); changed = true
        }
        for block in (try? context.fetch(FetchDescriptor<JournalBlock>())) ?? [] where isLegacy(block.filmID) {
            for photo in block.photos ?? [] { context.delete(photo) }
            for item in block.boardItems ?? [] { context.delete(item) }
            context.delete(block); changed = true
        }
        if changed { try? context.save() }
    }

    private func run(_ context: ModelContext, user: String) async throws {
        var base = loadBase(user: user)
        Self.purgeLegacy(context)

        // 1. Сервер
        async let rc = server.ownRows("collection_items")
        async let rs = server.ownRows("surveys")
        async let rb = server.ownRows("journal_blocks")
        async let rp = server.ownRows("journal_photos")
        async let ri = server.ownRows("board_items")
        let (dc, ds, db, dp, di) = try await (rc, rs, rb, rp, ri)
        let remoteCollection = try SyncCoding.decoder.decode([CollectionRow].self, from: dc)
        let remoteSurveys = try SyncCoding.decoder.decode([SurveyRow].self, from: ds)
        let remoteBlocks = try SyncCoding.decoder.decode([BlockRow].self, from: db)
        let remotePhotos = try SyncCoding.decoder.decode([PhotoRow].self, from: dp)
        let remoteBoards = try SyncCoding.decoder.decode([BoardRow].self, from: di)

        // 2. Телефон
        let items = (try? context.fetch(FetchDescriptor<CollectionItem>())) ?? []
        let surveys = (try? context.fetch(FetchDescriptor<SurveyEntry>())) ?? []
        let blocks = (try? context.fetch(FetchDescriptor<JournalBlock>())) ?? []
        let photos = (try? context.fetch(FetchDescriptor<JournalPhoto>())) ?? []
        let boards = (try? context.fetch(FetchDescriptor<BoardItem>())) ?? []

        func localMap<L, R: Encodable>(_ list: [L], key: (L) -> String, row: (L) -> R?) -> [String: (L, String)] {
            var map: [String: (L, String)] = [:]
            for item in list { if let r = row(item) { map[key(item)] = (item, SyncCoding.hash(r)) } }
            return map
        }
        func remoteMap<R: Encodable>(_ list: [R], key: (R) -> String) -> [String: (R, String)] {
            var map: [String: (R, String)] = [:]
            for r in list { map[key(r)] = (r, SyncCoding.hash(r)) }
            return map
        }

        let planC = makePlan(locals: localMap(items, key: \.filmID, row: Self.row),
                             remotes: remoteMap(remoteCollection, key: \.filmId), base: base.tables["c"] ?? [:])
        let planS = makePlan(locals: localMap(surveys, key: \.filmID, row: Self.row),
                             remotes: remoteMap(remoteSurveys, key: \.filmId), base: base.tables["s"] ?? [:])
        let planB = makePlan(locals: localMap(blocks, key: { $0.id.uuidString }, row: Self.row),
                             remotes: remoteMap(remoteBlocks, key: { $0.id.uuidString }), base: base.tables["b"] ?? [:])
        let planP = makePlan(locals: localMap(photos, key: { $0.id.uuidString }, row: { Self.row($0, user: user) }),
                             remotes: remoteMap(remotePhotos, key: { $0.id.uuidString }), base: base.tables["p"] ?? [:])
        let planI = makePlan(locals: localMap(boards, key: { $0.id.uuidString }, row: { Self.row($0, user: user) }),
                             remotes: remoteMap(remoteBoards, key: { $0.id.uuidString }), base: base.tables["i"] ?? [:])

        // 3. С сервера на телефон
        isApplying = true
        var blockByID: [UUID: JournalBlock] = [:]
        for block in blocks { blockByID[block.id] = block }

        for (_, r) in planC.insertLocal {
            let item = CollectionItem(filmID: r.filmId, status: CollectionStatus(rawValue: r.status) ?? .want)
            Self.apply(r, to: item)
            context.insert(item)
        }
        for (_, l, r) in planC.updateLocal { Self.apply(r, to: l) }
        for (_, l) in planC.deleteLocal { context.delete(l) }

        for (_, r) in planS.insertLocal {
            let entry = SurveyEntry(filmID: r.filmId)
            Self.apply(r, to: entry)
            context.insert(entry)
        }
        for (_, l, r) in planS.updateLocal { Self.apply(r, to: l) }
        for (_, l) in planS.deleteLocal { context.delete(l) }

        for (_, r) in planB.insertLocal {
            let block = JournalBlock(filmID: r.filmId, kind: JournalKind(rawValue: r.kind) ?? .text, order: r.ord)
            block.id = r.id
            Self.apply(r, to: block)
            context.insert(block)
            blockByID[r.id] = block
        }
        for (_, l, r) in planB.updateLocal { Self.apply(r, to: l) }
        for (_, l) in planB.deleteLocal { context.delete(l); blockByID[l.id] = nil }

        // Фото и картинки досок скачиваются; без связи — попробуем в следующий раз.
        var skippedPhotos = Set<String>()
        for (key, r) in planP.insertLocal {
            guard let block = blockByID[r.blockId],
                  let data = try? await server.downloadFile(bucket: "journal", path: r.path) else {
                skippedPhotos.insert(key)
                continue
            }
            let photo = JournalPhoto(data: data, order: r.ord)
            photo.id = r.id
            context.insert(photo)
            photo.block = block
        }
        for (_, l, r) in planP.updateLocal { l.order = r.ord; if let block = blockByID[r.blockId] { l.block = block } }
        for (_, l) in planP.deleteLocal { context.delete(l) }

        var skippedBoards = Set<String>()
        for (key, r) in planI.insertLocal {
            guard let block = blockByID[r.blockId] else { skippedBoards.insert(key); continue }
            var image: Data?
            if let path = r.imagePath {
                guard let data = try? await server.downloadFile(bucket: "journal", path: path) else {
                    skippedBoards.insert(key); continue
                }
                image = data
            }
            let item = BoardItem(kind: BoardItemKind(rawValue: r.kind) ?? .sticker, x: r.x, y: r.y, width: r.width, z: r.z)
            item.id = r.id
            item.imageData = image
            Self.apply(r, to: item)
            context.insert(item)
            item.block = block
        }
        for (_, l, r) in planI.updateLocal {
            Self.apply(r, to: l)
            if let block = blockByID[r.blockId] { l.block = block }
        }
        for (_, l) in planI.deleteLocal { context.delete(l) }

        try? context.save()
        isApplying = false

        // 4. С телефона на сервер: сначала строки, на которые ссылаются другие (блоки), потом остальное.
        try await server.upsert("collection_items",
                                rows: planC.push.compactMap { Self.row($0.local).flatMap { SyncCoding.object($0, user: user) } })
        try await server.upsert("surveys",
                                rows: planS.push.compactMap { Self.row($0.local).flatMap { SyncCoding.object($0, user: user) } })
        try await server.upsert("journal_blocks",
                                rows: planB.push.compactMap { Self.row($0.local).flatMap { SyncCoding.object($0, user: user) } })

        // Новые фото — сначала файл, потом строка.
        let knownPhotos = Set(remotePhotos.map(\.id))
        var photoRows: [[String: Any]] = []
        for (_, photo) in planP.push {
            guard let row = Self.row(photo, user: user), photo.block != nil else { continue }
            if !knownPhotos.contains(photo.id), let data = photo.data {
                try await server.uploadFile(bucket: "journal", path: row.path, data: data)
            }
            if let object = SyncCoding.object(row, user: user) { photoRows.append(object) }
        }
        try await server.upsert("journal_photos", rows: photoRows)

        let remoteBoardPaths = Dictionary(uniqueKeysWithValues: remoteBoards.map { ($0.id, $0.imagePath) })
        var boardRows: [[String: Any]] = []
        for (_, item) in planI.push {
            guard let row = Self.row(item, user: user), item.block != nil else { continue }
            if let path = row.imagePath, remoteBoardPaths[item.id] ?? nil == nil, let data = item.imageData {
                try await server.uploadFile(bucket: "journal", path: path, data: data)
            }
            if let object = SyncCoding.object(row, user: user) { boardRows.append(object) }
        }
        try await server.upsert("board_items", rows: boardRows)

        // Удалённое на телефоне — удалить на сервере (вместе с файлами).
        let photoPaths = Dictionary(uniqueKeysWithValues: remotePhotos.map { ($0.id.uuidString, $0.path) })
        let boardPaths = Dictionary(uniqueKeysWithValues: remoteBoards.map { ($0.id.uuidString, $0.imagePath) })
        try await server.deleteRows("board_items", column: "id", values: planI.deleteRemote)
        await server.deleteFiles(bucket: "journal", paths: planI.deleteRemote.compactMap { boardPaths[$0] ?? nil })
        try await server.deleteRows("journal_photos", column: "id", values: planP.deleteRemote)
        await server.deleteFiles(bucket: "journal", paths: planP.deleteRemote.compactMap { photoPaths[$0] })
        try await server.deleteRows("journal_blocks", column: "id", values: planB.deleteRemote)
        try await server.deleteRows("surveys", column: "film_id", values: planS.deleteRemote)
        try await server.deleteRows("collection_items", column: "film_id", values: planC.deleteRemote)

        // 5. Запоминаем, что теперь совпадает.
        base.tables["c"] = Self.snapshot(items: (try? context.fetch(FetchDescriptor<CollectionItem>())) ?? [],
                                         key: \.filmID, row: Self.row)
        base.tables["s"] = Self.snapshot(items: (try? context.fetch(FetchDescriptor<SurveyEntry>())) ?? [],
                                         key: \.filmID, row: Self.row)
        base.tables["b"] = Self.snapshot(items: (try? context.fetch(FetchDescriptor<JournalBlock>())) ?? [],
                                         key: { $0.id.uuidString }, row: Self.row)
        var photoBase = Self.snapshot(items: (try? context.fetch(FetchDescriptor<JournalPhoto>())) ?? [],
                                      key: { $0.id.uuidString }, row: { Self.row($0, user: user) })
        for key in skippedPhotos { photoBase[key] = nil }
        base.tables["p"] = photoBase
        var boardBase = Self.snapshot(items: (try? context.fetch(FetchDescriptor<BoardItem>())) ?? [],
                                      key: { $0.id.uuidString }, row: { Self.row($0, user: user) })
        for key in skippedBoards { boardBase[key] = nil }
        base.tables["i"] = boardBase
        saveBase(base)
    }

    private static func snapshot<L, R: Encodable>(items: [L], key: (L) -> String, row: (L) -> R?) -> [String: String] {
        var map: [String: String] = [:]
        for item in items { if let r = row(item) { map[key(item)] = SyncCoding.hash(r) } }
        return map
    }

    // MARK: Телефон ↔ строка

    private static func row(_ item: CollectionItem) -> CollectionRow? {
        guard !item.filmID.isEmpty else { return nil }
        return CollectionRow(filmId: item.filmID, status: item.statusRaw, addedAt: item.addedAt, seenAt: item.seenAt)
    }

    private static func apply(_ r: CollectionRow, to item: CollectionItem) {
        item.statusRaw = r.status
        item.addedAt = r.addedAt
        item.seenAt = r.seenAt
    }

    private static func row(_ s: SurveyEntry) -> SurveyRow? {
        guard !s.filmID.isEmpty else { return nil }
        return SurveyRow(filmId: s.filmID, date: s.date, rating: s.rating, emotions: s.emotions,
                         aspects: s.aspectsRaw, scales: s.scalesRaw, ending: s.ending, company: s.company,
                         place: s.place, rewatch: s.rewatch, recommend: s.recommend, word: s.word, essay: s.essay)
    }

    private static func apply(_ r: SurveyRow, to s: SurveyEntry) {
        s.date = r.date
        s.rating = r.rating
        s.emotions = r.emotions
        s.aspectsRaw = r.aspects
        s.scalesRaw = r.scales
        s.ending = r.ending
        s.company = r.company
        s.place = r.place
        s.rewatch = r.rewatch
        s.recommend = r.recommend
        s.word = r.word
        s.essay = r.essay
    }

    private static func row(_ b: JournalBlock) -> BlockRow? {
        guard !b.filmID.isEmpty else { return nil }
        return BlockRow(id: b.id, filmId: b.filmID, kind: b.kindRaw, ord: b.order, text: b.text,
                        detail: b.detail, createdAt: b.createdAt)
    }

    private static func apply(_ r: BlockRow, to b: JournalBlock) {
        b.filmID = r.filmId
        b.kindRaw = r.kind
        b.order = r.ord
        b.text = r.text
        b.detail = r.detail
        b.createdAt = r.createdAt
    }

    private static func row(_ p: JournalPhoto, user: String) -> PhotoRow? {
        guard let block = p.block else { return nil }
        return PhotoRow(id: p.id, blockId: block.id, ord: p.order, path: "\(user)/\(p.id.uuidString.lowercased()).jpg")
    }

    private static func row(_ i: BoardItem, user: String) -> BoardRow? {
        guard let block = i.block else { return nil }
        let path = i.imageData == nil ? nil : "\(user)/board-\(i.id.uuidString.lowercased()).jpg"
        return BoardRow(id: i.id, blockId: block.id, kind: i.kindRaw, x: i.x, y: i.y, width: i.width,
                        rotation: i.rotation, colorIndex: i.colorIndex, text: i.text, z: i.z,
                        imagePath: path, fromId: i.fromID, toId: i.toID)
    }

    private static func apply(_ r: BoardRow, to i: BoardItem) {
        i.kindRaw = r.kind
        i.x = r.x
        i.y = r.y
        i.width = r.width
        i.rotation = r.rotation
        i.colorIndex = r.colorIndex
        i.text = r.text
        i.z = r.z
        i.fromID = r.fromId
        i.toID = r.toId
    }
}
