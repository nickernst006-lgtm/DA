import Foundation
import Observation

/// Фильмы ance — только из библиотеки на сервере (данные Кинопоиска).
/// Здесь — то, что уже встречалось (поиск, подборки, коллекция, друзья): хранится и на телефоне,
/// поэтому карточки и коллекция открываются без сети. Плюс списки для фильтров.
@Observable
final class Library {
    /// Фильмы с сервера, которые уже встречались.
    private(set) var remote: [String: FilmItem] = [:]
    @ObservationIgnored private var remoteRaw: [String: ServerFilm] = [:]

    /// Жанры для фильтра — та же разметка, что у закачки.
    let genreFacets: [String] = ["Драма", "Комедия", "Мелодрама", "Триллер", "Боевик", "Фантастика", "Фэнтези",
                                 "Ужасы", "Криминал", "Детектив", "Приключения", "Анимация", "Семейный", "Военный",
                                 "Исторический", "Биография", "Мюзикл", "Документальный", "Вестерн", "Спорт", "Нуар"]
    /// Страны для фильтра — по числу фильмов; обновляются с сервера.
    private(set) var countryFacets: [String] = ["США", "Россия", "СССР", "Франция", "Великобритания", "Германия",
                                                "Япония", "Италия", "Южная Корея", "Испания", "Канада", "Китай",
                                                "Индия", "Швеция", "Дания", "Австралия", "Мексика", "Бразилия"]
    /// Страны, которые считаются «русским» кино.
    static let homeCountries = ["Россия", "СССР"]

    init() {
        loadRemoteCache()
        if let saved = UserDefaults.standard.stringArray(forKey: "countryFacets"), !saved.isEmpty {
            countryFacets = saved
        }
    }

    func setCountryFacets(_ list: [String]) {
        guard !list.isEmpty else { return }
        countryFacets = list
        UserDefaults.standard.set(list, forKey: "countryFacets")
    }

    // MARK: Фильмы с сервера

    /// Запомнить фильмы с сервера и вернуть их в виде для экранов.
    @discardableResult
    func remember(_ films: [ServerFilm]) -> [FilmItem] {
        guard !films.isEmpty else { return [] }
        var updated = remote
        var items: [FilmItem] = []
        items.reserveCapacity(films.count)
        for film in films {
            let item = FilmItem(server: film)
            remoteRaw[item.id] = film
            updated[item.id] = item
            items.append(item)
        }
        remote = updated
        saveRemoteCache()
        return items
    }

    private static let cacheQueue = DispatchQueue(label: "ance.server-films", qos: .utility)

    private static var remoteCacheURL: URL {
        let dir = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
        try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        return dir.appendingPathComponent("server-films.json")
    }

    private func loadRemoteCache() {
        guard let data = try? Data(contentsOf: Library.remoteCacheURL),
              let films = try? JSONDecoder().decode([ServerFilm].self, from: data) else { return }
        var map: [String: FilmItem] = [:]
        map.reserveCapacity(films.count)
        for film in films {
            let item = FilmItem(server: film)
            map[item.id] = item
            remoteRaw[item.id] = film
        }
        remote = map
    }

    private func saveRemoteCache() {
        let snapshot = Array(remoteRaw.values)
        let url = Library.remoteCacheURL
        Library.cacheQueue.async {
            guard let data = try? JSONEncoder().encode(snapshot) else { return }
            try? data.write(to: url, options: .atomic)
        }
    }

    /// Найти фильм по id.
    func film(id: String) -> FilmItem? {
        remote[id]
    }
}
