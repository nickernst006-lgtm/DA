import Foundation

/// Цифры для вкладки «Вкусы» («Досье»): всё считается из анкет и данных фильмов.
/// Каждый блок показывается, только когда данных хватает, чтобы вывод не врал.
struct TasteStats {
    struct MoodPoint: Identifiable {
        let id: String
        /// −1 светлый … +1 мрачный.
        let tone: Double
        /// −1 лёгкий … +1 тяжёлый.
        let weight: Double
        let rating: Int
    }

    struct Stat: Identifiable {
        let id: String
        let title: String
        let count: Int
        let average: Double?
    }

    struct Side: Identifiable {
        let id: String
        let title: String
        let strong: Int
        let weak: Int
    }

    struct Disagreement: Identifiable {
        let film: FilmItem
        let mine: Int
        let kp: Double
        var id: String { film.id }
        var diff: Double { Double(mine) - kp }
    }

    struct Share: Identifiable {
        let id: String
        let title: String
        let percent: Int
    }

    struct Zone {
        let tone: Double
        let weight: Double
    }

    let seenCount: Int
    let surveyCount: Int
    let average: Double?
    /// Средняя оценка Кинопоиска у тех же фильмов, что вы оценили.
    let kpAverage: Double?
    let mood: [MoodPoint]
    let zone: Zone?
    let emotions: [Stat]
    let sides: [Side]
    let genres: [Stat]
    let histogram: [Int]
    let disagreements: [Disagreement]
    let decades: [Stat]
    let countries: [Stat]
    let directors: [Stat]
    let company: [Share]

    var kpDelta: Double? {
        guard let average, let kpAverage else { return nil }
        return average - kpAverage
    }

    init(surveys: [SurveyEntry], seen: [FilmItem]) {
        var films: [String: FilmItem] = [:]
        for film in seen { films[film.id] = film }
        seenCount = seen.count
        surveyCount = surveys.count

        let rated = surveys.filter { $0.rating > 0 }
        average = rated.isEmpty ? nil : Double(rated.map(\.rating).reduce(0, +)) / Double(rated.count)

        // Оценки против Кинопоиска.
        var kpPairs: [(Int, Double, FilmItem)] = []
        for s in rated {
            if let film = films[s.filmID], let kp = film.ratingKP, kp > 0 { kpPairs.append((s.rating, kp, film)) }
        }
        kpAverage = kpPairs.count >= 3 ? kpPairs.map { $0.1 }.reduce(0, +) / Double(kpPairs.count) : nil
        disagreements = kpPairs
            .map { Disagreement(film: $0.2, mine: $0.0, kp: $0.1) }
            .filter { abs($0.diff) >= 1.5 }
            .sorted { abs($0.diff) > abs($1.diff) }
            .prefix(4)
            .map { $0 }

        // Распределение оценок 1–10.
        var hist = Array(repeating: 0, count: 10)
        for s in rated where (1...10).contains(s.rating) { hist[s.rating - 1] += 1 }
        histogram = hist

        // Карта настроения: тон и вес каждого оценённого фильма.
        var points: [MoodPoint] = []
        for s in rated {
            let scales = s.scaleValues()
            guard let tone = scales["tone"], let weight = scales["weight"] else { continue }
            points.append(MoodPoint(id: s.filmID, tone: Double(tone) / 2, weight: Double(weight) / 2, rating: s.rating))
        }
        mood = points
        let loved = points.filter { $0.rating >= 8 }
        if loved.count >= 2 {
            zone = Zone(tone: loved.map(\.tone).reduce(0, +) / Double(loved.count),
                        weight: loved.map(\.weight).reduce(0, +) / Double(loved.count))
        } else {
            zone = nil
        }

        // Что даёт кино: сколько фильмов и ваша средняя.
        emotions = SurveyOptions.emotions.compactMap { option -> Stat? in
            let with = surveys.filter { $0.emotions.contains(option.id) }
            guard !with.isEmpty else { return nil }
            return Stat(id: option.id, title: option.title, count: with.count, average: TasteStats.mean(with))
        }
        .sorted { $0.count == $1.count ? ($0.average ?? 0) > ($1.average ?? 0) : $0.count > $1.count }

        // Сильное и слабое.
        var strong: [String: Int] = [:]
        var weak: [String: Int] = [:]
        for s in surveys {
            for (key, value) in s.aspectValues() {
                if value >= 4 { strong[key, default: 0] += 1 } else if value > 0 && value <= 2 { weak[key, default: 0] += 1 }
            }
        }
        var titles: [String: String] = [:]
        for option in SurveyOptions.aspects { titles[option.id] = option.title }
        for option in SurveyOptions.weaknesses where titles[option.id] == nil { titles[option.id] = option.title }
        sides = Set(strong.keys).union(weak.keys)
            .compactMap { key -> Side? in
                guard let title = titles[key] else { return nil }
                return Side(id: key, title: title, strong: strong[key] ?? 0, weak: weak[key] ?? 0)
            }
            .sorted { ($0.strong - $0.weak) > ($1.strong - $1.weak) }

        // Жанры: сколько смотрите и как оцениваете.
        var genreRatings: [String: [Int]] = [:]
        var genreCount: [String: Int] = [:]
        for film in seen { for g in film.genres { genreCount[g, default: 0] += 1 } }
        for s in rated {
            guard let film = films[s.filmID] else { continue }
            for g in film.genres { genreRatings[g, default: []].append(s.rating) }
        }
        genres = genreCount
            .compactMap { key, count -> Stat? in
                guard let list = genreRatings[key], !list.isEmpty else { return nil }
                return Stat(id: key, title: key, count: count, average: Double(list.reduce(0, +)) / Double(list.count))
            }
            .sorted { $0.count > $1.count }
            .prefix(8)
            .map { $0 }

        // Десятилетия и страны.
        var decadeCount: [Int: Int] = [:]
        var countryCount: [String: Int] = [:]
        for film in seen {
            if let year = film.year { decadeCount[(year / 10) * 10, default: 0] += 1 }
            for c in film.countries.prefix(1) { countryCount[c == "СССР" ? "Россия и СССР" : (c == "Россия" ? "Россия и СССР" : c), default: 0] += 1 }
        }
        decades = decadeCount.keys.sorted().map { d in
            Stat(id: "\(d)", title: d < 1950 ? "\(d)" : String(format: "%02d-е", d % 100), count: decadeCount[d] ?? 0, average: nil)
        }
        let sortedCountries = countryCount.sorted { $0.value == $1.value ? $0.key < $1.key : $0.value > $1.value }
        var countryStats = sortedCountries.prefix(4).map { Stat(id: $0.key, title: $0.key, count: $0.value, average: nil) }
        let rest = sortedCountries.dropFirst(4).map(\.value).reduce(0, +)
        if rest > 0 { countryStats.append(Stat(id: "other", title: "Другие", count: rest, average: nil)) }
        countries = countryStats

        // Режиссёры: от двух фильмов.
        var dirCount: [String: Int] = [:]
        var dirRatings: [String: [Int]] = [:]
        for film in seen { for d in film.directors.prefix(1) { dirCount[d, default: 0] += 1 } }
        for s in rated {
            guard let d = films[s.filmID]?.directors.first else { continue }
            dirRatings[d, default: []].append(s.rating)
        }
        directors = dirCount
            .filter { $0.value >= 2 }
            .map { key, count -> Stat in
                let list = dirRatings[key] ?? []
                return Stat(id: key, title: key, count: count, average: list.isEmpty ? nil : Double(list.reduce(0, +)) / Double(list.count))
            }
            .sorted { $0.count == $1.count ? ($0.average ?? 0) > ($1.average ?? 0) : $0.count > $1.count }
            .prefix(5)
            .map { $0 }

        // С кем смотреть.
        let withCompany = surveys.filter { !$0.recommend.isEmpty }
        company = withCompany.isEmpty ? [] : SurveyOptions.recommend.compactMap { option -> Share? in
            let n = withCompany.filter { $0.recommend.contains(option.id) }.count
            guard n > 0 else { return nil }
            return Share(id: option.id, title: option.title, percent: Int((Double(n) / Double(withCompany.count) * 100).rounded()))
        }
        .sorted { $0.percent > $1.percent }
    }

    private static func mean(_ list: [SurveyEntry]) -> Double? {
        let r = list.map(\.rating).filter { $0 > 0 }
        return r.isEmpty ? nil : Double(r.reduce(0, +)) / Double(r.count)
    }

    static func number(_ value: Double, digits: Int = 1) -> String {
        String(format: "%.\(digits)f", value).replacingOccurrences(of: ".", with: ",")
    }

    // MARK: Выводы словами: (текст, жирный?)

    var moodInsight: [(String, Bool)]? {
        guard let zone else { return nil }
        var words: [String] = []
        if zone.tone >= 0.25 { words.append("мрачные") } else if zone.tone <= -0.25 { words.append("светлые") }
        if zone.weight >= 0.25 { words.append("тяжёлые") } else if zone.weight <= -0.25 { words.append("лёгкие") }
        if words.isEmpty { return [("Высокие оценки у вас получают фильмы самого разного настроения.", false)] }
        return [("Выше всего вы оцениваете ", false), (words.joined(separator: " и ") + " фильмы", true), (".", false)]
    }

    var emotionInsight: [(String, Bool)]? {
        guard let average else { return nil }
        let best = emotions.filter { $0.count >= 2 }.max { ($0.average ?? 0) < ($1.average ?? 0) }
        guard let best, let avg = best.average, avg - average >= 0.3 else { return nil }
        return [("Когда фильм даёт ", false), (best.title.lowercased(), true),
                (", вы ставите в среднем на \(TasteStats.number(avg - average)) балла выше.", false)]
    }

    var sidesInsight: [(String, Bool)]? {
        let s = sides.filter { $0.strong > 0 }.sorted { $0.strong > $1.strong }
        let w = sides.filter { $0.weak > 0 }.sorted { $0.weak > $1.weak }
        guard let top = s.first else { return nil }
        var parts: [(String, Bool)] = [("Вас покоряют ", false), (top.title.lowercased(), true)]
        if let second = s.dropFirst().first { parts += [(" и ", false), (second.title.lowercased(), true)] }
        if let bad = w.first { parts += [(", а не прощаете вы ", false), (bad.title.lowercased(), true)] }
        parts.append((".", false))
        return parts
    }

    var genreInsight: [(String, Bool)]? {
        guard let average, genres.count >= 3 else { return nil }
        let counts = genres.map(\.count).sorted()
        let median = counts[counts.count / 2]
        let hidden = genres
            .filter { $0.count <= median && ($0.average ?? 0) - average >= 0.5 }
            .max { ($0.average ?? 0) < ($1.average ?? 0) }
        if let hidden, let avg = hidden.average {
            return [("Жанр ", false), ("«\(hidden.title)»", true),
                    (" вы смотрите редко, но оцениваете высоко — \(TasteStats.number(avg)) в среднем. Стоит попробовать больше.", false)]
        }
        if let top = genres.max(by: { ($0.average ?? 0) < ($1.average ?? 0) }), let avg = top.average {
            return [("Выше всего вы оцениваете жанр ", false), ("«\(top.title)»", true), (" — \(TasteStats.number(avg)) в среднем.", false)]
        }
        return nil
    }

    var ratingInsight: [(String, Bool)]? {
        guard let delta = kpDelta else { return nil }
        let tens = histogram[9]
        let tensText = tens == 0 ? " Десяток вы ещё не ставили." : " Десятка — у \(tens) \(TasteProfile.plural(tens, "фильма", "фильмов", "фильмов"))."
        if abs(delta) < 0.15 { return [("Ваши оценки ", false), ("совпадают с Кинопоиском", true), (".\(tensText)", false)] }
        return [("Вы ", false), ((delta < 0 ? "строже" : "щедрее") + " Кинопоиска на \(TasteStats.number(abs(delta)))", true), (".\(tensText)", false)]
    }
}
