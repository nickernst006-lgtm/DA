import SwiftUI
import SwiftData
import PhotosUI
import UIKit

// MARK: - Текст эссе: абзацы и цитаты

/// Часть эссе: обычный текст или цитата (с подписью, кто сказал).
struct EssayPart: Identifiable, Equatable {
    enum Kind { case text, quote }
    var id = UUID()
    var kind: Kind
    var text: String
    var author: String = ""
}

/// Эссе хранится обычным текстом. Цитата — строки, начинающиеся с «> »;
/// последняя строка цитаты «> — Имя» — подпись.
enum EssayFormat {
    static func parse(_ raw: String) -> [EssayPart] {
        var parts: [EssayPart] = []
        var textLines: [String] = []
        var quoteLines: [String] = []

        func flushText() {
            let text = textLines.joined(separator: "\n").trimmingCharacters(in: .whitespacesAndNewlines)
            if !text.isEmpty { parts.append(EssayPart(kind: .text, text: text)) }
            textLines = []
        }
        func flushQuote() {
            guard !quoteLines.isEmpty else { return }
            var author = ""
            if let last = quoteLines.last, last.hasPrefix("— ") {
                author = String(last.dropFirst(2))
                quoteLines.removeLast()
            }
            let text = quoteLines.joined(separator: "\n").trimmingCharacters(in: .whitespacesAndNewlines)
            parts.append(EssayPart(kind: .quote, text: text, author: author))
            quoteLines = []
        }

        for line in raw.components(separatedBy: "\n") {
            if line.hasPrefix(">") {
                flushText()
                var content = String(line.dropFirst())
                if content.hasPrefix(" ") { content.removeFirst() }
                quoteLines.append(content)
            } else {
                flushQuote()
                textLines.append(line)
            }
        }
        flushQuote()
        flushText()
        return parts
    }

    static func serialize(_ parts: [EssayPart]) -> String {
        parts.compactMap { part -> String? in
            let text = part.text.trimmingCharacters(in: .whitespacesAndNewlines)
            switch part.kind {
            case .text:
                return text.isEmpty ? nil : text
            case .quote:
                guard !text.isEmpty else { return nil }
                var lines = text.components(separatedBy: "\n").map { "> " + $0 }
                let author = part.author.trimmingCharacters(in: .whitespacesAndNewlines)
                if !author.isEmpty { lines.append("> — " + author) }
                return lines.joined(separator: "\n")
            }
        }
        .joined(separator: "\n\n")
    }

    /// Сплошной текст — для отрывков в «Коллекции» и карточки для соцсетей.
    static func plain(_ raw: String) -> String {
        parse(raw).map { $0.kind == .quote ? "«\($0.text)»" : $0.text }
            .joined(separator: " ")
            .split(whereSeparator: { $0.isWhitespace || $0.isNewline })
            .joined(separator: " ")
    }
}

/// Фото эссе живут в блоке журнала «эссе» этого фильма (так они синхронизируются с сервером).
enum EssayPhotos {
    static let limit = 10

    static func block(for filmID: String, in context: ModelContext, create: Bool) -> JournalBlock? {
        if let existing = JournalActions.blocks(for: filmID, in: context).first(where: { $0.kind == .essay }) {
            return existing
        }
        guard create else { return nil }
        let block = JournalBlock(filmID: filmID, kind: .essay, order: 0)
        context.insert(block)
        return block
    }

    static func photos(for filmID: String, in context: ModelContext) -> [JournalPhoto] {
        block(for: filmID, in: context, create: false)?.sortedPhotos ?? []
    }
}

// MARK: - Черновик эссе

/// То, что пользователь пишет сейчас: части текста, оставленные и новые фото.
/// Применяется к анкете и фото только по «Готово».
@MainActor
@Observable
final class EssayDraft {
    var parts: [EssayPart]
    var keptPhotos: [JournalPhoto]
    struct NewPhoto: Identifiable {
        let id = UUID()
        let data: Data
    }
    var newPhotos: [NewPhoto] = []
    private var removedPhotos: [JournalPhoto] = []

    init(essay: String, photos: [JournalPhoto]) {
        var list = EssayFormat.parse(essay)
        if list.isEmpty { list = [EssayPart(kind: .text, text: "")] }
        if list.last?.kind == .quote { list.append(EssayPart(kind: .text, text: "")) }
        keptPhotos = photos
        parts = list
    }

    var photoCount: Int { keptPhotos.count + newPhotos.count }
    var canAddPhotos: Bool { photoCount < EssayPhotos.limit }
    var text: String { EssayFormat.serialize(parts) }
    var isEmpty: Bool { text.isEmpty && photoCount == 0 }

    /// Вставить цитату после части `after` (или в конец) и пустой абзац за ней.
    @discardableResult
    func insertQuote(after id: UUID?) -> UUID {
        let index = id.flatMap { target in parts.firstIndex { $0.id == target } } ?? (parts.count - 1)
        let quote = EssayPart(kind: .quote, text: "")
        parts.insert(quote, at: index + 1)
        if index + 2 >= parts.count || parts[index + 2].kind != .text {
            parts.insert(EssayPart(kind: .text, text: ""), at: index + 2)
        }
        return quote.id
    }

    /// Убрать цитату; соседние абзацы склеиваются.
    func removeQuote(_ id: UUID) {
        guard let index = parts.firstIndex(where: { $0.id == id }) else { return }
        parts.remove(at: index)
        if index > 0, index < parts.count, parts[index - 1].kind == .text, parts[index].kind == .text {
            let joined = [parts[index - 1].text, parts[index].text]
                .map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }
                .filter { !$0.isEmpty }
                .joined(separator: "\n\n")
            parts[index - 1].text = joined
            parts.remove(at: index)
        }
        if parts.isEmpty { parts = [EssayPart(kind: .text, text: "")] }
    }

    func addPhotos(_ datas: [Data]) {
        for data in datas where canAddPhotos {
            if let jpeg = ImagePrep.jpeg(from: data) { newPhotos.append(NewPhoto(data: jpeg)) }
        }
    }

    func removeKept(_ photo: JournalPhoto) {
        keptPhotos.removeAll { $0.id == photo.id }
        removedPhotos.append(photo)
    }

    func removeNew(_ id: UUID) {
        newPhotos.removeAll { $0.id == id }
    }

    /// Записать: текст — в анкету фильма (создаётся, если её нет), фото — в блок эссе.
    func apply(filmID: String, entry: SurveyEntry, in context: ModelContext) {
        entry.essay = text
        for photo in removedPhotos { context.delete(photo) }
        removedPhotos = []
        let needsBlock = !text.isEmpty || photoCount > 0
        if let block = EssayPhotos.block(for: filmID, in: context, create: needsBlock) {
            var order = (keptPhotos.map(\.order).max() ?? -1) + 1
            for item in newPhotos {
                let photo = JournalPhoto(data: item.data, order: order)
                context.insert(photo)
                photo.block = block
                order += 1
            }
            if !needsBlock { context.delete(block) }
        }
        newPhotos = []
        try? context.save()
    }
}

// MARK: - Показ эссе

/// Эссе в карточке фильма: абзацы, цитаты курсивом с жёлтой чертой, ниже — фото сеткой по три.
struct EssayView: View {
    let essay: String
    let photos: [JournalPhoto]
    @State private var viewer: Int?

    var body: some View {
        VStack(alignment: .leading, spacing: Space.s16) {
            ForEach(EssayFormat.parse(essay)) { part in
                switch part.kind {
                case .text:
                    Text(part.text)
                        .textStyle(.body)
                        .foregroundStyle(Theme.text)
                        .fixedSize(horizontal: false, vertical: true)
                case .quote:
                    QuoteBlock(text: part.text, author: part.author)
                }
            }
            if !photos.isEmpty {
                PhotoGrid(photos: photos) { viewer = $0 }
            }
        }
        .fullScreenCover(item: Binding(get: { viewer.map(PhotoIndex.init) }, set: { viewer = $0?.index })) { start in
            PhotoViewer(photos: photos, start: start.index)
        }
    }
}

private struct PhotoIndex: Identifiable {
    let index: Int
    var id: Int { index }
}

/// Цитата: курсив DM Serif с жёлтой чертой слева, подпись — мелко.
struct QuoteBlock: View {
    let text: String
    var author: String = ""

    var body: some View {
        HStack(alignment: .top, spacing: Space.s16) {
            Capsule().fill(Theme.accent).frame(width: 3)
            VStack(alignment: .leading, spacing: Space.s8) {
                Text("«\(text)»")
                    .textStyle(.quote)
                    .foregroundStyle(Theme.text)
                    .fixedSize(horizontal: false, vertical: true)
                if !author.isEmpty {
                    Text(author)
                        .textStyle(.caption)
                        .foregroundStyle(Theme.muted)
                }
            }
        }
        .fixedSize(horizontal: false, vertical: true)
    }
}

/// Сетка фото по три; если фото больше шести — шестая плитка «+N».
struct PhotoGrid: View {
    let photos: [JournalPhoto]
    var onOpen: (Int) -> Void = { _ in }

    private let columns = Array(repeating: GridItem(.flexible(), spacing: Space.s8), count: 3)

    var body: some View {
        let shown = Array(photos.prefix(6))
        LazyVGrid(columns: columns, spacing: Space.s8) {
            ForEach(Array(shown.enumerated()), id: \.element.id) { index, photo in
                Button { onOpen(index) } label: {
                    Color(hex: 0x1F1F1F)
                        .aspectRatio(1, contentMode: .fit)
                        .overlay {
                            if let image = PhotoCache.image(id: photo.id, data: photo.data) {
                                Image(uiImage: image).resizable().scaledToFill()
                            }
                        }
                        .overlay {
                            if index == 5 && photos.count > 6 {
                                ZStack {
                                    Color.black.opacity(0.55)
                                    Text("+\(photos.count - 5)")
                                        .textStyle(.h3)
                                        .foregroundStyle(Theme.text)
                                }
                            }
                        }
                        .clipShape(RoundedRectangle(cornerRadius: Radius.medium, style: .continuous))
                }
                .buttonStyle(.plain)
            }
        }
    }
}

/// Фото во весь экран, листаются в стороны.
private struct PhotoViewer: View {
    let photos: [JournalPhoto]
    let start: Int
    @Environment(\.dismiss) private var dismiss
    @State private var page = 0

    var body: some View {
        ZStack(alignment: .topTrailing) {
            Color.black.ignoresSafeArea()
            TabView(selection: $page) {
                ForEach(Array(photos.enumerated()), id: \.element.id) { index, photo in
                    Group {
                        if let image = PhotoCache.image(id: photo.id, data: photo.data) {
                            Image(uiImage: image).resizable().scaledToFit()
                        }
                    }
                    .tag(index)
                }
            }
            .tabViewStyle(.page(indexDisplayMode: photos.count > 1 ? .always : .never))
            CloseButton { dismiss() }
                .padding(Space.s20)
        }
        .onAppear { page = start }
    }
}

// MARK: - Редактор

/// Поле эссе: абзацы и цитаты по очереди, ниже — фото. Кнопки «Цитата» и «Фото» — у того, кто его показывает.
struct EssayComposer: View {
    @Bindable var draft: EssayDraft
    @FocusState.Binding var focused: UUID?

    var body: some View {
        VStack(alignment: .leading, spacing: Space.s16) {
            ForEach($draft.parts) { $part in
                switch part.kind {
                case .text:
                    TextField("", text: $part.text,
                              prompt: Text(part.id == draft.parts.first?.id ? "Что вы думаете о фильме?" : "Продолжайте…")
                                .foregroundColor(Theme.muted),
                              axis: .vertical)
                        .font(Font(AppFont.uiFont(.body) as CTFont))
                        .foregroundStyle(Theme.text)
                        .focused($focused, equals: part.id)
                case .quote:
                    HStack(alignment: .top, spacing: Space.s16) {
                        Capsule().fill(Theme.accent).frame(width: 3)
                        VStack(alignment: .leading, spacing: Space.s8) {
                            TextField("", text: $part.text, prompt: Text("Цитата").foregroundColor(Theme.muted), axis: .vertical)
                                .font(Font(AppFont.uiFont(.quote) as CTFont))
                                .foregroundStyle(Theme.text)
                                .focused($focused, equals: part.id)
                            TextField("", text: $part.author, prompt: Text("Кто сказал").foregroundColor(Theme.muted))
                                .font(Font(AppFont.uiFont(.caption) as CTFont))
                                .foregroundStyle(Theme.textSecondary)
                        }
                        Button {
                            withAnimation(.easeInOut(duration: 0.2)) { draft.removeQuote(part.id) }
                        } label: {
                            Image(systemName: "xmark.circle.fill")
                                .font(.system(size: 20))
                                .foregroundStyle(Theme.muted)
                        }
                        .buttonStyle(.plain)
                        .accessibilityLabel("Убрать цитату")
                    }
                    .fixedSize(horizontal: false, vertical: true)
                }
            }
            if draft.photoCount > 0 {
                photoStrip
            }
        }
    }

    private var photoStrip: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: Space.s8) {
                ForEach(draft.keptPhotos, id: \.id) { photo in
                    tile(PhotoCache.image(id: photo.id, data: photo.data)) { draft.removeKept(photo) }
                }
                ForEach(draft.newPhotos) { item in
                    tile(UIImage(data: item.data)) { draft.removeNew(item.id) }
                }
            }
        }
    }

    private func tile(_ image: UIImage?, remove: @escaping () -> Void) -> some View {
        Color(hex: 0x1F1F1F)
            .frame(width: 72, height: 72)
            .overlay {
                if let image { Image(uiImage: image).resizable().scaledToFill() }
            }
            .clipShape(RoundedRectangle(cornerRadius: Radius.small, style: .continuous))
            .overlay(alignment: .topTrailing) {
                Button(action: remove) {
                    Image(systemName: "xmark.circle.fill")
                        .font(.system(size: 20))
                        .symbolRenderingMode(.palette)
                        .foregroundStyle(Color.white, Color.black.opacity(0.6))
                }
                .buttonStyle(.plain)
                .padding(Space.s4)
                .accessibilityLabel("Убрать фото")
            }
    }
}

/// Кнопки «Цитата» и «Фото n/10».
struct EssayTools: View {
    @Bindable var draft: EssayDraft
    var focused: UUID?
    var onQuote: (UUID) -> Void
    @State private var picked: [PhotosPickerItem] = []

    var body: some View {
        HStack(spacing: Space.s8) {
            Button {
                let id = draft.insertQuote(after: focused)
                onQuote(id)
            } label: {
                Label("Цитата", systemImage: "quote.opening")
            }
            .buttonStyle(SmallButtonStyle(kind: .plain))
            PhotosPicker(selection: $picked, maxSelectionCount: max(1, EssayPhotos.limit - draft.photoCount), matching: .images) {
                Label("Фото · \(draft.photoCount)/\(EssayPhotos.limit)", systemImage: "photo")
                    .textStyle(.sub, .bold)
                    .foregroundStyle(draft.canAddPhotos ? Theme.textSecondary : Theme.muted)
                    .padding(.horizontal, Space.s12)
                    .frame(height: 36)
                    .background(Capsule().fill(Theme.dockButton))
            }
            .disabled(!draft.canAddPhotos)
            Spacer(minLength: 0)
        }
        .onChange(of: picked) { _, items in
            guard !items.isEmpty else { return }
            Task {
                var datas: [Data] = []
                for item in items {
                    if let data = try? await item.loadTransferable(type: Data.self) { datas.append(data) }
                }
                draft.addPhotos(datas)
                picked = []
            }
        }
    }
}

/// Редактор эссе отдельным экраном: «Отмена» / «Готово», крупно «Эссе», поле и кнопки над клавиатурой.
struct EssayEditorView: View {
    let film: FilmItem
    @Environment(\.modelContext) private var context
    @Environment(\.dismiss) private var dismiss
    @State private var draft: EssayDraft?
    @FocusState private var focused: UUID?

    var body: some View {
        VStack(spacing: 0) {
            HStack {
                Button("Отмена") { dismiss() }
                    .foregroundStyle(Theme.text)
                Spacer()
                Button("Готово") { save() }
                    .fontWeight(.bold)
                    .foregroundStyle(Theme.accent)
            }
            .textStyle(.body)
            .padding(.horizontal, ScreenLayout.sideMargin)
            .frame(height: 44)

            ScrollView {
                VStack(alignment: .leading, spacing: ScreenLayout.blockGap) {
                    VStack(alignment: .leading, spacing: Space.s4) {
                        ScreenTitle("Эссе")
                        Text(film.title)
                            .textStyle(.body)
                            .foregroundStyle(Theme.muted)
                    }
                    .padding(.top, ScreenLayout.pushedTitleTop)
                    if let draft {
                        EssayComposer(draft: draft, focused: $focused)
                            .padding(.horizontal, ScreenLayout.textInset)
                    }
                }
                .padding(.horizontal, ScreenLayout.sideMargin)
                .padding(.bottom, ScreenLayout.blockGap)
            }
            .scrollDismissesKeyboard(.interactively)
        }
        .safeAreaInset(edge: .bottom) {
            if let draft {
                EssayTools(draft: draft, focused: focused) { focused = $0 }
                    .padding(.horizontal, ScreenLayout.sideMargin)
                    .padding(.vertical, Space.s12)
                    .background(Theme.surface.ignoresSafeArea())
            }
        }
        .background(Theme.background.ignoresSafeArea())
        .onAppear {
            guard draft == nil else { return }
            let essay = CollectionActions.survey(for: film.id, in: context)?.essay ?? ""
            draft = EssayDraft(essay: essay, photos: EssayPhotos.photos(for: film.id, in: context))
        }
    }

    private func save() {
        guard let draft else { dismiss(); return }
        let entry = CollectionActions.survey(for: film.id, in: context) ?? {
            let created = SurveyEntry(filmID: film.id)
            context.insert(created)
            return created
        }()
        draft.apply(filmID: film.id, entry: entry, in: context)
        if CollectionActions.item(for: film.id, in: context)?.status != .seen {
            CollectionActions.setStatus(.seen, for: film.id, in: context)
        }
        dismiss()
    }
}
