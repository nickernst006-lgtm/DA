import SwiftUI
import SwiftData

/// Вкладка «Вселенная»: поиск, кнопки фильтров, «Выбрать фильм вдвоём»,
/// подборки «Рекомендации», «Русские», «Зарубежные» и случайные фильмы из базы.
struct AfishaView: View {
    @Environment(Library.self) private var library
    @Environment(Server.self) private var server
    @Query private var surveys: [SurveyEntry]

    @State private var query = ""
    @State private var filter = FilmFilter()
    @State private var openSection: FilterSection?
    /// Сколько случайных фильмов уже показано — подгружаются по мере прокрутки.
    @State private var randomLimit = 60
    @State private var showEvening = false
    @State private var showScrollTop = false
    /// Поиск в библиотеке на сервере: результаты и запрос, к которому они относятся.
    @State private var serverFound: [FilmItem] = []
    @State private var serverQuery = ""
    @State private var searchingServer = false
    /// Случайные фильмы с сервера — с настоящими афишами.
    @State private var serverRandom: [FilmItem] = []
    @State private var loadingRandom = false
    /// Подборки с сервера.
    @State private var popular: [FilmItem] = []
    @State private var russian: [FilmItem] = []
    @State private var foreign: [FilmItem] = []
    /// Фильмы по фильтрам — подгружаются страницами по 60.
    @State private var filtered: [FilmItem] = []
    @State private var filterLoading = false
    @State private var filterExhausted = false
    @Environment(\.dockClearance) private var dockClearance

    private let columns = [
        GridItem(.flexible(), spacing: Space.s12, alignment: .top),
        GridItem(.flexible(), spacing: Space.s12, alignment: .top)
    ]

    private var isSearching: Bool {
        !query.trimmingCharacters(in: .whitespaces).isEmpty
    }

    private var trimmedQuery: String {
        query.trimmingCharacters(in: .whitespacesAndNewlines)
    }

    private var personal: [String: PersonalTags] {
        var result: [String: PersonalTags] = [:]
        for s in surveys { result[s.filmID] = PersonalTags(emotions: s.emotions, word: s.word) }
        return result
    }

    var body: some View {
        NavigationStack {
            ScrollViewReader { reader in
                ScrollView {
                    VStack(alignment: .leading, spacing: ScreenLayout.blockGap) {
                        VStack(alignment: .leading, spacing: ScreenLayout.titleGap) {
                            // Метка прокрутки — фоном заголовка, а не отдельной строкой:
                            // иначе отступ стопки сдвигал заголовок ниже, чем на других вкладках.
                            ScreenTitle("Вселенная")
                                .padding(.top, Space.s12)
                                .background(alignment: .top) {
                                    GeometryReader { geo in
                                        Color.clear.preference(key: ScrollOffsetKey.self,
                                                               value: geo.frame(in: .named("universeScroll")).minY)
                                    }
                                }
                                .id("top")

                            VStack(alignment: .leading, spacing: Space.s12) {
                                // Поле поиска во всю ширину, как переключатель в «Коллекции».
                                SearchField(text: $query)
                                filterBar
                            }
                        }

                        if isSearching || !filter.isEmpty {
                            searchResults
                        } else {
                            eveningCard
                            shelf("Самое известное", films: popular)
                            shelf("Русские", films: russian)
                            shelf("Зарубежные", films: foreign)
                            randomGrid
                        }
                    }
                    .padding(.horizontal, ScreenLayout.sideMargin)
                    .padding(.bottom, ScreenLayout.blockGap)
                }
                .dockClearance()
                .coordinateSpace(name: "universeScroll")
                .onPreferenceChange(ScrollOffsetKey.self) { offset in
                    let shouldShow = offset < -700
                    if shouldShow != showScrollTop {
                        withAnimation(.easeInOut(duration: 0.2)) { showScrollTop = shouldShow }
                    }
                }
                .overlay(alignment: .bottomTrailing) {
                    if showScrollTop {
                        Button {
                            withAnimation(.easeInOut(duration: 0.35)) { reader.scrollTo("top", anchor: .top) }
                        } label: {
                            Image(systemName: "arrow.up")
                                .font(.system(size: 18, weight: .semibold))
                                .foregroundStyle(Color.black)
                                .frame(width: 48, height: 48)
                                .background(Circle().fill(Theme.text))
                                .shadow(color: .black.opacity(0.4), radius: 10, y: 4)
                        }
                        .buttonStyle(.plain)
                        .padding(.trailing, Space.s20)
                        // Кнопка — над доком: отступ под док без «воздуха» плюс 14 pt.
                        .padding(.bottom, max(14, dockClearance - 10))
                        .transition(.scale(scale: 0.6).combined(with: .opacity))
                        .accessibilityLabel("Наверх")
                    }
                }
            }
            .scrollDismissesKeyboard(.immediately)
            .task(id: query) { await searchServer() }
            .task { await loadShelves() }
            .task(id: filter) { await loadFiltered(reset: true) }
            .background(Theme.background.ignoresSafeArea())
            .navigationTitle("Вселенная")
            .toolbar(.hidden, for: .navigationBar)
            .navigationDestination(for: FilmRoute.self) { route in
                FilmDetailView(filmID: route.id)
            }
        }
        .sheet(item: $openSection) { section in
            let detents: Set<PresentationDetent> = section == .director || section == .country ? [.large] : [.medium, .large]
            FilterSheet(filter: $filter, section: section)
                .presentationDetents(detents)
        }
        .fullScreenCover(isPresented: $showEvening) {
            EveningView()
        }
    }

    /// Кнопки фильтров под строкой поиска. Выбранный фильтр — белый.
    private var filterBar: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: Space.s8) {
                ForEach(FilterSection.allCases) { section in
                    let active = filter.isActive(section)
                    Button {
                        openSection = section
                    } label: {
                        HStack(spacing: Space.s8) {
                            Text(filter.label(section))
                                .lineLimit(1)
                            Image(systemName: "chevron.down")
                                .font(.system(size: 11, weight: .semibold))
                        }
                        .textStyle(.sub, .medium)
                        .foregroundStyle(active ? Color.black : Theme.text)
                        .padding(.horizontal, Space.s16)
                        .frame(height: 40)
                        .background(Capsule().fill(active ? Theme.text : Theme.surface))
                    }
                    .buttonStyle(.plain)
                    .accessibilityLabel(active ? "\(section.title): \(filter.selectedTitles(section).joined(separator: ", "))" : section.title)
                }
                if !filter.isEmpty {
                    Button("Сбросить") { filter = FilmFilter() }
                        .textStyle(.sub, .medium)
                        .foregroundStyle(Theme.textSecondary)
                        .frame(height: 40)
                        .padding(.horizontal, Space.s8)
                }
            }
            .padding(.horizontal, Space.s20)
        }
        .padding(.horizontal, -20)
    }

    private var eveningCard: some View {
        Button {
            showEvening = true
        } label: {
            HStack(spacing: Space.s12) {
                Image(systemName: "person.2.fill")
                    .font(.system(size: 17))
                    .foregroundStyle(Color.black)
                    .frame(width: Space.s48, height: Space.s48)
                    .background(Circle().fill(Theme.text))
                    .accessibilityHidden(true)
                VStack(alignment: .leading, spacing: Space.s4) {
                    Text("Выбрать фильм вдвоём")
                        .textStyle(.body, .bold)
                        .foregroundStyle(Theme.text)
                    Text("Что посмотрим вечером?")
                        .textStyle(.sub)
                        .foregroundStyle(Theme.muted)
                }
                Spacer(minLength: 0)
                Image(systemName: "chevron.right")
                    .font(.system(size: 14, weight: .semibold))
                    .foregroundStyle(Theme.muted)
                    .accessibilityHidden(true)
            }
            .plate()
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
    }

    @ViewBuilder
    private var searchResults: some View {
        let results: [FilmItem] = {
            if isSearching {
                let found = serverQuery == trimmedQuery ? serverFound : []
                return filter.isEmpty ? found : found.filter { filter.matches($0, personal: personal[$0.id]) }
            }
            return filtered
        }()
        if results.isEmpty && ((isSearching && searchingServer) || (!isSearching && filterLoading)) {
            HStack(spacing: Space.s12) {
                ProgressView()
                    .tint(Theme.muted)
                Text("Ищу…")
                    .textStyle(.sub)
                    .foregroundStyle(Theme.muted)
            }
            .padding(.horizontal, ScreenLayout.textInset)
        } else if results.isEmpty {
            VStack(alignment: .leading, spacing: ScreenLayout.blockTitleGap) {
                SectionTitle("Ничего не нашлось",
                             hint: filter.isEmpty ? "Попробуйте другое название, имя режиссёра или год." : "Попробуйте убрать часть фильтров.")
                if !filter.isEmpty {
                    Button("Сбросить фильтры") { filter = FilmFilter() }
                        .buttonStyle(SecondaryButtonStyle())
                }
            }
        } else {
            filmGrid(title: "Найдено", count: isSearching ? results.count : nil, films: results, onLast: {
                if !isSearching { Task { await loadFiltered(reset: false) } }
            })
        }
    }

    /// Ширина плитки в подборках: на экране видно две с половиной обложки.
    private let shelfTileWidth: CGFloat = 160

    /// Подборка — горизонтальная лента обложек.
    @ViewBuilder
    private func shelf(_ title: String, films: [FilmItem]) -> some View {
        if !films.isEmpty {
            VStack(alignment: .leading, spacing: ScreenLayout.blockTitleGap) {
                SectionTitle(title)
                ScrollView(.horizontal, showsIndicators: false) {
                    LazyHStack(alignment: .top, spacing: Space.s12) {
                        ForEach(films) { film in
                            NavigationLink(value: FilmRoute(id: film.id)) {
                                FilmTile(film: film, subtitle: film.shortMeta)
                                    .frame(width: shelfTileWidth)
                            }
                            .buttonStyle(.plain)
                        }
                    }
                    .padding(.horizontal, Space.s20)
                }
                .padding(.horizontal, -20)
            }
        }
    }

    /// Случайные фильмы — сеткой, подгружаются при прокрутке.
    /// С сервера — известные фильмы с настоящими афишами; без связи — из встроенной базы.
    private var randomGrid: some View {
        let films: [FilmItem] = serverRandom
        return VStack(alignment: .leading, spacing: ScreenLayout.blockTitleGap) {
            SectionTitle("Случайные фильмы")
            LazyVGrid(columns: columns, alignment: .leading, spacing: ScreenLayout.blockGap) {
                ForEach(films) { film in
                    NavigationLink(value: FilmRoute(id: film.id)) {
                        FilmTile(film: film, subtitle: film.shortMeta)
                    }
                    .buttonStyle(.plain)
                    .onAppear {
                        if film.id == films.last?.id { loadMoreRandom() }
                    }
                }
            }
        }
        .task {
            if serverRandom.isEmpty { await loadServerRandom() }
        }
    }

    private func loadMoreRandom() {
        Task { await loadServerRandom() }
    }

    private func loadServerRandom() async {
        guard server.isSignedIn, !loadingRandom else { return }
        loadingRandom = true
        defer { loadingRandom = false }
        guard let found = try? await server.randomFilms(limit: 60) else { return }
        let known = Set(serverRandom.map(\.id))
        let fresh = library.remember(found).filter { !known.contains($0.id) }
        serverRandom.append(contentsOf: fresh)
    }

    /// Поиск на сервере — через треть секунды после того, как перестали печатать.
    private func searchServer() async {
        let text = trimmedQuery
        guard text.count >= 2, server.isSignedIn else {
            serverFound = []
            serverQuery = ""
            searchingServer = false
            return
        }
        searchingServer = true
        try? await Task.sleep(nanoseconds: 350_000_000)
        guard !Task.isCancelled else { return }
        let found = try? await server.searchFilms(text, limit: 80)
        guard !Task.isCancelled else { return }
        serverFound = library.remember(found ?? [])
        serverQuery = text
        searchingServer = false
    }

    /// Подборки «Вселенной»: самые известные, русские и зарубежные.
    private func loadShelves() async {
        guard server.isSignedIn, popular.isEmpty else { return }
        let home = Library.homeCountries
        async let top = server.filterFilms(minVotes: 50000, limit: 30)
        async let ru = server.filterFilms(countries: home, limit: 30)
        async let world = server.filterFilms(excludeCountries: home, limit: 30, skip: 30)
        if let list = try? await top { popular = library.remember(list) }
        if let list = try? await ru { russian = library.remember(list) }
        if let list = try? await world { foreign = library.remember(list) }
        if let countries = try? await server.countryFacets() { library.setCountryFacets(countries) }
    }

    /// Фильмы по фильтрам — с сервера, страницами.
    private func loadFiltered(reset: Bool) async {
        if reset {
            filtered = []
            filterExhausted = false
        }
        guard server.isSignedIn, !filter.isEmpty, !filterLoading, !filterExhausted else { return }
        filterLoading = true
        defer { filterLoading = false }
        let current = filter
        guard let list = try? await server.filterFilms(
            genres: Array(current.genres), anyGenres: current.derivedGenres, countries: Array(current.countries),
            decades: Array(current.decades), director: current.trimmedDirectorText, limit: 60, skip: filtered.count
        ), current == filter else { return }
        let known = Set(filtered.map(\.id))
        filtered += library.remember(list).filter { !known.contains($0.id) }
        if list.count < 60 { filterExhausted = true }
    }

    private func filmGrid(title: String, count: Int? = nil, films: [FilmItem], onLast: @escaping () -> Void = {}) -> some View {
        VStack(alignment: .leading, spacing: ScreenLayout.blockTitleGap) {
            SectionTitle(title, count: count)
            LazyVGrid(columns: columns, alignment: .leading, spacing: ScreenLayout.blockGap) {
                ForEach(films) { film in
                    NavigationLink(value: FilmRoute(id: film.id)) {
                        FilmTile(film: film, subtitle: film.shortMeta)
                    }
                    .buttonStyle(.plain)
                    .onAppear { if film.id == films.last?.id { onLast() } }
                }
            }
        }
    }
}

/// Положение верха прокрутки — чтобы показать кнопку «Наверх».
private struct ScrollOffsetKey: PreferenceKey {
    static let defaultValue: CGFloat = 0
    static func reduce(value: inout CGFloat, nextValue: () -> CGFloat) {
        value = nextValue()
    }
}
