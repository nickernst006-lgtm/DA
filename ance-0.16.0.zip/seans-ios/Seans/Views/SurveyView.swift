import SwiftUI
import SwiftData

/// Анкета после просмотра: семь коротких шагов и эссе, затем карточка для соцсетей.
/// Вопросы помогают другому понять, подойдёт ли ему фильм: что фильм даёт, под какое настроение,
/// что удалось, стоит ли смотреть и с кем.
@MainActor
struct SurveyView: View {
    let film: FilmItem
    /// Открыть сразу на шаге эссе.
    var startAtEssay = false

    @Environment(\.modelContext) private var context
    @Environment(\.dismiss) private var dismiss

    private enum Field: Hashable { case word, essay }

    @State private var step = 0
    @State private var rating = 0
    @State private var emotions: Set<String> = []
    @State private var aspects: [String: Int] = [:]
    @State private var scales: [String: Int] = [:]
    @State private var ending = ""
    @State private var company = ""
    @State private var place = ""
    @State private var rewatch = ""
    @State private var recommend: Set<String> = []
    @State private var word = ""
    @State private var essay = ""
    /// Эссе с цитатами и фото — собирается на последнем шаге.
    @State private var essayDraft: EssayDraft?
    @FocusState private var essayFocus: UUID?
    @State private var didLoad = false
    @FocusState private var focus: Field?

    /// Шаги 0…7 — вопросы; «Готово» на эссе сохраняет анкету и закрывает её.
    private let questionCount = 8
    private let essayStepIndex = 7

    var body: some View {
        VStack(spacing: 0) {
            header
            ScrollView {
                VStack(alignment: .leading, spacing: ScreenLayout.blockGap) {
                    switch step {
                    case 0: ratingStep
                    case 1: wordStep
                    case 2: emotionsStep
                    case 3: scalesStep
                    case 4: aspectsStep
                    case 5: contextStep
                    case 6: verdictStep
                    case 7: essayStep
                    default: essayStep
                    }
                }
                .padding(.horizontal, Space.s20)
                .padding(.top, Space.s32)
                .padding(.bottom, Space.s24)
                .frame(maxWidth: .infinity, alignment: .leading)
            }
            .scrollDismissesKeyboard(.interactively)
            footer
        }
        .background(Theme.background.ignoresSafeArea())
        .onAppear(perform: loadExisting)
        .animation(.easeInOut(duration: 0.2), value: step)
    }

    // MARK: Шапка и прогресс

    private var header: some View {
        VStack(spacing: Space.s16) {
            HStack {
                CloseButton(label: "Закрыть анкету") { dismiss() }
                Spacer()
                Text(film.title)
                    .textStyle(.sub, .bold)
                    .foregroundStyle(Theme.text)
                    .lineLimit(1)
                Spacer()
                Text(step < questionCount ? "\(step + 1)/\(questionCount)" : "")
                    .textStyle(.caption, .medium)
                    .foregroundStyle(Theme.muted)
                    .frame(width: 44, alignment: .trailing)
            }
            HStack(spacing: Space.s4) {
                ForEach(0..<questionCount, id: \.self) { i in
                    Capsule()
                        .fill(i <= step ? Theme.text : Theme.lineStrong)
                        .frame(height: 3)
                }
            }
            .accessibilityHidden(true)
        }
        .padding(.horizontal, Space.s20)
        .padding(.top, Space.s12)
    }

    private func question(_ title: String, hint: String? = nil) -> some View {
        VStack(alignment: .leading, spacing: Space.s8) {
            Text(title)
                .textStyle(.h1)
                .foregroundStyle(Theme.text)
                .fixedSize(horizontal: false, vertical: true)
                .accessibilityAddTraits(.isHeader)
            if let hint {
                Text(hint)
                    .textStyle(.sub)
                    .foregroundStyle(Theme.muted)
                    .fixedSize(horizontal: false, vertical: true)
            }
        }
    }

    private func groupLabel(_ text: String) -> some View {
        Text(text)
            .textStyle(.caption, .medium)
            .foregroundStyle(Theme.muted)
            .textCase(nil)
    }

    // MARK: 1. Оценка

    private var ratingStep: some View {
        VStack(alignment: .leading, spacing: ScreenLayout.blockGap) {
            question("Ваша оценка")
            LazyVGrid(columns: Array(repeating: GridItem(.flexible(), spacing: Space.s8), count: 5), spacing: Space.s8) {
                ForEach(1...10, id: \.self) { value in
                    let isSelected = rating == value
                    Button {
                        rating = value
                    } label: {
                        Text("\(value)")
                            .textStyle(.h2)
                            .foregroundStyle(isSelected ? Color.black : Theme.text)
                            .frame(maxWidth: .infinity, minHeight: 60)
                            .background(
                                RoundedRectangle(cornerRadius: Radius.medium, style: .continuous)
                                    .fill(isSelected ? Theme.text : Theme.surface)
                            )
                    }
                    .buttonStyle(.plain)
                    .accessibilityLabel("\(value) из 10")
                    .accessibilityAddTraits(isSelected ? .isSelected : [])
                }
            }
            .sensoryFeedback(.selection, trigger: rating)
            Text(rating > 0 ? SurveyOptions.ratingLabel(rating) : "Нажмите на число")
                .textStyle(.h2, .medium)
                .foregroundStyle(rating > 0 ? Theme.accent : Theme.muted)
        }
    }

    // MARK: 3. Что дал фильм

    private var emotionsStep: some View {
        VStack(alignment: .leading, spacing: ScreenLayout.blockGap) {
            question("Что дал фильм?", hint: "До двух ответов")
            FlowLayout(spacing: Space.s8, lineSpacing: 8) {
                ForEach(SurveyOptions.emotions) { option in
                    Chip(title: option.title, isSelected: emotions.contains(option.id), height: 48) {
                        toggleLimited(option.id, in: &emotions, limit: SurveyOptions.mainLimit)
                    }
                }
            }
        }
    }

    // MARK: 5. Сильные и слабые стороны

    private var aspectsStep: some View {
        VStack(alignment: .leading, spacing: ScreenLayout.blockGap) {
            question("Что удалось?")
            sideGroup("Сильные стороны", options: SurveyOptions.aspects, value: 5)
            sideGroup("Слабые стороны", options: SurveyOptions.weaknesses, value: 1)
        }
    }

    /// Группа сторон: сильные хранятся как 5, слабые — как 1. До двух в каждой.
    private func sideGroup(_ label: String, options: [SurveyOption], value: Int) -> some View {
        VStack(alignment: .leading, spacing: ScreenLayout.groupLabelGap) {
            GroupLabel(label)
            FlowLayout(spacing: Space.s8, lineSpacing: 8) {
                ForEach(options) { option in
                    let isOn = aspects[option.id] == value
                    Chip(title: option.title, isSelected: isOn, height: 48) {
                        if isOn {
                            aspects[option.id] = nil
                        } else if aspects.values.filter({ $0 == value }).count < SurveyOptions.sideLimit {
                            aspects[option.id] = value
                        }
                    }
                }
            }
        }
        .sensoryFeedback(.selection, trigger: aspects)
    }

    // MARK: 4. Шкалы

    private var scalesStep: some View {
        VStack(alignment: .leading, spacing: Space.s20) {
            question("Каким он был?", hint: "Можно оставить посередине")
            VStack(spacing: Space.s8) {
                ForEach(SurveyOptions.scales) { scale in
                    scaleRow(scale)
                }
            }
        }
    }

    private func scaleRow(_ scale: SurveyScale) -> some View {
        let selected = scales[scale.id]
        let sizes: [CGFloat] = [26, 19, 13, 19, 26]
        return VStack(alignment: .leading, spacing: Space.s8) {
            Text(scale.title)
                .textStyle(.caption, .medium)
                .foregroundStyle(Theme.muted)
            HStack(spacing: 0) {
                ForEach(-2...2, id: \.self) { v in
                    Button {
                        if selected == v { scales[scale.id] = nil } else { scales[scale.id] = v }
                    } label: {
                        Circle()
                            .fill(selected == v ? Theme.text : Theme.lineStrong)
                            .frame(width: sizes[v + 2], height: sizes[v + 2])
                            .frame(maxWidth: .infinity, minHeight: 44)
                            .contentShape(Rectangle())
                    }
                    .buttonStyle(.plain)
                }
            }
            HStack {
                Text(scale.left)
                Spacer()
                Text(scale.right)
            }
            .textStyle(.sub, .medium)
            .foregroundStyle(Theme.textSecondary)
        }
        .padding(Space.s16)
        .background(RoundedRectangle(cornerRadius: Radius.large, style: .continuous).fill(Theme.surface))
        .sensoryFeedback(.selection, trigger: selected)
        .accessibilityElement(children: .ignore)
        .accessibilityLabel("\(scale.title): от «\(scale.left)» до «\(scale.right)»")
        .accessibilityValue(scaleAccessibilityValue(scale, selected))
        .accessibilityAdjustableAction { direction in
            let current = selected ?? 0
            switch direction {
            case .increment: scales[scale.id] = min(2, current + 1)
            case .decrement: scales[scale.id] = max(-2, current - 1)
            @unknown default: break
            }
        }
    }

    private func scaleAccessibilityValue(_ scale: SurveyScale, _ value: Int?) -> String {
        guard let value else { return "не отмечено" }
        switch value {
        case -2: return "очень \(scale.left.lowercased())"
        case -1: return "скорее \(scale.left.lowercased())"
        case 0: return "посередине"
        case 1: return "скорее \(scale.right.lowercased())"
        default: return "очень \(scale.right.lowercased())"
        }
    }

    // MARK: 6. Как смотрели

    private var contextStep: some View {
        VStack(alignment: .leading, spacing: ScreenLayout.blockGap) {
            question("Как смотрели?")
            singleChoice("Впервые или пересмотр", options: SurveyOptions.rewatch, selection: $rewatch)
            singleChoice("Где", options: SurveyOptions.places, selection: $place)
        }
    }

    private func singleChoice(_ label: String, options: [SurveyOption], selection: Binding<String>) -> some View {
        VStack(alignment: .leading, spacing: ScreenLayout.groupLabelGap) {
            GroupLabel(label)
            FlowLayout(spacing: Space.s8, lineSpacing: 8) {
                ForEach(options) { option in
                    Chip(title: option.title, isSelected: selection.wrappedValue == option.id, height: 44) {
                        selection.wrappedValue = selection.wrappedValue == option.id ? "" : option.id
                    }
                }
            }
        }
    }

    // MARK: 7. Итог

    private var verdictStep: some View {
        VStack(alignment: .leading, spacing: ScreenLayout.blockGap) {
            question("Стоит смотреть?")
            VStack(spacing: Space.s8) {
                ForEach(SurveyOptions.endings) { option in
                    let isSelected = ending == option.id
                    Button {
                        ending = isSelected ? "" : option.id
                    } label: {
                        Text(option.title)
                            .textStyle(.body, .bold)
                            .foregroundStyle(isSelected ? Color.black : Theme.text)
                            .frame(maxWidth: .infinity, minHeight: 56, alignment: .leading)
                            .padding(.horizontal, Space.s16)
                            .background(
                                RoundedRectangle(cornerRadius: 20, style: .continuous)
                                    .fill(isSelected ? Theme.text : Theme.surface)
                            )
                    }
                    .buttonStyle(.plain)
                    .accessibilityAddTraits(isSelected ? .isSelected : [])
                }
            }
            .sensoryFeedback(.selection, trigger: ending)
            VStack(alignment: .leading, spacing: ScreenLayout.groupLabelGap) {
                GroupLabel("С кем смотреть")
                FlowLayout(spacing: Space.s8, lineSpacing: 8) {
                    ForEach(SurveyOptions.recommend) { option in
                        Chip(title: option.title, isSelected: recommend.contains(option.id), height: 48) {
                            toggle(option.id, in: &recommend)
                        }
                    }
                }
            }
        }
    }

    // MARK: 7. Слово

    private var wordStep: some View {
        VStack(alignment: .leading, spacing: ScreenLayout.blockGap) {
            question("Одно слово о фильме", hint: "Каким он был для вас")
            TextField("", text: $word, prompt: Text("Ваше слово").foregroundColor(Theme.muted))
                .textStyle(.h2)
                .foregroundStyle(Theme.text)
                .focused($focus, equals: .word)
                .submitLabel(.done)
                .padding(.horizontal, Space.s16)
                .frame(minHeight: 60)
                .background(RoundedRectangle(cornerRadius: Radius.medium, style: .continuous).fill(Theme.surface))
                .accessibilityLabel("Одно слово о фильме")
                .onChange(of: word) { _, newValue in
                    if newValue.count > 24 { word = String(newValue.prefix(24)) }
                }
            FlowLayout(spacing: Space.s8, lineSpacing: 8) {
                ForEach(SurveyOptions.wordSuggestions, id: \.self) { suggestion in
                    Chip(title: suggestion, isSelected: word == suggestion, height: 44) {
                        word = suggestion
                    }
                }
            }
        }
    }

    // MARK: 8. Эссе

    private var essayStep: some View {
        VStack(alignment: .leading, spacing: ScreenLayout.blockGap) {
            question("Эссе", hint: "Ваш отзыв о фильме. Можно вставить цитату и до 10 фото.")
            if let essayDraft {
                EssayComposer(draft: essayDraft, focused: $essayFocus)
                    .frame(minHeight: 160, alignment: .top)
                    .plate()
                EssayTools(draft: essayDraft, focused: essayFocus) { essayFocus = $0 }
                Text(essayWordCount == 0 ? "Можно пропустить" : "\(essayWordCount) \(TasteProfile.plural(essayWordCount, "слово", "слова", "слов"))")
                    .textStyle(.caption)
                    .foregroundStyle(Theme.muted)
                    .padding(.horizontal, ScreenLayout.textInset)
            }
        }
    }

    private var essayWordCount: Int {
        EssayFormat.plain(essayDraft?.text ?? essay).split(whereSeparator: { $0.isWhitespace || $0.isNewline }).count
    }

    // MARK: Нижние кнопки

    private var footer: some View {
        HStack(spacing: Space.s8) {
            if step > 0 && step < questionCount && !(startAtEssay && step == essayStepIndex) {
                Button {
                    focus = nil
                    step -= 1
                } label: {
                    Image(systemName: "arrow.left")
                        .font(.system(size: 17, weight: .medium))
                        .foregroundStyle(Theme.text)
                        .frame(width: 52, height: 52)
                        .background(RoundedRectangle(cornerRadius: Radius.medium, style: .continuous).fill(Theme.surface))
                }
                .buttonStyle(.plain)
                .accessibilityLabel("Назад")
            }
            Button(step == essayStepIndex ? "Готово" : "Дальше") {
                focus = nil
                if step == essayStepIndex {
                    save()
                    dismiss()
                } else {
                    step += 1
                }
            }
            .buttonStyle(PrimaryButtonStyle())
        }
        .padding(.horizontal, Space.s20)
        .padding(.top, Space.s8)
        .padding(.bottom, Space.s12)
    }

    // MARK: Логика

    private var trimmedWord: String {
        word.trimmingCharacters(in: .whitespacesAndNewlines)
    }

    private func toggleLimited(_ id: String, in set: inout Set<String>, limit: Int) {
        if set.contains(id) { set.remove(id) } else if set.count < limit { set.insert(id) }
    }

    private func toggle(_ id: String, in set: inout Set<String>) {
        if set.contains(id) { set.remove(id) } else { set.insert(id) }
    }

    private func loadExisting() {
        guard !didLoad else { return }
        didLoad = true
        if let existing = CollectionActions.survey(for: film.id, in: context) {
            rating = existing.rating
            emotions = Set(existing.emotions)
            aspects = existing.aspectValues()
            scales = existing.scaleValues()
            ending = existing.ending
            company = existing.company
            place = existing.place
            rewatch = existing.rewatch
            recommend = Set(existing.recommend)
            word = existing.word
            essay = existing.essay
        }
        essayDraft = EssayDraft(essay: essay, photos: EssayPhotos.photos(for: film.id, in: context))
        if startAtEssay { step = essayStepIndex }
    }

    private func save() {
        let entry = CollectionActions.survey(for: film.id, in: context) ?? {
            let created = SurveyEntry(filmID: film.id)
            context.insert(created)
            return created
        }()
        entry.date = Date()
        entry.rating = rating
        entry.emotions = SurveyOptions.emotions.map(\.id).filter { emotions.contains($0) }
        entry.setAspects(aspects.filter { $0.value > 0 })
        entry.setScales(scales)
        entry.ending = ending
        entry.company = company
        entry.place = place
        entry.rewatch = rewatch
        entry.recommend = SurveyOptions.recommend.map(\.id).filter { recommend.contains($0) }
        entry.word = trimmedWord
        if let essayDraft {
            essayDraft.apply(filmID: film.id, entry: entry, in: context)
            essay = entry.essay
        } else {
            entry.essay = essay.trimmingCharacters(in: .whitespacesAndNewlines)
        }
        // Если фильм ещё не отмечен как просмотренный — отмечаем.
        if CollectionActions.item(for: film.id, in: context)?.status != .seen {
            CollectionActions.setStatus(.seen, for: film.id, in: context)
        }
        try? context.save()
    }

}
