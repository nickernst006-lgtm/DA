import SwiftUI
import SwiftData

/// Открытие анкеты.
struct SurveyLaunch: Identifiable {
    let film: FilmItem
    var essayOnly = false
    var id: String { film.id + (essayOnly ? "-essay" : "") }
}

/// Карточка фильма: обложка-афиша, «Хочу» и «Посмотрел», «О фильме», описание,
/// анкеты друзей, «Вам подойдёт?», а после просмотра — ваша «Анкета» и «Эссе».
struct FilmDetailView: View {
    let filmID: String

    @Environment(Library.self) private var library
    @Environment(Server.self) private var server
    @Environment(Social.self) private var social
    @Environment(\.modelContext) private var context
    @Environment(\.dismiss) private var dismiss
    @Query private var collection: [CollectionItem]
    @Query private var surveys: [SurveyEntry]
    @Query private var essayBlocks: [JournalBlock]

    @State private var launch: SurveyLaunch?
    @State private var editEssay: FilmItem?
    @State private var others: [OtherSurvey] = []
    @State private var openFriend: FriendReview?

    init(filmID: String) {
        self.filmID = filmID
        let id = filmID
        let essayKind = JournalKind.essay.rawValue
        _essayBlocks = Query(filter: #Predicate<JournalBlock> { $0.filmID == id && $0.kindRaw == essayKind })
    }

    private var film: FilmItem? { library.film(id: filmID) }
    private var entry: CollectionItem? { collection.first { $0.filmID == filmID } }
    private var survey: SurveyEntry? { surveys.first { $0.filmID == filmID } }
    private var essayPhotos: [JournalPhoto] { essayBlocks.first?.sortedPhotos ?? [] }

    /// Анкеты друзей, которые их показывают.
    private var friendReviews: [FriendReview] {
        others.compactMap { other in
            guard let person = social.person(other.userId), person.relation == .friend else { return nil }
            return FriendReview(person: person, survey: other)
        }
        .sorted { $0.survey.rating > $1.survey.rating }
    }

    var body: some View {
        Group {
            if let film {
                content(film)
            } else {
                VStack(spacing: Space.s12) {
                    Text("Фильм не найден")
                        .textStyle(.body, .bold)
                        .foregroundStyle(Theme.text)
                    Button("Назад") { dismiss() }
                        .buttonStyle(SecondaryButtonStyle())
                        .frame(width: 160)
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
            }
        }
        .background(Theme.background.ignoresSafeArea())
        .pushedPage()
        .toolbar {
            if entry != nil {
                ToolbarItem(placement: .topBarTrailing) {
                    Menu {
                        if entry?.status == .seen {
                            Button("Хочу пересмотреть") { CollectionActions.setStatus(.want, for: filmID, in: context) }
                        }
                        Button("Убрать из коллекции", role: .destructive) {
                            CollectionActions.setStatus(nil, for: filmID, in: context)
                        }
                    } label: {
                        Image(systemName: "ellipsis").foregroundStyle(Theme.text)
                    }
                    .accessibilityLabel("Ещё")
                }
            }
        }
        .task { await loadOthers() }
        .fullScreenCover(item: $launch) { item in
            SurveyView(film: item.film, startAtEssay: item.essayOnly)
        }
        .fullScreenCover(item: $editEssay) { film in
            EssayEditorView(film: film)
        }
        .sheet(item: $openFriend) { review in
            FriendReviewSheet(review: review, filmID: filmID, filmTitle: film?.title ?? "")
                .presentationDetents([.large])
                .presentationDragIndicator(.visible)
        }
    }

    private func loadOthers() async {
        guard server.isSignedIn, let list = try? await server.otherSurveys(filmID: filmID) else { return }
        others = list
    }

    private func content(_ film: FilmItem) -> some View {
        ScrollView {
            VStack(alignment: .leading, spacing: ScreenLayout.blockGap) {
                hero(film)
                actions(film)

                let about = facts(film)
                if !about.isEmpty {
                    ScreenBlock(title: "О фильме") {
                        FactsPlate(facts: about)
                    }
                }

                if let synopsis = film.synopsis.map(Self.shortened), !synopsis.isEmpty {
                    Text(synopsis)
                        .textStyle(.body)
                        .foregroundStyle(Theme.textSecondary)
                        .fixedSize(horizontal: false, vertical: true)
                        .padding(.horizontal, ScreenLayout.textInset)
                }

                if !friendReviews.isEmpty {
                    ScreenBlock(title: "Друзья") {
                        RowGroup {
                            ForEach(Array(friendReviews.enumerated()), id: \.element.id) { index, review in
                                if index > 0 { RowDivider(inset: ScreenLayout.textInset + Space.s48 + Space.s12) }
                                FriendReviewRow(review: review) { openFriend = review }
                            }
                        }
                    }
                }

                if entry?.status != .seen, let match = MatchScore(friends: friendReviews.map(\.survey), mine: surveys) {
                    ScreenBlock(title: "Вам подойдёт?") {
                        MatchPlate(match: match)
                    }
                }

                if entry?.status == .seen {
                    if let survey {
                        BlockWithAction(title: "Анкета", action: "Изменить") { launch = SurveyLaunch(film: film) } content: {
                            SurveyAnswers(survey: survey)
                        }
                    } else {
                        ScreenBlock(title: "Анкета") {
                            Button("Заполнить анкету") { launch = SurveyLaunch(film: film) }
                                .buttonStyle(PrimaryButtonStyle())
                        }
                    }
                    essayBlock(film)
                }
            }
            .padding(.horizontal, ScreenLayout.sideMargin)
            .padding(.bottom, ScreenLayout.blockGap)
        }
        .dockClearance()
    }

    /// Обложка-афиша: размытая обложка за шапкой, постер по центру, название, год и оценки.
    private func hero(_ film: FilmItem) -> some View {
        VStack(spacing: 0) {
            CoverView(film: film, cornerRadius: Radius.medium, fullSize: true)
                .frame(width: 168)
                .shadow(color: .black.opacity(0.6), radius: 24, y: 12)
            Text(film.title)
                .textStyle(.h1)
                .foregroundStyle(Theme.text)
                .multilineTextAlignment(.center)
                .fixedSize(horizontal: false, vertical: true)
                .padding(.top, Space.s20)
            let meta = [film.year.map(String.init), film.genres.first, Self.duration(film.minutes)].compactMap { $0 }
            if !meta.isEmpty {
                Text(meta.joined(separator: " · "))
                    .textStyle(.sub)
                    .foregroundStyle(Theme.muted)
                    .padding(.top, Space.s4)
            }
            HStack(spacing: Space.s8) {
                if let kp = film.ratingKP, kp > 0 { InfoChip(text: "Кинопоиск " + Self.score(kp), accent: true) }
                if let imdb = film.ratingIMDb, imdb > 0 { InfoChip(text: "IMDb " + Self.score(imdb)) }
            }
            .padding(.top, Space.s12)
        }
        .frame(maxWidth: .infinity)
        .padding(.top, ScreenLayout.blockGap)
        .background(alignment: .top) {
            CoverView(film: film, cornerRadius: 0, fullSize: true)
                .frame(width: 520)
                .blur(radius: 48)
                .saturation(1.3)
                .opacity(0.55)
                .frame(maxWidth: .infinity, maxHeight: 560, alignment: .top)
                .clipped()
                .overlay(LinearGradient(colors: [.clear, Theme.background], startPoint: .center, endPoint: .bottom))
                .padding(.horizontal, -ScreenLayout.sideMargin)
                .offset(y: -80)
                .allowsHitTesting(false)
                .accessibilityHidden(true)
        }
    }

    /// «Хочу» (после нажатия — «В списке») и «Посмотрел». Посмотренный фильм — одна отметка с датой.
    @ViewBuilder
    private func actions(_ film: FilmItem) -> some View {
        if entry?.status == .seen {
            Label(seenCaption, systemImage: "checkmark")
                .textStyle(.body, .bold)
                .foregroundStyle(Theme.accent)
                .frame(maxWidth: .infinity, minHeight: Space.s48)
                .background(Capsule().fill(Theme.surface))
        } else {
            HStack(spacing: Space.s12) {
                if entry?.status == .want {
                    Button {
                        CollectionActions.setStatus(nil, for: film.id, in: context)
                    } label: {
                        Label("В списке", systemImage: "checkmark")
                    }
                    .buttonStyle(SecondaryButtonStyle(highlighted: true))
                } else {
                    Button("Хочу") {
                        CollectionActions.setStatus(.want, for: film.id, in: context)
                    }
                    .buttonStyle(SecondaryButtonStyle())
                }
                Button("Посмотрел") { markSeen(film) }
                    .buttonStyle(PrimaryButtonStyle())
            }
            .sensoryFeedback(.success, trigger: entry?.statusRaw)
        }
    }

    private struct Fact: Identifiable {
        let title: String
        let value: String
        var id: String { title }
    }

    private func facts(_ film: FilmItem) -> [Fact] {
        var result: [Fact] = []
        if !film.directors.isEmpty { result.append(Fact(title: "Режиссёр", value: film.directors.prefix(2).joined(separator: ", "))) }
        if !film.countries.isEmpty { result.append(Fact(title: "Страна", value: film.countries.prefix(3).joined(separator: ", "))) }
        if !film.actors.isEmpty { result.append(Fact(title: "В ролях", value: film.actors.prefix(4).joined(separator: ", "))) }
        return result
    }

    /// Плашка «название — значение» с разделителями.
    private struct FactsPlate: View {
        let facts: [Fact]

        var body: some View {
            Grid(alignment: .topLeading, horizontalSpacing: Space.s12, verticalSpacing: 0) {
                ForEach(Array(facts.enumerated()), id: \.element.id) { index, fact in
                    if index > 0 {
                        Rectangle().fill(Theme.lineStrong).frame(height: 1)
                            .gridCellUnsizedAxes(.horizontal)
                    }
                    GridRow {
                        Text(fact.title)
                            .foregroundStyle(Theme.muted)
                        Text(fact.value)
                            .foregroundStyle(Theme.text)
                            .fixedSize(horizontal: false, vertical: true)
                            .frame(maxWidth: .infinity, alignment: .leading)
                    }
                    .padding(.vertical, Space.s12)
                }
            }
            .textStyle(.sub)
            .padding(.horizontal, ScreenLayout.cardPadding)
            .padding(.vertical, Space.s4)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(RoundedRectangle(cornerRadius: Radius.large, style: .continuous).fill(Theme.surface))
        }
    }

    /// Описание — не длиннее пяти предложений.
    static func shortened(_ text: String) -> String {
        let clean = text.trimmingCharacters(in: .whitespacesAndNewlines)
        var sentences: [String] = []
        var current = ""
        for char in clean {
            current.append(char)
            if ".!?…".contains(char) {
                let trimmed = current.trimmingCharacters(in: .whitespaces)
                if trimmed.count > 1 { sentences.append(trimmed); current = "" }
                if sentences.count == 5 { break }
            }
        }
        if sentences.count < 5 {
            let rest = current.trimmingCharacters(in: .whitespacesAndNewlines)
            if !rest.isEmpty { sentences.append(rest) }
        }
        return sentences.joined(separator: " ")
    }

    private static func duration(_ minutes: Int?) -> String? {
        guard let minutes, minutes > 0 else { return nil }
        let h = minutes / 60, m = minutes % 60
        return h > 0 ? (m > 0 ? "\(h) ч \(m) мин" : "\(h) ч") : "\(m) мин"
    }

    private static func score(_ value: Double) -> String {
        String(format: "%.1f", value).replacingOccurrences(of: ".", with: ",")
    }

    @ViewBuilder
    private func essayBlock(_ film: FilmItem) -> some View {
        let essay = survey?.essay ?? ""
        if essay.isEmpty && essayPhotos.isEmpty {
            ScreenBlock(title: "Эссе") {
                Button("Написать эссе") { editEssay = film }
                    .buttonStyle(SecondaryButtonStyle())
            }
        } else {
            BlockWithAction(title: "Эссе", action: "Изменить") { editEssay = film } content: {
                EssayView(essay: essay, photos: essayPhotos)
                    .plate()
            }
        }
    }

    private var seenCaption: String {
        guard let date = entry?.seenAt else { return "Посмотрел" }
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "ru_RU")
        let sameYear = Calendar.current.isDate(date, equalTo: Date(), toGranularity: .year)
        formatter.dateFormat = sameYear ? "d MMMM" : "d MMMM yyyy"
        return "Посмотрел " + formatter.string(from: date)
    }

    private func markSeen(_ film: FilmItem) {
        CollectionActions.setStatus(.seen, for: film.id, in: context)
        if survey == nil {
            launch = SurveyLaunch(film: film)
        }
    }
}

// MARK: - Анкета в карточке

/// Анкета: плашка с оценкой и словом, ниже — заголовки и капсулы с ответами, в конце «Заключение».
struct SurveyAnswers: View {
    let survey: SurveyEntry

    var body: some View {
        VStack(alignment: .leading, spacing: ScreenLayout.blockGap) {
            if survey.rating > 0 || !survey.word.isEmpty {
                HStack(spacing: Space.s12) {
                    if survey.rating > 0 { RatingBadge(value: survey.rating, style: .h3) }
                    if !survey.word.isEmpty {
                        Text(survey.word)
                            .textStyle(.h3)
                            .foregroundStyle(Theme.accent)
                            .lineLimit(2)
                    }
                    Spacer(minLength: 0)
                }
                .plate()
            }
            ForEach(SurveyOptions.pointGroups(survey), id: \.title) { group in
                VStack(alignment: .leading, spacing: ScreenLayout.groupLabelGap) {
                    GroupLabel(group.title)
                    FlowLayout(spacing: Space.s8, lineSpacing: Space.s8) {
                        ForEach(group.answers, id: \.self) { answer in
                            AnswerCapsule(text: answer, accent: group.title == "Заключение")
                        }
                    }
                }
            }
        }
    }
}

/// Капсула с ответом.
struct AnswerCapsule: View {
    let text: String
    var accent = false

    var body: some View {
        Text(text)
            .textStyle(.sub, .bold)
            .foregroundStyle(accent ? Color.black : Theme.text)
            .padding(.horizontal, Space.s16)
            .frame(height: 40)
            .background(Capsule().fill(accent ? Theme.accent : Theme.surface))
    }
}

// MARK: - Друзья

struct FriendReview: Identifiable {
    let person: Person
    let survey: OtherSurvey
    var id: String { person.id }
}

private struct FriendReviewRow: View {
    let review: FriendReview
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            HStack(spacing: Space.s12) {
                AvatarView(path: review.person.avatarPath, name: review.person.name, seed: review.person.id, size: Space.s48)
                VStack(alignment: .leading, spacing: 0) {
                    Text(review.person.displayName)
                        .textStyle(.body, .bold)
                        .foregroundStyle(Theme.text)
                        .lineLimit(1)
                    if !review.survey.word.isEmpty {
                        Text(review.survey.word)
                            .textStyle(.caption)
                            .foregroundStyle(Theme.muted)
                            .lineLimit(1)
                    }
                }
                Spacer(minLength: 0)
                if review.survey.rating > 0 { RatingBadge(value: review.survey.rating, style: .h3) }
                Image(systemName: "chevron.right")
                    .font(.system(size: 14, weight: .semibold))
                    .foregroundStyle(Theme.muted)
            }
            .padding(.horizontal, ScreenLayout.textInset)
            .frame(minHeight: ScreenLayout.personRowHeight)
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
    }
}

/// Анкета и эссе друга — в том же виде, что ваши.
private struct FriendReviewSheet: View {
    let review: FriendReview
    let filmID: String
    let filmTitle: String
    @Environment(Server.self) private var server
    @State private var photos: [UIImage] = []

    var body: some View {
        let entry = review.survey.entry()
        ScrollView {
            VStack(alignment: .leading, spacing: ScreenLayout.blockGap) {
                HStack(spacing: Space.s12) {
                    AvatarView(path: review.person.avatarPath, name: review.person.name, seed: review.person.id, size: Space.s48)
                    VStack(alignment: .leading, spacing: 0) {
                        Text(review.person.displayName)
                            .textStyle(.h2)
                            .foregroundStyle(Theme.text)
                        Text(filmTitle)
                            .textStyle(.sub)
                            .foregroundStyle(Theme.muted)
                            .lineLimit(1)
                    }
                }
                .padding(.top, Space.s32)

                ScreenBlock(title: "Анкета") {
                    SurveyAnswers(survey: entry)
                }

                if !entry.essay.isEmpty || !photos.isEmpty {
                    ScreenBlock(title: "Эссе") {
                        VStack(alignment: .leading, spacing: Space.s16) {
                            ForEach(EssayFormat.parse(entry.essay)) { part in
                                switch part.kind {
                                case .text:
                                    Text(part.text)
                                        .textStyle(.body)
                                        .foregroundStyle(Theme.text)
                                        .fixedSize(horizontal: false, vertical: true)
                                case .quote:
                                    QuoteBlock(text: part.text, author: part.author)
                                }
                            }
                            if !photos.isEmpty {
                                LazyVGrid(columns: Array(repeating: GridItem(.flexible(), spacing: Space.s8), count: 3), spacing: Space.s8) {
                                    ForEach(Array(photos.enumerated()), id: \.offset) { _, image in
                                        Color(hex: 0x1F1F1F)
                                            .aspectRatio(1, contentMode: .fit)
                                            .overlay { Image(uiImage: image).resizable().scaledToFill() }
                                            .clipShape(RoundedRectangle(cornerRadius: Radius.medium, style: .continuous))
                                    }
                                }
                            }
                        }
                        .plate()
                    }
                }
            }
            .padding(.horizontal, ScreenLayout.sideMargin)
            .padding(.bottom, ScreenLayout.blockGap)
        }
        .background(Theme.background.ignoresSafeArea())
        .presentationBackground(Theme.background)
        .task {
            guard let paths = try? await server.essayPhotoPaths(user: review.person.id, filmID: filmID) else { return }
            var loaded: [UIImage] = []
            for path in paths {
                if let data = try? await server.downloadFile(bucket: "journal", path: path), let image = UIImage(data: data) {
                    loaded.append(image)
                }
            }
            photos = loaded
        }
    }
}

// MARK: - Вам подойдёт?

/// Совпадение с вашим вкусом: что фильм дал друзьям и каким он им показался —
/// против того, что дают и какими бывают фильмы, которые вы оценили на 7 и выше.
struct MatchScore {
    let percent: Int
    let mainNouns: [String]
    let likesMain: Bool

    init?(friends: [OtherSurvey], mine: [SurveyEntry]) {
        let liked = mine.filter { $0.rating >= 7 }
        guard !friends.isEmpty, liked.count >= 3 else { return nil }

        var counts: [String: Double] = [:]
        for s in liked { for e in s.emotions { counts[e, default: 0] += 1 } }
        let userMain = counts.mapValues { $0 / Double(liked.count) }

        var filmMain: [String: Int] = [:]
        for f in friends { for e in f.emotions { filmMain[e, default: 0] += 1 } }
        let topMain = filmMain.sorted { $0.value > $1.value }.prefix(2).map(\.key)

        var mainScore = 0.5
        if !topMain.isEmpty {
            var total = 0.0
            for key in topMain {
                let share: Double = userMain[key] ?? 0
                total += min(1.0, share * 2.0)
            }
            mainScore = total / Double(topMain.count)
        }

        func average(_ list: [[String: Int]]) -> [String: Double] {
            var sum: [String: Double] = [:], count: [String: Double] = [:]
            for map in list { for (k, v) in map { sum[k, default: 0] += Double(v); count[k, default: 0] += 1 } }
            var result: [String: Double] = [:]
            for (k, v) in sum { result[k] = v / (count[k] ?? 1) }
            return result
        }
        let userScales = average(liked.map { $0.scaleValues() })
        let filmScales = average(friends.map { SurveyEntry.decode($0.scales) })
        let shared = Set(userScales.keys).intersection(filmScales.keys)
        var scaleScore = 0.5
        if !shared.isEmpty {
            var distance = 0.0
            for key in shared {
                let mine: Double = userScales[key] ?? 0
                let theirs: Double = filmScales[key] ?? 0
                distance += abs(mine - theirs) / 4.0
            }
            scaleScore = 1.0 - distance / Double(shared.count)
        }

        let blended: Double = 0.6 * mainScore + 0.4 * scaleScore
        percent = Int((blended * 100.0).rounded())
        mainNouns = topMain.compactMap { SurveyOptions.emotionNouns[$0] }
        likesMain = mainScore >= 0.5
    }

    var sentence: String {
        guard !mainNouns.isEmpty else { return "По анкетам друзей и вашим оценкам." }
        let list = mainNouns.joined(separator: " и ")
        return likesMain ? "Друзьям он дал \(list) — вы такое любите." : "Друзьям он дал \(list) — вы такое выбираете нечасто."
    }
}

private struct MatchPlate: View {
    let match: MatchScore

    var body: some View {
        HStack(spacing: Space.s16) {
            ZStack {
                Circle().stroke(Theme.lineStrong, lineWidth: 6)
                Circle()
                    .trim(from: 0, to: CGFloat(match.percent) / 100)
                    .stroke(Theme.accent, style: StrokeStyle(lineWidth: 6, lineCap: .round))
                    .rotationEffect(.degrees(-90))
                Text("\(match.percent)%")
                    .textStyle(.sub, .bold)
                    .foregroundStyle(Theme.text)
            }
            .frame(width: 56, height: 56)
            Text(match.sentence)
                .textStyle(.body)
                .foregroundStyle(Theme.text)
                .fixedSize(horizontal: false, vertical: true)
            Spacer(minLength: 0)
        }
        .plate()
        .accessibilityElement(children: .combine)
    }
}
