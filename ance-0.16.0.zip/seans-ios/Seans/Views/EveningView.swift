import SwiftUI
import SwiftData

/// «Что посмотрим вечером?» — двое по очереди листают одни и те же фильмы
/// на одном телефоне, приложение показывает совпадения. Без интернета и аккаунтов.
@MainActor
struct EveningView: View {
    @Environment(Library.self) private var library
    @Environment(Server.self) private var server
    @Environment(\.modelContext) private var context
    @Environment(\.dismiss) private var dismiss
    @Query(sort: \CollectionItem.addedAt, order: .reverse) private var items: [CollectionItem]

    private enum Phase { case intro, first, handoff, second, result }

    @State private var phase: Phase = .intro
    @State private var pool: [FilmItem] = []
    @State private var index = 0
    @State private var firstLikes: Set<String> = []
    @State private var secondLikes: Set<String> = []
    @State private var addedToCollection = false

    private var matches: [FilmItem] {
        pool.filter { firstLikes.contains($0.id) && secondLikes.contains($0.id) }
    }

    var body: some View {
        VStack(spacing: 0) {
            HStack {
                CloseButton { dismiss() }
                Spacer()
            }
            .padding(.horizontal, Space.s20)
            .padding(.top, Space.s12)

            switch phase {
            case .intro: intro
            case .first, .second: swiping
            case .handoff: handoff
            case .result: result
            }
        }
        .background(Theme.background.ignoresSafeArea())
        .animation(.easeInOut(duration: 0.25), value: phase)
        .animation(.easeInOut(duration: 0.2), value: index)
    }

    // MARK: Экраны

    private var intro: some View {
        VStack(alignment: .leading, spacing: Space.s16) {
            Spacer()
            Text("Что посмотрим вечером?")
                .textStyle(.screen)
                .foregroundStyle(Theme.text)
                .fixedSize(horizontal: false, vertical: true)
            Text("Сначала вы листаете фильмы и отмечаете, какие хотите посмотреть. Потом передаёте телефон — и второй зритель делает то же самое. ance покажет совпадения.")
                .textStyle(.body)
                .foregroundStyle(Theme.textSecondary)
                .fixedSize(horizontal: false, vertical: true)
            Text("В подборке — ваш список «Хочу посмотреть» и фильмы из «Вселенной».")
                .textStyle(.sub)
                .foregroundStyle(Theme.muted)
                .fixedSize(horizontal: false, vertical: true)
            Spacer()
            Button("Начать") { start() }
                .buttonStyle(PrimaryButtonStyle())
                .padding(.bottom, Space.s12)
        }
        .padding(.horizontal, Space.s20)
    }

    private var swiping: some View {
        VStack(alignment: .leading, spacing: Space.s16) {
            Text(phase == .first ? "Первый зритель · \(index + 1) из \(pool.count)" : "Второй зритель · \(index + 1) из \(pool.count)")
                .textStyle(.caption, .medium)
                .foregroundStyle(Theme.muted)
                .padding(.top, Space.s12)

            if index < pool.count {
                let film = pool[index]
                CoverView(film: film, cornerRadius: Radius.medium)
                    .frame(maxWidth: .infinity)
                    .frame(maxHeight: .infinity)
                    .id(film.id + (phase == .first ? "-1" : "-2"))
                    .transition(.opacity)
                VStack(alignment: .leading, spacing: Space.s4) {
                    Text(film.title)
                        .textStyle(.h1)
                        .foregroundStyle(Theme.text)
                        .lineLimit(2)
                    if !film.fullMeta.isEmpty {
                        Text(film.fullMeta)
                            .textStyle(.sub)
                            .foregroundStyle(Theme.muted)
                            .lineLimit(2)
                    }
                }
                HStack(spacing: Space.s8) {
                    Button("Не сегодня") { answer(film, like: false) }
                        .buttonStyle(SecondaryButtonStyle())
                    Button("Хочу") { answer(film, like: true) }
                        .buttonStyle(PrimaryButtonStyle())
                }
                .padding(.bottom, Space.s12)
                .sensoryFeedback(.selection, trigger: index)
            }
        }
        .padding(.horizontal, Space.s20)
    }

    private var handoff: some View {
        VStack(spacing: Space.s16) {
            Spacer()
            Image(systemName: "iphone.and.arrow.forward")
                .font(.system(size: 44, weight: .light))
                .foregroundStyle(Theme.accent)
                .accessibilityHidden(true)
            Text("Передайте телефон")
                .textStyle(.screen)
                .foregroundStyle(Theme.text)
            Text("Второй зритель увидит те же фильмы, но не узнает ваших ответов.")
                .textStyle(.body)
                .foregroundStyle(Theme.textSecondary)
                .multilineTextAlignment(.center)
                .fixedSize(horizontal: false, vertical: true)
            Spacer()
            Button("Я второй зритель") {
                index = 0
                phase = .second
            }
            .buttonStyle(PrimaryButtonStyle())
            .padding(.bottom, Space.s12)
        }
        .padding(.horizontal, Space.s20)
    }

    private var result: some View {
        let found = matches
        return VStack(spacing: Space.s16) {
            if let best = found.first {
                Spacer(minLength: 8)
                CoverView(film: best, cornerRadius: Radius.medium)
                    .frame(width: 180)
                VStack(spacing: Space.s8) {
                    Text(found.count == 1 ? "Совпадение" : "Совпадений: \(found.count)")
                        .textStyle(.caption, .medium)
                        .foregroundStyle(Theme.accent)
                    Text(best.title)
                        .textStyle(.screen)
                        .foregroundStyle(Theme.text)
                        .multilineTextAlignment(.center)
                    if found.count > 1 {
                        Text("А ещё: " + found.dropFirst().map(\.title).joined(separator: ", "))
                            .textStyle(.sub)
                            .foregroundStyle(Theme.muted)
                            .multilineTextAlignment(.center)
                            .fixedSize(horizontal: false, vertical: true)
                    } else {
                        Text("Вы оба хотите посмотреть этот фильм")
                            .textStyle(.sub)
                            .foregroundStyle(Theme.muted)
                    }
                }
                Spacer(minLength: 8)
                Button(addedToCollection ? "Добавлено в «Хочу посмотреть»" : "Добавить в «Хочу посмотреть»") {
                    addMatchesToCollection(found)
                }
                .buttonStyle(PrimaryButtonStyle())
                .disabled(addedToCollection)
                Button("Попробовать ещё раз") { start() }
                    .buttonStyle(SecondaryButtonStyle())
                    .padding(.bottom, Space.s12)
            } else {
                Spacer()
                Text("Совпадений нет")
                    .textStyle(.screen)
                    .foregroundStyle(Theme.text)
                Text("Так бывает. Попробуйте ещё раз — подборка будет другой.")
                    .textStyle(.body)
                    .foregroundStyle(Theme.textSecondary)
                    .multilineTextAlignment(.center)
                Spacer()
                Button("Попробовать ещё раз") { start() }
                    .buttonStyle(PrimaryButtonStyle())
                    .padding(.bottom, Space.s12)
            }
        }
        .padding(.horizontal, Space.s20)
    }

    // MARK: Логика

    private func start() {
        Task { await prepare() }
    }

    /// Подборка: ваш список «Хочу посмотреть» и известные фильмы из библиотеки.
    private func prepare() async {
        let seenIDs = Set(items.filter { $0.status == .seen }.map(\.filmID))
        let wanted = items.filter { $0.status == .want }
            .compactMap { library.film(id: $0.filmID) }
        var selection = Array(wanted.shuffled().prefix(8))
        let chosen = Set(selection.map(\.id))
        let found = (try? await server.randomFilms(limit: 40)) ?? []
        let extra = library.remember(found)
            .filter { !chosen.contains($0.id) && !seenIDs.contains($0.id) }
        selection += extra.prefix(max(0, 12 - selection.count))
        pool = selection.shuffled()
        firstLikes = []
        secondLikes = []
        index = 0
        addedToCollection = false
        phase = pool.isEmpty ? .result : .first
    }

    private func answer(_ film: FilmItem, like: Bool) {
        if like {
            if phase == .first { firstLikes.insert(film.id) } else { secondLikes.insert(film.id) }
        }
        if index + 1 < pool.count {
            index += 1
        } else {
            phase = phase == .first ? .handoff : .result
        }
    }

    private func addMatchesToCollection(_ films: [FilmItem]) {
        for film in films where CollectionActions.item(for: film.id, in: context) == nil {
            CollectionActions.setStatus(.want, for: film.id, in: context)
        }
        addedToCollection = true
    }
}
