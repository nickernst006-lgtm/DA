import SwiftUI
import SwiftData

/// Вкладка «Коллекция»: «Хочу посмотреть» — сеткой обложек,
/// «Посмотрел» — крупными карточками-журналами.
struct CollectionView: View {
    var onBrowse: () -> Void = {}

    @Environment(Library.self) private var library
    @Query(sort: \CollectionItem.addedAt, order: .reverse) private var items: [CollectionItem]
    @Query private var surveys: [SurveyEntry]

    @State private var list: CollectionStatus = .want
    @State private var surveyFilm: FilmItem?

    private let columns = [
        GridItem(.flexible(), spacing: Space.s12, alignment: .top),
        GridItem(.flexible(), spacing: Space.s12, alignment: .top),
        GridItem(.flexible(), spacing: Space.s12, alignment: .top)
    ]

    private var wantFilms: [FilmItem] {
        items.filter { $0.status == .want }
            .compactMap { library.film(id: $0.filmID) }
    }

    private struct SeenEntry: Identifiable {
        let item: CollectionItem
        let film: FilmItem
        var id: String { film.id }
    }

    private var seenItems: [SeenEntry] {
        items.filter { $0.status == .seen }
            .sorted { ($0.seenAt ?? $0.addedAt) > ($1.seenAt ?? $1.addedAt) }
            .compactMap { item in library.film(id: item.filmID).map { SeenEntry(item: item, film: $0) } }
    }

    /// Последний просмотренный фильм без анкеты.
    private var pendingSurveyFilm: FilmItem? {
        seenItems.map(\.film).first { film in !surveys.contains { $0.filmID == film.id } }
    }

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 0) {
                    VStack(alignment: .leading, spacing: ScreenLayout.titleGap) {
                        ScreenTitle("Коллекция")
                            .padding(.top, Space.s12)

                        SegmentedControl(
                            options: [
                                SegmentOption(value: CollectionStatus.want, title: "Хочу посмотреть · \(wantFilms.count)"),
                                SegmentOption(value: CollectionStatus.seen, title: "Посмотрел · \(seenItems.count)")
                            ],
                            selection: $list
                        )
                    }

                    // Напоминание об анкете — под переключателем, чтобы тот всегда стоял на месте.
                    if let pending = pendingSurveyFilm {
                        reminder(pending)
                            .padding(.top, Space.s20)
                    }

                    Group {
                        if list == .want {
                            wantGrid
                        } else {
                            seenList
                        }
                    }
                    .padding(.top, Space.s20)
                }
                .padding(.horizontal, ScreenLayout.sideMargin)
                .padding(.bottom, ScreenLayout.blockGap)
            }
            .dockClearance()
            .background(Theme.background.ignoresSafeArea())
            .navigationTitle("Коллекция")
            .toolbar(.hidden, for: .navigationBar)
            .navigationDestination(for: FilmRoute.self) { route in
                FilmDetailView(filmID: route.id)
            }
        }
        .fullScreenCover(item: $surveyFilm) { film in
            SurveyView(film: film)
        }
    }

    // MARK: Хочу посмотреть

    @ViewBuilder
    private var wantGrid: some View {
        if wantFilms.isEmpty {
            emptyState
        } else {
            LazyVGrid(columns: columns, alignment: .leading, spacing: ScreenLayout.blockGap) {
                ForEach(wantFilms) { film in
                    NavigationLink(value: FilmRoute(id: film.id)) {
                        FilmTile(film: film, subtitle: film.shortMeta, compact: true)
                    }
                    .buttonStyle(.plain)
                }
            }
        }
    }

    // MARK: Посмотрел

    @ViewBuilder
    private var seenList: some View {
        if seenItems.isEmpty {
            emptyState
        } else {
            LazyVStack(alignment: .leading, spacing: ScreenLayout.blockGap) {
                ForEach(seenItems) { pair in
                    NavigationLink(value: FilmRoute(id: pair.film.id)) {
                        JournalCard(
                            film: pair.film,
                            survey: surveys.first { $0.filmID == pair.film.id },
                            seenAt: pair.item.seenAt ?? pair.item.addedAt
                        )
                    }
                    .buttonStyle(.plain)
                }
            }
        }
    }

    private func reminder(_ film: FilmItem) -> some View {
        Button {
            surveyFilm = film
        } label: {
            HStack(spacing: Space.s12) {
                CoverView(film: film, cornerRadius: Radius.small)
                    .frame(width: 48)
                VStack(alignment: .leading, spacing: Space.s4) {
                    Text("Как вам «\(film.title)»?")
                        .textStyle(.sub, .bold)
                        .foregroundStyle(Theme.text)
                        .lineLimit(2)
                    Text("Заполните короткую анкету")
                        .textStyle(.caption)
                        .foregroundStyle(Theme.muted)
                        .fixedSize(horizontal: false, vertical: true)
                }
                Spacer(minLength: 0)
                Image(systemName: "chevron.right")
                    .font(.system(size: 14, weight: .semibold))
                    .foregroundStyle(Theme.muted)
                    .accessibilityHidden(true)
            }
            .plate()
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
    }

    private var emptyState: some View {
        VStack(alignment: .leading, spacing: ScreenLayout.blockTitleGap) {
            SectionTitle(list == .want ? "Список пока пуст" : "Вы ещё ничего не отметили",
                         hint: list == .want
                            ? "Найдите фильм и нажмите «Хочу посмотреть»."
                            : "Отметьте фильм как просмотренный и заполните анкету.")
            Button("Открыть Вселенную", action: onBrowse)
                .buttonStyle(SecondaryButtonStyle())
        }
    }
}

// MARK: - Карточка-журнал

/// Фильм в «Посмотрел»: обложка, название, год, режиссёр, оценка и дата просмотра.
struct JournalCard: View {
    let film: FilmItem
    let survey: SurveyEntry?
    let seenAt: Date

    private let coverSize = CGSize(width: 72, height: 108)

    /// Обложка слева; название, год и режиссёр — от верха обложки;
    /// квадрат оценки — в правом верхнем углу, дата — в правом нижнем, вровень с низом обложки.
    var body: some View {
        HStack(alignment: .top, spacing: Space.s12) {
            CoverView(film: film, cornerRadius: Radius.medium)
                .frame(width: coverSize.width, height: coverSize.height)
            VStack(alignment: .leading, spacing: Space.s4) {
                Text(film.title)
                    .textStyle(.h3)
                    .foregroundStyle(Theme.text)
                    .lineLimit(2)
                    .multilineTextAlignment(.leading)
                if !film.shortMeta.isEmpty {
                    Text(film.shortMeta)
                        .textStyle(.sub)
                        .foregroundStyle(Theme.muted)
                        .lineLimit(1)
                }
            }
            // место под квадрат оценки, чтобы название под него не заходило
            .padding(.trailing, survey.map { $0.rating > 0 } == true ? 32 + Space.s12 : 0)
            .frame(maxWidth: .infinity, alignment: .leading)
        }
        .frame(height: coverSize.height, alignment: .top)
        .overlay(alignment: .topTrailing) {
            if let survey, survey.rating > 0 {
                RatingBadge(value: survey.rating, style: .h3)
            }
        }
        .overlay(alignment: .bottomTrailing) {
            InfoChip(text: dateText)
        }
        .plate()
        .contentShape(RoundedRectangle(cornerRadius: Radius.large, style: .continuous))
        .accessibilityElement(children: .combine)
    }

    private var dateText: String {
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "ru_RU")
        let sameYear = Calendar.current.isDate(seenAt, equalTo: Date(), toGranularity: .year)
        formatter.dateFormat = sameYear ? "d MMMM" : "d MMMM yyyy"
        return formatter.string(from: seenAt)
    }
}
