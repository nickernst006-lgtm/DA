import SwiftUI
import UIKit

/// Обложка фильма: цветной фон и один абстрактный круг, без текста.
/// Рисуется приложением — в базе хранятся только цвета.
/// Если пользователь выбрал своё фото, показывается оно.
struct CoverView: View {
    let film: FilmItem
    var cornerRadius: CGFloat = 12

    var body: some View {
        GeometryReader { geo in
            let size = geo.size
            ZStack {
                if let data = film.photo, let image = UIImage(data: data) {
                    Image(uiImage: image)
                        .resizable()
                        .scaledToFill()
                        .frame(width: size.width, height: size.height)
                        .clipped()
                } else {
                    CoverArt(style: film.cover, seed: film.id, size: size)
                }
            }
            .frame(width: size.width, height: size.height)
        }
        .aspectRatio(2.0 / 3.0, contentMode: .fit)
        .clipShape(RoundedRectangle(cornerRadius: cornerRadius, style: .continuous))
        .accessibilityHidden(true)
    }
}

/// Сам рисунок обложки.
struct CoverArt: View {
    let style: CoverStyle
    let seed: String
    let size: CGSize

    var body: some View {
        let g = style.geometry(seed: seed)
        let diameter = size.width * CGFloat(g.size)
        ZStack(alignment: .topLeading) {
            style.bgColor
            Circle()
                .fill(style.accentColor)
                .frame(width: diameter, height: diameter)
                .position(x: size.width * CGFloat(g.x), y: size.height * CGFloat(g.y))
        }
        .frame(width: size.width, height: size.height)
        .clipped()
    }
}

/// Плитка фильма для сеток: обложка, название, год и фамилия режиссёра.
struct FilmTile: View {
    let film: FilmItem
    var subtitle: String? = nil
    /// Дополнительная строка акцентным цветом: оценка и слово о фильме.
    var note: String? = nil
    var titleSize: CGFloat = 15

    var body: some View {
        VStack(alignment: .leading, spacing: 9) {
            CoverView(film: film, cornerRadius: titleSize < 15 ? 10 : 14)
            VStack(alignment: .leading, spacing: 3) {
                Text(film.title)
                    .font(AppFont.ui(titleSize, .medium))
                    .foregroundStyle(Theme.text)
                    .lineLimit(2)
                    .multilineTextAlignment(.leading)
                if let subtitle, !subtitle.isEmpty {
                    Text(subtitle)
                        .font(AppFont.ui(titleSize - 2))
                        .foregroundStyle(Theme.muted)
                        .lineLimit(1)
                }
                if let note, !note.isEmpty {
                    Text(note)
                        .font(AppFont.ui(titleSize - 2, .medium))
                        .foregroundStyle(Theme.accent)
                        .lineLimit(1)
                }
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .contentShape(Rectangle())
        .accessibilityElement(children: .combine)
    }
}
