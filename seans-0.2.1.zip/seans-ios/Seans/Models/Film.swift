import SwiftUI

/// Настроения для подборок в Афише.
enum Mood: String, CaseIterable, Identifiable, Codable {
    case think, cozy, chills, laugh, beauty

    var id: String { rawValue }

    var title: String {
        switch self {
        case .think: return "Подумать"
        case .cozy: return "Уютное"
        case .chills: return "До мурашек"
        case .laugh: return "Посмеяться"
        case .beauty: return "Красиво"
        }
    }

    var sectionTitle: String {
        switch self {
        case .think: return "Чтобы подумать"
        case .cozy: return "Для уютного вечера"
        case .chills: return "До мурашек"
        case .laugh: return "Чтобы посмеяться"
        case .beauty: return "Просто красиво"
        }
    }
}

/// Обложка: цветной фон и один абстрактный элемент — круг.
/// Положение и размер круга у каждого фильма свои: их можно задать в базе,
/// иначе они вычисляются из id фильма и не меняются от запуска к запуску.
struct CoverStyle: Codable, Hashable {
    /// Цвет фона: "#33402F".
    var bg: String
    /// Цвет круга, светлее фона: "#D9C27A".
    var accent: String
    /// Центр круга по горизонтали и вертикали, доли обложки (0…1).
    var x: Double?
    var y: Double?
    /// Диаметр круга относительно ширины обложки (0.2…0.9).
    var size: Double?

    var bgColor: Color { Color(hexString: bg, fallback: Color(hex: 0x2A2A2A)) }
    var accentColor: Color { Color(hexString: accent, fallback: Color(hex: 0xE5E5E5)) }

    /// Палитры для фильмов, которые пользователь добавляет сам.
    static let userPalettes: [(bg: String, accent: String)] = [
        ("#33402F", "#D9C27A"),
        ("#8C2427", "#F0BE5E"),
        ("#22324A", "#A9BDD3"),
        ("#3B2A5C", "#F2C14E"),
        ("#C0803F", "#F7E0B0"),
        ("#3A3A3A", "#F5F5F5")
    ]

    static func user(palette: Int) -> CoverStyle {
        let p = userPalettes[max(0, min(userPalettes.count - 1, palette))]
        return CoverStyle(bg: p.bg, accent: p.accent, x: 0.62, y: 0.36, size: 0.5)
    }

    /// Итоговая геометрия круга для фильма с данным id.
    func geometry(seed: String) -> (x: Double, y: Double, size: Double) {
        var hash: UInt64 = 5381
        for scalar in seed.unicodeScalars {
            hash = (hash &* 33) &+ UInt64(scalar.value)
        }
        func unit(_ shift: UInt64) -> Double {
            Double((hash >> shift) & 0xFFFF) / Double(0xFFFF)
        }
        let gx = x ?? (0.28 + 0.44 * unit(0))
        let gy = y ?? (0.26 + 0.36 * unit(16))
        let gs = size ?? (0.38 + 0.2 * unit(32))
        return (gx, gy, gs)
    }
}

/// Фильм из встроенной базы (файл films.json).
struct CatalogFilm: Codable, Identifiable, Hashable {
    let id: String
    let title: String
    let originalTitle: String?
    let year: Int?
    let countries: [String]?
    let directors: [String]?
    let minutes: Int?
    let genres: [String]?
    let synopsis: String?
    /// Строки: think, cozy, chills, laugh, beauty. Неизвестные значения пропускаются.
    let moods: [String]?
    let cover: CoverStyle
}

/// Единое представление фильма для экранов — из базы или добавленного пользователем.
struct FilmItem: Identifiable, Hashable {
    let id: String
    let title: String
    let originalTitle: String?
    let year: Int?
    let countries: [String]
    let directors: [String]
    let minutes: Int?
    let genres: [String]
    let synopsis: String?
    let moods: [Mood]
    let cover: CoverStyle
    let photo: Data?
    let isCustom: Bool

    init(catalog f: CatalogFilm) {
        id = f.id
        title = f.title
        originalTitle = f.originalTitle
        year = f.year
        countries = f.countries ?? []
        directors = f.directors ?? []
        minutes = f.minutes
        genres = f.genres ?? []
        synopsis = f.synopsis
        moods = (f.moods ?? []).compactMap(Mood.init(rawValue:))
        cover = f.cover
        photo = nil
        isCustom = false
    }

    init(custom f: CustomFilm) {
        id = f.filmID
        title = f.title
        originalTitle = nil
        year = f.year
        countries = []
        let director = f.director.trimmingCharacters(in: .whitespacesAndNewlines)
        directors = director.isEmpty ? [] : [director]
        minutes = nil
        genres = []
        synopsis = nil
        moods = []
        cover = CoverStyle.user(palette: f.paletteIndex)
        photo = f.photo
        isCustom = true
    }

    /// Для предпросмотров и примеров.
    init(previewTitle: String, year: Int?, director: String? = nil, cover: CoverStyle, photo: Data?) {
        id = "preview-" + previewTitle
        title = previewTitle
        originalTitle = nil
        self.year = year
        countries = []
        directors = director.map { [$0] } ?? []
        minutes = nil
        genres = []
        synopsis = nil
        moods = []
        self.cover = cover
        self.photo = photo
        isCustom = true
    }

    /// «1979 · Тарковский»
    var shortMeta: String {
        var parts: [String] = []
        if let year { parts.append(String(year)) }
        if let first = directors.first {
            parts.append(first.split(separator: " ").last.map(String.init) ?? first)
        }
        return parts.joined(separator: " · ")
    }

    /// «1979 · Андрей Тарковский · 2 ч 42 мин»
    var fullMeta: String {
        var parts: [String] = []
        if let year { parts.append(String(year)) }
        if !directors.isEmpty { parts.append(directors.joined(separator: ", ")) }
        if let minutes, minutes > 0 {
            let h = minutes / 60
            let m = minutes % 60
            if h > 0 && m > 0 {
                parts.append("\(h) ч \(m) мин")
            } else if h > 0 {
                parts.append("\(h) ч")
            } else {
                parts.append("\(m) мин")
            }
        }
        return parts.joined(separator: " · ")
    }

    /// «СССР · Драма, Фантастика»
    var originMeta: String {
        var parts: [String] = []
        if !countries.isEmpty { parts.append(countries.joined(separator: ", ")) }
        if !genres.isEmpty { parts.append(genres.joined(separator: ", ")) }
        return parts.joined(separator: " · ")
    }

    /// Фамилия первого режиссёра.
    var directorSurname: String? {
        guard let first = directors.first else { return nil }
        return first.split(separator: " ").last.map(String.init) ?? first
    }

    /// Строка, по которой ищем.
    var searchText: String {
        ([title, originalTitle ?? "", year.map(String.init) ?? ""] + directors)
            .joined(separator: " ")
            .normalizedForSearch
    }
}

/// Маршрут для перехода на карточку фильма.
struct FilmRoute: Hashable {
    let id: String
}

extension String {
    /// Нижний регистр, «ё» → «е», без диакритики.
    var normalizedForSearch: String {
        self.lowercased()
            .replacingOccurrences(of: "ё", with: "е")
            .folding(options: [.diacriticInsensitive], locale: Locale(identifier: "ru_RU"))
    }
}
