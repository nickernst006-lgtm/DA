"""Проверка базы фильмов перед сборкой.

Запуск: python3 scripts/check_films.py
Ищет частые ошибки: повторяющиеся id, пропущенные поля, неверные цвета и настроения.
"""
import json
import re
import sys

PATH = "Seans/Resources/films.json"
MOODS = {"think", "cozy", "chills", "laugh", "beauty"}
HEX = re.compile(r"^#[0-9A-Fa-f]{6}$")


def main() -> int:
    try:
        with open(PATH, encoding="utf-8") as f:
            films = json.load(f)
    except json.JSONDecodeError as e:
        print(f"Ошибка в JSON: строка {e.lineno}, позиция {e.colno}: {e.msg}")
        return 1

    problems = []
    seen_ids = set()
    for i, film in enumerate(films, start=1):
        where = f"#{i} «{film.get('title', '?')}»"
        fid = film.get("id")
        if not fid:
            problems.append(f"{where}: нет id")
        elif fid in seen_ids:
            problems.append(f"{where}: id «{fid}» уже используется")
        else:
            seen_ids.add(fid)
        if not film.get("title"):
            problems.append(f"{where}: нет названия")
        year = film.get("year")
        if year is not None and not (1888 <= int(year) <= 2100):
            problems.append(f"{where}: странный год {year}")
        for mood in film.get("moods", []):
            if mood not in MOODS:
                problems.append(f"{where}: неизвестное настроение «{mood}»")
        cover = film.get("cover") or {}
        for key in ("bg", "accent"):
            if not HEX.match(str(cover.get(key, ""))):
                problems.append(f"{where}: цвет cover.{key} должен быть вида #33402F")
        for key, low, high in (("x", 0, 1), ("y", 0, 1), ("size", 0.2, 0.9)):
            value = cover.get(key)
            if value is not None and not (low <= float(value) <= high):
                problems.append(f"{where}: cover.{key} должен быть от {low} до {high}")

    if problems:
        print("Найдены ошибки в базе фильмов:")
        for p in problems:
            print(" -", p)
        return 1
    print(f"База фильмов в порядке: {len(films)} фильмов")
    return 0


if __name__ == "__main__":
    sys.exit(main())
