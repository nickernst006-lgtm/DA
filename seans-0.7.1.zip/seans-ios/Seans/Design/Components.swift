import SwiftUI

/// Заголовок вкладки: «Вселенная», «Коллекция», «Вкусы», «Друзья».
struct ScreenTitle: View {
    let text: String

    init(_ text: String) { self.text = text }

    var body: some View {
        Text(text)
            .font(AppFont.title(34))
            .tracking(-0.8)
            .foregroundStyle(Theme.text)
            .frame(maxWidth: .infinity, alignment: .leading)
            .accessibilityAddTraits(.isHeader)
    }
}

/// Подзаголовок раздела внутри экрана.
struct SectionTitle: View {
    let text: String
    var hint: String? = nil

    init(_ text: String, hint: String? = nil) {
        self.text = text
        self.hint = hint
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 3) {
            Text(text)
                .font(AppFont.ui(17, .bold, relativeTo: .headline))
                .tracking(-0.2)
                .foregroundStyle(Theme.text)
                .accessibilityAddTraits(.isHeader)
            if let hint {
                Text(hint)
                    .font(AppFont.ui(13, relativeTo: .footnote))
                    .foregroundStyle(Theme.muted)
                    .fixedSize(horizontal: false, vertical: true)
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }
}

/// Белая основная кнопка.
struct PrimaryButtonStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(AppFont.ui(16, .bold))
            .foregroundStyle(Color.black)
            .frame(maxWidth: .infinity, minHeight: 52)
            .padding(.horizontal, 16)
            .background(
                RoundedRectangle(cornerRadius: 16, style: .continuous)
                    .fill(Theme.text.opacity(configuration.isPressed ? 0.8 : 1))
            )
    }
}

/// Тёмная второстепенная кнопка.
struct SecondaryButtonStyle: ButtonStyle {
    var highlighted = false

    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(AppFont.ui(16, .medium))
            .foregroundStyle(highlighted ? Theme.accent : Theme.text)
            .frame(maxWidth: .infinity, minHeight: 52)
            .padding(.horizontal, 16)
            .background(
                RoundedRectangle(cornerRadius: 16, style: .continuous)
                    .fill(configuration.isPressed ? Theme.surfaceRaised : Theme.surface)
            )
    }
}

/// Чип выбора: настроение, вариант ответа в анкете.
struct Chip: View {
    let title: String
    let isSelected: Bool
    var height: CGFloat = 44
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            Text(title)
                .font(AppFont.ui(15, .medium))
                .foregroundStyle(isSelected ? Color.black : Theme.text)
                .padding(.horizontal, 16)
                .frame(minHeight: height)
                .background(
                    Capsule().fill(isSelected ? Theme.text : Theme.surface)
                )
        }
        .buttonStyle(.plain)
        .accessibilityAddTraits(isSelected ? .isSelected : [])
        .sensoryFeedback(.selection, trigger: isSelected)
    }
}

/// Сегментированный переключатель в стиле приложения.
struct SegmentOption<Value: Hashable>: Identifiable {
    let value: Value
    let title: String
    var id: Value { value }
}

struct SegmentedControl<Value: Hashable>: View {
    let options: [SegmentOption<Value>]
    @Binding var selection: Value

    var body: some View {
        HStack(spacing: 4) {
            ForEach(options) { option in
                let isSelected = option.value == selection
                Button {
                    selection = option.value
                } label: {
                    Text(option.title)
                        .font(AppFont.ui(14, .medium))
                        .lineLimit(1)
                        .minimumScaleFactor(0.8)
                        .foregroundStyle(isSelected ? Color.black : Theme.muted)
                        .frame(maxWidth: .infinity, minHeight: 40)
                        .background(
                            Capsule().fill(isSelected ? Theme.text : Color.clear)
                        )
                }
                .buttonStyle(.plain)
                .accessibilityAddTraits(isSelected ? .isSelected : [])
            }
        }
        .padding(4)
        .background(Capsule().fill(Theme.surface))
        .sensoryFeedback(.selection, trigger: selection)
    }
}

/// Раскладка «в строку с переносом» — для чипов.
struct FlowLayout: Layout {
    var spacing: CGFloat = 8
    var lineSpacing: CGFloat = 8

    func sizeThatFits(proposal: ProposedViewSize, subviews: Subviews, cache: inout ()) -> CGSize {
        let maxWidth = proposal.width ?? .infinity
        var x: CGFloat = 0
        var y: CGFloat = 0
        var rowHeight: CGFloat = 0
        var widest: CGFloat = 0
        for view in subviews {
            let size = view.sizeThatFits(.unspecified)
            if x > 0 && x + size.width > maxWidth {
                x = 0
                y += rowHeight + lineSpacing
                rowHeight = 0
            }
            x += size.width
            widest = max(widest, x)
            x += spacing
            rowHeight = max(rowHeight, size.height)
        }
        let width = proposal.width ?? widest
        return CGSize(width: width, height: y + rowHeight)
    }

    func placeSubviews(in bounds: CGRect, proposal: ProposedViewSize, subviews: Subviews, cache: inout ()) {
        var x = bounds.minX
        var y = bounds.minY
        var rowHeight: CGFloat = 0
        for view in subviews {
            let size = view.sizeThatFits(.unspecified)
            if x > bounds.minX && x + size.width > bounds.maxX {
                x = bounds.minX
                y += rowHeight + lineSpacing
                rowHeight = 0
            }
            view.place(at: CGPoint(x: x, y: y), anchor: .topLeading, proposal: ProposedViewSize(size))
            x += size.width + spacing
            rowHeight = max(rowHeight, size.height)
        }
    }
}

/// Поле поиска.
struct SearchField: View {
    @Binding var text: String
    var placeholder = "Фильм, режиссёр или год"

    var body: some View {
        HStack(spacing: 10) {
            Image(systemName: "magnifyingglass")
                .font(.system(size: 16, weight: .medium))
                .foregroundStyle(Theme.muted)
                .accessibilityHidden(true)
            TextField("", text: $text, prompt: Text(placeholder).foregroundColor(Theme.muted))
                .font(AppFont.ui(16))
                .foregroundStyle(Theme.text)
                .autocorrectionDisabled()
                .submitLabel(.search)
                .accessibilityLabel("Поиск фильма")
            if !text.isEmpty {
                Button {
                    text = ""
                } label: {
                    Image(systemName: "xmark.circle.fill")
                        .foregroundStyle(Theme.muted)
                        .frame(width: 32, height: 32)
                }
                .buttonStyle(.plain)
                .accessibilityLabel("Очистить поиск")
            }
        }
        .padding(.horizontal, 14)
        .frame(minHeight: 46)
        .background(Capsule().fill(Theme.surface))
    }
}

/// Круглая кнопка закрытия.
struct CloseButton: View {
    var systemImage = "xmark"
    var label = "Закрыть"
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            Image(systemName: systemImage)
                .font(.system(size: 15, weight: .semibold))
                .foregroundStyle(Theme.text)
                .frame(width: 44, height: 44)
                .background(Circle().fill(Theme.surface))
        }
        .buttonStyle(.plain)
        .accessibilityLabel(label)
    }
}
