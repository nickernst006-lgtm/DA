import SwiftUI
import SwiftData

/// Вкладка «Вкусы»: тип зрителя и портрет вкуса по анкетам.
struct TasteView: View {
    @Environment(Library.self) private var library
    @Query private var surveys: [SurveyEntry]
    @Query private var items: [CollectionItem]
    @Query private var customFilms: [CustomFilm]

    private var seenFilms: [FilmItem] {
        items.filter { $0.status == .seen }
            .compactMap { library.film(id: $0.filmID, custom: customFilms) }
    }

    var body: some View {
        let profile = TasteProfile(surveys: surveys, seenFilms: seenFilms)
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 30) {
                    ScreenTitle("Вкусы")
                        .padding(.top, 12)

                    typeCard(profile)

                    if profile.surveyCount > 0 {
                        stats(profile)
                        favorites(profile)
                        if !profile.axes.isEmpty { axesSection(profile) }
                        if !profile.aspects.isEmpty { aspectsSection(profile) }
                        if !profile.feelings.isEmpty { feelingsSection(profile) }
                        if !profile.words.isEmpty { wordsSection(profile) }
                    }
                }
                .padding(.horizontal, 20)
                .padding(.bottom, 28)
            }
            .background(Theme.background.ignoresSafeArea())
            .toolbar(.hidden, for: .navigationBar)
            .navigationDestination(for: FilmRoute.self) { route in
                FilmDetailView(filmID: route.id)
            }
        }
    }

    // MARK: Плашка архетипа зрителя

    private func typeCard(_ p: TasteProfile) -> some View {
        VStack(alignment: .leading, spacing: 0) {
            ZStack {
                Color(hex: 0x2A2A2A)
                if let archetype = p.archetype {
                    Image(archetype.iconAsset)
                        .renderingMode(.template)
                        .resizable()
                        .scaledToFit()
                        .frame(width: 76, height: 76)
                        .foregroundStyle(archetype.color)
                }
            }
            .frame(height: 150)
            .frame(maxWidth: .infinity)
            .accessibilityHidden(true)
            VStack(alignment: .leading, spacing: 10) {
                Text("Ваш архетип зрителя")
                    .font(AppFont.ui(13, .medium))
                    .foregroundStyle(Theme.muted)
                if let archetype = p.archetype {
                    Text(archetype.title)
                        .font(AppFont.title(30, relativeTo: .title))
                        .tracking(-0.8)
                        .foregroundStyle(Theme.text)
                        .fixedSize(horizontal: false, vertical: true)
                    Text("«\(archetype.motto)»")
                        .font(AppFont.ui(15, .medium))
                        .foregroundStyle(Theme.accent)
                    Text(archetype.description)
                        .font(AppFont.ui(16))
                        .foregroundStyle(Theme.textSecondary)
                        .lineSpacing(2)
                        .fixedSize(horizontal: false, vertical: true)
                    if let second = p.secondArchetype {
                        Text("Второй архетип — \(second.title)")
                            .font(AppFont.ui(14, .medium))
                            .foregroundStyle(Theme.textSecondary)
                            .padding(.top, 2)
                    }
                    if let reason = p.reason {
                        Text(reason)
                            .font(AppFont.ui(13))
                            .foregroundStyle(Theme.muted)
                            .fixedSize(horizontal: false, vertical: true)
                            .padding(.top, 2)
                    }
                } else {
                    Text("Появится после первой анкеты")
                        .font(AppFont.title(26, relativeTo: .title2))
                        .tracking(-0.6)
                        .foregroundStyle(Theme.text)
                        .fixedSize(horizontal: false, vertical: true)
                    Text("Отметьте фильм как просмотренный и заполните короткую анкету. С каждой новой анкетой портрет вашего вкуса будет точнее.")
                        .font(AppFont.ui(15))
                        .foregroundStyle(Theme.textSecondary)
                        .fixedSize(horizontal: false, vertical: true)
                }
            }
            .padding(20)
            .frame(maxWidth: .infinity, alignment: .leading)
        }
        .background(Theme.surface)
        .clipShape(RoundedRectangle(cornerRadius: 26, style: .continuous))
        .accessibilityElement(children: .combine)
    }

    // MARK: Цифры

    private func stats(_ p: TasteProfile) -> some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack(alignment: .top, spacing: 8) {
                stat(value: "\(p.seenCount)", label: TasteProfile.plural(p.seenCount, "фильм", "фильма", "фильмов"))
                stat(value: p.averageRating.map { String(format: "%.1f", $0).replacingOccurrences(of: ".", with: ",") } ?? "—",
                     label: "средняя оценка")
                stat(value: "\(p.essayCount)", label: TasteProfile.plural(p.essayCount, "эссе", "эссе", "эссе"))
            }
            let extrasRaw: [String?] = [
                p.favoriteDecade.map { "Любимое десятилетие — \($0)" },
                p.favoriteDirector.map { "Чаще всего смотрите — \($0)" },
                p.essayWords > 0 ? "Написано \(p.essayWords) \(TasteProfile.plural(p.essayWords, "слово", "слова", "слов")) о кино" : nil
            ]
            let extras = extrasRaw.compactMap { $0 }
            if !extras.isEmpty {
                VStack(alignment: .leading, spacing: 6) {
                    ForEach(extras, id: \.self) { line in
                        Text(line)
                            .font(AppFont.ui(14))
                            .foregroundStyle(Theme.textSecondary)
                    }
                }
            }
        }
    }

    private func stat(value: String, label: String) -> some View {
        VStack(alignment: .leading, spacing: 2) {
            Text(value)
                .font(AppFont.title(30, relativeTo: .title))
                .tracking(-0.6)
                .foregroundStyle(Theme.text)
            Text(label)
                .font(AppFont.ui(13))
                .foregroundStyle(Theme.muted)
                .fixedSize(horizontal: false, vertical: true)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(14)
        .background(RoundedRectangle(cornerRadius: 18, style: .continuous).fill(Theme.surface))
        .accessibilityElement(children: .combine)
    }

    // MARK: Любимые фильмы

    @ViewBuilder
    private func favorites(_ p: TasteProfile) -> some View {
        let films = p.favoriteIDs.compactMap { library.film(id: $0, custom: customFilms) }
        if !films.isEmpty {
            VStack(alignment: .leading, spacing: 14) {
                SectionTitle("Любимые фильмы", hint: "Оценка 8 и выше")
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(alignment: .top, spacing: 12) {
                        ForEach(films) { film in
                            NavigationLink(value: FilmRoute(id: film.id)) {
                                FilmTile(film: film, subtitle: film.shortMeta, titleSize: 13)
                                    .frame(width: 112)
                            }
                            .buttonStyle(.plain)
                        }
                    }
                    .padding(.horizontal, 20)
                }
                .padding(.horizontal, -20)
            }
        }
    }

    // MARK: Ваше кино — шкалы

    private func axesSection(_ p: TasteProfile) -> some View {
        VStack(alignment: .leading, spacing: 16) {
            SectionTitle("Ваше кино", hint: "Какие фильмы вы оцениваете выше")
            VStack(spacing: 18) {
                ForEach(p.axes) { axis in
                    VStack(spacing: 8) {
                        GeometryReader { geo in
                            let width = geo.size.width
                            let x = CGFloat(axis.value + 1) / 2 * width
                            ZStack(alignment: .leading) {
                                Capsule().fill(Theme.lineStrong).frame(height: 2)
                                Circle()
                                    .fill(Theme.text)
                                    .frame(width: 16, height: 16)
                                    .offset(x: min(max(0, x - 8), width - 16))
                            }
                            .frame(height: 16)
                        }
                        .frame(height: 16)
                        HStack {
                            Text(axis.left)
                            Spacer()
                            Text(axis.right)
                        }
                        .font(AppFont.ui(14, .medium))
                        .foregroundStyle(Theme.textSecondary)
                    }
                    .accessibilityElement(children: .ignore)
                    .accessibilityLabel("\(axis.title): ближе к «\(axis.value < 0 ? axis.left : axis.right)»")
                }
            }
            .padding(18)
            .background(RoundedRectangle(cornerRadius: 22, style: .continuous).fill(Theme.surface))
        }
    }

    // MARK: Стороны фильма

    private func aspectsSection(_ p: TasteProfile) -> some View {
        VStack(alignment: .leading, spacing: 16) {
            SectionTitle("Что для вас важнее", hint: "Средняя оценка сторон фильма в ваших анкетах")
            VStack(spacing: 14) {
                ForEach(Array(p.aspects.enumerated()), id: \.element.id) { index, bar in
                    VStack(alignment: .leading, spacing: 7) {
                        HStack {
                            Text(bar.title)
                                .font(AppFont.ui(15, .medium))
                                .foregroundStyle(Theme.text)
                            Spacer()
                            Text(bar.label.replacingOccurrences(of: ".", with: ","))
                                .font(AppFont.ui(15))
                                .foregroundStyle(Theme.muted)
                        }
                        GeometryReader { geo in
                            ZStack(alignment: .leading) {
                                Capsule().fill(Theme.lineStrong)
                                Capsule()
                                    .fill(index == 0 ? Theme.accent : Theme.text)
                                    .frame(width: geo.size.width * CGFloat(bar.value))
                            }
                        }
                        .frame(height: 6)
                    }
                    .accessibilityElement(children: .combine)
                }
            }
        }
    }

    // MARK: Чувства

    private func feelingsSection(_ p: TasteProfile) -> some View {
        VStack(alignment: .leading, spacing: 14) {
            SectionTitle("Чувства, за которыми вы приходите")
            FlowLayout(spacing: 8, lineSpacing: 8) {
                ForEach(p.feelings) { feeling in
                    HStack(spacing: 8) {
                        Text(feeling.title)
                            .foregroundStyle(Theme.text)
                        Text("\(feeling.count)")
                            .foregroundStyle(Theme.muted)
                    }
                    .font(AppFont.ui(15, .medium))
                    .padding(.horizontal, 16)
                    .frame(minHeight: 40)
                    .background(Capsule().fill(Theme.surface))
                    .accessibilityElement(children: .combine)
                }
            }
        }
    }

    // MARK: Слова

    private func wordsSection(_ p: TasteProfile) -> some View {
        let maxCount = p.words.map(\.count).max() ?? 1
        return VStack(alignment: .leading, spacing: 14) {
            SectionTitle("Ваши слова о кино")
            FlowLayout(spacing: 14, lineSpacing: 4) {
                ForEach(Array(p.words.enumerated()), id: \.element.id) { index, word in
                    let weight = Double(word.count) / Double(maxCount)
                    Text(word.title)
                        .font(AppFont.title(CGFloat(18 + 14 * weight) - CGFloat(min(index, 6)), relativeTo: .title3))
                        .tracking(-0.4)
                        .foregroundStyle(index == 0 ? Theme.accent : (index % 3 == 1 ? Theme.textSecondary : Theme.text))
                }
            }
        }
    }
}
