import SwiftUI
import SwiftData

/// Вкладка «Вселенная»: поиск по базе, подборки под настроение, вечер вдвоём.
struct AfishaView: View {
    @Environment(Library.self) private var library
    @Query(sort: \CustomFilm.createdAt, order: .reverse) private var customFilms: [CustomFilm]
    @Query private var surveys: [SurveyEntry]

    @State private var query = ""
    @State private var mood: Mood? = nil
    @State private var filter = FilmFilter()
    @State private var showFilters = false
    @State private var showAddFilm = false
    @State private var showEvening = false
    @State private var showScrollTop = false

    private let columns = [
        GridItem(.flexible(), spacing: 14, alignment: .top),
        GridItem(.flexible(), spacing: 14, alignment: .top)
    ]

    private var isSearching: Bool {
        !query.trimmingCharacters(in: .whitespaces).isEmpty
    }

    private var personal: [String: PersonalTags] {
        var result: [String: PersonalTags] = [:]
        for s in surveys { result[s.filmID] = PersonalTags(emotions: s.emotions, word: s.word) }
        return result
    }

    var body: some View {
        NavigationStack {
            ScrollViewReader { reader in
                ScrollView {
                    VStack(alignment: .leading, spacing: 22) {
                        GeometryReader { geo in
                            Color.clear.preference(key: ScrollOffsetKey.self,
                                                   value: geo.frame(in: .named("universeScroll")).minY)
                        }
                        .frame(height: 0)
                        .id("top")

                        ScreenTitle("Вселенная")
                            .padding(.top, 12)

                        VStack(alignment: .leading, spacing: 10) {
                            HStack(spacing: 8) {
                                SearchField(text: $query)
                                filterButton
                            }
                            if !filter.isEmpty { activeFilters }
                            Button {
                                showAddFilm = true
                            } label: {
                                HStack(spacing: 5) {
                                    Text("Нет нужного фильма?")
                                        .foregroundStyle(Theme.muted)
                                    Text("Добавить свой")
                                        .foregroundStyle(Theme.text)
                                }
                                .font(AppFont.ui(14, .medium))
                                .frame(minHeight: 36)
                            }
                            .buttonStyle(.plain)
                        }

                        if isSearching || !filter.isEmpty {
                            searchResults
                        } else {
                            moodPicker
                            eveningCard
                            filmGrid(title: mood?.sectionTitle ?? "Стоит посмотреть", films: library.films(for: mood))
                        }
                    }
                    .padding(.horizontal, 20)
                    .padding(.bottom, 24)
                }
                .coordinateSpace(name: "universeScroll")
                .onPreferenceChange(ScrollOffsetKey.self) { offset in
                    let shouldShow = offset < -700
                    if shouldShow != showScrollTop {
                        withAnimation(.easeInOut(duration: 0.2)) { showScrollTop = shouldShow }
                    }
                }
                .overlay(alignment: .bottomTrailing) {
                    if showScrollTop {
                        Button {
                            withAnimation(.easeInOut(duration: 0.35)) { reader.scrollTo("top", anchor: .top) }
                        } label: {
                            Image(systemName: "arrow.up")
                                .font(.system(size: 18, weight: .semibold))
                                .foregroundStyle(Color.black)
                                .frame(width: 50, height: 50)
                                .background(Circle().fill(Theme.text))
                                .shadow(color: .black.opacity(0.4), radius: 10, y: 4)
                        }
                        .buttonStyle(.plain)
                        .padding(.trailing, 20)
                        .padding(.bottom, 14)
                        .transition(.scale(scale: 0.6).combined(with: .opacity))
                        .accessibilityLabel("Наверх")
                    }
                }
            }
            .scrollDismissesKeyboard(.immediately)
            .background(Theme.background.ignoresSafeArea())
            .toolbar(.hidden, for: .navigationBar)
            .navigationDestination(for: FilmRoute.self) { route in
                FilmDetailView(filmID: route.id)
            }
        }
        .sheet(isPresented: $showAddFilm) {
            AddFilmView(prefillTitle: isSearching ? query : "")
        }
        .sheet(isPresented: $showFilters) {
            FilterSheet(filter: $filter)
        }
        .fullScreenCover(isPresented: $showEvening) {
            EveningView()
        }
    }

    private var filterButton: some View {
        Button {
            showFilters = true
        } label: {
            Image(systemName: "slider.horizontal.3")
                .font(.system(size: 17, weight: .medium))
                .foregroundStyle(filter.isEmpty ? Theme.text : Color.black)
                .frame(width: 46, height: 46)
                .background(Circle().fill(filter.isEmpty ? Theme.surface : Theme.text))
                .overlay(alignment: .topTrailing) {
                    if !filter.isEmpty {
                        Text("\(filter.activeCount)")
                            .font(AppFont.ui(11, .bold))
                            .foregroundStyle(Color.black)
                            .frame(minWidth: 18, minHeight: 18)
                            .background(Circle().fill(Theme.accent))
                            .offset(x: 3, y: -3)
                    }
                }
        }
        .buttonStyle(.plain)
        .accessibilityLabel(filter.isEmpty ? "Фильтры" : "Фильтры, выбрано: \(filter.activeCount)")
    }

    private var activeFilters: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 8) {
                ForEach(filter.tokens) { token in
                    Button {
                        filter.remove(token)
                    } label: {
                        HStack(spacing: 6) {
                            Text(token.title)
                            Image(systemName: "xmark")
                                .font(.system(size: 10, weight: .bold))
                        }
                        .font(AppFont.ui(14, .medium))
                        .foregroundStyle(Color.black)
                        .padding(.horizontal, 14)
                        .frame(minHeight: 36)
                        .background(Capsule().fill(Theme.text))
                    }
                    .buttonStyle(.plain)
                    .accessibilityLabel("Убрать фильтр \(token.title)")
                }
                Button("Сбросить") { filter = FilmFilter() }
                    .font(AppFont.ui(14, .medium))
                    .foregroundStyle(Theme.textSecondary)
                    .frame(minHeight: 36)
                    .padding(.horizontal, 6)
            }
            .padding(.horizontal, 20)
        }
        .padding(.horizontal, -20)
    }

    private var moodPicker: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 8) {
                Chip(title: "Всё", isSelected: mood == nil, height: 38) { mood = nil }
                ForEach(Mood.allCases) { item in
                    Chip(title: item.title, isSelected: mood == item, height: 38) { mood = item }
                }
            }
            .padding(.horizontal, 20)
        }
        .padding(.horizontal, -20)
    }

    private var eveningCard: some View {
        Button {
            showEvening = true
        } label: {
            HStack(spacing: 14) {
                Image(systemName: "person.2.fill")
                    .font(.system(size: 17))
                    .foregroundStyle(Color.black)
                    .frame(width: 44, height: 44)
                    .background(Circle().fill(Theme.text))
                    .accessibilityHidden(true)
                VStack(alignment: .leading, spacing: 2) {
                    Text("Что посмотрим вечером?")
                        .font(AppFont.ui(16, .bold))
                        .foregroundStyle(Theme.text)
                    Text("Выберите фильм вдвоём")
                        .font(AppFont.ui(14))
                        .foregroundStyle(Theme.muted)
                }
                Spacer(minLength: 0)
                Image(systemName: "arrow.right")
                    .font(.system(size: 15, weight: .medium))
                    .foregroundStyle(Theme.muted)
                    .accessibilityHidden(true)
            }
            .padding(14)
            .background(RoundedRectangle(cornerRadius: 20, style: .continuous).fill(Theme.surface))
        }
        .buttonStyle(.plain)
    }

    @ViewBuilder
    private var searchResults: some View {
        let results: [FilmItem] = {
            if isSearching {
                let found = library.search(query, custom: customFilms, limit: 400)
                return filter.isEmpty ? found : found.filter { filter.matches($0, personal: personal[$0.id]) }
            }
            return library.filter(filter, custom: customFilms, personal: personal)
        }()
        if results.isEmpty {
            VStack(alignment: .leading, spacing: 8) {
                Text("Ничего не нашлось")
                    .font(AppFont.ui(18, .bold))
                    .foregroundStyle(Theme.text)
                Text(isSearching
                     ? "Этого фильма пока нет в базе «Сеанса» или он не подходит под фильтры. Можно добавить его самому — он сохранится только у вас."
                     : "Под такие фильтры фильмов нет. Попробуйте убрать часть фильтров.")
                    .font(AppFont.ui(15))
                    .foregroundStyle(Theme.muted)
                    .fixedSize(horizontal: false, vertical: true)
                if isSearching {
                    Button("Добавить «\(query.trimmingCharacters(in: .whitespaces))»") {
                        showAddFilm = true
                    }
                    .buttonStyle(SecondaryButtonStyle())
                    .padding(.top, 8)
                } else {
                    Button("Сбросить фильтры") { filter = FilmFilter() }
                        .buttonStyle(SecondaryButtonStyle())
                        .padding(.top, 8)
                }
            }
            .padding(.top, 8)
        } else {
            filmGrid(title: "Найдено: \(results.count)", films: results)
        }
    }

    private func filmGrid(title: String, films: [FilmItem]) -> some View {
        VStack(alignment: .leading, spacing: 14) {
            SectionTitle(title)
            LazyVGrid(columns: columns, alignment: .leading, spacing: 24) {
                ForEach(films) { film in
                    NavigationLink(value: FilmRoute(id: film.id)) {
                        FilmTile(film: film, subtitle: film.shortMeta)
                    }
                    .buttonStyle(.plain)
                }
            }
        }
    }
}

/// Положение верха прокрутки — чтобы показать кнопку «Наверх».
private struct ScrollOffsetKey: PreferenceKey {
    static let defaultValue: CGFloat = 0
    static func reduce(value: inout CGFloat, nextValue: () -> CGFloat) {
        value = nextValue()
    }
}
