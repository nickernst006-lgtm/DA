import SwiftUI
import SwiftData
import UIKit

/// Вкладка «Друзья»: личная ссылка-приглашение и список добавленных друзей.
struct FriendsView: View {
    @Environment(\.modelContext) private var context
    @AppStorage("myFriendCode") private var myCode = ""
    @AppStorage("myDisplayName") private var myName = ""
    @Query(sort: \Friend.addedAt, order: .reverse) private var friends: [Friend]

    @State private var showAdd = false
    @State private var copied = false
    @State private var friendToDelete: Friend?

    private var invite: FriendInvite {
        FriendInvite(code: myCode, name: myName.trimmingCharacters(in: .whitespacesAndNewlines))
    }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 28) {
                ScreenTitle("Друзья")
                    .padding(.top, 12)

                inviteCard

                Button {
                    showAdd = true
                } label: {
                    Label("Добавить по коду или ссылке", systemImage: "plus")
                }
                .buttonStyle(SecondaryButtonStyle())

                friendsList
            }
            .padding(.horizontal, 20)
            .padding(.bottom, 28)
        }
        .scrollDismissesKeyboard(.interactively)
        .background(Theme.background.ignoresSafeArea())
        .onAppear {
            if myCode.isEmpty { myCode = FriendInvite.makeCode() }
        }
        .sheet(isPresented: $showAdd) {
            AddFriendSheet(myCode: myCode)
        }
        .confirmationDialog(
            "Удалить из друзей?",
            isPresented: Binding(get: { friendToDelete != nil }, set: { if !$0 { friendToDelete = nil } }),
            titleVisibility: .visible,
            presenting: friendToDelete
        ) { friend in
            Button("Удалить «\(friend.name)»", role: .destructive) {
                context.delete(friend)
                try? context.save()
            }
            Button("Отмена", role: .cancel) {}
        }
    }

    // MARK: Ссылка-приглашение

    private var inviteCard: some View {
        VStack(alignment: .leading, spacing: 16) {
            VStack(alignment: .leading, spacing: 4) {
                Text("Ваша ссылка")
                    .font(AppFont.ui(20, .bold))
                    .foregroundStyle(Theme.text)
                Text("Отправьте её другу: он откроет ссылку в «Сеансе» — и вы появитесь у него в друзьях. Попросите его прислать свою ссылку в ответ.")
                    .font(AppFont.ui(14))
                    .foregroundStyle(Theme.muted)
                    .fixedSize(horizontal: false, vertical: true)
            }

            VStack(alignment: .leading, spacing: 6) {
                Text("Ваше имя для друзей")
                    .font(AppFont.ui(13))
                    .foregroundStyle(Theme.muted)
                TextField("", text: $myName, prompt: Text("Как вас подписать").foregroundColor(Theme.muted))
                    .font(AppFont.ui(16))
                    .foregroundStyle(Theme.text)
                    .textContentType(.givenName)
                    .submitLabel(.done)
                    .padding(.horizontal, 14)
                    .frame(minHeight: 48)
                    .background(RoundedRectangle(cornerRadius: 14, style: .continuous).fill(Theme.surfaceRaised))
                    .accessibilityLabel("Ваше имя для друзей")
                    .onChange(of: myName) { _, newValue in
                        if newValue.count > 30 { myName = String(newValue.prefix(30)) }
                    }
            }

            VStack(alignment: .leading, spacing: 4) {
                Text("Ваш код")
                    .font(AppFont.ui(13))
                    .foregroundStyle(Theme.muted)
                Text(myCode)
                    .font(AppFont.title(30, relativeTo: .title))
                    .tracking(2)
                    .foregroundStyle(Theme.text)
                    .textSelection(.enabled)
                    .accessibilityLabel("Ваш код: \(myCode.map { String($0) }.joined(separator: " "))")
            }

            HStack(spacing: 10) {
                ShareLink(item: invite.message) {
                    Label("Отправить", systemImage: "square.and.arrow.up")
                }
                .buttonStyle(PrimaryButtonStyle())

                Button {
                    UIPasteboard.general.string = invite.url?.absoluteString ?? myCode
                    copied = true
                    Task {
                        try? await Task.sleep(nanoseconds: 1_600_000_000)
                        copied = false
                    }
                } label: {
                    Label(copied ? "Скопировано" : "Копировать", systemImage: copied ? "checkmark" : "doc.on.doc")
                }
                .buttonStyle(SecondaryButtonStyle(highlighted: copied))
                .sensoryFeedback(.success, trigger: copied) { _, new in new }
            }

            HStack(alignment: .top, spacing: 10) {
                Image(systemName: "icloud")
                    .font(.system(size: 15))
                    .foregroundStyle(Theme.muted)
                    .padding(.top, 1)
                    .accessibilityHidden(true)
                Text("Когда в «Сеансе» появится iCloud, друзья смогут видеть коллекции друг друга и выбирать фильм на вечер с двух телефонов. Сейчас список друзей хранится только на этом iPhone.")
                    .font(AppFont.ui(13))
                    .foregroundStyle(Theme.muted)
                    .fixedSize(horizontal: false, vertical: true)
            }
        }
        .padding(18)
        .background(RoundedRectangle(cornerRadius: 24, style: .continuous).fill(Theme.surface))
    }

    // MARK: Список друзей

    @ViewBuilder
    private var friendsList: some View {
        VStack(alignment: .leading, spacing: 12) {
            SectionTitle(friends.isEmpty ? "Ваши друзья" : "Ваши друзья · \(friends.count)")
            if friends.isEmpty {
                Text("Пока никого. Отправьте ссылку другу или добавьте его по коду.")
                    .font(AppFont.ui(15))
                    .foregroundStyle(Theme.muted)
                    .fixedSize(horizontal: false, vertical: true)
            } else {
                VStack(spacing: 0) {
                    ForEach(friends) { friend in
                        friendRow(friend)
                        if friend.id != friends.last?.id {
                            Rectangle().fill(Theme.line).frame(height: 1).padding(.leading, 66)
                        }
                    }
                }
                .background(RoundedRectangle(cornerRadius: 20, style: .continuous).fill(Theme.surface))
            }
        }
    }

    private func friendRow(_ friend: Friend) -> some View {
        HStack(spacing: 14) {
            Text(String(friend.name.prefix(1)).uppercased())
                .font(AppFont.ui(18, .bold))
                .foregroundStyle(Color.black)
                .frame(width: 40, height: 40)
                .background(Circle().fill(Theme.text))
                .accessibilityHidden(true)
            VStack(alignment: .leading, spacing: 2) {
                Text(friend.name)
                    .font(AppFont.ui(16, .medium))
                    .foregroundStyle(Theme.text)
                Text("Код \(friend.code) · с \(FriendsView.dateText(friend.addedAt))")
                    .font(AppFont.ui(13))
                    .foregroundStyle(Theme.muted)
            }
            Spacer(minLength: 0)
            Menu {
                Button(role: .destructive) {
                    friendToDelete = friend
                } label: {
                    Label("Удалить из друзей", systemImage: "person.badge.minus")
                }
            } label: {
                Image(systemName: "ellipsis")
                    .font(.system(size: 16, weight: .semibold))
                    .foregroundStyle(Theme.textSecondary)
                    .frame(width: 44, height: 44)
            }
            .accessibilityLabel("Действия с другом \(friend.name)")
        }
        .padding(.leading, 12)
        .padding(.trailing, 4)
        .padding(.vertical, 8)
    }

    private static func dateText(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "ru_RU")
        formatter.dateFormat = "d MMMM yyyy"
        return formatter.string(from: date)
    }
}

/// Добавление друга по коду или вставленной ссылке.
struct AddFriendSheet: View {
    let myCode: String

    @Environment(\.modelContext) private var context
    @Environment(\.dismiss) private var dismiss

    @State private var codeText = ""
    @State private var name = ""
    @State private var message: String?

    private var invite: FriendInvite? { FriendInvite(text: codeText) }

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            HStack {
                Button("Отмена") { dismiss() }
                    .font(AppFont.ui(16))
                    .foregroundStyle(Theme.textSecondary)
                    .frame(minWidth: 44, minHeight: 44, alignment: .leading)
                Spacer()
                Text("Добавить друга")
                    .font(AppFont.ui(16, .bold))
                    .foregroundStyle(Theme.text)
                Spacer()
                Color.clear.frame(width: 64, height: 44)
            }
            .padding(.horizontal, 16)
            .padding(.top, 8)

            VStack(alignment: .leading, spacing: 18) {
                field(label: "Код или ссылка друга", text: $codeText, prompt: "ABCD-EF23")
                    .onChange(of: codeText) { _, _ in
                        message = nil
                        if name.isEmpty, let parsed = invite, !parsed.name.isEmpty { name = parsed.name }
                    }
                field(label: "Имя друга", text: $name, prompt: "Как его подписать")

                Button {
                    if let text = UIPasteboard.general.string { codeText = text }
                } label: {
                    Label("Вставить из буфера", systemImage: "doc.on.clipboard")
                        .font(AppFont.ui(15, .medium))
                        .foregroundStyle(Theme.textSecondary)
                        .frame(minHeight: 44)
                }
                .buttonStyle(.plain)

                if let message {
                    Text(message)
                        .font(AppFont.ui(14))
                        .foregroundStyle(Theme.accent)
                        .fixedSize(horizontal: false, vertical: true)
                }
                Spacer(minLength: 0)
                Button("Добавить", action: add)
                    .buttonStyle(PrimaryButtonStyle())
                    .disabled(invite == nil)
                    .opacity(invite == nil ? 0.4 : 1)
                    .padding(.bottom, 12)
            }
            .padding(.horizontal, 20)
            .padding(.top, 16)
        }
        .background(Theme.background.ignoresSafeArea())
        .presentationBackground(Theme.background)
        .presentationDetents([.medium, .large])
    }

    private func field(label: String, text: Binding<String>, prompt: String) -> some View {
        VStack(alignment: .leading, spacing: 6) {
            Text(label)
                .font(AppFont.ui(13))
                .foregroundStyle(Theme.muted)
            TextField("", text: text, prompt: Text(prompt).foregroundColor(Theme.muted))
                .font(AppFont.ui(16))
                .foregroundStyle(Theme.text)
                .autocorrectionDisabled()
                .padding(.horizontal, 14)
                .frame(minHeight: 50)
                .background(RoundedRectangle(cornerRadius: 14, style: .continuous).fill(Theme.surface))
                .accessibilityLabel(label)
        }
    }

    private func add() {
        guard let parsed = invite else { return }
        let finalName = name.trimmingCharacters(in: .whitespacesAndNewlines)
        let result = FriendActions.add(FriendInvite(code: parsed.code, name: finalName.isEmpty ? parsed.name : finalName),
                                       myCode: myCode, in: context)
        switch result {
        case .isSelf:
            message = "Это ваш собственный код."
        case .added, .updated:
            dismiss()
        }
    }
}
