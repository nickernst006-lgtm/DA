import SwiftUI
import SwiftData

/// Открытие анкеты: с начала или сразу на эссе.
struct SurveyLaunch: Identifiable {
    let film: FilmItem
    var essayOnly = false
    var id: String { film.id + (essayOnly ? "-essay" : "") }
}

/// Карточка фильма.
struct FilmDetailView: View {
    let filmID: String

    @Environment(Library.self) private var library
    @Environment(\.modelContext) private var context
    @Environment(\.dismiss) private var dismiss
    @Query private var customFilms: [CustomFilm]
    @Query private var collection: [CollectionItem]
    @Query private var surveys: [SurveyEntry]

    @State private var launch: SurveyLaunch?
    @State private var confirmDelete = false

    private var film: FilmItem? { library.film(id: filmID, custom: customFilms) }
    private var entry: CollectionItem? { collection.first { $0.filmID == filmID } }
    private var survey: SurveyEntry? { surveys.first { $0.filmID == filmID } }

    var body: some View {
        Group {
            if let film {
                content(film)
            } else {
                VStack(spacing: 12) {
                    Text("Фильм не найден")
                        .font(AppFont.ui(17, .bold))
                        .foregroundStyle(Theme.text)
                    Button("Назад") { dismiss() }
                        .buttonStyle(SecondaryButtonStyle())
                        .frame(width: 160)
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
            }
        }
        .background(Theme.background.ignoresSafeArea())
        .toolbar(.visible, for: .navigationBar)
        .toolbarBackground(Theme.background, for: .navigationBar)
        .navigationBarTitleDisplayMode(.inline)
        .fullScreenCover(item: $launch) { item in
            SurveyView(film: item.film, startAtEssay: item.essayOnly)
        }
    }

    private func content(_ film: FilmItem) -> some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 24) {
                CoverView(film: film, cornerRadius: 20)
                    .frame(width: 220)
                    .frame(maxWidth: .infinity)
                    .padding(.top, 4)

                VStack(alignment: .leading, spacing: 8) {
                    Text(film.title)
                        .font(AppFont.title(32, relativeTo: .title))
                        .tracking(-0.8)
                        .foregroundStyle(Theme.text)
                        .fixedSize(horizontal: false, vertical: true)
                    if let original = film.originalTitle, !original.isEmpty {
                        Text(original)
                            .font(AppFont.ui(15))
                            .foregroundStyle(Theme.muted)
                    }
                    VStack(alignment: .leading, spacing: 3) {
                        if !film.fullMeta.isEmpty {
                            Text(film.fullMeta)
                        }
                        if !film.originMeta.isEmpty {
                            Text(film.originMeta)
                        }
                    }
                    .font(AppFont.ui(15))
                    .foregroundStyle(Theme.muted)
                }

                if let synopsis = film.synopsis, !synopsis.isEmpty {
                    Text(synopsis)
                        .font(AppFont.ui(17))
                        .foregroundStyle(Theme.textSecondary)
                        .lineSpacing(3)
                        .fixedSize(horizontal: false, vertical: true)
                }

                actions(film)

                if let survey {
                    review(survey, film: film)
                }

                let archetypes = film.archetypes.compactMap(Archetype.init(rawValue:))
                if !archetypes.isEmpty {
                    ArchetypeBadges(archetypes: archetypes)
                        .padding(.top, 6)
                }

                if film.isCustom {
                    Button {
                        confirmDelete = true
                    } label: {
                        Text("Удалить фильм")
                            .font(AppFont.ui(15, .medium))
                            .foregroundStyle(Theme.muted)
                            .frame(maxWidth: .infinity, minHeight: 44)
                    }
                    .buttonStyle(.plain)
                    .confirmationDialog("Удалить «\(film.title)»?", isPresented: $confirmDelete, titleVisibility: .visible) {
                        Button("Удалить", role: .destructive) { deleteCustom() }
                        Button("Отмена", role: .cancel) {}
                    } message: {
                        Text("Фильм, его статус, анкета и эссе будут удалены с этого iPhone.")
                    }
                }
            }
            .padding(.horizontal, 20)
            .padding(.bottom, 32)
        }
    }

    @ViewBuilder
    private func actions(_ film: FilmItem) -> some View {
        let status = entry?.status
        VStack(spacing: 10) {
            switch status {
            case .some(.seen):
                if survey == nil {
                    Button("Заполнить анкету") { launch = SurveyLaunch(film: film) }
                        .buttonStyle(PrimaryButtonStyle())
                }
                Button("Хочу пересмотреть") {
                    CollectionActions.setStatus(.want, for: film.id, in: context)
                }
                .buttonStyle(SecondaryButtonStyle())
                Text(seenCaption)
                    .font(AppFont.ui(13))
                    .foregroundStyle(Theme.muted)
                    .frame(maxWidth: .infinity)
            case .some(.want):
                Button("Посмотрел") { markSeen(film) }
                    .buttonStyle(PrimaryButtonStyle())
                Button {
                    CollectionActions.setStatus(nil, for: film.id, in: context)
                } label: {
                    Label("В списке «Хочу посмотреть»", systemImage: "checkmark")
                }
                .buttonStyle(SecondaryButtonStyle(highlighted: true))
            case .none:
                Button("Посмотрел") { markSeen(film) }
                    .buttonStyle(PrimaryButtonStyle())
                Button("Хочу посмотреть") {
                    CollectionActions.setStatus(.want, for: film.id, in: context)
                }
                .buttonStyle(SecondaryButtonStyle())
            }
        }
        .sensoryFeedback(.success, trigger: entry?.statusRaw)
    }

    private var seenCaption: String {
        guard let date = entry?.seenAt else { return "Отмечен как просмотренный" }
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "ru_RU")
        formatter.dateFormat = "d MMMM yyyy"
        return "Просмотрен \(formatter.string(from: date))"
    }

    private func review(_ survey: SurveyEntry, film: FilmItem) -> some View {
        VStack(alignment: .leading, spacing: 18) {
            HStack(alignment: .firstTextBaseline) {
                Text("Ваш отзыв")
                    .font(AppFont.ui(20, .bold))
                    .foregroundStyle(Theme.text)
                Spacer()
                Button("Изменить") { launch = SurveyLaunch(film: film) }
                    .font(AppFont.ui(15, .medium))
                    .foregroundStyle(Theme.textSecondary)
                    .frame(minHeight: 44)
            }

            if survey.rating > 0 || !survey.word.isEmpty {
                HStack(alignment: .firstTextBaseline, spacing: 14) {
                    if survey.rating > 0 {
                        HStack(alignment: .firstTextBaseline, spacing: 2) {
                            Text("\(survey.rating)")
                                .font(AppFont.title(48, relativeTo: .largeTitle))
                                .foregroundStyle(Theme.text)
                            Text("/10")
                                .font(AppFont.ui(17, .medium))
                                .foregroundStyle(Theme.muted)
                        }
                    }
                    if !survey.word.isEmpty {
                        Text(survey.word)
                            .font(AppFont.title(28, relativeTo: .title))
                            .tracking(-0.5)
                            .foregroundStyle(Theme.accent)
                            .lineLimit(2)
                    }
                }
            }

            let feel = SurveyOptions.titles(for: survey.emotions, in: SurveyOptions.emotions)
            if !feel.isEmpty {
                Text(feel.joined(separator: " · "))
                    .font(AppFont.ui(16))
                    .foregroundStyle(Theme.textSecondary)
                    .fixedSize(horizontal: false, vertical: true)
            }

            let aspects = survey.aspectValues()
            if !aspects.isEmpty {
                VStack(spacing: 8) {
                    ForEach(SurveyOptions.aspects.filter { (aspects[$0.id] ?? 0) > 0 }) { aspect in
                        let value = aspects[aspect.id] ?? 0
                        HStack {
                            Text(aspect.title)
                                .font(AppFont.ui(15))
                                .foregroundStyle(Theme.text)
                            Spacer()
                            HStack(spacing: 5) {
                                ForEach(1...5, id: \.self) { v in
                                    Circle()
                                        .fill(v <= value ? Theme.text : Theme.lineStrong)
                                        .frame(width: 9, height: 9)
                                }
                            }
                        }
                        .accessibilityElement(children: .ignore)
                        .accessibilityLabel("\(aspect.title): \(value) из 5")
                    }
                }
            }

            let details = detailsLine(survey)
            if !details.isEmpty {
                Text(details)
                    .font(AppFont.ui(14))
                    .foregroundStyle(Theme.muted)
                    .fixedSize(horizontal: false, vertical: true)
            }

            VStack(alignment: .leading, spacing: 10) {
                Text("Эссе")
                    .font(AppFont.ui(20, .bold))
                    .foregroundStyle(Theme.text)
                if survey.essay.isEmpty {
                    Button("Написать эссе") { launch = SurveyLaunch(film: film, essayOnly: true) }
                        .buttonStyle(SecondaryButtonStyle())
                } else {
                    Text(survey.essay)
                        .font(AppFont.ui(17))
                        .foregroundStyle(Theme.text)
                        .lineSpacing(4)
                        .textSelection(.enabled)
                        .fixedSize(horizontal: false, vertical: true)
                    Button("Редактировать эссе") { launch = SurveyLaunch(film: film, essayOnly: true) }
                        .font(AppFont.ui(15, .medium))
                        .foregroundStyle(Theme.textSecondary)
                        .frame(minHeight: 44)
                }
            }
            .padding(.top, 6)
        }
        .padding(18)
        .background(RoundedRectangle(cornerRadius: 22, style: .continuous).fill(Theme.surface))
    }

    private func detailsLine(_ survey: SurveyEntry) -> String {
        var parts: [String] = []
        if let e = SurveyOptions.title(for: survey.ending, in: SurveyOptions.endings) { parts.append(e) }
        if let r = SurveyOptions.rewatchShort[survey.rewatch] { parts.append(r) }
        let company = SurveyOptions.title(for: survey.company, in: SurveyOptions.company)
        let place = SurveyOptions.title(for: survey.place, in: SurveyOptions.places)
        let context = [company, place].compactMap { $0 }.map { $0.lowercased() }
        if !context.isEmpty { parts.append("Смотрели: " + context.joined(separator: ", ")) }
        return parts.joined(separator: " · ")
    }

    private func markSeen(_ film: FilmItem) {
        CollectionActions.setStatus(.seen, for: film.id, in: context)
        if survey == nil {
            launch = SurveyLaunch(film: film)
        }
    }

    private func deleteCustom() {
        guard let own = customFilms.first(where: { $0.filmID == filmID }) else { return }
        CollectionActions.deleteCustomFilm(own, in: context)
        dismiss()
    }
}
