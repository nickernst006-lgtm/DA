import SwiftUI

/// Настроения для подборок во «Вселенной».
enum Mood: String, CaseIterable, Identifiable, Codable {
    case think, cozy, chills, laugh, beauty

    var id: String { rawValue }

    var title: String {
        switch self {
        case .think: return "Подумать"
        case .cozy: return "Уютное"
        case .chills: return "До мурашек"
        case .laugh: return "Посмеяться"
        case .beauty: return "Красиво"
        }
    }

    var sectionTitle: String {
        switch self {
        case .think: return "Чтобы подумать"
        case .cozy: return "Для уютного вечера"
        case .chills: return "До мурашек"
        case .laugh: return "Чтобы посмеяться"
        case .beauty: return "Просто красиво"
        }
    }
}

/// Обложка: цветной фон и один абстрактный элемент — круг.
/// Положение и размер круга у каждого фильма свои: их можно задать в базе,
/// иначе они вычисляются из id фильма и не меняются от запуска к запуску.
struct CoverStyle: Codable, Hashable {
    /// Цвет фона: "#33402F".
    var bg: String
    /// Цвет круга, светлее фона: "#D9C27A".
    var accent: String
    /// Центр круга по горизонтали и вертикали, доли обложки (0…1).
    var x: Double?
    var y: Double?
    /// Диаметр круга относительно ширины обложки (0.2…0.9).
    var size: Double?

    var bgColor: Color { Color(hexString: bg, fallback: Color(hex: 0x2A2A2A)) }
    var accentColor: Color { Color(hexString: accent, fallback: Color(hex: 0xE5E5E5)) }

    /// Палитры для фильмов, которые пользователь добавляет сам.
    static let userPalettes: [(bg: String, accent: String)] = [
        ("#33402F", "#D9C27A"),
        ("#8C2427", "#F0BE5E"),
        ("#22324A", "#A9BDD3"),
        ("#3B2A5C", "#F2C14E"),
        ("#C0803F", "#F7E0B0"),
        ("#3A3A3A", "#F5F5F5")
    ]

    /// Палитры для фильмов из большой базы: цвет выбирается по id и не меняется.
    static let autoPalettes: [(bg: String, accent: String)] = [
        ("#33402F", "#D9C27A"), ("#2C4348", "#BFD4CF"), ("#4A3F2E", "#E3C9A0"), ("#2A3D57", "#F4EEE6"),
        ("#5A2E3A", "#F0C7B0"), ("#7A2A1E", "#F2C14E"), ("#3A3A3E", "#DCDCDC"), ("#4A4440", "#E2D8CC"),
        ("#2F3B44", "#B9C6CC"), ("#8C2427", "#F0BE5E"), ("#3C3A57", "#F2D9A6"), ("#2D4A3E", "#E8D27C"),
        ("#22324A", "#A9BDD3"), ("#3B2A5C", "#F2C14E"), ("#C0803F", "#F7E0B0"), ("#9C4A24", "#F5B76B"),
        ("#B8506A", "#F3D1A0"), ("#5C7A8A", "#F1D7A0"), ("#2E4F5C", "#F0A982"), ("#3F5A3A", "#D8E3B5"),
        ("#6E1B1F", "#E9A86B"), ("#2F3550", "#F2B8C6"), ("#284A63", "#F28C3B"), ("#3E2A3C", "#F07AA0")
    ]

    static func auto(seed: String) -> CoverStyle {
        var hash: UInt64 = 1469598103934665603
        for scalar in seed.unicodeScalars {
            hash = (hash ^ UInt64(scalar.value)) &* 1099511628211
        }
        let p = autoPalettes[Int(hash % UInt64(autoPalettes.count))]
        return CoverStyle(bg: p.bg, accent: p.accent, x: nil, y: nil, size: nil)
    }

    static func user(palette: Int) -> CoverStyle {
        let p = userPalettes[max(0, min(userPalettes.count - 1, palette))]
        return CoverStyle(bg: p.bg, accent: p.accent, x: 0.62, y: 0.36, size: 0.5)
    }

    /// Итоговая геометрия круга для фильма с данным id.
    func geometry(seed: String) -> (x: Double, y: Double, size: Double) {
        var hash: UInt64 = 5381
        for scalar in seed.unicodeScalars {
            hash = (hash &* 33) &+ UInt64(scalar.value)
        }
        func unit(_ shift: UInt64) -> Double {
            Double((hash >> shift) & 0xFFFF) / Double(0xFFFF)
        }
        let gx = x ?? (0.28 + 0.44 * unit(0))
        let gy = y ?? (0.26 + 0.36 * unit(16))
        let gs = size ?? (0.38 + 0.2 * unit(32))
        return (gx, gy, gs)
    }
}

/// Фильм из встроенной базы (файл films.json).
struct CatalogFilm: Codable, Identifiable, Hashable {
    let id: String
    let title: String
    let originalTitle: String?
    let year: Int?
    let countries: [String]?
    let directors: [String]?
    let minutes: Int?
    let genres: [String]?
    let synopsis: String?
    /// Строки: think, cozy, chills, laugh, beauty. Неизвестные значения пропускаются.
    let moods: [String]?
    /// Для фильмов из Wikidata обложка не задаётся — цвета подбираются автоматически.
    let cover: CoverStyle?
    /// Чувства, которые вызывает фильм (id из анкеты: think, warm, chills…). Если не заданы — по жанрам.
    let feelings: [String]?
    /// Слова, которые ассоциируются с фильмом.
    let words: [String]?
    /// Архетипы зрителей, которым фильм подойдёт (sage, hero…), не больше трёх. Если не заданы — по жанрам.
    let archetypes: [String]?
}

/// Единое представление фильма для экранов — из базы или добавленного пользователем.
struct FilmItem: Identifiable, Hashable {
    let id: String
    let title: String
    let originalTitle: String?
    let year: Int?
    let countries: [String]
    let directors: [String]
    let minutes: Int?
    let genres: [String]
    let synopsis: String?
    let moods: [Mood]
    let cover: CoverStyle
    let photo: Data?
    let isCustom: Bool
    /// Подготовленная строка для поиска: название, оригинальное название, год, режиссёры.
    let searchKey: String
    /// Чувства, слова и архетипы — для фильтров «Вселенной».
    let feelings: [String]
    let words: [String]
    /// Архетипы зрителей — не больше трёх.
    let archetypes: [String]
    /// Нормализованное название — для сортировки результатов поиска.
    var titleKey: String { title.normalizedForSearch }

    init(catalog f: CatalogFilm) {
        id = f.id
        title = f.title
        originalTitle = f.originalTitle
        year = f.year
        countries = f.countries ?? []
        directors = f.directors ?? []
        minutes = f.minutes
        genres = f.genres ?? []
        synopsis = f.synopsis
        moods = (f.moods ?? []).compactMap(Mood.init(rawValue:))
        cover = f.cover ?? CoverStyle.auto(seed: f.id)
        searchKey = FilmItem.makeSearchKey(title: f.title, original: f.originalTitle, year: f.year, directors: f.directors ?? [])
        let filmGenres = f.genres ?? []
        feelings = f.feelings ?? FilmTags.feelings(genres: filmGenres, year: f.year)
        words = (f.words ?? []).map { $0.lowercased() }
        let validArchetypes = (f.archetypes ?? []).filter { Archetype(rawValue: $0) != nil }
        archetypes = Array((validArchetypes.isEmpty ? Archetype.forGenres(filmGenres) : validArchetypes).prefix(Archetype.maxPerFilm))
        photo = nil
        isCustom = false
    }

    init(custom f: CustomFilm) {
        id = f.filmID
        title = f.title
        originalTitle = nil
        year = f.year
        countries = []
        let director = f.director.trimmingCharacters(in: .whitespacesAndNewlines)
        directors = director.isEmpty ? [] : [director]
        minutes = nil
        genres = []
        synopsis = nil
        moods = []
        cover = CoverStyle.user(palette: f.paletteIndex)
        searchKey = FilmItem.makeSearchKey(title: f.title, original: nil, year: f.year, directors: director.isEmpty ? [] : [director])
        feelings = []
        words = []
        archetypes = []
        photo = f.photo
        isCustom = true
    }

    /// Для предпросмотров и примеров.
    init(previewTitle: String, year: Int?, director: String? = nil, cover: CoverStyle, photo: Data?) {
        id = "preview-" + previewTitle
        title = previewTitle
        originalTitle = nil
        self.year = year
        countries = []
        directors = director.map { [$0] } ?? []
        minutes = nil
        genres = []
        synopsis = nil
        moods = []
        self.cover = cover
        searchKey = previewTitle.normalizedForSearch
        feelings = []
        words = []
        archetypes = []
        self.photo = photo
        isCustom = true
    }

    /// «1979 · Тарковский»
    var shortMeta: String {
        var parts: [String] = []
        if let year { parts.append(String(year)) }
        if let first = directors.first {
            parts.append(first.split(separator: " ").last.map(String.init) ?? first)
        }
        return parts.joined(separator: " · ")
    }

    /// «1979 · Андрей Тарковский · 2 ч 42 мин»
    var fullMeta: String {
        var parts: [String] = []
        if let year { parts.append(String(year)) }
        if !directors.isEmpty { parts.append(directors.joined(separator: ", ")) }
        if let minutes, minutes > 0 {
            let h = minutes / 60
            let m = minutes % 60
            if h > 0 && m > 0 {
                parts.append("\(h) ч \(m) мин")
            } else if h > 0 {
                parts.append("\(h) ч")
            } else {
                parts.append("\(m) мин")
            }
        }
        return parts.joined(separator: " · ")
    }

    /// «СССР · Драма, Фантастика»
    var originMeta: String {
        var parts: [String] = []
        if !countries.isEmpty { parts.append(countries.joined(separator: ", ")) }
        if !genres.isEmpty { parts.append(genres.joined(separator: ", ")) }
        return parts.joined(separator: " · ")
    }

    /// Фамилия первого режиссёра.
    var directorSurname: String? {
        guard let first = directors.first else { return nil }
        return first.split(separator: " ").last.map(String.init) ?? first
    }

    static func makeSearchKey(title: String, original: String?, year: Int?, directors: [String]) -> String {
        ([title, original ?? "", year.map(String.init) ?? ""] + directors)
            .joined(separator: " ")
            .normalizedForSearch
    }
}

/// Маршрут для перехода на карточку фильма.
struct FilmRoute: Hashable {
    let id: String
}

extension String {
    /// Нижний регистр, «ё» → «е», без диакритики.
    var normalizedForSearch: String {
        self.lowercased()
            .replacingOccurrences(of: "ё", with: "е")
            .folding(options: [.diacriticInsensitive], locale: Locale(identifier: "ru_RU"))
    }
}
