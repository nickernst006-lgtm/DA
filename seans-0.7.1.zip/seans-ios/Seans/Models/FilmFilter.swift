import Foundation

/// Чувства для фильмов без ручной разметки — по жанрам.
enum FilmTags {
    private static let genreFeelings: [String: [String]] = [
        "Комедия": ["laugh", "warm"],
        "Ужасы": ["anx", "chills"],
        "Триллер": ["anx", "chills"],
        "Боевик": ["wow", "chills"],
        "Драма": ["think", "sad"],
        "Мелодрама": ["warm", "sad"],
        "Фантастика": ["wow", "think"],
        "Фэнтези": ["wow", "insp"],
        "Анимация": ["warm", "wow"],
        "Семейный": ["warm"],
        "Приключения": ["wow", "insp"],
        "Мюзикл": ["insp", "warm"],
        "Криминал": ["chills"],
        "Детектив": ["think", "chills"],
        "Военный": ["sad", "think"],
        "Биография": ["insp"],
        "Исторический": ["think"],
        "Документальный": ["think"],
        "Вестерн": ["nostalgia"],
        "Нуар": ["anx"],
        "Спорт": ["insp"]
    ]

    static func feelings(genres: [String], year: Int?) -> [String] {
        var result: [String] = []
        for genre in genres {
            for feeling in genreFeelings[genre] ?? [] where !result.contains(feeling) {
                result.append(feeling)
            }
        }
        if let year, year < 1985, !result.contains("nostalgia") {
            result.append("nostalgia")
        }
        return result
    }
}

/// Собственные ответы пользователя по фильму — тоже участвуют в фильтрах.
struct PersonalTags {
    let emotions: [String]
    let word: String
}

/// Фильтры «Вселенной». Внутри одной группы — «или», между группами — «и».
struct FilmFilter: Equatable {
    var genres: Set<String> = []
    var countries: Set<String> = []
    /// Десятилетия: 1990 — «1990-е», 0 — «до 1950».
    var decades: Set<Int> = []
    var director: String = ""
    var feelings: Set<String> = []
    var words: Set<String> = []
    var archetypes: Set<String> = []

    static let decadeOptions: [Int] = [2020, 2010, 2000, 1990, 1980, 1970, 1960, 1950, 0]

    static func decadeTitle(_ decade: Int) -> String {
        decade == 0 ? "До 1950" : "\(decade)-е"
    }

    static func decade(for year: Int) -> Int {
        year < 1950 ? 0 : (year / 10) * 10
    }

    var isEmpty: Bool {
        genres.isEmpty && countries.isEmpty && decades.isEmpty && trimmedDirector.isEmpty
            && feelings.isEmpty && words.isEmpty && archetypes.isEmpty
    }

    var activeCount: Int {
        genres.count + countries.count + decades.count + (trimmedDirector.isEmpty ? 0 : 1)
            + feelings.count + words.count + archetypes.count
    }

    private var trimmedDirector: String {
        director.trimmingCharacters(in: .whitespacesAndNewlines)
    }

    func matches(_ film: FilmItem, personal: PersonalTags?) -> Bool {
        if !genres.isEmpty && !film.genres.contains(where: { genres.contains($0) }) { return false }
        if !countries.isEmpty && !film.countries.contains(where: { countries.contains($0) }) { return false }
        if !decades.isEmpty {
            guard let year = film.year, decades.contains(FilmFilter.decade(for: year)) else { return false }
        }
        let director = trimmedDirector.normalizedForSearch
        if !director.isEmpty && !film.directors.contains(where: { $0.normalizedForSearch.contains(director) }) {
            return false
        }
        if !feelings.isEmpty {
            let own = personal?.emotions ?? []
            if !film.feelings.contains(where: { feelings.contains($0) }) && !own.contains(where: { feelings.contains($0) }) { return false }
        }
        if !words.isEmpty {
            let own = personal?.word.lowercased() ?? ""
            if !film.words.contains(where: { words.contains($0) }) && !words.contains(own) { return false }
        }
        if !archetypes.isEmpty && !film.archetypes.contains(where: { archetypes.contains($0) }) { return false }
        return true
    }

    /// Активные фильтры — для строки чипов под поиском.
    struct Token: Identifiable {
        let id: String
        let title: String
    }

    var tokens: [Token] {
        var result: [Token] = []
        for g in genres.sorted() { result.append(Token(id: "g:" + g, title: g)) }
        for d in decades.sorted(by: >) { result.append(Token(id: "d:\(d)", title: FilmFilter.decadeTitle(d))) }
        for c in countries.sorted() { result.append(Token(id: "c:" + c, title: c)) }
        if !trimmedDirector.isEmpty { result.append(Token(id: "r:", title: trimmedDirector)) }
        for f in SurveyOptions.emotions where feelings.contains(f.id) { result.append(Token(id: "f:" + f.id, title: f.title)) }
        for w in words.sorted() { result.append(Token(id: "w:" + w, title: "«\(w)»")) }
        for a in Archetype.allCases where archetypes.contains(a.rawValue) { result.append(Token(id: "t:" + a.rawValue, title: a.title)) }
        return result
    }

    mutating func remove(_ token: Token) {
        let parts = token.id.split(separator: ":", maxSplits: 1).map(String.init)
        let kind = parts.first ?? ""
        let value = parts.count > 1 ? parts[1] : ""
        switch kind {
        case "g": genres.remove(value)
        case "d": decades.remove(Int(value) ?? -1)
        case "c": countries.remove(value)
        case "r": director = ""
        case "f": feelings.remove(value)
        case "w": words.remove(value)
        case "t": archetypes.remove(value)
        default: break
        }
    }
}
