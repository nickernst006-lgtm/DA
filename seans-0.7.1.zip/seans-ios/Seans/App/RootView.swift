import SwiftUI

enum AppTab: String, CaseIterable, Identifiable {
    case universe, collection, taste, friends

    var id: String { rawValue }

    var title: String {
        switch self {
        case .universe: return "Вселенная"
        case .collection: return "Коллекция"
        case .taste: return "Вкусы"
        case .friends: return "Друзья"
        }
    }
}

struct RootView: View {
    @AppStorage("didFinishWelcome") private var didFinishWelcome = false
    @State private var showSplash = true

    var body: some View {
        ZStack {
            Theme.background.ignoresSafeArea()

            if didFinishWelcome {
                MainTabsView()
            } else {
                WelcomeView {
                    withAnimation(.easeInOut(duration: 0.35)) { didFinishWelcome = true }
                }
            }

            if showSplash {
                SplashView()
                    .transition(.opacity)
                    .zIndex(1)
            }
        }
        .task {
            try? await Task.sleep(nanoseconds: 1_700_000_000)
            withAnimation(.easeInOut(duration: 0.5)) { showSplash = false }
        }
    }
}

/// Четыре вкладки и док внизу — как на экране «Домой» iPhone.
struct MainTabsView: View {
    @Environment(\.modelContext) private var context
    @AppStorage("myFriendCode") private var myCode = ""
    @State private var tab: AppTab = .universe
    @State private var pendingInvite: FriendInvite?

    var body: some View {
        GeometryReader { proxy in
            ZStack {
                AfishaView()
                    .opacity(tab == .universe ? 1 : 0)
                    .allowsHitTesting(tab == .universe)
                    .accessibilityHidden(tab != .universe)
                CollectionView(onBrowse: { tab = .universe })
                    .opacity(tab == .collection ? 1 : 0)
                    .allowsHitTesting(tab == .collection)
                    .accessibilityHidden(tab != .collection)
                TasteView()
                    .opacity(tab == .taste ? 1 : 0)
                    .allowsHitTesting(tab == .taste)
                    .accessibilityHidden(tab != .taste)
                FriendsView()
                    .opacity(tab == .friends ? 1 : 0)
                    .allowsHitTesting(tab == .friends)
                    .accessibilityHidden(tab != .friends)
            }
            .safeAreaInset(edge: .bottom, spacing: 0) {
                DockBar(selection: $tab, screenWidth: proxy.size.width)
                    // Док стоит над полоской «Домой», в 14 pt от нижнего края экрана.
                    .padding(.bottom, 14 - proxy.safeAreaInsets.bottom)
            }
        }
        .background(Theme.background.ignoresSafeArea())
        .onOpenURL { url in
            if let invite = FriendInvite(url: url) {
                tab = .friends
                pendingInvite = invite
            }
        }
        .alert(
            "Добавить в друзья?",
            isPresented: Binding(get: { pendingInvite != nil }, set: { if !$0 { pendingInvite = nil } }),
            presenting: pendingInvite
        ) { invite in
            Button("Добавить") {
                _ = FriendActions.add(invite, myCode: myCode, in: context)
            }
            Button("Отмена", role: .cancel) {}
        } message: { invite in
            Text("\(invite.name.isEmpty ? "Друг" : invite.name) · код \(invite.code)")
        }
    }
}

/// Док: размеры и форма как у дока iPhone — скруглённая плашка
/// с четырьмя иконками-«приложениями».
struct DockBar: View {
    @Binding var selection: AppTab
    let screenWidth: CGFloat

    /// Иконка приложения на iPhone — 60 pt на экранах 6,1″ и около 64 pt на 6,7″.
    private var iconSize: CGFloat { min(64, max(54, (screenWidth * 0.153).rounded())) }
    /// Скругление иконки — около 22,5 % стороны.
    private var iconRadius: CGFloat { iconSize * 0.225 }
    private var dockHeight: CGFloat { iconSize + 32 }

    var body: some View {
        HStack(spacing: 0) {
            ForEach(AppTab.allCases) { tab in
                let isSelected = tab == selection
                let tile = isSelected ? Theme.text : Theme.dockButton
                Button {
                    selection = tab
                } label: {
                    TabIcon(tab: tab, tile: tile)
                        .foregroundStyle(isSelected ? Color.black : Theme.textSecondary)
                        .frame(width: iconSize, height: iconSize)
                        .background(
                            RoundedRectangle(cornerRadius: iconRadius, style: .continuous)
                                .fill(tile)
                        )
                        .frame(maxWidth: .infinity, maxHeight: .infinity)
                        .contentShape(Rectangle())
                }
                .buttonStyle(.plain)
                .accessibilityLabel(tab.title)
                .accessibilityAddTraits(isSelected ? .isSelected : [])
            }
        }
        .frame(height: dockHeight)
        .background(
            RoundedRectangle(cornerRadius: 36, style: .continuous)
                .fill(.ultraThinMaterial)
        )
        .overlay(
            RoundedRectangle(cornerRadius: 36, style: .continuous)
                .stroke(Color.white.opacity(0.06), lineWidth: 1)
        )
        .padding(.horizontal, 12)
        .environment(\.colorScheme, .dark)
        .sensoryFeedback(.selection, trigger: selection)
    }
}

/// Значки вкладок — все из системного набора Apple, в одном стиле (заливка)
/// и в одинаковом квадрате, чтобы выглядели одного размера.
struct TabIcon: View {
    let tab: AppTab
    let tile: Color

    private var symbol: String {
        switch tab {
        case .universe: return "globe.europe.africa.fill"
        case .collection: return "rectangle.stack.fill"
        case .taste: return "sparkle"
        case .friends: return "person.fill"
        }
    }

    /// Звезда визуально мельче остальных — даём ей чуть больше места.
    private var side: CGFloat {
        tab == .taste ? 36 : 32
    }

    var body: some View {
        Image(systemName: symbol)
            .resizable()
            .scaledToFit()
            .frame(width: side, height: side)
    }
}

/// Заставка: на чёрном фоне плавно появляется название.
struct SplashView: View {
    @State private var visible = false

    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()
            Text("Сеанс")
                .font(AppFont.titleFixed(40))
                .tracking(-1)
                .foregroundStyle(Theme.text)
                .opacity(visible ? 1 : 0)
        }
        .onAppear {
            withAnimation(.easeIn(duration: 0.9).delay(0.15)) { visible = true }
        }
        .accessibilityLabel("Сеанс")
    }
}

/// Первый запуск.
struct WelcomeView: View {
    let onStart: () -> Void

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            Spacer()
            HStack(spacing: -24) {
                CoverView(film: WelcomeView.sample[0]).frame(width: 108).rotationEffect(.degrees(-7))
                CoverView(film: WelcomeView.sample[1]).frame(width: 132).zIndex(1)
                    .overlay(RoundedRectangle(cornerRadius: 12, style: .continuous).stroke(Color.black, lineWidth: 6))
                CoverView(film: WelcomeView.sample[2]).frame(width: 108).rotationEffect(.degrees(7))
            }
            .frame(maxWidth: .infinity)
            .padding(.bottom, 48)

            VStack(alignment: .leading, spacing: 12) {
                Text("Сеанс")
                    .font(AppFont.title(40))
                    .tracking(-1)
                    .foregroundStyle(Theme.text)
                Text("Отмечайте фильмы, рассказывайте, как они вам, — и узнавайте свой киновкус.")
                    .font(AppFont.ui(17))
                    .foregroundStyle(Theme.textSecondary)
                    .fixedSize(horizontal: false, vertical: true)
            }

            HStack(alignment: .top, spacing: 14) {
                Image(systemName: "lock.fill")
                    .font(.system(size: 17))
                    .foregroundStyle(Theme.accent)
                    .accessibilityHidden(true)
                VStack(alignment: .leading, spacing: 4) {
                    Text("Без регистрации и паролей")
                        .font(AppFont.ui(15, .bold))
                        .foregroundStyle(Theme.text)
                    Text("Ваши фильмы, анкеты и эссе хранятся только на этом iPhone. Мы их не видим и не храним.")
                        .font(AppFont.ui(14))
                        .foregroundStyle(Theme.muted)
                        .fixedSize(horizontal: false, vertical: true)
                }
            }
            .padding(16)
            .background(RoundedRectangle(cornerRadius: 18, style: .continuous).fill(Theme.surface))
            .padding(.top, 28)

            Spacer()

            Button("Начать", action: onStart)
                .buttonStyle(PrimaryButtonStyle())
                .padding(.bottom, 12)
        }
        .padding(.horizontal, 24)
        .background(Theme.background.ignoresSafeArea())
    }

    static let sample: [FilmItem] = [
        FilmItem(previewTitle: "Амели", year: 2001,
                 cover: CoverStyle(bg: "#8C2427", accent: "#F0BE5E", x: 0.32, y: 0.34, size: 0.48), photo: nil),
        FilmItem(previewTitle: "Сталкер", year: 1979,
                 cover: CoverStyle(bg: "#33402F", accent: "#D9C27A", x: 0.6, y: 0.4, size: 0.5), photo: nil),
        FilmItem(previewTitle: "Начало", year: 2010,
                 cover: CoverStyle(bg: "#22324A", accent: "#A9BDD3", x: 0.66, y: 0.36, size: 0.44), photo: nil)
    ]
}
