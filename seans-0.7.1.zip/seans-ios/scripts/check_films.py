"""Проверка базы фильмов перед сборкой.

Запуск: python3 scripts/check_films.py
Ищет частые ошибки: повторяющиеся id, пропущенные поля, неверные цвета и настроения.
"""
import json
import os
import re
import sys

PATH = "Seans/Resources/films.json"
MOODS = {"think", "cozy", "chills", "laugh", "beauty"}
FEELINGS = {"wow", "chills", "anx", "sad", "think", "insp", "warm", "laugh", "nostalgia", "bored"}
ARCHETYPES = {"innocent", "everyman", "hero", "caregiver", "explorer", "rebel", "lover", "creator", "jester", "sage", "magician", "ruler"}
HEX = re.compile(r"^#[0-9A-Fa-f]{6}$")


def main() -> int:
    try:
        with open(PATH, encoding="utf-8") as f:
            films = json.load(f)
    except json.JSONDecodeError as e:
        print(f"Ошибка в JSON: строка {e.lineno}, позиция {e.colno}: {e.msg}")
        return 1

    problems = []
    seen_ids = set()
    for i, film in enumerate(films, start=1):
        where = f"#{i} «{film.get('title', '?')}»"
        fid = film.get("id")
        if not fid:
            problems.append(f"{where}: нет id")
        elif fid in seen_ids:
            problems.append(f"{where}: id «{fid}» уже используется")
        else:
            seen_ids.add(fid)
        if not film.get("title"):
            problems.append(f"{where}: нет названия")
        year = film.get("year")
        if year is not None and not (1888 <= int(year) <= 2100):
            problems.append(f"{where}: странный год {year}")
        for mood in film.get("moods", []):
            if mood not in MOODS:
                problems.append(f"{where}: неизвестное настроение «{mood}»")
        for feeling in film.get("feelings", []):
            if feeling not in FEELINGS:
                problems.append(f"{where}: неизвестное чувство «{feeling}», доступны: {', '.join(sorted(FEELINGS))}")
        archetypes = film.get("archetypes", [])
        if len(archetypes) > 3:
            problems.append(f"{where}: архетипов {len(archetypes)}, можно не больше трёх")
        if len(set(archetypes)) != len(archetypes):
            problems.append(f"{where}: архетипы повторяются")
        for archetype in archetypes:
            if archetype not in ARCHETYPES:
                problems.append(f"{where}: неизвестный архетип «{archetype}», доступны: {', '.join(sorted(ARCHETYPES))}")
        if "viewerTypes" in film:
            problems.append(f"{where}: поле viewerTypes устарело — используйте archetypes")
        cover = film.get("cover") or {}
        for key in ("bg", "accent"):
            if not HEX.match(str(cover.get(key, ""))):
                problems.append(f"{where}: цвет cover.{key} должен быть вида #33402F")
        for key, low, high in (("x", 0, 1), ("y", 0, 1), ("size", 0.2, 0.9)):
            value = cover.get(key)
            if value is not None and not (low <= float(value) <= high):
                problems.append(f"{where}: cover.{key} должен быть от {low} до {high}")

    # Обложки-картинки: имя файла должно совпадать с id фильма.
    covers_dir = "Seans/Resources/Covers"
    image_ext = {".jpg", ".jpeg", ".png", ".webp"}
    with_image = 0
    if os.path.isdir(covers_dir):
        for name in sorted(os.listdir(covers_dir)):
            stem, ext = os.path.splitext(name)
            if ext.lower() not in image_ext:
                continue
            if ext != ext.lower():
                problems.append(f"обложка {name}: расширение пишите маленькими буквами ({stem}{ext.lower()})")
            elif stem not in seen_ids:
                problems.append(f"обложка {name}: нет фильма с id «{stem}» — проверьте имя файла")
            else:
                with_image += 1
                size_kb = os.path.getsize(os.path.join(covers_dir, name)) / 1024
                if size_kb > 600:
                    print(f"Внимание: обложка {name} весит {size_kb:.0f} КБ — лучше сжать до 200 КБ")

    # Большая база из Wikidata: только проверяем, что файл читается.
    bulk_path = "Seans/Resources/films_wikidata.json"
    bulk_count = 0
    if os.path.exists(bulk_path):
        try:
            with open(bulk_path, encoding="utf-8") as f:
                bulk_count = len(json.load(f))
        except json.JSONDecodeError as e:
            problems.append(f"films_wikidata.json повреждён: строка {e.lineno}: {e.msg}")

    if problems:
        print("Найдены ошибки в базе фильмов:")
        for p in problems:
            print(" -", p)
        return 1
    print(f"База фильмов в порядке: ручная — {len(films)}, с картинкой-обложкой — {with_image}, из Wikidata — {bulk_count}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
