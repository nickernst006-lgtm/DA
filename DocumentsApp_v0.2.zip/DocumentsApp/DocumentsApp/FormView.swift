import SwiftUI
import PhotosUI
import PDFKit
import UniformTypeIdentifiers

// Вкладка «Форма» (ТЗ, раздел 5.1): создание новой карточки и правка
// существующей. После сохранения — переход в «Хранилище» к этой карточке.
//
// Файлы шифруются и пишутся на диск сразу при добавлении, чтобы не держать
// в памяти десятки мегабайт. Если форму очистили — они стираются сразу;
// если приложение заблокировалось посреди заполнения — стираются при
// следующем входе как ни на что не ссылающиеся (AppState.cleanOrphanBlobs).

/// Черновик карточки в форме
struct CardDraft: Equatable {
    var typeId: String = CardTemplate.basicId
    var personId: UUID? = nil
    var folderId: UUID? = nil
    var title: String = ""
    var status: CardStatus = .active
    var fields: [String: String] = [:]
    var note: String = ""
    /// Только файлы, которые остаются в карточке (без лежащих в корзине)
    var files: [StoredFile] = []
}

struct FormView: View {
    @EnvironmentObject var appState: AppState
    @Binding var editState: EditState?
    var onSaved: (UUID) -> Void

    @State private var draft = CardDraft()
    @State private var editingId: UUID? = nil
    /// Блобы, созданные в этом черновике и ещё не сохранённые в карточку
    @State private var newBlobs: Set<String> = []
    /// Пользователь сам правил название — тип его больше не перезаписывает
    @State private var titleEdited = false

    @State private var photoItems: [PhotosPickerItem] = []
    @State private var showFileImporter = false
    @State private var isImporting = false
    @State private var importError: String? = nil

    @State private var folderTarget: FolderEditTarget? = nil
    @State private var showAddPerson = false
    @State private var newPersonName = ""
    @State private var renamingFileId: UUID? = nil
    @State private var renameText = ""
    @State private var confirmDiscard = false

    private var template: CardTemplate { CardTemplate.find(draft.typeId) }

    private var hasContent: Bool {
        editingId != nil || !draft.title.isEmpty || !draft.files.isEmpty
            || !draft.fields.isEmpty || !draft.note.isEmpty
    }

    private var canSave: Bool {
        draft.folderId != nil && !draft.title.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
    }

    var body: some View {
        List {
            Section {
                ScreenHeader(title: editingId == nil ? "Новая карточка" : "Правка карточки") {
                    if hasContent {
                        HeaderButton(symbol: "xmark", label: "Очистить форму") { confirmDiscard = true }
                    }
                }
            }
            .plainRow()

            typeSection
            locationSection
            mainSection
            if !template.fields.isEmpty {
                fieldsSection
            }
            filesSection
            noteSection
            saveSection
        }
        .themedScreen()
        .onAppear { applyEditState() }
        .onChange(of: editState) { _, _ in applyEditState() }
        .onChange(of: photoItems) { _, items in importPhotos(items) }
        .fileImporter(isPresented: $showFileImporter,
                      allowedContentTypes: [.item],
                      allowsMultipleSelection: true) { result in
            switch result {
            case .success(let urls): importFiles(urls)
            case .failure(let error): importError = "Не удалось открыть файл: \(error.localizedDescription)"
            }
        }
        .sheet(item: $folderTarget) { target in
            FolderEditor(target: target, onCreated: { newId in draft.folderId = newId })
                .environmentObject(appState)
        }
        .alert("Новый член семьи", isPresented: $showAddPerson) {
            TextField("Имя", text: $newPersonName)
            Button("Отмена", role: .cancel) {}
            Button("Добавить") { addPerson() }
        }
        .alert("Имя файла", isPresented: Binding(
            get: { renamingFileId != nil },
            set: { if !$0 { renamingFileId = nil } }
        )) {
            TextField("Имя файла", text: $renameText)
            Button("Отмена", role: .cancel) { renamingFileId = nil }
            Button("Сохранить") { applyRename() }
        }
        .confirmationDialog("Очистить форму?", isPresented: $confirmDiscard, titleVisibility: .visible) {
            Button("Очистить", role: .destructive) { discardDraft() }
            Button("Отмена", role: .cancel) {}
        } message: {
            Text(editingId == nil
                 ? "Введённые данные и добавленные файлы будут удалены."
                 : "Правка будет отменена, карточка останется как была.")
        }
    }

    // MARK: - Разделы формы

    private var typeSection: some View {
        Section(header: SectionTitle("Тип карточки")) {
            Picker(selection: typeBinding) {
                ForEach(CardTemplate.all) { t in
                    Label(t.title, systemImage: t.symbol).tag(t.id)
                }
            } label: {
                HStack(spacing: Theme.gap) {
                    IconBadge(symbol: template.symbol, color: template.color)
                    Text("Тип").font(Theme.body)
                }
            }
            .pickerStyle(.menu)
            .accessibilityIdentifier("cardType")
        }
    }

    @ViewBuilder
    private var locationSection: some View {
        let persons = appState.data.activePersons
        Section(header: SectionTitle("Где лежит")) {
            if persons.isEmpty {
                Text("Сначала добавьте члена семьи — у каждого свой набор папок.")
                    .font(Theme.caption)
                    .foregroundStyle(.secondary)
            } else {
                Picker("Член семьи", selection: personBinding) {
                    Text("Не выбран").tag(UUID?.none)
                    ForEach(persons) { p in
                        Text(p.name).tag(Optional(p.id))
                    }
                }
                .pickerStyle(.menu)
                .font(Theme.body)
                .accessibilityIdentifier("cardPerson")
            }
            Button("Добавить члена семьи") {
                newPersonName = ""
                showAddPerson = true
            }
            .font(Theme.body)
            .accessibilityIdentifier("formAddPerson")

            if let personId = draft.personId {
                let folders = appState.data.activeFolders(of: personId)
                if folders.isEmpty {
                    Text("У этого члена семьи ещё нет папок.")
                        .font(Theme.caption)
                        .foregroundStyle(.secondary)
                } else {
                    Picker("Папка", selection: $draft.folderId) {
                        Text("Не выбрана").tag(UUID?.none)
                        ForEach(folders) { f in
                            Text(appState.data.folderTitle(f)).tag(Optional(f.id))
                        }
                    }
                    .pickerStyle(.menu)
                    .font(Theme.body)
                    .accessibilityIdentifier("cardFolder")
                }
                Button("Новая папка") { folderTarget = .new(personId) }
                    .font(Theme.body)
                    .accessibilityIdentifier("formAddFolder")
            }
        }
    }

    private var mainSection: some View {
        Section(header: SectionTitle("Карточка")) {
            LabeledField(title: "Название") {
                TextField("Например, «Паспорт РФ»", text: titleBinding)
                    .font(Theme.body)
                    .accessibilityIdentifier("cardTitle")
            }
            Picker("Статус", selection: $draft.status) {
                ForEach(CardStatus.allCases, id: \.self) { status in
                    Text(status.title).tag(status)
                }
            }
            .pickerStyle(.segmented)
        }
    }

    private var fieldsSection: some View {
        Section(header: SectionTitle(template.title)) {
            ForEach(template.fields, id: \.key) { spec in
                FieldEditorRow(spec: spec, value: fieldBinding(spec.key))
            }
        }
    }

    private var filesSection: some View {
        Section {
            ForEach(draft.files) { file in
                FileRow(file: file)
                    .swipeActions(edge: .trailing) {
                        Button(role: .destructive) {
                            removeFile(file)
                        } label: {
                            Label("Убрать", systemImage: "trash")
                        }
                        Button {
                            renameText = file.displayName
                            renamingFileId = file.id
                        } label: {
                            Label("Имя", systemImage: "pencil")
                        }
                        .tint(.blue)
                    }
            }
            PhotosPicker(selection: $photoItems, maxSelectionCount: 20, matching: .images) {
                IconRow(title: "Из Фото", symbol: "photo.on.rectangle", color: .pink)
                    .foregroundStyle(Color.primary)
            }
            .accessibilityIdentifier("addFromPhotos")
            Button {
                showFileImporter = true
            } label: {
                IconRow(title: "Из Файлов", symbol: "folder.fill", color: .blue)
                    .foregroundStyle(Color.primary)
            }
            .accessibilityIdentifier("addFromFiles")
            HStack(spacing: Theme.gap) {
                IconBadge(symbol: "doc.viewfinder", color: .gray)
                Text("Сканировать").font(Theme.body).foregroundStyle(.secondary)
                Spacer(minLength: Theme.gap)
                Text("в версии 0.3").font(Theme.caption).foregroundStyle(.tertiary)
            }
            if isImporting {
                HStack(spacing: Theme.gap) {
                    ProgressView()
                    Text("Шифрование…").font(Theme.caption).foregroundStyle(.secondary)
                }
            }
            if let importError {
                Text(importError).font(Theme.caption).foregroundStyle(.red)
            }
        } header: {
            SectionTitle("Файлы")
        } footer: {
            if !draft.files.isEmpty {
                Text("Смахните файл влево, чтобы переименовать или убрать. Оригинал в Фото или «Файлах» остаётся на месте — при желании удалите его сами.")
            }
        }
    }

    private var noteSection: some View {
        Section(header: SectionTitle("Заметка")) {
            TextField("Необязательно", text: $draft.note, axis: .vertical)
                .font(Theme.body)
                .lineLimit(2...8)
        }
    }

    private var saveSection: some View {
        Section {
            Button {
                save()
            } label: {
                Text(editingId == nil ? "Сохранить карточку" : "Сохранить изменения")
                    .font(Theme.subtitle)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 6)
            }
            .buttonStyle(.borderedProminent)
            .buttonBorderShape(.capsule)
            .controlSize(.large)
            .disabled(!canSave || isImporting)
            .accessibilityIdentifier("saveCard")

            if !canSave {
                Text("Чтобы сохранить, выберите члена семьи, папку и укажите название.")
                    .font(Theme.caption)
                    .foregroundStyle(.secondary)
                    .frame(maxWidth: .infinity)
                    .multilineTextAlignment(.center)
            }
        }
        .plainRow()
    }

    // MARK: - Привязки

    private var typeBinding: Binding<String> {
        Binding(get: { draft.typeId }, set: { newValue in
            let oldTitle = CardTemplate.find(draft.typeId).title
            draft.typeId = newValue
            // Название следует за типом, пока пользователь его не менял
            if !titleEdited || draft.title == oldTitle || draft.title.isEmpty {
                let t = CardTemplate.find(newValue)
                draft.title = t.id == CardTemplate.basicId ? "" : t.title
                titleEdited = false
            }
        })
    }

    private var titleBinding: Binding<String> {
        Binding(get: { draft.title }, set: { newValue in
            draft.title = newValue
            titleEdited = true
        })
    }

    private var personBinding: Binding<UUID?> {
        Binding(get: { draft.personId }, set: { newValue in
            draft.personId = newValue
            // Папка другого человека здесь уже не подходит
            if let folderId = draft.folderId, appState.data.folder(folderId)?.personId != newValue {
                draft.folderId = nil
            }
        })
    }

    private func fieldBinding(_ key: String) -> Binding<String> {
        Binding(get: { draft.fields[key] ?? "" }, set: { newValue in
            if newValue.isEmpty {
                draft.fields.removeValue(forKey: key)
            } else {
                draft.fields[key] = newValue
            }
        })
    }

    // MARK: - Открытие правки

    private func applyEditState() {
        guard let state = editState else { return }
        editState = nil
        switch state {
        case .edit(let id):
            guard let card = appState.data.card(id) else { return }
            discardNewBlobs()
            var active: [StoredFile] = []
            for f in card.files where f.deletion == nil { active.append(f) }
            let folder = appState.data.folder(card.folderId)
            draft = CardDraft(typeId: card.typeId,
                              personId: folder?.personId,
                              folderId: card.folderId,
                              title: card.title,
                              status: card.status,
                              fields: card.fields,
                              note: card.note,
                              files: active)
            editingId = id
            titleEdited = true
            importError = nil
        case .newIn(let folderId):
            if editingId != nil {
                discardNewBlobs()
                draft = CardDraft()
                editingId = nil
                titleEdited = false
            }
            draft.folderId = folderId
            draft.personId = appState.data.folder(folderId)?.personId
        }
    }

    // MARK: - Члены семьи

    private func addPerson() {
        let name = newPersonName.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !name.isEmpty else { return }
        let person = Person(name: name, order: appState.data.nextPersonOrder())
        appState.data.persons.append(person)
        appState.data.log(.personCreated, object: name)
        appState.persist()
        draft.personId = person.id
        draft.folderId = nil
    }

    // MARK: - Файлы

    private func importPhotos(_ items: [PhotosPickerItem]) {
        guard !items.isEmpty else { return }
        photoItems = []
        isImporting = true
        importError = nil
        Task { @MainActor in
            var number = draft.files.count
            for item in items {
                number += 1
                do {
                    guard let data = try await item.loadTransferable(type: Data.self) else { continue }
                    let type: UTType = item.supportedContentTypes.first ?? .jpeg
                    let ext = type.preferredFilenameExtension ?? "jpg"
                    addFile(data: data, name: "Фото \(number).\(ext)", type: type, source: .photos)
                } catch {
                    importError = "Не удалось загрузить фото: \(error.localizedDescription)"
                }
            }
            isImporting = false
        }
    }

    private func importFiles(_ urls: [URL]) {
        importError = nil
        for url in urls {
            let access = url.startAccessingSecurityScopedResource()
            defer { if access { url.stopAccessingSecurityScopedResource() } }
            do {
                let data = try Data(contentsOf: url)
                let type: UTType = UTType(filenameExtension: url.pathExtension) ?? .data
                addFile(data: data, name: url.lastPathComponent, type: type, source: .files)
            } catch {
                importError = "Не удалось прочитать «\(url.lastPathComponent)»: \(error.localizedDescription)"
            }
        }
    }

    private func addFile(data: Data, name: String, type: UTType, source: FileSource) {
        do {
            let blob = try appState.storeFile(data)
            newBlobs.insert(blob)
            var pages: Int? = nil
            if type.conforms(to: .pdf) { pages = PDFDocument(data: data)?.pageCount }
            let file = StoredFile(displayName: name, originalName: name,
                                  typeIdentifier: type.identifier, size: data.count,
                                  pageCount: pages, blobName: blob, source: source)
            draft.files.append(file)
        } catch {
            importError = "Не удалось сохранить файл: \(error.localizedDescription)"
        }
    }

    /// Убрать файл из черновика. Только что добавленный стирается сразу;
    /// уже сохранённый уйдёт в корзину при сохранении карточки.
    private func removeFile(_ file: StoredFile) {
        if newBlobs.contains(file.blobName) {
            appState.deleteBlob(file.blobName)
            newBlobs.remove(file.blobName)
        }
        draft.files.removeAll { $0.id == file.id }
    }

    private func applyRename() {
        let name = renameText.trimmingCharacters(in: .whitespacesAndNewlines)
        defer { renamingFileId = nil }
        guard !name.isEmpty, let id = renamingFileId,
              let i = draft.files.firstIndex(where: { $0.id == id }) else { return }
        draft.files[i].displayName = name
    }

    private func discardNewBlobs() {
        for blob in newBlobs { appState.deleteBlob(blob) }
        newBlobs = []
    }

    /// Очистить форму: новые файлы стираются, выбор человека и папки остаётся
    private func discardDraft() {
        discardNewBlobs()
        let keepPerson = draft.personId
        let keepFolder = draft.folderId
        draft = CardDraft()
        draft.personId = keepPerson
        draft.folderId = keepFolder
        editingId = nil
        titleEdited = false
        importError = nil
    }

    // MARK: - Сохранение

    /// Только поля текущего шаблона и только заполненные
    private func cleanedFields() -> [String: String] {
        var out: [String: String] = [:]
        for spec in template.fields {
            let v = (draft.fields[spec.key] ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
            if !v.isEmpty { out[spec.key] = v }
        }
        return out
    }

    private func save() {
        guard canSave, let folderId = draft.folderId else { return }
        let title = draft.title.trimmingCharacters(in: .whitespacesAndNewlines)
        let now = Date()
        let savedId: UUID

        if let id = editingId, let old = appState.data.card(id) {
            var card = old
            card.typeId = draft.typeId
            card.folderId = folderId
            card.title = title
            card.status = draft.status
            card.fields = cleanedFields()
            card.note = draft.note
            // Файлы: оставшиеся в черновике + то, что уже было в корзине +
            // убранные сейчас (они уходят в корзину одним пакетом).
            let batch = UUID()
            var keptIds: Set<UUID> = []
            for f in draft.files { keptIds.insert(f.id) }
            var merged: [StoredFile] = draft.files
            for f in old.files {
                if f.deletion != nil {
                    merged.append(f)
                } else if !keptIds.contains(f.id) {
                    var trashed = f
                    trashed.deletion = Deletion(date: now, batchId: batch)
                    merged.append(trashed)
                }
            }
            card.files = merged
            card.updatedAt = now
            let changes = appState.data.cardChanges(old: old, new: card)
            appState.data.updateCard(card)
            if !changes.isEmpty {
                appState.data.log(.cardEdited, object: title, details: changes)
            }
            savedId = id
        } else {
            let card = DocumentCard(folderId: folderId, typeId: draft.typeId, title: title,
                                    status: draft.status, fields: cleanedFields(),
                                    note: draft.note, files: draft.files,
                                    createdAt: now, updatedAt: now)
            appState.data.cards.append(card)
            appState.data.log(.cardCreated, object: title, details: appState.data.cardSnapshot(card))
            savedId = card.id
        }

        appState.persist()
        guard appState.saveError == nil else { return }
        newBlobs = []
        let keepPerson = draft.personId
        let keepFolder = draft.folderId
        draft = CardDraft()
        draft.personId = keepPerson
        draft.folderId = keepFolder
        editingId = nil
        titleEdited = false
        importError = nil
        onSaved(savedId)
    }
}
