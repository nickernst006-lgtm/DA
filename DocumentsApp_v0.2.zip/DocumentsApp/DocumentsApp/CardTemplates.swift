import SwiftUI

// Типы карточек версии 1.0 (ТЗ, раздел 6). Шаблоны зашиты в код:
// новые появляются только с обновлениями приложения.
//
// ВАЖНО: ключи полей (`key`) и идентификаторы шаблонов (`id`) — часть
// формата хранения. Их нельзя менять или переиспользовать: по ним в
// карточках лежат значения. Подписи (`title`) менять можно.

/// Как вводится поле
nonisolated enum FieldKind: Equatable {
    /// Обычный текст
    case text
    /// Латиница — как в загранпаспорте, заглавными
    case latin
    /// Только цифры по маске: «0» — цифра, остальное подставляется само
    case digits(String)
    /// Дата, хранится строкой «ГГГГ-ММ-ДД»
    case date
    /// Выбор одного значения
    case choice([String])
    /// Выбор нескольких значений, хранятся через запятую
    case multiChoice([String])
}

/// Дополнительная проверка значения
nonisolated enum FieldCheck: Equatable {
    case none
    case snils
}

nonisolated struct FieldSpec: Equatable {
    let key: String
    let title: String
    let kind: FieldKind
    var check: FieldCheck = .none
}

nonisolated struct CardTemplate: Identifiable {
    let id: String
    let title: String
    let symbol: String
    let color: Color
    let fields: [FieldSpec]

    static let basicId = "basic"

    /// Порядок в списке выбора типа
    static let all: [CardTemplate] = [basic, passportRF, foreignPassport, driverLicense, snils, oms]

    /// Шаблон по идентификатору. Незнакомый (из будущей версии) — как базовая.
    static func find(_ id: String) -> CardTemplate {
        for t in all where t.id == id { return t }
        return basic
    }

    static let sexOptions = ["Мужской", "Женский"]

    static let basic = CardTemplate(
        id: "basic", title: "Базовая", symbol: "doc.text.fill", color: .gray, fields: [])

    static let passportRF = CardTemplate(
        id: "passportRF", title: "Паспорт РФ", symbol: "person.text.rectangle.fill", color: .red,
        fields: [
            FieldSpec(key: "series", title: "Серия", kind: .digits("00 00")),
            FieldSpec(key: "number", title: "Номер", kind: .digits("000000")),
            FieldSpec(key: "lastName", title: "Фамилия", kind: .text),
            FieldSpec(key: "firstName", title: "Имя", kind: .text),
            FieldSpec(key: "middleName", title: "Отчество", kind: .text),
            FieldSpec(key: "sex", title: "Пол", kind: .choice(sexOptions)),
            FieldSpec(key: "birthDate", title: "Дата рождения", kind: .date),
            FieldSpec(key: "birthPlace", title: "Место рождения", kind: .text),
            FieldSpec(key: "issuedBy", title: "Кем выдан", kind: .text),
            FieldSpec(key: "issueDate", title: "Дата выдачи", kind: .date),
            FieldSpec(key: "divisionCode", title: "Код подразделения", kind: .digits("000-000")),
            FieldSpec(key: "regAddress", title: "Адрес регистрации", kind: .text),
            FieldSpec(key: "regDate", title: "Дата регистрации", kind: .date),
        ])

    static let foreignPassport = CardTemplate(
        id: "foreignPassport", title: "Загранпаспорт", symbol: "globe", color: .blue,
        fields: [
            FieldSpec(key: "kind", title: "Вид",
                      kind: .choice(["Биометрический (10 лет)", "Старого образца (5 лет)"])),
            FieldSpec(key: "number", title: "Серия и номер", kind: .digits("00 0000000")),
            FieldSpec(key: "lastName", title: "Фамилия", kind: .text),
            FieldSpec(key: "firstName", title: "Имя", kind: .text),
            FieldSpec(key: "lastNameLatin", title: "Фамилия латиницей", kind: .latin),
            FieldSpec(key: "firstNameLatin", title: "Имя латиницей", kind: .latin),
            FieldSpec(key: "sex", title: "Пол", kind: .choice(sexOptions)),
            FieldSpec(key: "birthDate", title: "Дата рождения", kind: .date),
            FieldSpec(key: "birthPlace", title: "Место рождения", kind: .text),
            FieldSpec(key: "issueDate", title: "Дата выдачи", kind: .date),
            FieldSpec(key: "expiryDate", title: "Действителен до", kind: .date),
            FieldSpec(key: "issuedBy", title: "Орган, выдавший документ", kind: .text),
        ])

    static let driverCategories = ["A", "A1", "B", "B1", "BE", "C", "C1", "CE", "C1E",
                                   "D", "D1", "DE", "D1E", "M", "Tm", "Tb"]

    static let driverLicense = CardTemplate(
        id: "driverLicense", title: "Водительское удостоверение", symbol: "car.fill", color: .orange,
        fields: [
            FieldSpec(key: "lastName", title: "1. Фамилия", kind: .text),
            FieldSpec(key: "lastNameLatin", title: "1. Фамилия латиницей", kind: .latin),
            FieldSpec(key: "firstMiddle", title: "2. Имя, отчество", kind: .text),
            FieldSpec(key: "firstMiddleLatin", title: "2. Имя, отчество латиницей", kind: .latin),
            FieldSpec(key: "birthDate", title: "3. Дата рождения", kind: .date),
            FieldSpec(key: "birthPlace", title: "3. Место рождения", kind: .text),
            FieldSpec(key: "issueDate", title: "4a. Дата выдачи", kind: .date),
            FieldSpec(key: "expiryDate", title: "4b. Действительно до", kind: .date),
            FieldSpec(key: "issuedBy", title: "4c. Кем выдано", kind: .text),
            FieldSpec(key: "number", title: "5. Серия и номер", kind: .digits("00 00 000000")),
            FieldSpec(key: "region", title: "8. Регион", kind: .text),
            FieldSpec(key: "categories", title: "9. Категории", kind: .multiChoice(driverCategories)),
            FieldSpec(key: "notes", title: "Особые отметки", kind: .text),
        ])

    static let snils = CardTemplate(
        id: "snils", title: "СНИЛС", symbol: "number", color: .green,
        fields: [
            FieldSpec(key: "kind", title: "Вид",
                      kind: .choice(["Зелёная карточка", "Уведомление АДИ-РЕГ"])),
            FieldSpec(key: "number", title: "Номер", kind: .digits("000-000-000 00"), check: .snils),
            FieldSpec(key: "lastName", title: "Фамилия", kind: .text),
            FieldSpec(key: "firstName", title: "Имя", kind: .text),
            FieldSpec(key: "middleName", title: "Отчество", kind: .text),
            FieldSpec(key: "sex", title: "Пол", kind: .choice(sexOptions)),
            FieldSpec(key: "birthDate", title: "Дата рождения", kind: .date),
            FieldSpec(key: "birthPlace", title: "Место рождения", kind: .text),
            FieldSpec(key: "regDate", title: "Дата регистрации", kind: .date),
        ])

    static let oms = CardTemplate(
        id: "oms", title: "Полис ОМС", symbol: "cross.case.fill", color: .teal,
        fields: [
            FieldSpec(key: "kind", title: "Вид",
                      kind: .choice(["Выписка из регистра", "Пластиковая карта", "Бумажный полис"])),
            FieldSpec(key: "number", title: "Номер полиса", kind: .digits("0000 0000 0000 0000")),
            FieldSpec(key: "lastName", title: "Фамилия", kind: .text),
            FieldSpec(key: "firstName", title: "Имя", kind: .text),
            FieldSpec(key: "middleName", title: "Отчество", kind: .text),
            FieldSpec(key: "sex", title: "Пол", kind: .choice(sexOptions)),
            FieldSpec(key: "birthDate", title: "Дата рождения", kind: .date),
            FieldSpec(key: "insurer", title: "Страховая медицинская организация", kind: .text),
            FieldSpec(key: "issueDate", title: "Дата выдачи", kind: .date),
        ])
}

extension FieldSpec {
    /// Значение для показа: даты — «ДД.ММ.ГГГГ», остальное как есть
    func display(_ raw: String) -> String {
        if kind == .date { return DateFmt.display(raw) }
        return raw
    }

    /// Краткое описание вида поля — для справочника типов
    var kindTitle: String {
        switch kind {
        case .text: return "Текст"
        case .latin: return "Латиница"
        case .digits(let mask): return "Цифры · " + mask
        case .date: return "Дата"
        case .choice: return "Выбор"
        case .multiChoice: return "Несколько значений"
        }
    }

    /// Текст ошибки, если значение заполнено, но не проходит проверку
    func problem(in raw: String) -> String? {
        switch check {
        case .none:
            return nil
        case .snils:
            let digits = Mask.digits(raw)
            guard digits.count == 11 else { return nil }
            return Snils.isValid(digits) ? nil : "Контрольное число не сходится — проверьте номер"
        }
    }
}

/// Маска ввода: «0» — место для цифры, остальные знаки подставляются сами.
/// Лишние цифры отбрасываются, буквы игнорируются.
nonisolated enum Mask {
    static func digits(_ s: String) -> [Character] {
        var out: [Character] = []
        for ch in s where ch >= "0" && ch <= "9" { out.append(ch) }
        return out
    }

    static func apply(_ mask: String, to input: String) -> String {
        let ds = digits(input)
        var result = ""
        var index = 0
        for m in mask {
            if index >= ds.count { break }
            if m == "0" {
                result.append(ds[index])
                index += 1
            } else {
                result.append(m)
            }
        }
        return result
    }
}

/// Контрольное число СНИЛС. Номер из 11 цифр: 9 цифр номера и 2 контрольные.
/// Сумма цифр номера с весами 9…1; меньше 100 — это и есть контрольное число,
/// 100 и 101 — «00», больше — остаток от деления на 101 (и снова 100 → «00»).
/// Для номеров не больше 001-001-998 проверка не выполняется.
nonisolated enum Snils {
    static func isValid(_ digits: [Character]) -> Bool {
        guard digits.count == 11 else { return false }
        var values: [Int] = []
        for ch in digits {
            guard let v = ch.wholeNumberValue else { return false }
            values.append(v)
        }
        var number = 0
        for i in 0..<9 { number = number * 10 + values[i] }
        let control = values[9] * 10 + values[10]
        if number <= 1_001_998 { return true }
        var sum = 0
        for i in 0..<9 { sum += values[i] * (9 - i) }
        var expected: Int
        if sum < 100 {
            expected = sum
        } else if sum <= 101 {
            expected = 0
        } else {
            expected = sum % 101
            if expected == 100 { expected = 0 }
        }
        return expected == control
    }
}
