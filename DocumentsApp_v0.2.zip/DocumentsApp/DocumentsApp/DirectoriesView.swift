import SwiftUI

// Вкладка «Справочники» (ТЗ, раздел 5.4): теги папок, именованные цвета,
// типы карточек (только просмотр — новые приходят с обновлениями).

nonisolated enum DirectoryRoute: Hashable {
    case tags
    case colors
    case types
    case type(String)
}

struct DirectoriesView: View {
    @EnvironmentObject var appState: AppState

    var body: some View {
        List {
            Section {
                ScreenHeader(title: "Справочники")
            }
            .plainRow()

            Section {
                NavigationLink(value: DirectoryRoute.tags) {
                    HStack(spacing: Theme.gap) {
                        IconBadge(symbol: "tag.fill", color: .orange)
                        DirectoryRow(name: "Теги папок", detail: "\(appState.data.tags.count)")
                    }
                }
                .accessibilityIdentifier("dir_tags")
                NavigationLink(value: DirectoryRoute.colors) {
                    HStack(spacing: Theme.gap) {
                        IconBadge(symbol: "paintpalette.fill", color: .purple)
                        DirectoryRow(name: "Цвета папок", detail: "\(appState.data.colors.count)")
                    }
                }
                .accessibilityIdentifier("dir_colors")
                NavigationLink(value: DirectoryRoute.types) {
                    HStack(spacing: Theme.gap) {
                        IconBadge(symbol: "doc.on.doc.fill", color: .blue)
                        DirectoryRow(name: "Типы карточек", detail: "\(CardTemplate.all.count)")
                    }
                }
                .accessibilityIdentifier("dir_types")
            }
        }
        .themedScreen()
        .navigationDestination(for: DirectoryRoute.self) { route in
            switch route {
            case .tags: TagsView()
            case .colors: ColorsView()
            case .types: TypesView()
            case .type(let id): TypeDetailView(template: CardTemplate.find(id))
            }
        }
    }
}

// MARK: - Теги

struct TagsView: View {
    @EnvironmentObject var appState: AppState
    @State private var pendingDelete: FolderTag? = nil

    var body: some View {
        List {
            if appState.data.tags.isEmpty {
                Section {
                    EmptyStateRow(symbol: "tag", title: "Тегов пока нет",
                                  text: "Теги помечают папки: «Удостоверения», «Поездки», «Работа». Добавьте первый ниже.")
                }
                .plainRow()
            } else {
                Section {
                    ForEach(appState.data.tags) { tag in
                        EditableRow(name: tag.name,
                                    onRename: { rename(tag, to: $0) },
                                    onDelete: { pendingDelete = tag })
                    }
                }
            }
            Section {
                AddRow(placeholder: "Новый тег") { add($0) }
            }
        }
        .themedList()
        .navigationTitle("Теги папок")
        .navigationBarTitleDisplayMode(.inline)
        .confirmationDialog("Удалить тег?", isPresented: Binding(
            get: { pendingDelete != nil },
            set: { if !$0 { pendingDelete = nil } }
        ), titleVisibility: .visible) {
            Button("Удалить", role: .destructive) {
                if let tag = pendingDelete { delete(tag) }
                pendingDelete = nil
            }
            Button("Отмена", role: .cancel) { pendingDelete = nil }
        } message: {
            Text("Тег снимется со всех папок. Сами папки не пострадают.")
        }
    }

    private func exists(_ name: String, except id: UUID? = nil) -> Bool {
        for tag in appState.data.tags where tag.id != id {
            if tag.name.compare(name, options: .caseInsensitive) == .orderedSame { return true }
        }
        return false
    }

    private func add(_ name: String) -> Bool {
        guard !exists(name) else { return false }
        appState.data.tags.append(FolderTag(name: name))
        appState.data.log(.directoryChanged, object: "Тег «\(name)»", summary: "Добавлен")
        appState.persist()
        return true
    }

    private func rename(_ tag: FolderTag, to name: String) {
        guard !exists(name, except: tag.id),
              let i = appState.data.tags.firstIndex(where: { $0.id == tag.id }) else { return }
        appState.data.tags[i].name = name
        appState.data.log(.directoryChanged, object: "Тег «\(name)»",
                          details: [HistoryDetail(field: "Название", old: tag.name, new: name)])
        appState.persist()
    }

    private func delete(_ tag: FolderTag) {
        appState.data.tags.removeAll { $0.id == tag.id }
        for i in appState.data.folders.indices {
            appState.data.folders[i].tagIds.removeAll { $0 == tag.id }
        }
        appState.data.log(.directoryChanged, object: "Тег «\(tag.name)»", summary: "Удалён, снят со всех папок")
        appState.persist()
    }
}

// MARK: - Цвета

struct ColorsView: View {
    @EnvironmentObject var appState: AppState
    @State private var newName = ""
    @State private var newIndex = 0
    @State private var pendingDelete: NamedColor? = nil

    var body: some View {
        List {
            if appState.data.colors.isEmpty {
                Section {
                    EmptyStateRow(symbol: "paintpalette", title: "Цветов пока нет",
                                  text: "Именованный цвет помечает папку: «Важное — красный», «Медицина — мятный».")
                }
                .plainRow()
            } else {
                Section {
                    ForEach(appState.data.colors) { named in
                        HStack(spacing: Theme.gap) {
                            IconBadge(symbol: "folder.fill", color: Theme.color(at: named.paletteIndex))
                            EditableRow(name: named.name,
                                        onRename: { rename(named, to: $0) },
                                        onDelete: { pendingDelete = named })
                        }
                    }
                }
            }

            Section {
                TextField("Название нового цвета", text: $newName)
                    .font(Theme.body)
                    .accessibilityIdentifier("newColorName")
                PaletteRow(selected: $newIndex)
                Button("Добавить цвет") { add() }
                    .font(Theme.body)
                    .disabled(newName.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
            } header: {
                SectionTitle("Новый цвет")
            }
        }
        .themedList()
        .navigationTitle("Цвета папок")
        .navigationBarTitleDisplayMode(.inline)
        .confirmationDialog("Удалить цвет?", isPresented: Binding(
            get: { pendingDelete != nil },
            set: { if !$0 { pendingDelete = nil } }
        ), titleVisibility: .visible) {
            Button("Удалить", role: .destructive) {
                if let named = pendingDelete { delete(named) }
                pendingDelete = nil
            }
            Button("Отмена", role: .cancel) { pendingDelete = nil }
        } message: {
            Text("Папки этого цвета станут серыми. Сами папки не пострадают.")
        }
    }

    private func add() {
        let name = newName.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !name.isEmpty else { return }
        appState.data.colors.append(NamedColor(name: name, paletteIndex: newIndex))
        appState.data.log(.directoryChanged, object: "Цвет «\(name)»", summary: "Добавлен")
        appState.persist()
        newName = ""
    }

    private func rename(_ named: NamedColor, to name: String) {
        guard let i = appState.data.colors.firstIndex(where: { $0.id == named.id }) else { return }
        appState.data.colors[i].name = name
        appState.data.log(.directoryChanged, object: "Цвет «\(name)»",
                          details: [HistoryDetail(field: "Название", old: named.name, new: name)])
        appState.persist()
    }

    private func delete(_ named: NamedColor) {
        appState.data.colors.removeAll { $0.id == named.id }
        for i in appState.data.folders.indices where appState.data.folders[i].colorId == named.id {
            appState.data.folders[i].colorId = nil
        }
        appState.data.log(.directoryChanged, object: "Цвет «\(named.name)»", summary: "Удалён")
        appState.persist()
    }
}

/// Ряд кружков системной палитры для выбора цвета
struct PaletteRow: View {
    @Binding var selected: Int

    var body: some View {
        HStack(spacing: 6) {
            ForEach(0..<Theme.palette.count, id: \.self) { index in
                Button {
                    selected = index
                } label: {
                    Circle()
                        .fill(Theme.color(at: index).gradient)
                        .frame(width: 26, height: 26)
                        .overlay {
                            if selected == index {
                                Image(systemName: "checkmark")
                                    .font(.system(size: 12, weight: .bold))
                                    .foregroundStyle(.white)
                            }
                        }
                }
                .buttonStyle(.plain)
                .accessibilityLabel("Цвет \(index + 1)")
                .accessibilityAddTraits(selected == index ? [.isSelected] : [])
            }
        }
        .frame(maxWidth: .infinity)
    }
}

// MARK: - Типы карточек

struct TypesView: View {
    var body: some View {
        List {
            Section {
                ForEach(CardTemplate.all) { template in
                    NavigationLink(value: DirectoryRoute.type(template.id)) {
                        HStack(spacing: Theme.gap) {
                            IconBadge(symbol: template.symbol, color: template.color)
                            DirectoryRow(name: template.title,
                                         detail: template.fields.isEmpty ? "без полей" : Plural.fields(template.fields.count))
                        }
                    }
                }
            } footer: {
                Text("Новые типы карточек появляются с обновлениями приложения.")
            }
        }
        .themedList()
        .navigationTitle("Типы карточек")
        .navigationBarTitleDisplayMode(.inline)
    }
}

struct TypeDetailView: View {
    let template: CardTemplate

    var body: some View {
        List {
            Section {
                IconRow(title: template.title, symbol: template.symbol, color: template.color)
            }
            Section {
                DirectoryRow(name: "Название", detail: "Текст")
                DirectoryRow(name: "Член семьи и папка", detail: "Выбор")
                DirectoryRow(name: "Статус", detail: "Действующий / Не действующий")
                DirectoryRow(name: "Файлы", detail: "Любые форматы")
                DirectoryRow(name: "Заметка", detail: "Текст")
            } header: {
                SectionTitle("Общая часть")
            }
            if !template.fields.isEmpty {
                Section {
                    ForEach(template.fields, id: \.key) { spec in
                        DirectoryRow(name: spec.title, detail: spec.kindTitle)
                    }
                } header: {
                    SectionTitle("Поля шаблона")
                } footer: {
                    Text("Все поля необязательные: можно заполнить только номер, остальное потом.")
                }
            }
        }
        .themedList()
        .navigationTitle(template.title)
        .navigationBarTitleDisplayMode(.inline)
    }
}
