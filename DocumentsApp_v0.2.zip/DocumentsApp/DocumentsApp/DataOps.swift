import Foundation

// Операции над данными: выборки для экранов, корзина, поиск.
// Всё — обычные функции над AppData без интерфейса, чтобы их можно было
// проверить юнит-тестами. Расчёты — одним проходом, без вложенных переборов
// там, где их можно избежать (N_Apps_05, раздел 5).

/// Одно действие удаления в корзине: всё, что ушло туда одним нажатием.
nonisolated struct TrashBatch: Identifiable, Equatable {
    let id: UUID
    let date: Date
    /// Верхние элементы пакета: «Папка «1 · Паспорта»» и т. п.
    let titles: [String]
    /// Сколько всего элементов в пакете, включая вложенные
    let count: Int
}

private func byOrderThenName(_ a: Person, _ b: Person) -> Bool {
    if a.order != b.order { return a.order < b.order }
    return a.name.localizedStandardCompare(b.name) == .orderedAscending
}

private func folderSort(_ a: Folder, _ b: Folder) -> Bool {
    if a.order != b.order { return a.order < b.order }
    let byNumber = a.number.localizedStandardCompare(b.number)
    if byNumber != .orderedSame { return byNumber == .orderedAscending }
    return a.name.localizedStandardCompare(b.name) == .orderedAscending
}

private func cardSort(_ a: DocumentCard, _ b: DocumentCard) -> Bool {
    a.title.localizedStandardCompare(b.title) == .orderedAscending
}

extension AppData {

    // MARK: - Поиск по идентификатору

    func person(_ id: UUID) -> Person? {
        for p in persons where p.id == id { return p }
        return nil
    }

    func folder(_ id: UUID) -> Folder? {
        for f in folders where f.id == id { return f }
        return nil
    }

    func card(_ id: UUID) -> DocumentCard? {
        for c in cards where c.id == id { return c }
        return nil
    }

    func namedColor(_ id: UUID?) -> NamedColor? {
        guard let id else { return nil }
        for c in colors where c.id == id { return c }
        return nil
    }

    // MARK: - Выборки для экранов (только то, что не в корзине)

    var activePersons: [Person] {
        let alive: [Person] = persons.filter { $0.deletion == nil }
        return alive.sorted(by: byOrderThenName)
    }

    func activeFolders(of personId: UUID) -> [Folder] {
        var result: [Folder] = []
        for f in folders where f.personId == personId && f.deletion == nil { result.append(f) }
        return result.sorted(by: folderSort)
    }

    func activeCards(in folderId: UUID) -> [DocumentCard] {
        var result: [DocumentCard] = []
        for c in cards where c.folderId == folderId && c.deletion == nil { result.append(c) }
        return result.sorted(by: cardSort)
    }

    /// Число живых карточек в каждой папке — одним проходом по карточкам
    func activeCardCounts() -> [UUID: Int] {
        var counts: [UUID: Int] = [:]
        for c in cards where c.deletion == nil { counts[c.folderId, default: 0] += 1 }
        return counts
    }

    /// Число живых папок у каждого человека — одним проходом
    func activeFolderCounts() -> [UUID: Int] {
        var counts: [UUID: Int] = [:]
        for f in folders where f.deletion == nil { counts[f.personId, default: 0] += 1 }
        return counts
    }

    func folderTitle(_ folder: Folder) -> String {
        let number = folder.number.trimmingCharacters(in: .whitespaces)
        return number.isEmpty ? folder.name : number + " · " + folder.name
    }

    func tagNames(of folder: Folder) -> [String] {
        var names: [String] = []
        for tag in tags where folder.tagIds.contains(tag.id) { names.append(tag.name) }
        return names
    }

    /// «Я → 1 · Удостоверения»
    func location(of card: DocumentCard) -> String {
        guard let folder = folder(card.folderId) else { return "—" }
        let personName = person(folder.personId)?.name ?? "—"
        return personName + " → " + folderTitle(folder)
    }

    func nextPersonOrder() -> Int {
        var maxOrder = -1
        for p in persons where p.order > maxOrder { maxOrder = p.order }
        return maxOrder + 1
    }

    func nextFolderOrder(for personId: UUID) -> Int {
        var maxOrder = -1
        for f in folders where f.personId == personId && f.order > maxOrder { maxOrder = f.order }
        return maxOrder + 1
    }

    mutating func updateCard(_ card: DocumentCard) {
        guard let i = cards.firstIndex(where: { $0.id == card.id }) else { return }
        cards[i] = card
    }

    // MARK: - Поиск

    /// Карточки, где запрос встречается в названии, заметке, любом поле,
    /// названии или номере папки, её тегах или имени человека.
    func search(_ query: String) -> [DocumentCard] {
        let q = query.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !q.isEmpty else { return [] }
        var folderText: [UUID: String] = [:]
        for f in folders where f.deletion == nil {
            let personName = person(f.personId)?.name ?? ""
            let tagText = tagNames(of: f).joined(separator: " ")
            folderText[f.id] = [f.number, f.name, tagText, personName].joined(separator: " ")
        }
        var result: [DocumentCard] = []
        for c in cards where c.deletion == nil {
            guard let context = folderText[c.folderId] else { continue }
            var pieces: [String] = [c.title, c.note, context, CardTemplate.find(c.typeId).title]
            for value in c.fields.values { pieces.append(value) }
            for file in c.files where file.deletion == nil { pieces.append(file.displayName) }
            let haystack = pieces.joined(separator: " ")
            if haystack.localizedCaseInsensitiveContains(q) { result.append(c) }
        }
        return result.sorted(by: cardSort)
    }

    // MARK: - Корзина

    /// Человек уходит в корзину вместе со всеми своими папками и карточками.
    mutating func trashPerson(_ id: UUID, batch: UUID, date: Date) {
        let mark = Deletion(date: date, batchId: batch)
        for i in persons.indices where persons[i].id == id && persons[i].deletion == nil {
            persons[i].deletion = mark
        }
        for f in folders where f.personId == id && f.deletion == nil {
            trashFolder(f.id, batch: batch, date: date)
        }
    }

    /// Папка уходит в корзину вместе со всеми своими карточками.
    mutating func trashFolder(_ id: UUID, batch: UUID, date: Date) {
        let mark = Deletion(date: date, batchId: batch)
        for i in folders.indices where folders[i].id == id && folders[i].deletion == nil {
            folders[i].deletion = mark
        }
        for i in cards.indices where cards[i].folderId == id && cards[i].deletion == nil {
            cards[i].deletion = mark
        }
    }

    mutating func trashCard(_ id: UUID, batch: UUID, date: Date) {
        let mark = Deletion(date: date, batchId: batch)
        for i in cards.indices where cards[i].id == id && cards[i].deletion == nil {
            cards[i].deletion = mark
        }
    }

    /// Восстанавливает всё удалённое одним действием. Если родитель тоже
    /// в корзине (удалён отдельно), он восстанавливается вместе с элементом —
    /// иначе восстановленное было бы некуда показать.
    mutating func restore(batch: UUID) {
        var parentCards: Set<UUID> = []
        var parentFolders: Set<UUID> = []
        var parentPersons: Set<UUID> = []

        for i in persons.indices where persons[i].deletion?.batchId == batch {
            persons[i].deletion = nil
        }
        for i in folders.indices where folders[i].deletion?.batchId == batch {
            folders[i].deletion = nil
            parentPersons.insert(folders[i].personId)
        }
        for i in cards.indices {
            if cards[i].deletion?.batchId == batch {
                cards[i].deletion = nil
                parentFolders.insert(cards[i].folderId)
            }
            for j in cards[i].files.indices where cards[i].files[j].deletion?.batchId == batch {
                cards[i].files[j].deletion = nil
                parentCards.insert(cards[i].id)
            }
        }
        // Родители — снизу вверх: карточка → папка → человек
        for i in cards.indices where parentCards.contains(cards[i].id) && cards[i].deletion != nil {
            cards[i].deletion = nil
            parentFolders.insert(cards[i].folderId)
        }
        for i in folders.indices where parentFolders.contains(folders[i].id) && folders[i].deletion != nil {
            folders[i].deletion = nil
            parentPersons.insert(folders[i].personId)
        }
        for i in persons.indices where parentPersons.contains(persons[i].id) && persons[i].deletion != nil {
            persons[i].deletion = nil
        }
    }

    /// Содержимое корзины, сгруппированное по действиям удаления, новые сверху.
    func trashBatches() -> [TrashBatch] {
        var dates: [UUID: Date] = [:]
        var titles: [UUID: [String]] = [:]
        var counts: [UUID: Int] = [:]

        func add(_ mark: Deletion, title: String?) {
            dates[mark.batchId] = mark.date
            counts[mark.batchId, default: 0] += 1
            if let title { titles[mark.batchId, default: []].append(title) }
        }

        var personBatch: [UUID: UUID] = [:]
        for p in persons {
            guard let mark = p.deletion else { continue }
            personBatch[p.id] = mark.batchId
            add(mark, title: "Член семьи «\(p.name)»")
        }
        var folderBatch: [UUID: UUID] = [:]
        for f in folders {
            guard let mark = f.deletion else { continue }
            folderBatch[f.id] = mark.batchId
            let top = personBatch[f.personId] != mark.batchId
            add(mark, title: top ? "Папка «\(folderTitle(f))»" : nil)
        }
        for c in cards {
            if let mark = c.deletion {
                let top = folderBatch[c.folderId] != mark.batchId
                add(mark, title: top ? "Карточка «\(c.title)»" : nil)
            }
            for file in c.files {
                guard let mark = file.deletion else { continue }
                let top = c.deletion?.batchId != mark.batchId
                add(mark, title: top ? "Файл «\(file.displayName)» из «\(c.title)»" : nil)
            }
        }

        var result: [TrashBatch] = []
        for (id, date) in dates {
            result.append(TrashBatch(id: id, date: date, titles: titles[id] ?? [], count: counts[id] ?? 0))
        }
        return result.sorted { $0.date > $1.date }
    }
}

/// Склонение числительных для подписей
nonisolated enum Plural {
    /// 1 папка, 2 папки, 5 папок, 11 папок, 21 папка
    static func folders(_ n: Int) -> String {
        "\(n) " + form(n, one: "папка", few: "папки", many: "папок")
    }

    static func cards(_ n: Int) -> String {
        "\(n) " + form(n, one: "карточка", few: "карточки", many: "карточек")
    }

    static func files(_ n: Int) -> String {
        "\(n) " + form(n, one: "файл", few: "файла", many: "файлов")
    }

    static func fields(_ n: Int) -> String {
        "\(n) " + form(n, one: "поле", few: "поля", many: "полей")
    }

    static func items(_ n: Int) -> String {
        "\(n) " + form(n, one: "элемент", few: "элемента", many: "элементов")
    }

    static func form(_ n: Int, one: String, few: String, many: String) -> String {
        let mod100 = abs(n) % 100
        let mod10 = abs(n) % 10
        if mod100 >= 11 && mod100 <= 14 { return many }
        if mod10 == 1 { return one }
        if mod10 >= 2 && mod10 <= 4 { return few }
        return many
    }
}
