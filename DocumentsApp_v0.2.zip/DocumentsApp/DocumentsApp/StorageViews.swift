import SwiftUI

// Вкладка «Хранилище» (ТЗ, раздел 5.3):
//   Члены семьи → Папки человека → Карточки папки → Карточка → Файл
// Переходы — через navigationDestination со своим типом маршрута, как
// справочник в N Finance. Корневой экран рисует заголовок сам, экраны,
// на которые проваливаются, оставляют системную шапку с кнопкой «назад».

nonisolated enum StorageRoute: Hashable {
    case person(UUID)
    case folder(UUID)
    case card(UUID)
    case file(UUID, UUID)
    case trash
}

/// Что редактируется в окне папки
nonisolated enum FolderEditTarget: Identifiable, Equatable {
    case new(UUID)          // новая папка у человека
    case edit(UUID)         // существующая папка

    var id: String {
        switch self {
        case .new(let personId): return "new-" + personId.uuidString
        case .edit(let folderId): return "edit-" + folderId.uuidString
        }
    }
}

extension AppData {
    /// Цвет значка папки: именованный цвет из справочника или серый
    func folderColor(_ folder: Folder) -> Color {
        guard let named = namedColor(folder.colorId) else { return .gray }
        return Theme.color(at: named.paletteIndex)
    }
}

// MARK: - Корневой экран

struct StorageView: View {
    @EnvironmentObject var appState: AppState
    @Binding var editState: EditState?
    var goToForm: () -> Void

    @State private var query = ""
    @State private var showAddPerson = false
    @State private var newPersonName = ""

    var body: some View {
        List {
            Section {
                ScreenHeader(title: "Хранилище") {
                    HeaderButton(symbol: "person.badge.plus", label: "Добавить члена семьи") {
                        newPersonName = ""
                        showAddPerson = true
                    }
                    .accessibilityIdentifier("addPerson")
                }
            }
            .plainRow()

            if !appState.data.persons.isEmpty {
                Section {
                    SearchField(text: $query, prompt: "Поиск по карточкам")
                }
                .plainRow()
            }

            if query.trimmingCharacters(in: .whitespaces).isEmpty {
                personsSection
            } else {
                searchSection
            }
        }
        .themedScreen()
        .navigationDestination(for: StorageRoute.self) { route in
            StorageDestination(route: route, editState: $editState, goToForm: goToForm)
        }
        .alert("Новый член семьи", isPresented: $showAddPerson) {
            TextField("Имя", text: $newPersonName)
            Button("Отмена", role: .cancel) {}
            Button("Добавить") { addPerson() }
        } message: {
            Text("У каждого члена семьи свой набор папок.")
        }
    }

    @ViewBuilder
    private var personsSection: some View {
        let persons = appState.data.activePersons
        if persons.isEmpty {
            Section {
                EmptyStateRow(symbol: "archivebox",
                              title: "Хранилище пусто",
                              text: "Добавьте члена семьи кнопкой вверху, затем папки и карточки документов.")
            }
            .plainRow()
        } else {
            let counts = appState.data.activeFolderCounts()
            Section(header: SectionTitle("Члены семьи")) {
                ForEach(persons) { person in
                    NavigationLink(value: StorageRoute.person(person.id)) {
                        HStack(spacing: Theme.gap) {
                            IconBadge(symbol: "person.fill", color: .blue)
                            DirectoryRow(name: person.name, detail: Plural.folders(counts[person.id] ?? 0))
                        }
                    }
                    .accessibilityIdentifier("person_\(person.name)")
                }
            }
        }
        let trashCount = appState.data.trashBatches().count
        Section {
            NavigationLink(value: StorageRoute.trash) {
                HStack(spacing: Theme.gap) {
                    IconBadge(symbol: "trash.fill", color: .gray)
                    DirectoryRow(name: "Корзина", detail: trashCount == 0 ? "пусто" : "\(trashCount)")
                }
            }
            .accessibilityIdentifier("trashRow")
        }
    }

    @ViewBuilder
    private var searchSection: some View {
        let found = appState.data.search(query)
        if found.isEmpty {
            Section {
                EmptyStateRow(symbol: "magnifyingglass",
                              title: "Ничего не найдено",
                              text: "Поиск идёт по названиям, полям и заметкам карточек, по папкам, тегам и именам.")
            }
            .plainRow()
        } else {
            Section(header: SectionTitle("Найдено: " + Plural.cards(found.count))) {
                ForEach(found) { card in
                    NavigationLink(value: StorageRoute.card(card.id)) {
                        CardRow(card: card, showLocation: true)
                    }
                }
            }
        }
    }

    private func addPerson() {
        let name = newPersonName.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !name.isEmpty else { return }
        let person = Person(name: name, order: appState.data.nextPersonOrder())
        appState.data.persons.append(person)
        appState.data.log(.personCreated, object: name)
        appState.persist()
    }
}

/// Куда ведёт маршрут
struct StorageDestination: View {
    let route: StorageRoute
    @Binding var editState: EditState?
    var goToForm: () -> Void

    var body: some View {
        switch route {
        case .person(let id):
            PersonView(personId: id)
        case .folder(let id):
            FolderView(folderId: id, editState: $editState, goToForm: goToForm)
        case .card(let id):
            CardDetailView(cardId: id, editState: $editState, goToForm: goToForm)
        case .file(let cardId, let fileId):
            FileViewerView(cardId: cardId, fileId: fileId)
        case .trash:
            TrashView()
        }
    }
}

// MARK: - Член семьи: его папки

struct PersonView: View {
    @EnvironmentObject var appState: AppState
    @Environment(\.dismiss) private var dismiss
    let personId: UUID

    @State private var folderTarget: FolderEditTarget? = nil
    @State private var showRename = false
    @State private var renameText = ""
    @State private var confirmDelete = false

    var body: some View {
        let person = appState.data.person(personId)
        List {
            if let person, person.deletion == nil {
                foldersSection
                Section {
                    Button {
                        folderTarget = .new(personId)
                    } label: {
                        IconRow(title: "Новая папка", symbol: "folder.badge.plus", color: .accentColor)
                            .foregroundStyle(Color.primary)
                    }
                    .accessibilityIdentifier("addFolder")
                }
            } else {
                Section {
                    EmptyStateRow(symbol: "trash", title: "В корзине",
                                  text: "Этот член семьи удалён. Его можно восстановить из корзины.")
                }
                .plainRow()
            }
        }
        .themedList()
        .navigationTitle(person?.name ?? "")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                Menu {
                    Button {
                        renameText = person?.name ?? ""
                        showRename = true
                    } label: {
                        Label("Переименовать", systemImage: "pencil")
                    }
                    Button(role: .destructive) {
                        confirmDelete = true
                    } label: {
                        Label("Удалить в корзину", systemImage: "trash")
                    }
                } label: {
                    Image(systemName: "ellipsis.circle")
                }
                .accessibilityLabel("Действия")
                .disabled(person?.deletion != nil)
            }
        }
        .sheet(item: $folderTarget) { target in
            FolderEditor(target: target)
                .environmentObject(appState)
        }
        .alert("Имя", isPresented: $showRename) {
            TextField("Имя", text: $renameText)
            Button("Отмена", role: .cancel) {}
            Button("Сохранить") { rename() }
        }
        .confirmationDialog("Удалить члена семьи?", isPresented: $confirmDelete, titleVisibility: .visible) {
            Button("Удалить в корзину", role: .destructive) { trash() }
            Button("Отмена", role: .cancel) {}
        } message: {
            Text("Вместе со всеми папками и карточками. Всё можно будет восстановить из корзины.")
        }
    }

    @ViewBuilder
    private var foldersSection: some View {
        let folders = appState.data.activeFolders(of: personId)
        if folders.isEmpty {
            Section {
                EmptyStateRow(symbol: "folder", title: "Папок пока нет",
                              text: "Создайте первую папку: например, «Удостоверения» или «Медицина».")
            }
            .plainRow()
        } else {
            let counts = appState.data.activeCardCounts()
            Section(header: SectionTitle("Папки")) {
                ForEach(folders) { folder in
                    NavigationLink(value: StorageRoute.folder(folder.id)) {
                        FolderRow(folder: folder, cardCount: counts[folder.id] ?? 0)
                    }
                    .accessibilityIdentifier("folder_\(folder.name)")
                }
            }
        }
    }

    private func rename() {
        let name = renameText.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !name.isEmpty,
              let i = appState.data.persons.firstIndex(where: { $0.id == personId }) else { return }
        let old = appState.data.persons[i].name
        guard old != name else { return }
        appState.data.persons[i].name = name
        appState.data.log(.personEdited, object: name,
                          details: [HistoryDetail(field: "Имя", old: old, new: name)])
        appState.persist()
    }

    private func trash() {
        guard let person = appState.data.person(personId) else { return }
        let batch = UUID()
        appState.data.trashPerson(personId, batch: batch, date: Date())
        appState.data.log(.trashed, object: "Член семьи «\(person.name)»",
                          summary: "Вместе со всеми папками и карточками")
        appState.persist()
        dismiss()
    }
}

/// Строка папки: цветной значок, номер и название, теги, число карточек
struct FolderRow: View {
    @EnvironmentObject var appState: AppState
    let folder: Folder
    let cardCount: Int

    var body: some View {
        let tags = appState.data.tagNames(of: folder)
        HStack(spacing: Theme.gap) {
            IconBadge(symbol: "folder.fill", color: appState.data.folderColor(folder))
            DirectoryRow(name: appState.data.folderTitle(folder),
                         note: tags.isEmpty ? nil : tags.joined(separator: ", "),
                         detail: Plural.cards(cardCount))
        }
    }
}

// MARK: - Окно папки: создание и правка

struct FolderEditor: View {
    @EnvironmentObject var appState: AppState
    @Environment(\.dismiss) private var dismiss
    let target: FolderEditTarget
    /// Вызывается с id новой папки — форма карточки сразу её выбирает
    var onCreated: (UUID) -> Void = { _ in }

    @State private var number = ""
    @State private var name = ""
    @State private var colorId: UUID? = nil
    @State private var tagIds: Set<UUID> = []
    @State private var loaded = false

    private var isNew: Bool {
        if case .new = target { return true }
        return false
    }

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    TextField("Номер (необязательно)", text: $number)
                        .accessibilityIdentifier("folderNumber")
                    TextField("Название", text: $name)
                        .accessibilityIdentifier("folderName")
                }

                Section {
                    ChoiceRow(title: "Без цвета", symbol: "folder.fill", color: .gray,
                              selected: colorId == nil) { colorId = nil }
                    ForEach(appState.data.colors) { named in
                        ChoiceRow(title: named.name, symbol: "folder.fill",
                                  color: Theme.color(at: named.paletteIndex),
                                  selected: colorId == named.id) { colorId = named.id }
                    }
                } header: {
                    SectionTitle("Цвет")
                } footer: {
                    if appState.data.colors.isEmpty {
                        Text("Именованные цвета заводятся во вкладке «Справочники».")
                    }
                }

                Section {
                    ForEach(appState.data.tags) { tag in
                        ChoiceRow(title: tag.name, selected: tagIds.contains(tag.id)) {
                            if tagIds.contains(tag.id) { tagIds.remove(tag.id) } else { tagIds.insert(tag.id) }
                        }
                    }
                } header: {
                    SectionTitle("Теги")
                } footer: {
                    if appState.data.tags.isEmpty {
                        Text("Теги заводятся во вкладке «Справочники».")
                    }
                }
            }
            .navigationTitle(isNew ? "Новая папка" : "Папка")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Отмена") { dismiss() }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Готово") { save() }
                        .disabled(name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                        .accessibilityIdentifier("folderSave")
                }
            }
            .onAppear(perform: load)
        }
    }

    private func load() {
        guard !loaded else { return }
        loaded = true
        if case .edit(let id) = target, let folder = appState.data.folder(id) {
            number = folder.number
            name = folder.name
            colorId = folder.colorId
            tagIds = Set(folder.tagIds)
        }
    }

    /// Теги — в порядке справочника, а не в случайном порядке множества
    private var orderedTagIds: [UUID] {
        var out: [UUID] = []
        for tag in appState.data.tags where tagIds.contains(tag.id) { out.append(tag.id) }
        return out
    }

    private func tagText(_ ids: [UUID]) -> String {
        var names: [String] = []
        for tag in appState.data.tags where ids.contains(tag.id) { names.append(tag.name) }
        return names.joined(separator: ", ")
    }

    private func colorText(_ id: UUID?) -> String {
        appState.data.namedColor(id)?.name ?? "Без цвета"
    }

    private func save() {
        let cleanName = name.trimmingCharacters(in: .whitespacesAndNewlines)
        let cleanNumber = number.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !cleanName.isEmpty else { return }
        let tags = orderedTagIds

        switch target {
        case .new(let personId):
            let folder = Folder(personId: personId, number: cleanNumber, name: cleanName,
                                colorId: colorId, tagIds: tags,
                                order: appState.data.nextFolderOrder(for: personId))
            appState.data.folders.append(folder)
            var details: [HistoryDetail] = []
            let owner = appState.data.person(personId)?.name ?? "—"
            details.append(HistoryDetail(field: "Член семьи", new: owner))
            if !cleanNumber.isEmpty { details.append(HistoryDetail(field: "Номер", new: cleanNumber)) }
            details.append(HistoryDetail(field: "Цвет", new: colorText(colorId)))
            if !tags.isEmpty { details.append(HistoryDetail(field: "Теги", new: tagText(tags))) }
            appState.data.log(.folderCreated, object: appState.data.folderTitle(folder), details: details)
            appState.persist()
            onCreated(folder.id)

        case .edit(let id):
            guard let i = appState.data.folders.firstIndex(where: { $0.id == id }) else { break }
            let old = appState.data.folders[i]
            var changes: [HistoryDetail] = []
            if old.number != cleanNumber {
                changes.append(HistoryDetail(field: "Номер", old: old.number, new: cleanNumber))
            }
            if old.name != cleanName {
                changes.append(HistoryDetail(field: "Название", old: old.name, new: cleanName))
            }
            if old.colorId != colorId {
                changes.append(HistoryDetail(field: "Цвет", old: colorText(old.colorId), new: colorText(colorId)))
            }
            if old.tagIds != tags {
                changes.append(HistoryDetail(field: "Теги", old: tagText(old.tagIds), new: tagText(tags)))
            }
            appState.data.folders[i].number = cleanNumber
            appState.data.folders[i].name = cleanName
            appState.data.folders[i].colorId = colorId
            appState.data.folders[i].tagIds = tags
            if !changes.isEmpty {
                appState.data.log(.folderEdited, object: appState.data.folderTitle(appState.data.folders[i]),
                                  details: changes)
                appState.persist()
            }
        }
        dismiss()
    }
}

// MARK: - Папка: её карточки

nonisolated enum CardFilter: String, CaseIterable, Identifiable {
    case all, active, inactive
    var id: String { rawValue }
    var title: String {
        switch self {
        case .all: return "Все"
        case .active: return "Действующие"
        case .inactive: return "Не действующие"
        }
    }
}

struct FolderView: View {
    @EnvironmentObject var appState: AppState
    @Environment(\.dismiss) private var dismiss
    let folderId: UUID
    @Binding var editState: EditState?
    var goToForm: () -> Void

    @State private var filter: CardFilter = .all
    @State private var folderTarget: FolderEditTarget? = nil
    @State private var confirmDelete = false

    var body: some View {
        let folder = appState.data.folder(folderId)
        List {
            if let folder, folder.deletion == nil {
                Section {
                    Picker("Статус", selection: $filter) {
                        ForEach(CardFilter.allCases) { f in
                            Text(f.title).tag(f)
                        }
                    }
                    .pickerStyle(.segmented)
                }
                .plainRow()

                cardsSection

                Section {
                    Button {
                        editState = .newIn(folderId)
                        goToForm()
                    } label: {
                        IconRow(title: "Новая карточка в этой папке", symbol: "doc.badge.plus", color: .accentColor)
                            .foregroundStyle(Color.primary)
                    }
                }
            } else {
                Section {
                    EmptyStateRow(symbol: "trash", title: "В корзине",
                                  text: "Эта папка удалена. Её можно восстановить из корзины.")
                }
                .plainRow()
            }
        }
        .themedList()
        .navigationTitle(folder.map { appState.data.folderTitle($0) } ?? "")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                Menu {
                    Button {
                        folderTarget = .edit(folderId)
                    } label: {
                        Label("Изменить папку", systemImage: "pencil")
                    }
                    Button(role: .destructive) {
                        confirmDelete = true
                    } label: {
                        Label("Удалить в корзину", systemImage: "trash")
                    }
                } label: {
                    Image(systemName: "ellipsis.circle")
                }
                .accessibilityLabel("Действия")
                .disabled(folder?.deletion != nil)
            }
        }
        .sheet(item: $folderTarget) { target in
            FolderEditor(target: target)
                .environmentObject(appState)
        }
        .confirmationDialog("Удалить папку?", isPresented: $confirmDelete, titleVisibility: .visible) {
            Button("Удалить в корзину", role: .destructive) { trash() }
            Button("Отмена", role: .cancel) {}
        } message: {
            Text("Вместе со всеми карточками. Всё можно будет восстановить из корзины.")
        }
    }

    @ViewBuilder
    private var cardsSection: some View {
        let all = appState.data.activeCards(in: folderId)
        let shown = filtered(all)
        if shown.isEmpty {
            Section {
                EmptyStateRow(symbol: "doc",
                              title: all.isEmpty ? "Карточек пока нет" : "Нет карточек с таким статусом",
                              text: all.isEmpty ? "Создайте карточку кнопкой ниже или во вкладке «Форма»." : "Выберите другой фильтр вверху.")
            }
            .plainRow()
        } else {
            Section(header: SectionTitle("Карточки")) {
                ForEach(shown) { card in
                    NavigationLink(value: StorageRoute.card(card.id)) {
                        CardRow(card: card, showLocation: false)
                    }
                    .accessibilityIdentifier("card_\(card.title)")
                }
            }
        }
    }

    private func filtered(_ cards: [DocumentCard]) -> [DocumentCard] {
        switch filter {
        case .all: return cards
        case .active: return cards.filter { $0.status == .active }
        case .inactive: return cards.filter { $0.status == .inactive }
        }
    }

    private func trash() {
        guard let folder = appState.data.folder(folderId) else { return }
        let title = appState.data.folderTitle(folder)
        appState.data.trashFolder(folderId, batch: UUID(), date: Date())
        appState.data.log(.trashed, object: "Папка «\(title)»", summary: "Вместе со всеми карточками")
        appState.persist()
        dismiss()
    }
}

/// Строка карточки: значок типа, название, тип или расположение, статус и файлы
struct CardRow: View {
    @EnvironmentObject var appState: AppState
    let card: DocumentCard
    let showLocation: Bool

    var body: some View {
        let template = CardTemplate.find(card.typeId)
        HStack(spacing: Theme.gap) {
            IconBadge(symbol: template.symbol, color: template.color)
            DirectoryRow(name: card.title, note: note(template), detail: detail)
        }
        .opacity(card.status == .inactive ? 0.55 : 1)
    }

    private func note(_ template: CardTemplate) -> String? {
        if showLocation { return appState.data.location(of: card) }
        if template.id == CardTemplate.basicId || template.title == card.title { return nil }
        return template.title
    }

    private var detail: String {
        if card.status == .inactive { return "Не действует" }
        var count = 0
        for f in card.files where f.deletion == nil { count += 1 }
        return count == 0 ? "" : Plural.files(count)
    }
}

// MARK: - Карточка

/// Строка «поле — значение» для экрана карточки
nonisolated struct FieldValue: Identifiable {
    let id: String
    let title: String
    let value: String
}

struct CardDetailView: View {
    @EnvironmentObject var appState: AppState
    @Environment(\.dismiss) private var dismiss
    let cardId: UUID
    @Binding var editState: EditState?
    var goToForm: () -> Void

    @State private var showMove = false
    @State private var confirmDelete = false

    var body: some View {
        List {
            if let card = appState.data.card(cardId), card.deletion == nil {
                headerSection(card)
                statusSection(card)
                locationSection(card)
                fieldsSection(card)
                filesSection(card)
                if !card.note.isEmpty {
                    Section(header: SectionTitle("Заметка")) {
                        Text(card.note)
                            .font(Theme.body)
                            .textSelection(.enabled)
                    }
                }
                Section {
                    DestructiveRow(title: "Удалить карточку в корзину") { confirmDelete = true }
                }
            } else {
                Section {
                    EmptyStateRow(symbol: "trash", title: "В корзине",
                                  text: "Эта карточка удалена. Её можно восстановить из корзины.")
                }
                .plainRow()
            }
        }
        .themedList()
        .navigationTitle("Карточка")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                Button("Править") {
                    editState = .edit(cardId)
                    goToForm()
                }
                .disabled(appState.data.card(cardId)?.deletion != nil)
                .accessibilityIdentifier("editCard")
            }
        }
        .sheet(isPresented: $showMove) {
            MoveCardSheet(cardId: cardId)
                .environmentObject(appState)
        }
        .confirmationDialog("Удалить карточку?", isPresented: $confirmDelete, titleVisibility: .visible) {
            Button("Удалить в корзину", role: .destructive) { trash() }
            Button("Отмена", role: .cancel) {}
        } message: {
            Text("Карточку со всеми файлами можно будет восстановить из корзины.")
        }
    }

    private func headerSection(_ card: DocumentCard) -> some View {
        let template = CardTemplate.find(card.typeId)
        return Section {
            HStack(spacing: Theme.gap) {
                IconBadge(symbol: template.symbol, color: template.color, size: 44)
                VStack(alignment: .leading, spacing: 2) {
                    Text(card.title)
                        .font(Theme.title)
                        .fixedSize(horizontal: false, vertical: true)
                    Text(template.title)
                        .font(Theme.caption)
                        .foregroundStyle(.secondary)
                }
            }
            .padding(.vertical, 4)
        }
    }

    private func statusSection(_ card: DocumentCard) -> some View {
        Section(header: SectionTitle("Статус")) {
            ForEach(CardStatus.allCases, id: \.self) { status in
                ChoiceRow(title: status.title, selected: card.status == status) {
                    setStatus(status)
                }
            }
        }
    }

    private func locationSection(_ card: DocumentCard) -> some View {
        let folder = appState.data.folder(card.folderId)
        let personName: String = folder.flatMap { appState.data.person($0.personId)?.name } ?? "—"
        let folderName: String = folder.map { appState.data.folderTitle($0) } ?? "—"
        return Section(header: SectionTitle("Расположение")) {
            DirectoryRow(name: "Член семьи", detail: personName)
            DirectoryRow(name: "Папка", detail: folderName)
            Button("Переместить в другую папку") { showMove = true }
                .font(Theme.body)
                .accessibilityIdentifier("moveCard")
        }
    }

    @ViewBuilder
    private func fieldsSection(_ card: DocumentCard) -> some View {
        let rows = fieldValues(card)
        if !rows.isEmpty {
            Section(header: SectionTitle("Данные")) {
                ForEach(rows) { row in
                    HStack(alignment: .firstTextBaseline, spacing: Theme.gap) {
                        Text(row.title)
                            .font(Theme.caption)
                            .foregroundStyle(.secondary)
                        Spacer(minLength: Theme.gap)
                        Text(row.value)
                            .font(Theme.body)
                            .multilineTextAlignment(.trailing)
                            .textSelection(.enabled)
                    }
                }
            }
        }
    }

    private func filesSection(_ card: DocumentCard) -> some View {
        var active: [StoredFile] = []
        for f in card.files where f.deletion == nil { active.append(f) }
        return Section(header: SectionTitle("Файлы")) {
            if active.isEmpty {
                Text("Файлов нет — добавьте их кнопкой «Править».")
                    .font(Theme.caption)
                    .foregroundStyle(.secondary)
            } else {
                ForEach(active) { file in
                    NavigationLink(value: StorageRoute.file(card.id, file.id)) {
                        FileRow(file: file)
                    }
                }
            }
        }
    }

    private func fieldValues(_ card: DocumentCard) -> [FieldValue] {
        let template = CardTemplate.find(card.typeId)
        var rows: [FieldValue] = []
        for spec in template.fields {
            let raw = card.fields[spec.key] ?? ""
            if raw.isEmpty { continue }
            rows.append(FieldValue(id: spec.key, title: spec.title, value: spec.display(raw)))
        }
        return rows
    }

    private func setStatus(_ status: CardStatus) {
        guard let i = appState.data.cards.firstIndex(where: { $0.id == cardId }) else { return }
        let old = appState.data.cards[i].status
        guard old != status else { return }
        appState.data.cards[i].status = status
        appState.data.cards[i].updatedAt = Date()
        appState.data.log(.statusChanged, object: appState.data.cards[i].title,
                          details: [HistoryDetail(field: "Статус", old: old.title, new: status.title)])
        appState.persist()
    }

    private func trash() {
        guard let card = appState.data.card(cardId) else { return }
        appState.data.trashCard(cardId, batch: UUID(), date: Date())
        appState.data.log(.trashed, object: "Карточка «\(card.title)»",
                          details: appState.data.cardSnapshot(card))
        appState.persist()
        dismiss()
    }
}

/// Перенос карточки в другую папку — в том числе к другому члену семьи
struct MoveCardSheet: View {
    @EnvironmentObject var appState: AppState
    @Environment(\.dismiss) private var dismiss
    let cardId: UUID

    var body: some View {
        NavigationStack {
            List {
                let current = appState.data.card(cardId)?.folderId
                ForEach(appState.data.activePersons) { person in
                    let folders = appState.data.activeFolders(of: person.id)
                    if !folders.isEmpty {
                        Section(header: SectionTitle(person.name)) {
                            ForEach(folders) { folder in
                                ChoiceRow(title: appState.data.folderTitle(folder), symbol: "folder.fill",
                                          color: appState.data.folderColor(folder),
                                          selected: current == folder.id) {
                                    move(to: folder.id)
                                }
                            }
                        }
                    }
                }
            }
            .navigationTitle("Переместить")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Отмена") { dismiss() }
                }
            }
        }
    }

    private func move(to folderId: UUID) {
        guard let i = appState.data.cards.firstIndex(where: { $0.id == cardId }) else { return }
        let old = appState.data.cards[i]
        guard old.folderId != folderId else { dismiss(); return }
        var moved = old
        moved.folderId = folderId
        moved.updatedAt = Date()
        let from = appState.data.location(of: old)
        let to = appState.data.location(of: moved)
        appState.data.cards[i] = moved
        appState.data.log(.cardMoved, object: moved.title,
                          details: [HistoryDetail(field: "Расположение", old: from, new: to)])
        appState.persist()
        dismiss()
    }
}

// MARK: - Корзина

struct TrashView: View {
    @EnvironmentObject var appState: AppState

    var body: some View {
        let batches = appState.data.trashBatches()
        List {
            if batches.isEmpty {
                Section {
                    EmptyStateRow(symbol: "trash", title: "Корзина пуста",
                                  text: "Удалённое попадает сюда целиком, со всем содержимым, и восстанавливается так же.")
                }
                .plainRow()
            } else {
                ForEach(batches) { batch in
                    Section {
                        ForEach(Array(batch.titles.enumerated()), id: \.offset) { item in
                            Text(item.element).font(Theme.body)
                        }
                        Button {
                            restore(batch)
                        } label: {
                            IconRow(title: "Восстановить", symbol: "arrow.uturn.backward", color: .orange)
                                .foregroundStyle(Color.primary)
                        }
                    } header: {
                        SectionTitle("Удалено " + DateFmt.stamp(batch.date))
                    } footer: {
                        if batch.count > batch.titles.count {
                            Text("Всего в этом удалении: " + Plural.items(batch.count) + ".")
                        }
                    }
                }
                Section {
                    Text("Окончательное удаление с указанием причины появится в следующей версии. Пока файлы из корзины остаются зашифрованными на телефоне.")
                        .font(Theme.caption)
                        .foregroundStyle(.secondary)
                }
                .plainRow()
            }
        }
        .themedList()
        .navigationTitle("Корзина")
        .navigationBarTitleDisplayMode(.inline)
    }

    private func restore(_ batch: TrashBatch) {
        appState.data.restore(batch: batch.id)
        appState.data.log(.restored, object: batch.titles.joined(separator: ", "),
                          summary: Plural.items(batch.count))
        appState.persist()
    }
}
