import SwiftUI

/// Вкладка «О приложении»: логотип, версия, блокировка вручную, смена пароля,
/// перечень мер защиты человеческим языком и полный сброс с подтверждением
/// вводом слова. Перенесена из N Finance почти дословно.
///
/// Перечень мер защиты держит разработку в рамках: если пункт перестал быть
/// правдой, это сразу видно. Пункты про сканер и архив с паролем станут
/// правдой в версиях 0.3 и 0.4 — до выпуска 1.0.
struct AboutView: View {
    @EnvironmentObject var appState: AppState
    @State private var showResetSheet = false
    @State private var resetConfirmText = ""
    @State private var showChangePassword = false

    var appVersion: String {
        let v = Bundle.main.infoDictionary?["CFBundleShortVersionString"] as? String ?? "0.2"
        return v
    }

    var body: some View {
        List {
            Section {
                ScreenHeader(title: "О приложении")
            }
            .plainRow()

            Section {
                VStack(spacing: 10) {
                    AppBadge(size: 88)
                        .shadow(color: .black.opacity(0.15), radius: 12, y: 6)
                    Text("N Documents").font(Theme.title)
                    Text("Версия \(appVersion)").font(Theme.caption).foregroundStyle(.secondary)
                }
                .frame(maxWidth: .infinity)
                .padding(.vertical, Theme.gap)
            }
            .listRowBackground(Color.clear)

            Section {
                Button {
                    appState.lock()
                } label: {
                    IconRow(title: "Заблокировать сейчас", symbol: "lock.fill", color: .blue)
                        .foregroundStyle(Color.primary)
                }
                Button {
                    showChangePassword = true
                } label: {
                    HStack {
                        IconRow(title: "Сменить пароль", symbol: "key.fill", color: .gray)
                            .foregroundStyle(Color.primary)
                        Spacer()
                        Image(systemName: "chevron.right").font(Theme.caption.weight(.semibold)).foregroundStyle(.tertiary)
                    }
                }
            }

            Section(header: SectionTitle("Как защищены документы")) {
                FeatureRow(symbol: "wifi.slash", color: .green, title: "Без интернета",
                           text: "В приложении нет ни одного сетевого запроса. Серверов и облака нет.")
                FeatureRow(symbol: "iphone", color: .blue, title: "Только на этом iPhone",
                           text: "Документы лежат во внутренней папке приложения и не попадают в резервные копии iCloud.")
                FeatureRow(symbol: "lock.shield.fill", color: .indigo, title: "Шифрование AES-256",
                           text: "Ключ выводится из пароля (PBKDF2, 250 000 итераций). Пароль нигде не хранится.")
                FeatureRow(symbol: "doc.on.doc.fill", color: .purple, title: "Каждый файл — отдельно",
                           text: "Каждый скан зашифрован отдельно и расшифровывается только в памяти, пока вы его смотрите.")
                FeatureRow(symbol: "camera.fill", color: .pink, title: "Сканы не попадают в Фото",
                           text: "Снимки со сканера сохраняются только внутри приложения.")
                FeatureRow(symbol: "timer", color: .orange, title: "Автоблокировка",
                           text: "Через 5 минут бездействия ключ удаляется из памяти. В переключателе приложений содержимое скрыто.")
                FeatureRow(symbol: "square.and.arrow.up", color: .teal, title: "Экспорт только вручную",
                           text: "Документы покидают приложение только по вашему нажатию: в архиве с паролем или в папку «На iPhone».")
            }

            Section {
                Button(role: .destructive) {
                    resetConfirmText = ""
                    showResetSheet = true
                } label: {
                    IconRow(title: "Сбросить приложение", symbol: "trash.fill", color: .red)
                }
            } footer: {
                Text("Удаляет все документы, файлы, историю и пароль. Действие нельзя отменить.")
            }
        }
        .themedScreen()
        .sheet(isPresented: $showChangePassword) {
            ChangePasswordView()
                .environmentObject(appState)
        }
        .sheet(isPresented: $showResetSheet) {
            NavigationStack {
                Form {
                    Section {
                        Text("Будут уничтожены все документы, файлы, история и пароль. Восстановить их будет невозможно.")
                    }
                    Section {
                        TextField("Введите УДАЛИТЬ", text: $resetConfirmText)
                            .textInputAutocapitalization(.characters)
                            .autocorrectionDisabled()
                    } footer: {
                        Text("Для подтверждения введите слово УДАЛИТЬ заглавными буквами.")
                    }
                    Section {
                        Button("Удалить всё", role: .destructive) {
                            appState.fullReset()
                            showResetSheet = false
                        }
                        .frame(maxWidth: .infinity)
                        .disabled(resetConfirmText.trimmingCharacters(in: .whitespaces) != "УДАЛИТЬ")
                    }
                }
                .navigationTitle("Сброс")
                .navigationBarTitleDisplayMode(.inline)
                .toolbar {
                    ToolbarItem(placement: .cancellationAction) {
                        Button("Отмена") { showResetSheet = false }
                    }
                }
            }
            .presentationDetents([.medium, .large])
        }
    }
}

struct ChangePasswordView: View {
    @EnvironmentObject var appState: AppState
    @Environment(\.dismiss) private var dismiss
    @State private var oldPw = ""
    @State private var newPw1 = ""
    @State private var newPw2 = ""
    @State private var errorText = ""
    @State private var done = false

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    SecureField("Текущий пароль", text: $oldPw)
                }
                Section {
                    SecureField("Новый пароль (мин. 4 символа)", text: $newPw1)
                    SecureField("Повторите новый пароль", text: $newPw2)
                } footer: {
                    Text("Все документы будут перешифрованы новым ключом. Забытый пароль восстановить невозможно.")
                }
                if !errorText.isEmpty {
                    Section { Text(errorText).foregroundStyle(.red).font(Theme.caption) }
                }
                if done {
                    Section { Label("Пароль изменён", systemImage: "checkmark.circle.fill").foregroundStyle(.green) }
                }
                Section {
                    Button {
                        submit()
                    } label: {
                        HStack {
                            if appState.isBusy { ProgressView() }
                            Text(appState.isBusy ? "Перешифровка…" : "Сменить пароль")
                        }
                        .frame(maxWidth: .infinity)
                    }
                    .disabled(appState.isBusy || done || oldPw.isEmpty || newPw1.isEmpty)
                }
            }
            .navigationTitle("Смена пароля")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button(done ? "Готово" : "Отмена") { dismiss() }
                }
            }
            .interactiveDismissDisabled(appState.isBusy)
        }
    }

    func submit() {
        errorText = ""
        guard newPw1 == newPw2 else { errorText = "Новые пароли не совпадают."; return }
        guard newPw1 != oldPw else { errorText = "Новый пароль совпадает с текущим."; return }
        let old = oldPw, new = newPw1
        Task { @MainActor in
            if let err = await appState.changePassword(old: old, new: new) {
                errorText = err
            } else {
                oldPw = ""; newPw1 = ""; newPw2 = ""
                done = true
            }
        }
    }
}
