import SwiftUI
import SwiftData

/// Вкладка «Вкусы» — «Досье»: архетип зрителя и блоки, каждый из которых отвечает на один вопрос
/// и заканчивается выводом словами.
struct TasteView: View {
    @Environment(Library.self) private var library
    @Query private var surveys: [SurveyEntry]
    @Query private var items: [CollectionItem]

    private var seenFilms: [FilmItem] {
        items.filter { $0.status == .seen }.compactMap { library.film(id: $0.filmID) }
    }

    var body: some View {
        let seen = seenFilms
        let profile = TasteProfile(surveys: surveys, seenFilms: seen)
        let stats = TasteStats(surveys: surveys, seen: seen)
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: ScreenLayout.blockGap) {
                    ScreenTitle("Вкусы")
                        .padding(.top, Space.s12)
                    ArchetypeCard(profile: profile)
                    if stats.surveyCount > 0 {
                        TasteDossier(stats: stats)
                    }
                }
                .padding(.horizontal, ScreenLayout.sideMargin)
                .padding(.bottom, ScreenLayout.blockGap)
            }
            .dockClearance()
            .background(Theme.background.ignoresSafeArea())
            .navigationTitle("Вкусы")
            .toolbar(.hidden, for: .navigationBar)
            .navigationDestination(for: FilmRoute.self) { route in
                FilmDetailView(filmID: route.id)
            }
        }
    }
}

// MARK: - Архетип

private struct ArchetypeCard: View {
    let profile: TasteProfile

    var body: some View {
        if let archetype = profile.archetype {
            filled(archetype)
        } else {
            VStack(alignment: .leading, spacing: Space.s8) {
                Text("Появится после первой анкеты")
                    .textStyle(.h2)
                    .foregroundStyle(Theme.text)
                    .fixedSize(horizontal: false, vertical: true)
                Text("Отметьте фильм как просмотренный и заполните короткую анкету. С каждой новой анкетой портрет вашего вкуса будет точнее.")
                    .textStyle(.sub)
                    .foregroundStyle(Theme.textSecondary)
                    .fixedSize(horizontal: false, vertical: true)
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .plate()
        }
    }

    private func filled(_ a: Archetype) -> some View {
        let share = profile.archetypeShares.first { $0.archetype == a }?.percent
        let others = Array(profile.archetypeShares.filter { $0.archetype != a }.prefix(2))
        return VStack(alignment: .leading, spacing: 0) {
            ArchetypePattern(archetype: a)
                .frame(height: 188)
                .frame(maxWidth: .infinity)
                .clipped()
                .overlay(alignment: .bottomLeading) {
                    ZStack {
                        Circle().fill(PatternPalette(a.color).bg)
                        Image(a.iconAsset)
                            .renderingMode(.template)
                            .resizable()
                            .scaledToFit()
                            .frame(width: 34, height: 34)
                            .foregroundStyle(a.color)
                    }
                    .frame(width: 64, height: 64)
                    .overlay(Circle().stroke(Theme.surface, lineWidth: 4))
                    .offset(x: ScreenLayout.cardPadding, y: 32)
                }
                .zIndex(1)

            VStack(alignment: .leading, spacing: 0) {
                HStack(alignment: .firstTextBaseline) {
                    Text("Ваш архетип")
                        .textStyle(.caption, .medium, tracking: 0.8)
                        .textCase(.uppercase)
                        .foregroundStyle(Theme.muted)
                    Spacer()
                    if let share {
                        Text("\(share)%")
                            .textStyle(.h1)
                            .foregroundStyle(a.color)
                    }
                }
                Text(a.title)
                    .textStyle(.h1)
                    .foregroundStyle(Theme.text)
                    .fixedSize(horizontal: false, vertical: true)
                Text("«\(a.motto)»")
                    .textStyle(.body, .bold)
                    .foregroundStyle(a.color)
                    .fixedSize(horizontal: false, vertical: true)
                    .padding(.top, Space.s4)
                Text(a.description)
                    .textStyle(.body)
                    .foregroundStyle(Theme.textSecondary)
                    .fixedSize(horizontal: false, vertical: true)
                    .padding(.top, Space.s12)
                if !others.isEmpty {
                    HStack(spacing: Space.s8) {
                        Text("Ещё в вас")
                            .textStyle(.caption)
                            .foregroundStyle(Theme.muted)
                        ForEach(others) { other in
                            HStack(spacing: 6) {
                                Circle().fill(other.archetype.color).frame(width: 10, height: 10)
                                Text(other.archetype.title)
                                    .textStyle(.caption, .medium)
                                    .foregroundStyle(Theme.textSecondary)
                                Text("\(other.percent)%")
                                    .textStyle(.caption, .bold)
                                    .foregroundStyle(Theme.text)
                            }
                            .lineLimit(1)
                            .padding(.horizontal, Space.s12)
                            .frame(height: 32)
                            .background(Capsule().fill(Theme.dockButton))
                        }
                    }
                    .padding(.top, Space.s16)
                }
            }
            .padding(.horizontal, ScreenLayout.cardPadding)
            .padding(.top, 44)
            .padding(.bottom, ScreenLayout.cardPadding)
        }
        .background(Theme.surface)
        .clipShape(RoundedRectangle(cornerRadius: Radius.large, style: .continuous))
        .accessibilityElement(children: .combine)
    }
}

// MARK: - Досье

private struct TasteDossier: View {
    let stats: TasteStats

    var body: some View {
        VStack(alignment: .leading, spacing: ScreenLayout.blockGap) {
            ScreenBlock(title: "В цифрах") { numbers }

            if stats.mood.count >= 3 {
                ScreenBlock(title: "Ваша зона") {
                    VStack(alignment: .leading, spacing: Space.s12) {
                        MoodMap(points: stats.mood, zone: stats.zone).plate()
                        if let text = stats.moodInsight { Insight(parts: text) }
                    }
                }
            }
            if !stats.emotions.isEmpty {
                ScreenBlock(title: "Что вам даёт кино") {
                    VStack(alignment: .leading, spacing: Space.s12) {
                        EmotionBars(items: stats.emotions, overall: stats.average ?? 0).plate()
                        if let text = stats.emotionInsight { Insight(parts: text) }
                    }
                }
            }
            if !stats.sides.isEmpty {
                ScreenBlock(title: "Что решает оценку") {
                    VStack(alignment: .leading, spacing: Space.s12) {
                        SidesChart(sides: stats.sides).plate()
                        if let text = stats.sidesInsight { Insight(parts: text) }
                    }
                }
            }
            if stats.genres.count >= 3, let average = stats.average {
                ScreenBlock(title: "Жанры") {
                    VStack(alignment: .leading, spacing: Space.s12) {
                        GenreMap(genres: stats.genres, overall: average).plate()
                        if let text = stats.genreInsight { Insight(parts: text) }
                    }
                }
            }
            if stats.histogram.reduce(0, +) >= 3 {
                ScreenBlock(title: "Как вы оцениваете") {
                    VStack(alignment: .leading, spacing: Space.s12) {
                        RatingHistogram(counts: stats.histogram, mine: stats.average, kp: stats.kpAverage).plate()
                        if let text = stats.ratingInsight { Insight(parts: text) }
                    }
                }
            }
            if !stats.disagreements.isEmpty {
                ScreenBlock(title: "Вы и большинство") {
                    RowGroup {
                        ForEach(Array(stats.disagreements.enumerated()), id: \.element.id) { index, item in
                            if index > 0 { RowDivider() }
                            DisagreementRow(item: item)
                        }
                    }
                }
            }
            if !stats.decades.isEmpty {
                ScreenBlock(title: "Эпохи и страны") {
                    ErasPlate(decades: stats.decades, countries: stats.countries).plate()
                }
            }
            if !stats.directors.isEmpty {
                ScreenBlock(title: "Ваши режиссёры") {
                    RowGroup {
                        ForEach(Array(stats.directors.enumerated()), id: \.element.id) { index, d in
                            if index > 0 { RowDivider(inset: ScreenLayout.textInset + 40 + Space.s12) }
                            DirectorRow(stat: d)
                        }
                    }
                }
            }
            if !stats.company.isEmpty {
                ScreenBlock(title: "С кем смотрите") {
                    CompanyBars(shares: stats.company).plate()
                }
            }
        }
    }

    private var numbers: some View {
        HStack(alignment: .top, spacing: Space.s12) {
            NumberTile(value: "\(stats.seenCount)",
                       label: TasteProfile.plural(stats.seenCount, "фильм", "фильма", "фильмов") + " посмотрено")
            NumberTile(value: stats.average.map { TasteStats.number($0) } ?? "—", label: "средняя оценка")
            if let delta = stats.kpDelta {
                NumberTile(value: TasteStats.signed(delta), label: delta < 0 ? "строже Кинопоиска" : "щедрее Кинопоиска")
            } else {
                NumberTile(value: "\(stats.surveyCount)", label: TasteProfile.plural(stats.surveyCount, "анкета", "анкеты", "анкет"))
            }
        }
    }
}

// MARK: - Элементы

private struct NumberTile: View {
    let value: String
    let label: String

    var body: some View {
        VStack(alignment: .leading, spacing: Space.s4) {
            Text(value)
                .textStyle(.h1)
                .foregroundStyle(Theme.text)
                .lineLimit(1)
                .minimumScaleFactor(0.6)
            Text(label)
                .textStyle(.caption)
                .foregroundStyle(Theme.muted)
                .fixedSize(horizontal: false, vertical: true)
        }
        .padding(ScreenLayout.cardPadding)
        .frame(maxWidth: .infinity, minHeight: 96, alignment: .topLeading)
        .background(RoundedRectangle(cornerRadius: 24, style: .continuous).fill(Theme.surface))
    }
}

/// Вывод под графиком: обычный текст с выделенными словами.
private struct Insight: View {
    let parts: [(String, Bool)]

    private var combined: Text {
        var text = Text("")
        for part in parts {
            let weight: Font.Weight = part.1 ? .bold : .regular
            let color: Color = part.1 ? Theme.text : Theme.textSecondary
            text = text + Text(part.0).foregroundColor(color).fontWeight(weight)
        }
        return text
    }

    var body: some View {
        combined
        .textStyle(.sub)
        .fixedSize(horizontal: false, vertical: true)
        .padding(.horizontal, ScreenLayout.textInset)
    }
}

/// Полоска заданной доли ширины.
private struct BarFill: View {
    let value: Double
    let color: Color
    var height: CGFloat = 10
    var alignment: Alignment = .leading

    private func barWidth(_ total: CGFloat) -> CGFloat {
        let clamped: Double = Swift.min(1.0, Swift.max(0.0, value))
        let width: CGFloat = total * CGFloat(clamped)
        return Swift.max(height, width)
    }

    var body: some View {
        GeometryReader { geo in
            Capsule()
                .fill(color)
                .frame(width: barWidth(geo.size.width), height: height)
                .frame(maxWidth: .infinity, alignment: alignment)
        }
        .frame(height: height)
    }
}

private struct Caption: View {
    let text: String
    var body: some View {
        Text(text)
            .textStyle(.caption, .medium, tracking: 0.6)
            .textCase(.uppercase)
            .foregroundStyle(Theme.muted)
    }
}

// MARK: Карта настроения

private struct MoodMap: View {
    let points: [TasteStats.MoodPoint]
    let zone: TasteStats.Zone?

    private struct Placed: Identifiable {
        let id: String
        let x: Double
        let y: Double
        let rating: Int
    }

    /// Одинаковые ответы — в одной точке; раскладываем их маленькой спиралью, чтобы было видно все.
    private var placed: [Placed] {
        var seen: [String: Int] = [:]
        var result: [Placed] = []
        for p in points.sorted(by: { $0.rating < $1.rating }) {
            let key = "\(p.tone)|\(p.weight)"
            let k = seen[key, default: 0]
            seen[key] = k + 1
            let angle = Double(k) * 2.4
            let radius = k == 0 ? 0 : 0.045 * sqrt(Double(k))
            result.append(Placed(id: p.id, x: p.tone + radius * cos(angle), y: p.weight + radius * sin(angle), rating: p.rating))
        }
        return result
    }

    var body: some View {
        VStack(spacing: Space.s8) {
            GeometryReader { geo in
                content(side: geo.size.width)
            }
            .aspectRatio(1, contentMode: .fit)
            HStack(spacing: Space.s16) {
                legend(Theme.accent, "9–10")
                legend(Color(hex: 0x9A9A9A), "7–8")
                legend(Color(hex: 0x4A4A4A), "1–6")
            }
        }
    }

    private func legend(_ color: Color, _ text: String) -> some View {
        HStack(spacing: 6) {
            Circle().fill(color).frame(width: 10, height: 10)
            Text(text).textStyle(.caption).foregroundStyle(Theme.muted)
        }
    }

    private func content(side: CGFloat) -> some View {
        let pad: CGFloat = 28
        let inner: CGFloat = side - pad * 2
        func px(_ v: Double) -> CGFloat {
            let t: Double = (v + 1) / 2
            return pad + CGFloat(t) * inner
        }
        func py(_ v: Double) -> CGFloat {
            let t: Double = (1 - v) / 2
            return pad + CGFloat(t) * inner
        }
        return ZStack {
            Path { p in
                p.move(to: CGPoint(x: pad, y: side / 2)); p.addLine(to: CGPoint(x: side - pad, y: side / 2))
                p.move(to: CGPoint(x: side / 2, y: pad)); p.addLine(to: CGPoint(x: side / 2, y: side - pad))
            }
            .stroke(Theme.lineStrong, lineWidth: 1)

            if let zone {
                Ellipse()
                    .fill(Theme.accent.opacity(0.12))
                    .overlay(Ellipse().stroke(Theme.accent.opacity(0.5), style: StrokeStyle(lineWidth: 1, dash: [4, 4])))
                    .frame(width: inner * 0.4, height: inner * 0.34)
                    .position(x: px(zone.tone), y: py(zone.weight))
                Text("ваша зона")
                    .textStyle(.caption, .bold)
                    .foregroundStyle(Theme.accent)
                    .fixedSize()
                    .position(x: px(zone.tone), y: labelY(py(zone.weight), inner))
            }

            ForEach(placed) { p in
                Circle()
                    .fill(dotColor(p.rating))
                    .frame(width: p.rating >= 9 ? 14 : 11, height: p.rating >= 9 ? 14 : 11)
                    .position(x: px(p.x), y: py(p.y))
            }

            axisLabel("Тяжёлый").position(x: side / 2, y: 10)
            axisLabel("Лёгкий").position(x: side / 2, y: side - 10)
            axisLabel("Светлый").fixedSize().frame(width: 80, alignment: .leading).position(x: 40, y: side / 2 - 12)
            axisLabel("Мрачный").fixedSize().frame(width: 80, alignment: .trailing).position(x: side - 40, y: side / 2 - 12)
        }
        .frame(width: side, height: side)
    }

    private func labelY(_ y: CGFloat, _ inner: CGFloat) -> CGFloat {
        let raised: CGFloat = y - inner * 0.17 - 10
        return Swift.max(10, raised)
    }

    private func axisLabel(_ text: String) -> some View {
        Text(text).textStyle(.caption).foregroundStyle(Theme.muted).fixedSize()
    }

    private func dotColor(_ rating: Int) -> Color {
        if rating >= 9 { return Theme.accent }
        if rating >= 7 { return Color(hex: 0x9A9A9A) }
        return Color(hex: 0x4A4A4A)
    }
}

// MARK: Что даёт кино

private struct EmotionBars: View {
    let items: [TasteStats.Stat]
    let overall: Double

    var body: some View {
        let maxCount = Double(items.map(\.count).max() ?? 1)
        VStack(alignment: .leading, spacing: Space.s16) {
            HStack {
                Caption(text: "Сколько фильмов")
                Spacer()
                Caption(text: "Ваша средняя")
            }
            ForEach(items) { item in
                let high = (item.average ?? 0) >= overall + 0.3
                VStack(alignment: .leading, spacing: 6) {
                    HStack {
                        Text(item.title)
                            .textStyle(.sub)
                            .foregroundStyle(Theme.text)
                        Spacer()
                        Text(item.average.map { TasteStats.number($0) } ?? "—")
                            .textStyle(.sub, .bold)
                            .foregroundStyle(high ? Theme.accent : Theme.muted)
                    }
                    HStack(spacing: Space.s8) {
                        BarFill(value: Double(item.count) / maxCount, color: high ? Theme.accent : Color(hex: 0x5A5A5A))
                        Text("\(item.count)")
                            .textStyle(.caption)
                            .foregroundStyle(Theme.muted)
                            .frame(width: 24, alignment: .leading)
                    }
                }
            }
        }
    }
}

// MARK: Сильное и слабое

private struct SidesChart: View {
    let sides: [TasteStats.Side]

    /// Самая длинная полоска — 100%.
    private var maxValue: Double {
        var peak = 1
        for side in sides { peak = Swift.max(peak, side.strong, side.weak) }
        return Double(peak)
    }

    var body: some View {
        VStack(spacing: Space.s8) {
            HStack {
                Caption(text: "Слабое").frame(maxWidth: .infinity, alignment: .trailing)
                Color.clear.frame(width: 104, height: 1)
                Caption(text: "Сильное").frame(maxWidth: .infinity, alignment: .leading)
            }
            ForEach(sides) { side in
                HStack(spacing: Space.s8) {
                    half(count: side.weak, max: maxValue, color: Color(hex: 0xE5735F), alignment: .trailing)
                    Text(side.title)
                        .textStyle(.caption)
                        .foregroundStyle(Theme.textSecondary)
                        .multilineTextAlignment(.center)
                        .lineLimit(2)
                        .frame(width: 104)
                    half(count: side.strong, max: maxValue, color: Theme.accent, alignment: .leading)
                }
                .frame(minHeight: 24)
            }
        }
    }

    @ViewBuilder
    private func half(count: Int, max maxValue: Double, color: Color, alignment: Alignment) -> some View {
        HStack(spacing: 6) {
            if count > 0 {
                if alignment == .trailing {
                    Text("\(count)").textStyle(.caption).foregroundStyle(Theme.muted)
                    BarFill(value: Double(count) / maxValue, color: color, height: 12, alignment: .trailing)
                } else {
                    BarFill(value: Double(count) / maxValue, color: color, height: 12, alignment: .leading)
                    Text("\(count)").textStyle(.caption).foregroundStyle(Theme.muted)
                }
            } else {
                Spacer(minLength: 0)
            }
        }
        .frame(maxWidth: .infinity)
    }
}

// MARK: Жанры

private struct GenreMap: View {
    let genres: [TasteStats.Stat]
    let overall: Double

    var body: some View {
        GeometryReader { geo in
            content(width: geo.size.width, height: 280)
        }
        .frame(height: 280)
    }

    private func content(width: CGFloat, height: CGFloat) -> some View {
        let left: CGFloat = 20, right: CGFloat = 8, top: CGFloat = 8, bottom: CGFloat = 24
        let maxCount = Double(genres.map(\.count).max() ?? 2)
        let averages = genres.compactMap(\.average)
        let minAverage: Double = averages.min() ?? 5
        let maxAverage: Double = averages.max() ?? 9
        let lo: Double = Swift.min(minAverage, overall) - 0.5
        let hi: Double = Swift.max(maxAverage, overall) + 0.5
        let counts: [Int] = genres.map(\.count).sorted()
        let median = Double(counts[counts.count / 2])
        let plotWidth: CGFloat = width - left - right
        let plotHeight: CGFloat = height - top - bottom
        func px(_ n: Double) -> CGFloat {
            let t: Double = maxCount > 1 ? log(Swift.max(1.0, n)) / log(maxCount) : 0.5
            let share: Double = 0.08 + 0.84 * t
            return left + CGFloat(share) * plotWidth
        }
        func py(_ r: Double) -> CGFloat {
            let share: Double = (hi - r) / (hi - lo)
            return top + CGFloat(share) * plotHeight
        }
        let midX = px(median), midY = py(overall)
        return ZStack(alignment: .topLeading) {
            Rectangle().fill(Theme.accent.opacity(0.06))
                .frame(width: Swift.max(0, midX - left), height: Swift.max(0, midY - top))
                .offset(x: left, y: top)
            Rectangle().fill(Theme.accent.opacity(0.13))
                .frame(width: Swift.max(0, width - right - midX), height: Swift.max(0, midY - top))
                .offset(x: midX, y: top)
            Path { p in
                p.move(to: CGPoint(x: left, y: midY)); p.addLine(to: CGPoint(x: width - right, y: midY))
                p.move(to: CGPoint(x: midX, y: top)); p.addLine(to: CGPoint(x: midX, y: height - bottom))
            }
            .stroke(Theme.lineStrong, lineWidth: 1)

            corner("Скрытая любовь", Theme.accent).position(x: left + 62, y: top + 12)
            corner("Ваше", Theme.accent).position(x: width - right - 24, y: top + 12)
            corner("Не ваше", Theme.muted).position(x: left + 34, y: height - bottom - 10)
            corner("Привычка", Theme.muted).position(x: width - right - 40, y: height - bottom - 10)

            ForEach(genres) { g in
                let x = px(Double(g.count)), y = py(g.average ?? overall)
                let onRight = x > width - 110
                Circle()
                    .fill((g.average ?? 0) >= overall ? Theme.accent : Color(hex: 0x777777))
                    .frame(width: 12, height: 12)
                    .position(x: x, y: y)
                Text(g.title)
                    .textStyle(.caption)
                    .foregroundStyle(Theme.textSecondary)
                    .fixedSize()
                    .frame(width: 120, alignment: onRight ? .trailing : .leading)
                    .position(x: onRight ? x - 70 : x + 70, y: y)
            }

            Text("смотрите чаще →")
                .textStyle(.caption)
                .foregroundStyle(Theme.muted)
                .fixedSize()
                .frame(width: width - right, alignment: .trailing)
                .position(x: (width - right) / 2, y: height - 8)
        }
        .frame(width: width, height: height)
    }

    private func corner(_ text: String, _ color: Color) -> some View {
        Text(text)
            .textStyle(.caption, .bold, tracking: 0.6)
            .textCase(.uppercase)
            .foregroundStyle(color)
            .fixedSize()
    }
}

// MARK: Оценки

private struct RatingHistogram: View {
    let counts: [Int]
    let mine: Double?
    let kp: Double?

    var body: some View {
        GeometryReader { geo in
            content(width: geo.size.width)
        }
        .frame(height: 150)
    }

    private func content(width: CGFloat) -> some View {
        let gap: CGFloat = 8
        let col: CGFloat = (width - gap * 9) / 10
        let highest: Int = counts.max() ?? 1
        let maxCount = CGFloat(Swift.max(1, highest))
        let barArea: CGFloat = 96, base: CGFloat = 126
        func cx(_ v: Double) -> CGFloat {
            let step: CGFloat = col + gap
            return CGFloat(v - 1) * step + col / 2
        }
        return ZStack(alignment: .topLeading) {
            ForEach(0..<10, id: \.self) { i in
                let h: CGFloat = CGFloat(counts[i]) / maxCount * barArea
                if counts[i] > 0 {
                    RoundedRectangle(cornerRadius: 6, style: .continuous)
                        .fill(i >= 8 ? Theme.accent : Color(hex: 0x5A5A5A))
                        .frame(width: col, height: h)
                        .offset(x: CGFloat(i) * (col + gap), y: base - h)
                }
                Text("\(i + 1)")
                    .textStyle(.caption)
                    .foregroundStyle(Theme.muted)
                    .frame(width: col)
                    .offset(x: CGFloat(i) * (col + gap), y: base + 6)
            }
            if let mine { marker(x: cx(mine), label: "вы " + TasteStats.number(mine), color: Theme.text, top: 0, trailing: true, base: base) }
            if let kp { marker(x: cx(kp), label: "КП " + TasteStats.number(kp), color: Theme.muted, top: 14, trailing: false, base: base) }
        }
        .frame(width: width, height: 150, alignment: .topLeading)
    }

    private func marker(x: CGFloat, label: String, color: Color, top: CGFloat, trailing: Bool, base: CGFloat) -> some View {
        ZStack(alignment: .topLeading) {
            Path { p in
                p.move(to: CGPoint(x: x, y: top + 16)); p.addLine(to: CGPoint(x: x, y: base))
            }
            .stroke(color, style: StrokeStyle(lineWidth: 1.5, dash: [3, 3]))
            Text(label)
                .textStyle(.caption, .bold)
                .foregroundStyle(color)
                .fixedSize()
                .frame(width: 80, alignment: trailing ? .trailing : .leading)
                .offset(x: trailing ? x - 84 : x + 4, y: top)
        }
    }
}

private struct DisagreementRow: View {
    let item: TasteStats.Disagreement

    private var subtitle: String {
        let kp = "Кинопоиск " + TasteStats.number(item.kp)
        guard let year = item.film.year else { return kp }
        return "\(year) · " + kp
    }

    var body: some View {
        NavigationLink(value: FilmRoute(id: item.film.id)) {
            HStack(spacing: Space.s12) {
                VStack(alignment: .leading, spacing: 2) {
                    Text(item.film.title)
                        .textStyle(.body, .bold)
                        .foregroundStyle(Theme.text)
                        .lineLimit(1)
                    Text(subtitle)
                        .textStyle(.caption)
                        .foregroundStyle(Theme.muted)
                }
                Spacer(minLength: 0)
                Text(TasteStats.signed(item.diff))
                    .textStyle(.sub, .bold)
                    .foregroundStyle(item.diff > 0 ? Theme.accent : Color(hex: 0xE5735F))
                RatingBadge(value: item.mine, style: .h3)
            }
            .padding(.horizontal, ScreenLayout.textInset)
            .frame(minHeight: 64)
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
    }
}

// MARK: Эпохи и страны

private struct ErasPlate: View {
    let decades: [TasteStats.Stat]
    let countries: [TasteStats.Stat]

    private func barHeight(_ count: Int, _ maxCount: CGFloat) -> CGFloat {
        let h: CGFloat = CGFloat(count) / maxCount * 80
        return Swift.max(6, h)
    }

    private func segment(_ count: Int, of total: Double, in width: CGFloat) -> CGFloat {
        let usable: CGFloat = width - CGFloat(countries.count - 1) * 2
        let share: CGFloat = CGFloat(Double(count) / total)
        return Swift.max(2, usable * share)
    }

    private let countryColors: [Color] = [Theme.accent, Color(hex: 0xC98F2E), Color(hex: 0x8C6A2C), Color(hex: 0x5E4A24), Color(hex: 0x3A3A3A)]

    var body: some View {
        let maxCount = CGFloat(decades.map(\.count).max() ?? 1)
        let countrySum: Int = countries.map(\.count).reduce(0, +)
        let total = Double(Swift.max(1, countrySum))
        VStack(alignment: .leading, spacing: Space.s12) {
            Caption(text: "Десятилетия")
            HStack(alignment: .bottom, spacing: Space.s8) {
                ForEach(decades) { d in
                    VStack(spacing: 6) {
                        RoundedRectangle(cornerRadius: 6, style: .continuous)
                            .fill(CGFloat(d.count) == maxCount ? Theme.accent : Color(hex: 0x5A5A5A))
                            .frame(height: barHeight(d.count, maxCount))
                        Text(d.title)
                            .textStyle(.caption)
                            .foregroundStyle(Theme.muted)
                            .lineLimit(1)
                            .minimumScaleFactor(0.7)
                    }
                    .frame(maxWidth: .infinity, alignment: .bottom)
                }
            }
            .frame(height: 104, alignment: .bottom)

            if !countries.isEmpty {
                Caption(text: "Страны").padding(.top, Space.s8)
                GeometryReader { geo in
                    HStack(spacing: 2) {
                        ForEach(Array(countries.enumerated()), id: \.element.id) { index, c in
                            Rectangle()
                                .fill(countryColors[min(index, countryColors.count - 1)])
                                .frame(width: segment(c.count, of: total, in: geo.size.width))
                        }
                    }
                }
                .frame(height: 16)
                .clipShape(Capsule())
                FlowLayout(spacing: Space.s12, lineSpacing: Space.s8) {
                    ForEach(Array(countries.enumerated()), id: \.element.id) { index, c in
                        HStack(spacing: 6) {
                            Circle().fill(countryColors[min(index, countryColors.count - 1)]).frame(width: 10, height: 10)
                            Text("\(c.title) \(c.count)")
                                .textStyle(.caption)
                                .foregroundStyle(Theme.textSecondary)
                        }
                    }
                }
            }
        }
    }
}

// MARK: Режиссёры и компания

private struct DirectorRow: View {
    let stat: TasteStats.Stat

    var body: some View {
        HStack(spacing: Space.s12) {
            Text(String(stat.title.prefix(1)))
                .textStyle(.sub, .bold)
                .foregroundStyle(Theme.textSecondary)
                .frame(width: 40, height: 40)
                .background(Circle().fill(Theme.dockButton))
            VStack(alignment: .leading, spacing: 2) {
                Text(stat.title)
                    .textStyle(.body, .bold)
                    .foregroundStyle(Theme.text)
                    .lineLimit(1)
                Text("\(stat.count) " + TasteProfile.plural(stat.count, "фильм", "фильма", "фильмов"))
                    .textStyle(.caption)
                    .foregroundStyle(Theme.muted)
            }
            Spacer(minLength: 0)
            if let avg = stat.average {
                InfoChip(text: TasteStats.number(avg), accent: true)
            }
        }
        .padding(.horizontal, ScreenLayout.textInset)
        .frame(minHeight: ScreenLayout.personRowHeight - 8)
    }
}

private struct CompanyBars: View {
    let shares: [TasteStats.Share]

    var body: some View {
        VStack(spacing: Space.s12) {
            ForEach(Array(shares.enumerated()), id: \.element.id) { index, s in
                HStack(spacing: Space.s8) {
                    Text(s.title)
                        .textStyle(.sub)
                        .foregroundStyle(Theme.text)
                        .frame(width: 96, alignment: .leading)
                    ZStack(alignment: .leading) {
                        Capsule().fill(Color(hex: 0x222222)).frame(height: 10)
                        BarFill(value: Double(s.percent) / 100, color: index == 0 ? Theme.accent : Color(hex: 0x5A5A5A))
                    }
                    Text("\(s.percent)%")
                        .textStyle(.sub, .bold)
                        .foregroundStyle(Theme.text)
                        .frame(width: 48, alignment: .trailing)
                }
            }
        }
    }
}
