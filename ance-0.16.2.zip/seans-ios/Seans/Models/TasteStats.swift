import Foundation

/// Цифры для вкладки «Вкусы» («Досье»): всё считается из анкет и данных фильмов.
/// Каждый блок показывается, только когда данных хватает, чтобы вывод не врал.
struct TasteStats {
    struct MoodPoint: Identifiable {
        let id: String
        /// −1 светлый … +1 мрачный.
        let tone: Double
        /// −1 лёгкий … +1 тяжёлый.
        let weight: Double
        let rating: Int
    }

    struct Stat: Identifiable {
        let id: String
        let title: String
        let count: Int
        let average: Double?
    }

    struct Side: Identifiable {
        let id: String
        let title: String
        let strong: Int
        let weak: Int
    }

    struct Disagreement: Identifiable {
        let film: FilmItem
        let mine: Int
        let kp: Double
        var id: String { film.id }
        var diff: Double { Double(mine) - kp }
    }

    struct Share: Identifiable {
        let id: String
        let title: String
        let percent: Int
    }

    struct Zone {
        let tone: Double
        let weight: Double
    }

    let seenCount: Int
    let surveyCount: Int
    let average: Double?
    /// Средняя оценка Кинопоиска у тех же фильмов, что вы оценили.
    let kpAverage: Double?
    let mood: [MoodPoint]
    let zone: Zone?
    let emotions: [Stat]
    let sides: [Side]
    let genres: [Stat]
    let histogram: [Int]
    let disagreements: [Disagreement]
    let decades: [Stat]
    let countries: [Stat]
    let directors: [Stat]
    let company: [Share]

    var kpDelta: Double? {
        guard let average, let kpAverage else { return nil }
        return average - kpAverage
    }

    init(surveys: [SurveyEntry], seen: [FilmItem]) {
        var films: [String: FilmItem] = [:]
        for film in seen { films[film.id] = film }
        seenCount = seen.count
        surveyCount = surveys.count

        let rated = surveys.filter { $0.rating > 0 }
        average = TasteStats.meanOf(rated.map(\.rating))

        // Оценки против Кинопоиска.
        var kpPairs: [(Int, Double, FilmItem)] = []
        for s in rated {
            if let film = films[s.filmID], let kp = film.ratingKP, kp > 0 { kpPairs.append((s.rating, kp, film)) }
        }
        var kpSum: Double = 0
        for pair in kpPairs { kpSum += pair.1 }
        kpAverage = kpPairs.count >= 3 ? kpSum / Double(kpPairs.count) : nil
        var gaps: [Disagreement] = []
        for pair in kpPairs {
            let item = Disagreement(film: pair.2, mine: pair.0, kp: pair.1)
            if abs(item.diff) >= 1.5 { gaps.append(item) }
        }
        gaps.sort { (a: Disagreement, b: Disagreement) -> Bool in abs(a.diff) > abs(b.diff) }
        disagreements = Array(gaps.prefix(4))

        // Распределение оценок 1–10.
        var hist = Array(repeating: 0, count: 10)
        for s in rated where (1...10).contains(s.rating) { hist[s.rating - 1] += 1 }
        histogram = hist

        // Карта настроения: тон и вес каждого оценённого фильма.
        var points: [MoodPoint] = []
        for s in rated {
            let scales = s.scaleValues()
            guard let tone = scales["tone"], let weight = scales["weight"] else { continue }
            points.append(MoodPoint(id: s.filmID, tone: Double(tone) / 2, weight: Double(weight) / 2, rating: s.rating))
        }
        mood = points
        let loved = points.filter { $0.rating >= 8 }
        if loved.count >= 2 {
            var toneSum: Double = 0, weightSum: Double = 0
            for point in loved { toneSum += point.tone; weightSum += point.weight }
            let n = Double(loved.count)
            zone = Zone(tone: toneSum / n, weight: weightSum / n)
        } else {
            zone = nil
        }

        // Что даёт кино: сколько фильмов и ваша средняя.
        var emotionStats: [Stat] = []
        for option in SurveyOptions.emotions {
            let with: [SurveyEntry] = surveys.filter { $0.emotions.contains(option.id) }
            if with.isEmpty { continue }
            emotionStats.append(Stat(id: option.id, title: option.title, count: with.count, average: TasteStats.mean(with)))
        }
        emotionStats.sort(by: TasteStats.byCount)
        emotions = emotionStats

        // Сильное и слабое.
        var strong: [String: Int] = [:]
        var weak: [String: Int] = [:]
        for s in surveys {
            for (key, value) in s.aspectValues() {
                if value >= 4 { strong[key, default: 0] += 1 } else if value > 0 && value <= 2 { weak[key, default: 0] += 1 }
            }
        }
        var titles: [String: String] = [:]
        for option in SurveyOptions.aspects { titles[option.id] = option.title }
        for option in SurveyOptions.weaknesses where titles[option.id] == nil { titles[option.id] = option.title }
        var sideList: [Side] = []
        for key in Set(strong.keys).union(weak.keys) {
            guard let title = titles[key] else { continue }
            sideList.append(Side(id: key, title: title, strong: strong[key] ?? 0, weak: weak[key] ?? 0))
        }
        sideList.sort { (a: Side, b: Side) -> Bool in
            let left: Int = a.strong - a.weak
            let right: Int = b.strong - b.weak
            return left == right ? a.title < b.title : left > right
        }
        sides = sideList

        // Жанры: сколько смотрите и как оцениваете.
        var genreRatings: [String: [Int]] = [:]
        var genreCount: [String: Int] = [:]
        for film in seen { for g in film.genres { genreCount[g, default: 0] += 1 } }
        for s in rated {
            guard let film = films[s.filmID] else { continue }
            for g in film.genres { genreRatings[g, default: []].append(s.rating) }
        }
        var genreStats: [Stat] = []
        for (key, count) in genreCount {
            guard let list = genreRatings[key], let avg = TasteStats.meanOf(list) else { continue }
            genreStats.append(Stat(id: key, title: key, count: count, average: avg))
        }
        genreStats.sort(by: TasteStats.byCount)
        genres = Array(genreStats.prefix(8))

        // Десятилетия и страны.
        var decadeCount: [Int: Int] = [:]
        var countryCount: [String: Int] = [:]
        for film in seen {
            if let year = film.year { decadeCount[(year / 10) * 10, default: 0] += 1 }
            if let first = film.countries.first {
                let name: String = (first == "СССР" || first == "Россия") ? "Россия и СССР" : first
                countryCount[name, default: 0] += 1
            }
        }
        var decadeStats: [Stat] = []
        for d in decadeCount.keys.sorted() {
            let title: String = d < 1950 ? "\(d)" : String(format: "%02d-е", d % 100)
            decadeStats.append(Stat(id: "\(d)", title: title, count: decadeCount[d] ?? 0, average: nil))
        }
        decades = decadeStats
        var countryPairs: [(String, Int)] = []
        for (key, value) in countryCount { countryPairs.append((key, value)) }
        countryPairs.sort { (a: (String, Int), b: (String, Int)) -> Bool in a.1 == b.1 ? a.0 < b.0 : a.1 > b.1 }
        var countryStats: [Stat] = []
        var rest = 0
        for (index, pair) in countryPairs.enumerated() {
            if index < 4 { countryStats.append(Stat(id: pair.0, title: pair.0, count: pair.1, average: nil)) } else { rest += pair.1 }
        }
        if rest > 0 { countryStats.append(Stat(id: "other", title: "Другие", count: rest, average: nil)) }
        countries = countryStats

        // Режиссёры: от двух фильмов.
        var dirCount: [String: Int] = [:]
        var dirRatings: [String: [Int]] = [:]
        for film in seen { for d in film.directors.prefix(1) { dirCount[d, default: 0] += 1 } }
        for s in rated {
            guard let d = films[s.filmID]?.directors.first else { continue }
            dirRatings[d, default: []].append(s.rating)
        }
        var directorStats: [Stat] = []
        for (key, count) in dirCount where count >= 2 {
            directorStats.append(Stat(id: key, title: key, count: count, average: TasteStats.meanOf(dirRatings[key] ?? [])))
        }
        directorStats.sort(by: TasteStats.byCount)
        directors = Array(directorStats.prefix(5))

        // С кем смотреть.
        let withCompany = surveys.filter { !$0.recommend.isEmpty }
        var shares: [Share] = []
        if !withCompany.isEmpty {
            let total = Double(withCompany.count)
            for option in SurveyOptions.recommend {
                let n: Int = withCompany.filter { $0.recommend.contains(option.id) }.count
                if n == 0 { continue }
                let percent = Int((Double(n) / total * 100).rounded())
                shares.append(Share(id: option.id, title: option.title, percent: percent))
            }
        }
        shares.sort { (a: Share, b: Share) -> Bool in a.percent > b.percent }
        company = shares
    }

    private static func mean(_ list: [SurveyEntry]) -> Double? {
        meanOf(list.map(\.rating).filter { $0 > 0 })
    }

    private static func meanOf(_ list: [Int]) -> Double? {
        guard !list.isEmpty else { return nil }
        let sum: Int = list.reduce(0, +)
        return Double(sum) / Double(list.count)
    }

    /// Элемент с самой высокой средней оценкой.
    private static func highest(_ list: [Stat]) -> Stat? {
        var best: Stat?
        for item in list {
            let value: Double = item.average ?? 0
            let current: Double = best?.average ?? -1
            if best == nil || value > current { best = item }
        }
        return best
    }

    /// Больше фильмов — выше; при равенстве — выше средняя.
    private static func byCount(_ a: Stat, _ b: Stat) -> Bool {
        if a.count != b.count { return a.count > b.count }
        let left: Double = a.average ?? 0
        let right: Double = b.average ?? 0
        return left > right
    }

    /// «+1,2» или «−0,3».
    static func signed(_ value: Double) -> String {
        let sign: String = value < 0 ? "−" : "+"
        return sign + number(abs(value))
    }

    static func number(_ value: Double, digits: Int = 1) -> String {
        String(format: "%.\(digits)f", value).replacingOccurrences(of: ".", with: ",")
    }

    // MARK: Выводы словами: (текст, жирный?)

    var moodInsight: [(String, Bool)]? {
        guard let zone else { return nil }
        var words: [String] = []
        if zone.tone >= 0.25 { words.append("мрачные") } else if zone.tone <= -0.25 { words.append("светлые") }
        if zone.weight >= 0.25 { words.append("тяжёлые") } else if zone.weight <= -0.25 { words.append("лёгкие") }
        if words.isEmpty { return [("Высокие оценки у вас получают фильмы самого разного настроения.", false)] }
        let bold: String = words.joined(separator: " и ") + " фильмы"
        return [("Выше всего вы оцениваете ", false), (bold, true), (".", false)]
    }

    var emotionInsight: [(String, Bool)]? {
        guard let average else { return nil }
        let best: Stat? = TasteStats.highest(emotions.filter { $0.count >= 2 })
        guard let best, let avg = best.average, avg - average >= 0.3 else { return nil }
        let gain: String = TasteStats.number(avg - average)
        let tail: String = ", вы ставите в среднем на " + gain + " балла выше."
        return [("Когда фильм даёт ", false), (best.title.lowercased(), true), (tail, false)]
    }

    var sidesInsight: [(String, Bool)]? {
        var s: [Side] = sides.filter { $0.strong > 0 }
        s.sort { (a: Side, b: Side) -> Bool in a.strong > b.strong }
        var w: [Side] = sides.filter { $0.weak > 0 }
        w.sort { (a: Side, b: Side) -> Bool in a.weak > b.weak }
        guard let top = s.first else { return nil }
        var parts: [(String, Bool)] = [("Вас покоряют ", false), (top.title.lowercased(), true)]
        if s.count > 1 {
            parts.append((" и ", false))
            parts.append((s[1].title.lowercased(), true))
        }
        if let bad = w.first {
            parts.append((", а не прощаете вы ", false))
            parts.append((bad.title.lowercased(), true))
        }
        parts.append((".", false))
        return parts
    }

    var genreInsight: [(String, Bool)]? {
        guard let average, genres.count >= 3 else { return nil }
        let counts: [Int] = genres.map(\.count).sorted()
        let median: Int = counts[counts.count / 2]
        var rare: [Stat] = []
        for g in genres where g.count <= median {
            let avg: Double = g.average ?? 0
            if avg - average >= 0.5 { rare.append(g) }
        }
        let hidden: Stat? = TasteStats.highest(rare)
        if let hidden, let avg = hidden.average {
            let name: String = "«" + hidden.title + "»"
            let tail: String = " вы смотрите редко, но оцениваете высоко — " + TasteStats.number(avg) + " в среднем. Стоит попробовать больше."
            return [("Жанр ", false), (name, true), (tail, false)]
        }
        if let top = TasteStats.highest(genres), let avg = top.average {
            let name: String = "«" + top.title + "»"
            let tail: String = " — " + TasteStats.number(avg) + " в среднем."
            return [("Выше всего вы оцениваете жанр ", false), (name, true), (tail, false)]
        }
        return nil
    }

    var ratingInsight: [(String, Bool)]? {
        guard let delta = kpDelta else { return nil }
        let tens: Int = histogram[9]
        var tensText: String = " Десяток вы ещё не ставили."
        if tens > 0 {
            let films: String = TasteProfile.plural(tens, "фильма", "фильмов", "фильмов")
            tensText = " Десятка — у \(tens) \(films)."
        }
        let ending: String = "." + tensText
        if abs(delta) < 0.15 {
            return [("Ваши оценки ", false), ("совпадают с Кинопоиском", true), (ending, false)]
        }
        let side: String = delta < 0 ? "строже" : "щедрее"
        let amount: String = TasteStats.number(abs(delta))
        let bold: String = side + " Кинопоиска на " + amount
        return [("Вы ", false), (bold, true), (ending, false)]
    }
}
