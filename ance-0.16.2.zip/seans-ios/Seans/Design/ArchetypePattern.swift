import SwiftUI
import UIKit

/// Обложка архетипа — бесшовный японский узор (вагара) в цвете архетипа.
/// Рисуется кодом: чётко на любом экране и без картинок.
struct ArchetypePattern: View {
    let archetype: Archetype

    var body: some View {
        Canvas { context, size in
            let p = PatternPalette(archetype.color)
            context.fill(Path(CGRect(origin: .zero, size: size)), with: .color(p.bg))
            switch archetype {
            case .innocent: Wagara.asanoha(&context, size, p)
            case .everyman: Wagara.ichimatsu(&context, size, p)
            case .hero: Wagara.yagasuri(&context, size, p)
            case .caregiver: Wagara.tatewaku(&context, size, p)
            case .explorer: Wagara.seigaiha(&context, size, p)
            case .rebel: Wagara.uroko(&context, size, p)
            case .lover: Wagara.shippo(&context, size, p)
            case .creator: Wagara.higaki(&context, size, p)
            case .jester: Wagara.yoroke(&context, size, p)
            case .sage: Wagara.kikko(&context, size, p)
            case .magician: Wagara.kagome(&context, size, p)
            case .ruler: Wagara.hishi(&context, size, p)
            }
        }
        .accessibilityHidden(true)
    }
}

/// Тона узора из цвета архетипа: тёмный фон, второй фон, основной, приглушённый, светлый.
struct PatternPalette {
    let bg: Color
    let bg2: Color
    let line: Color
    let soft: Color
    let light: Color

    init(_ color: Color) {
        var h: CGFloat = 0, s: CGFloat = 0, v: CGFloat = 0, a: CGFloat = 0
        _ = UIColor(color).getHue(&h, saturation: &s, brightness: &v, alpha: &a)
        let hue = Double(h)
        func make(_ sat: CGFloat, _ bri: CGFloat) -> Color {
            let ss: CGFloat = Swift.min(1, Swift.max(0, sat))
            let bb: CGFloat = Swift.min(1, Swift.max(0, bri))
            return Color(hue: hue, saturation: Double(ss), brightness: Double(bb))
        }
        bg = make(s * 0.8, 0.17)
        bg2 = make(s * 0.85, 0.24)
        line = color
        soft = make(s * 0.75, v * 0.62)
        light = make(s * 0.4, v * 1.06)
    }
}

/// Узоры. Каждый — один элемент, повторённый на сетке.
enum Wagara {
    private static func polygon(_ pts: [CGPoint]) -> Path {
        var path = Path()
        path.addLines(pts)
        path.closeSubpath()
        return path
    }

    private static func polyline(_ pts: [CGPoint]) -> Path {
        var path = Path()
        path.addLines(pts)
        return path
    }

    private static func odd(_ n: Int) -> Bool { n & 1 == 1 }

    /// Асаноха — лист конопли: треугольная сетка, из центра каждого треугольника — лучи к вершинам.
    static func asanoha(_ g: inout GraphicsContext, _ size: CGSize, _ p: PatternPalette) {
        let a: CGFloat = 30, hh = a * sqrt(3) / 2
        var thin = Path(), thick = Path()
        for j in -1...(Int(size.height / hh) + 2) {
            for i in -2...(Int(size.width / a) + 3) {
                let x0 = CGFloat(i) * a + (odd(j) ? a / 2 : 0), y0 = CGFloat(j) * hh
                let t1 = [CGPoint(x: x0, y: y0), CGPoint(x: x0 + a, y: y0), CGPoint(x: x0 + a / 2, y: y0 + hh)]
                let t2 = [CGPoint(x: x0 + a / 2, y: y0 + hh), CGPoint(x: x0 + a, y: y0), CGPoint(x: x0 + a * 1.5, y: y0 + hh)]
                for t in [t1, t2] {
                    let c = CGPoint(x: (t[0].x + t[1].x + t[2].x) / 3, y: (t[0].y + t[1].y + t[2].y) / 3)
                    for v in t { thin.move(to: c); thin.addLine(to: v) }
                }
                thick.move(to: t1[0]); thick.addLine(to: t1[1])
                thick.move(to: t1[0]); thick.addLine(to: t1[2])
                thick.move(to: t1[1]); thick.addLine(to: t1[2])
            }
        }
        g.stroke(thin, with: .color(p.soft), lineWidth: 1)
        g.stroke(thick, with: .color(p.line), lineWidth: 1.6)
    }

    /// Ичимацу — шахматка.
    static func ichimatsu(_ g: inout GraphicsContext, _ size: CGSize, _ p: PatternPalette) {
        let c: CGFloat = 26
        var cells = Path(), frames = Path(), dots = Path()
        for j in 0...(Int(size.height / c) + 1) {
            for i in 0...(Int(size.width / c) + 1) {
                let x = CGFloat(i) * c, y = CGFloat(j) * c
                if (i + j) % 2 == 0 {
                    cells.addRect(CGRect(x: x, y: y, width: c, height: c))
                    frames.addRect(CGRect(x: x + 5, y: y + 5, width: c - 10, height: c - 10))
                } else {
                    dots.addEllipse(in: CGRect(x: x + c / 2 - 2, y: y + c / 2 - 2, width: 4, height: 4))
                }
            }
        }
        g.fill(cells, with: .color(p.soft))
        g.stroke(frames, with: .color(p.line), lineWidth: 1.2)
        g.fill(dots, with: .color(p.soft))
    }

    /// Ягасури — оперение стрелы.
    static func yagasuri(_ g: inout GraphicsContext, _ size: CGSize, _ p: PatternPalette) {
        let cw: CGFloat = 28, rh: CGFloat = 36
        var a1 = Path(), a2 = Path(), b1 = Path(), b2 = Path(), seams = Path()
        for i in 0...(Int(size.width / cw) + 1) {
            let x = CGFloat(i) * cw, off = odd(i) ? rh / 2 : 0
            for j in -2...(Int(size.height / rh) + 2) {
                let y = CGFloat(j) * rh + off
                let left = polygon([CGPoint(x: x, y: y), CGPoint(x: x + cw / 2, y: y + rh / 4),
                                    CGPoint(x: x + cw / 2, y: y + rh * 0.75), CGPoint(x: x, y: y + rh / 2)])
                let right = polygon([CGPoint(x: x + cw / 2, y: y + rh / 4), CGPoint(x: x + cw, y: y),
                                     CGPoint(x: x + cw, y: y + rh / 2), CGPoint(x: x + cw / 2, y: y + rh * 0.75)])
                if odd(j) { b1.addPath(left); b2.addPath(right) } else { a1.addPath(left); a2.addPath(right) }
            }
            seams.move(to: CGPoint(x: x, y: 0)); seams.addLine(to: CGPoint(x: x, y: size.height))
        }
        g.fill(a1, with: .color(p.line))
        g.fill(a2, with: .color(p.soft))
        g.fill(b1, with: .color(p.light))
        g.fill(b2, with: .color(p.bg2))
        g.stroke(seams, with: .color(p.bg), lineWidth: 2)
    }

    /// Татеваку — поднимающийся пар: пары волнистых линий.
    static func tatewaku(_ g: inout GraphicsContext, _ size: CGSize, _ p: PatternPalette) {
        let pitch: CGFloat = 40, amp: CGFloat = 9, period: CGFloat = 44
        var fills = Path(), lines = Path(), inner = Path(), dots = Path()
        let ys: [CGFloat] = Array(stride(from: CGFloat(-4), through: size.height + 4, by: 2))
        for i in -1...(Int(size.width / pitch) + 1) {
            let x0 = CGFloat(i) * pitch + pitch / 2
            var left: [CGPoint] = [], right: [CGPoint] = [], innerLeft: [CGPoint] = [], innerRight: [CGPoint] = []
            for y in ys {
                let w: CGFloat = amp * cos(2 * CGFloat.pi * y / period)
                left.append(CGPoint(x: x0 - 10 - w, y: y))
                right.append(CGPoint(x: x0 + 10 + w, y: y))
                innerLeft.append(CGPoint(x: x0 - 4 - w * 0.55, y: y))
                innerRight.append(CGPoint(x: x0 + 4 + w * 0.55, y: y))
            }
            fills.addPath(polygon(left + right.reversed()))
            lines.addPath(polyline(left)); lines.addPath(polyline(right))
            inner.addPath(polyline(innerLeft)); inner.addPath(polyline(innerRight))
            var k: CGFloat = 0
            while k * period < size.height + period {
                dots.addEllipse(in: CGRect(x: x0 - 2.4, y: k * period + period / 2 - 2.4, width: 4.8, height: 4.8))
                k += 1
            }
        }
        g.fill(fills, with: .color(p.bg2))
        g.stroke(lines, with: .color(p.line), lineWidth: 2.2)
        g.stroke(inner, with: .color(p.soft), lineWidth: 1)
        g.fill(dots, with: .color(p.light))
    }

    /// Сэйгайха — волны: ряды концентрических полукругов, нижние перекрывают верхние.
    static func seigaiha(_ g: inout GraphicsContext, _ size: CGSize, _ p: PatternPalette) {
        let r0: CGFloat = 26, dy = r0 / 2
        func arc(_ c: CGPoint, _ r: CGFloat, closed: Bool) -> Path {
            var path = Path()
            let steps = 28
            for s in 0...steps {
                let t = Double.pi + Double.pi * Double(s) / Double(steps)
                let pt = CGPoint(x: c.x + r * CGFloat(cos(t)), y: c.y + r * CGFloat(sin(t)))
                if s == 0 { path.move(to: pt) } else { path.addLine(to: pt) }
            }
            if closed { path.closeSubpath() }
            return path
        }
        for j in -1...(Int(size.height / dy) + 2) {
            for i in -1...(Int(size.width / (2 * r0)) + 1) {
                let c = CGPoint(x: CGFloat(i) * 2 * r0 + (odd(j) ? r0 : 0), y: CGFloat(j) * dy)
                g.fill(arc(c, r0, closed: true), with: .color(p.bg))
                for (k, f) in [CGFloat(1), 0.78, 0.56, 0.34].enumerated() {
                    g.stroke(arc(c, r0 * f, closed: false), with: .color(k % 2 == 0 ? p.line : p.soft), lineWidth: k == 0 ? 2 : 1.4)
                }
                g.fill(Path(ellipseIn: CGRect(x: c.x - 3.6, y: c.y - 3.6, width: 7.2, height: 7.2)), with: .color(p.light))
            }
        }
    }

    /// Уроко — чешуя: ряды треугольников.
    static func uroko(_ g: inout GraphicsContext, _ size: CGSize, _ p: PatternPalette) {
        let b: CGFloat = 30, t: CGFloat = 26
        var even = Path(), oddRows = Path()
        for j in 0...(Int(size.height / t) + 1) {
            for i in -1...(Int(size.width / b) + 1) {
                let x = CGFloat(i) * b + (odd(j) ? b / 2 : 0), y = CGFloat(j) * t
                let tri = polygon([CGPoint(x: x, y: y + t), CGPoint(x: x + b / 2, y: y), CGPoint(x: x + b, y: y + t)])
                if odd(j) { oddRows.addPath(tri) } else { even.addPath(tri) }
            }
        }
        g.fill(even, with: .color(p.line))
        g.fill(oddRows, with: .color(p.light))
    }

    /// Сиппо — семь сокровищ: сцепленные круги.
    static func shippo(_ g: inout GraphicsContext, _ size: CGSize, _ p: PatternPalette) {
        let d: CGFloat = 40, r = d / sqrt(2)
        var circles = Path(), dots = Path(), rings = Path()
        for j in -1...(Int(size.height / d) + 1) {
            for i in -1...(Int(size.width / d) + 1) {
                let x = CGFloat(i) * d, y = CGFloat(j) * d
                circles.addEllipse(in: CGRect(x: x - r, y: y - r, width: 2 * r, height: 2 * r))
                dots.addEllipse(in: CGRect(x: x + d / 2 - 3, y: y + d / 2 - 3, width: 6, height: 6))
                let rr = d * 0.16
                rings.addEllipse(in: CGRect(x: x - rr, y: y - rr, width: 2 * rr, height: 2 * rr))
            }
        }
        g.stroke(circles, with: .color(p.line), lineWidth: 1.8)
        g.fill(dots, with: .color(p.light))
        g.stroke(rings, with: .color(p.soft), lineWidth: 1.2)
    }

    /// Хигаки — плетёная ограда: корзиночное плетение под 45°.
    static func higaki(_ g: inout GraphicsContext, _ size: CGSize, _ p: PatternPalette) {
        let c: CGFloat = 30, n = 4, gap = c / CGFloat(n)
        var r = g
        r.translateBy(x: size.width / 2, y: size.height / 2)
        r.rotate(by: .degrees(45))
        let half = Int((hypot(size.width, size.height) / 2) / c) + 2
        var lineP = Path(), softP = Path(), lightP = Path()
        for j in -half...half {
            for i in -half...half {
                let x = CGFloat(i) * c, y = CGFloat(j) * c
                for k in 0..<n {
                    if (i + j) % 2 == 0 {
                        let rect = Path(roundedRect: CGRect(x: x + 1, y: y + CGFloat(k) * gap + 1, width: c - 2, height: gap - 2), cornerRadius: 1.5)
                        if k % 2 == 0 { lineP.addPath(rect) } else { softP.addPath(rect) }
                    } else {
                        let rect = Path(roundedRect: CGRect(x: x + CGFloat(k) * gap + 1, y: y + 1, width: gap - 2, height: c - 2), cornerRadius: 1.5)
                        if k % 2 == 0 { lightP.addPath(rect) } else { softP.addPath(rect) }
                    }
                }
            }
        }
        r.fill(lineP, with: .color(p.line))
        r.fill(softP, with: .color(p.soft))
        r.fill(lightP, with: .color(p.light))
    }

    /// Ёрокэ-дзима — шатающиеся полосы.
    static func yoroke(_ g: inout GraphicsContext, _ size: CGSize, _ p: PatternPalette) {
        let pitch: CGFloat = 18
        let widths: [CGFloat] = [5, 2, 8, 2]
        let colors = [p.line, p.light, p.soft, p.line]
        let ys: [CGFloat] = Array(stride(from: CGFloat(-4), through: size.height + 4, by: 2))
        for i in -1...(Int(size.width / pitch) + 1) {
            let x0 = CGFloat(i) * pitch, ph = CGFloat(i) * 1.7
            let m = ((i % 4) + 4) % 4
            var left: [CGPoint] = []
            var right: [CGPoint] = []
            for y in ys {
                let slow: CGFloat = 4 * sin(y / 26 + ph)
                let fast: CGFloat = 2 * sin(y / 9 + ph * 2)
                let x: CGFloat = x0 + slow + fast
                let wobble: CGFloat = 1.2 * sin(y / 13 + ph)
                left.append(CGPoint(x: x, y: y))
                right.append(CGPoint(x: x + widths[m] + wobble, y: y))
            }
            g.fill(polygon(left + right.reversed()), with: .color(colors[m]))
        }
    }

    /// Кикко — панцирь черепахи: шестиугольники с внутренним контуром.
    static func kikko(_ g: inout GraphicsContext, _ size: CGSize, _ p: PatternPalette) {
        let r: CGFloat = 19, w = sqrt(3) * r
        func hexagon(_ c: CGPoint, _ rr: CGFloat) -> Path {
            var pts: [CGPoint] = []
            for k in 0..<6 {
                let a: Double = Double(60 * k + 30) * Double.pi / 180
                pts.append(CGPoint(x: c.x + rr * CGFloat(cos(a)), y: c.y + rr * CGFloat(sin(a))))
            }
            return polygon(pts)
        }
        var outer = Path(), inner = Path(), cores = Path()
        for j in -1...(Int(size.height / (1.5 * r)) + 1) {
            for i in -1...(Int(size.width / w) + 1) {
                let c = CGPoint(x: CGFloat(i) * w + (odd(j) ? w / 2 : 0), y: CGFloat(j) * 1.5 * r)
                outer.addPath(hexagon(c, r - 1.5))
                inner.addPath(hexagon(c, r * 0.62))
                if (((i * 2 + j) % 5) + 5) % 5 == 0 { cores.addPath(hexagon(c, r * 0.3)) }
            }
        }
        g.fill(outer, with: .color(p.bg2))
        g.stroke(outer, with: .color(p.line), lineWidth: 1.8)
        g.stroke(inner, with: .color(p.soft), lineWidth: 1.2)
        g.fill(cores, with: .color(p.light))
    }

    /// Кагомэ — плетёная корзина: три семейства линий, в переплетении проступают звёзды.
    static func kagome(_ g: inout GraphicsContext, _ size: CGSize, _ p: PatternPalette) {
        let spacing: CGFloat = 22, reach = (size.width + size.height) * 1.2
        let center = CGPoint(x: size.width / 2, y: size.height / 2)
        let families: [(Double, Color, CGFloat)] = [(0, p.light, 0.5), (60, p.line, 0), (120, p.line, 0)]
        for family in families {
            let a = family.0 * .pi / 180
            let dir = CGPoint(x: CGFloat(cos(a)), y: CGFloat(sin(a)))
            let normal = CGPoint(x: -dir.y, y: dir.x)
            var path = Path()
            let count = Int(reach / spacing)
            for k in -count...count {
                let o = (CGFloat(k) + family.2) * spacing
                let base = CGPoint(x: center.x + normal.x * o, y: center.y + normal.y * o)
                path.move(to: CGPoint(x: base.x - dir.x * reach, y: base.y - dir.y * reach))
                path.addLine(to: CGPoint(x: base.x + dir.x * reach, y: base.y + dir.y * reach))
            }
            g.stroke(path, with: .color(family.1), lineWidth: 3.2)
            g.stroke(path, with: .color(p.bg), lineWidth: 0.8)
        }
    }

    /// Хиси — вложенные ромбы.
    static func hishi(_ g: inout GraphicsContext, _ size: CGSize, _ p: PatternPalette) {
        let dw: CGFloat = 36, dh: CGFloat = 22
        func diamond(_ c: CGPoint, _ f: CGFloat) -> Path {
            polygon([CGPoint(x: c.x, y: c.y - dh / 2 * f), CGPoint(x: c.x + dw / 2 * f, y: c.y),
                     CGPoint(x: c.x, y: c.y + dh / 2 * f), CGPoint(x: c.x - dw / 2 * f, y: c.y)])
        }
        var outer = Path(), mid = Path(), core = Path()
        for j in -1...(Int(size.height / (dh / 2)) + 1) {
            for i in -1...(Int(size.width / dw) + 1) {
                let c = CGPoint(x: CGFloat(i) * dw + (odd(j) ? dw / 2 : 0), y: CGFloat(j) * dh / 2)
                outer.addPath(diamond(c, 0.96))
                mid.addPath(diamond(c, 0.66))
                core.addPath(diamond(c, 0.32))
            }
        }
        g.fill(outer, with: .color(p.bg2))
        g.stroke(outer, with: .color(p.line), lineWidth: 1.6)
        g.stroke(mid, with: .color(p.soft), lineWidth: 1.1)
        g.fill(core, with: .color(p.light))
    }
}
