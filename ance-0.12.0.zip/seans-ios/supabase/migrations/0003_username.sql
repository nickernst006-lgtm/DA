-- ance: ID пользователя — придумывает сам, только строчные латинские буквы и цифры, 3–20 знаков.
-- Виден всем вместо почты, по нему ищут. Почту видит только сам пользователь.
-- Вставить целиком в SQL Editor и нажать Run. Можно запускать повторно.
-- Требует 0001 и 0002 (ance-schema.sql и ance-profile.sql).

alter table public.profiles add column if not exists username text;

alter table public.profiles drop constraint if exists profiles_username_format;
alter table public.profiles add constraint profiles_username_format
    check (username is null or username ~ '^[a-z0-9]{3,20}$');

create unique index if not exists profiles_username_key on public.profiles (username);

-- people() — то же, что раньше, плюс ID.
drop function if exists public.people();
create function public.people()
returns table (id uuid, username text, name text, about text, avatar_path text, relation text,
               sees_collection boolean, sees_journal boolean, since timestamptz)
language sql stable security definer set search_path = public as $$
    with me as (select auth.uid() as uid),
    rel as (
        select p.id,
               (select f.status from public.friendships f, me
                 where (f.requester = me.uid and f.addressee = p.id) or (f.requester = p.id and f.addressee = me.uid)
                 order by f.status = 'accepted' desc limit 1) as status,
               exists (select 1 from public.friendships f, me
                        where f.requester = p.id and f.addressee = me.uid and f.status = 'pending') as incoming,
               (select f.created_at from public.friendships f, me
                 where (f.requester = me.uid and f.addressee = p.id) or (f.requester = p.id and f.addressee = me.uid)
                 order by f.created_at desc limit 1) as since
        from public.profiles p, me
        where me.uid is not null and p.id <> me.uid
    )
    select p.id, p.username, p.name,
           case when (r.status = 'accepted' and p.friends_about)
                  or (coalesce(r.status, '') <> 'accepted' and p.strangers_about) then p.about else '' end,
           p.avatar_path,
           case when r.status = 'accepted' then 'friend'
                when r.incoming then 'incoming'
                when r.status = 'pending' then 'outgoing'
                else 'none' end,
           case when r.status = 'accepted' then p.share_collection else p.strangers_collection end,
           case when r.status = 'accepted' then p.share_journal else p.strangers_journal end,
           r.since
    from public.profiles p join rel r on r.id = p.id;
$$;

revoke execute on function public.people() from public, anon;
grant execute on function public.people() to authenticated;

-- Свободен ли ID (для подсказки при вводе).
create or replace function public.username_available(candidate text)
returns boolean language sql stable security definer set search_path = public as $$
    select candidate ~ '^[a-z0-9]{3,20}$'
       and not exists (select 1 from public.profiles where username = candidate and id <> auth.uid());
$$;
revoke execute on function public.username_available(text) from public, anon;
grant execute on function public.username_available(text) to authenticated;

select 'Готово: ID пользователей добавлены' as "Результат";
