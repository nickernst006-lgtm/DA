-- ance: профиль, друзья по заявкам, видимость для друзей и для незнакомцев, фото профиля.
-- Вставить целиком в SQL Editor и нажать Run. Можно запускать повторно — ничего не сломается.
-- Требует, чтобы до этого был выполнен 0001 (ance-schema.sql).

-- ───────────────────────── Профиль ─────────────────────────

alter table public.profiles add column if not exists about                text    not null default '';
alter table public.profiles add column if not exists avatar_path          text;
-- Что видят друзья (share_collection и share_journal уже есть — это коллекция и журналы для друзей).
alter table public.profiles add column if not exists friends_about        boolean not null default true;
-- Что видят незнакомцы.
alter table public.profiles add column if not exists strangers_about      boolean not null default true;
alter table public.profiles add column if not exists strangers_collection boolean not null default false;
alter table public.profiles add column if not exists strangers_journal    boolean not null default false;

-- ───────────────────────── Дружба ─────────────────────────
-- Заявка: requester → addressee. Принята — status = 'accepted'. Отклонённая заявка просто удаляется.

create table if not exists public.friendships (
    requester  uuid not null references auth.users on delete cascade,
    addressee  uuid not null references auth.users on delete cascade,
    status     text not null default 'pending' check (status in ('pending', 'accepted')),
    created_at timestamptz not null default now(),
    primary key (requester, addressee),
    check (requester <> addressee)
);
create index if not exists friendships_addressee_idx on public.friendships (addressee);

alter table public.friendships enable row level security;
drop policy if exists "Свои заявки" on public.friendships;
create policy "Свои заявки" on public.friendships for select to authenticated
    using (requester = auth.uid() or addressee = auth.uid());
-- Менять заявки напрямую нельзя — только функциями ниже.
revoke all on public.friendships from anon, authenticated;
grant select on public.friendships to authenticated;

-- Друг — только тот, с кем заявка принята.
create or replace function public.is_friend(owner uuid)
returns boolean language sql stable security definer set search_path = public as $$
    select auth.uid() is not null and owner <> auth.uid() and exists (
        select 1 from public.friendships
        where status = 'accepted'
          and ((requester = auth.uid() and addressee = owner) or (requester = owner and addressee = auth.uid())));
$$;

-- Может ли вошедший видеть это у владельца: 'about', 'collection' или 'journal'.
-- Друзьям — по настройкам «Что видят друзья», остальным — по «Что видят незнакомцы».
create or replace function public.can_see(owner uuid, what text)
returns boolean language sql stable security definer set search_path = public as $$
    select auth.uid() is not null and owner <> auth.uid() and coalesce((
        select case when public.is_friend(owner) then
                   case what when 'about' then p.friends_about
                             when 'collection' then p.share_collection
                             when 'journal' then p.share_journal else false end
               else
                   case what when 'about' then p.strangers_about
                             when 'collection' then p.strangers_collection
                             when 'journal' then p.strangers_journal else false end
               end
        from public.profiles p where p.id = owner), false);
$$;

-- Прежняя функция — теперь через can_see (на случай, если где-то осталась).
create or replace function public.shares(owner uuid, what text)
returns boolean language sql stable security definer set search_path = public as $$
    select public.can_see(owner, what);
$$;

-- ───────────────────────── Замки на данные ─────────────────────────
-- Чужие профили напрямую больше не читаются: только через people(), где скрытое уже вырезано.
drop policy if exists "Профили друзей" on public.profiles;

do $$
declare t text; what text;
begin
    foreach t in array array['collection_items', 'surveys', 'journal_blocks', 'journal_photos', 'board_items'] loop
        what := case when t = 'collection_items' then 'collection' else 'journal' end;
        execute format('drop policy if exists "Друзьям" on public.%I', t);
        execute format('drop policy if exists "Другим" on public.%I', t);
        execute format('create policy "Другим" on public.%I for select to authenticated using (public.can_see(user_id, %L))', t, what);
    end loop;
end $$;

drop policy if exists "Фото друзей" on storage.objects;
drop policy if exists "Фото журналов другим" on storage.objects;
create policy "Фото журналов другим" on storage.objects for select to authenticated
    using (bucket_id = 'journal' and public.can_see(((storage.foldername(name))[1])::uuid, 'journal'));

-- ───────────────────────── Люди ─────────────────────────
-- Все остальные участники с отношением к вам: friend, incoming (заявка вам), outgoing (ваша заявка), none.
-- Имя и фото видны всем; «О себе» — по настройкам владельца.
drop function if exists public.people();
create function public.people()
returns table (id uuid, name text, about text, avatar_path text, relation text,
               sees_collection boolean, sees_journal boolean, since timestamptz)
language sql stable security definer set search_path = public as $$
    with me as (select auth.uid() as uid),
    rel as (
        select p.id,
               (select f.status from public.friendships f, me
                 where (f.requester = me.uid and f.addressee = p.id) or (f.requester = p.id and f.addressee = me.uid)
                 order by f.status = 'accepted' desc limit 1) as status,
               exists (select 1 from public.friendships f, me
                        where f.requester = p.id and f.addressee = me.uid and f.status = 'pending') as incoming,
               (select f.created_at from public.friendships f, me
                 where (f.requester = me.uid and f.addressee = p.id) or (f.requester = p.id and f.addressee = me.uid)
                 order by f.created_at desc limit 1) as since
        from public.profiles p, me
        where me.uid is not null and p.id <> me.uid
    )
    select p.id, p.name,
           case when (r.status = 'accepted' and p.friends_about)
                  or (coalesce(r.status, '') <> 'accepted' and p.strangers_about) then p.about else '' end,
           p.avatar_path,
           case when r.status = 'accepted' then 'friend'
                when r.incoming then 'incoming'
                when r.status = 'pending' then 'outgoing'
                else 'none' end,
           case when r.status = 'accepted' then p.share_collection else p.strangers_collection end,
           case when r.status = 'accepted' then p.share_journal else p.strangers_journal end,
           r.since
    from public.profiles p join rel r on r.id = p.id;
$$;

-- Отправить заявку. Если этот человек уже позвал вас — вы сразу друзья.
create or replace function public.send_friend_request(target uuid)
returns text language plpgsql security definer set search_path = public as $$
declare me uuid := auth.uid();
begin
    if me is null or target is null or target = me or not exists (select 1 from public.profiles where id = target) then
        raise exception 'Нельзя отправить эту заявку';
    end if;
    if exists (select 1 from public.friendships where requester = target and addressee = me) then
        update public.friendships set status = 'accepted' where requester = target and addressee = me;
        return 'friend';
    end if;
    insert into public.friendships (requester, addressee) values (me, target) on conflict do nothing;
    return (select case status when 'accepted' then 'friend' else 'outgoing' end
              from public.friendships where requester = me and addressee = target);
end $$;

-- Ответить на заявку: принять — вы друзья, отклонить — заявка исчезает.
create or replace function public.respond_friend_request(from_user uuid, accept boolean)
returns void language plpgsql security definer set search_path = public as $$
begin
    if accept then
        update public.friendships set status = 'accepted'
         where requester = from_user and addressee = auth.uid() and status = 'pending';
    else
        delete from public.friendships
         where requester = from_user and addressee = auth.uid() and status = 'pending';
    end if;
end $$;

-- Отменить свою заявку или удалить из друзей.
create or replace function public.remove_friend(other uuid)
returns void language sql security definer set search_path = public as $$
    delete from public.friendships
     where (requester = auth.uid() and addressee = other) or (requester = other and addressee = auth.uid());
$$;

revoke execute on function public.can_see(uuid, text)                   from public, anon;
revoke execute on function public.people()                             from public, anon;
revoke execute on function public.send_friend_request(uuid)            from public, anon;
revoke execute on function public.respond_friend_request(uuid, boolean) from public, anon;
revoke execute on function public.remove_friend(uuid)                  from public, anon;
grant execute on function public.is_friend(uuid)                      to authenticated;
grant execute on function public.shares(uuid, text)                   to authenticated;
grant execute on function public.can_see(uuid, text)                  to authenticated;
grant execute on function public.people()                             to authenticated;
grant execute on function public.send_friend_request(uuid)            to authenticated;
grant execute on function public.respond_friend_request(uuid, boolean) to authenticated;
grant execute on function public.remove_friend(uuid)                  to authenticated;

-- ───────────────────────── Фото профиля ─────────────────────────
-- Закрытая корзина: смотреть могут все вошедшие (фото видно в поиске), менять — только своё (папка = ваш id).
insert into storage.buckets (id, name, public)
values ('avatars', 'avatars', false)
on conflict (id) do nothing;

drop policy if exists "Фото профиля видны участникам" on storage.objects;
create policy "Фото профиля видны участникам" on storage.objects for select to authenticated
    using (bucket_id = 'avatars');
drop policy if exists "Своё фото профиля" on storage.objects;
create policy "Своё фото профиля" on storage.objects for all to authenticated
    using (bucket_id = 'avatars' and (storage.foldername(name))[1] = auth.uid()::text)
    with check (bucket_id = 'avatars' and (storage.foldername(name))[1] = auth.uid()::text);

select 'Готово: профиль и друзья обновлены' as "Результат";
