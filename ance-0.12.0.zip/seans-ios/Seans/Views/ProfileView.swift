import SwiftUI
import PhotosUI
import UIKit
import CoreText

/// Куда ведут строки вкладки «Профиль».
enum ProfileRoute: Hashable {
    case settings
    case person(String)
}

/// Вкладка «Профиль»: вы и ваши друзья.
/// Сверху — фото, имя, почта и «О себе». Ниже — друзья: поиск, заявки вам, ваши заявки, друзья по алфавиту.
/// Если среди друзей никого не нашлось, поиск предлагает остальных участников.
struct ProfileView: View {
    @Environment(Server.self) private var server
    @Environment(Social.self) private var social
    @State private var query = ""

    private var trimmedQuery: String { query.trimmingCharacters(in: .whitespacesAndNewlines) }

    /// Ищем по имени и по ID; «@» в начале запроса не мешает.
    private func matches(_ person: Person) -> Bool {
        var q = trimmedQuery.normalizedForSearch
        if q.hasPrefix("@") { q.removeFirst() }
        guard !q.isEmpty else { return true }
        return person.displayName.normalizedForSearch.contains(q) || (person.username ?? "").contains(q)
    }

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: Space.s32) {
                    VStack(alignment: .leading, spacing: ScreenLayout.titleGap) {
                        ScreenTitle("Профиль")
                            .padding(.top, Space.s12)
                        userCard
                    }
                    friendsSection
                }
                .padding(.horizontal, Space.s20)
                .padding(.bottom, Space.s32)
            }
            .dockClearance()
            .scrollDismissesKeyboard(.interactively)
            .background(Theme.background.ignoresSafeArea())
            .toolbar(.hidden, for: .navigationBar)
            .refreshable { await social.load() }
            .navigationDestination(for: ProfileRoute.self) { route in
                switch route {
                case .settings: ProfileSettingsView()
                case .person(let id): PersonView(personID: id)
                }
            }
        }
    }

    // MARK: Вы

    private var userCard: some View {
        let me = social.me
        let name = me?.name.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
        let about = me?.about.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
        return VStack(alignment: .leading, spacing: 0) {
            HStack(alignment: .center, spacing: Space.s16) {
                AvatarView(path: me?.avatarPath, name: name, seed: server.userID ?? "", size: 96)
                VStack(alignment: .leading, spacing: 0) {
                    Text(name.isEmpty ? "Без имени" : name)
                        .textStyle(.h2)
                        .foregroundStyle(name.isEmpty ? Theme.muted : Theme.text)
                        .lineLimit(2)
                    if let username = me?.username, !username.isEmpty {
                        Text("@" + username)
                            .textStyle(.sub)
                            .foregroundStyle(Theme.muted)
                            .lineLimit(1)
                    } else {
                        NavigationLink(value: ProfileRoute.settings) {
                            Text("Придумайте ID")
                                .textStyle(.sub, .medium)
                                .foregroundStyle(Theme.accent)
                        }
                        .buttonStyle(.plain)
                    }
                }
                Spacer(minLength: 0)
            }
            if !about.isEmpty {
                Text(about)
                    .textStyle(.body)
                    .foregroundStyle(Theme.textSecondary)
                    .fixedSize(horizontal: false, vertical: true)
                    .padding(.top, Space.s16)
            }
            NavigationLink(value: ProfileRoute.settings) {
                Text("Настройки профиля")
            }
            .buttonStyle(RaisedButtonStyle())
            .padding(.top, Space.s16)
        }
        .padding(Space.s16)
        .background(RoundedRectangle(cornerRadius: Radius.large, style: .continuous).fill(Theme.surface))
    }

    // MARK: Друзья

    private var friendsSection: some View {
        let requests = social.incoming.filter(matches)
        let pending = social.outgoing.filter(matches)
        let friends = social.friends.filter(matches)
        let foundAmongFriends = !(requests.isEmpty && pending.isEmpty && friends.isEmpty)
        let searching = !trimmedQuery.isEmpty

        return VStack(alignment: .leading, spacing: Space.s12) {
            HStack(alignment: .firstTextBaseline, spacing: Space.s8) {
                Text("Друзья")
                    .textStyle(.h2)
                    .foregroundStyle(Theme.text)
                    .accessibilityAddTraits(.isHeader)
                if !social.friends.isEmpty {
                    Text("\(social.friends.count)")
                        .textStyle(.sub)
                        .foregroundStyle(Theme.muted)
                }
            }
            .padding(.bottom, Space.s4)

            SearchField(text: $query, placeholder: "Имя или ID")

            if foundAmongFriends {
                PeopleList(people: requests + pending + friends)
            } else if searching {
                strangerResults
            } else if social.loaded || !social.people.isEmpty {
                Text("Пока нет друзей. Найдите участника ance через поиск и отправьте заявку.")
                    .textStyle(.sub)
                    .foregroundStyle(Theme.muted)
                    .fixedSize(horizontal: false, vertical: true)
                    .padding(.horizontal, Space.s4)
            }

            if social.failed && social.people.isEmpty {
                Text("Нет связи с сервером. Потяните экран вниз, чтобы попробовать ещё раз.")
                    .textStyle(.sub)
                    .foregroundStyle(Theme.muted)
                    .fixedSize(horizontal: false, vertical: true)
                    .padding(.horizontal, Space.s4)
            }
        }
    }

    /// Среди друзей никого — показываем остальных участников с таким именем.
    @ViewBuilder
    private var strangerResults: some View {
        let others = social.strangers.filter(matches)
        Text("Среди друзей никого не нашлось.")
            .textStyle(.sub)
            .foregroundStyle(Theme.muted)
            .padding(.horizontal, Space.s4)
        if others.isEmpty {
            Text("Среди участников ance тоже никого не нашлось.")
                .textStyle(.sub)
                .foregroundStyle(Theme.muted)
                .padding(.horizontal, Space.s4)
        } else {
            Text("Участники ance")
                .textStyle(.caption, .medium, tracking: 0.8)
                .textCase(.uppercase)
                .foregroundStyle(Theme.muted)
                .padding(.horizontal, Space.s4)
                .padding(.top, Space.s8)
            PeopleList(people: others)
        }
    }
}

// MARK: - Строки

/// Список людей одной плашкой с разделителями, как в настройках iOS.
/// Заявки вам — со своими кнопками, остальные — обычной строкой.
private struct PeopleList: View {
    let people: [Person]

    var body: some View {
        VStack(spacing: 0) {
            ForEach(Array(people.enumerated()), id: \.element.id) { index, person in
                if index > 0 {
                    Rectangle()
                        .fill(Theme.lineStrong)
                        .frame(height: 1)
                        .padding(.leading, Space.s16 + Space.s48 + Space.s12)
                }
                if person.relation == .incoming {
                    RequestRow(person: person)
                } else {
                    PersonRow(person: person)
                }
            }
        }
        .background(RoundedRectangle(cornerRadius: Radius.large, style: .continuous).fill(Theme.surface))
        .clipShape(RoundedRectangle(cornerRadius: Radius.large, style: .continuous))
    }
}

/// Фото и имя участника; нажатие — его страница.
private struct PersonLabel: View {
    let person: Person
    var caption: String? = nil

    var body: some View {
        NavigationLink(value: ProfileRoute.person(person.id)) {
            HStack(spacing: Space.s12) {
                AvatarView(path: person.avatarPath, name: person.name, seed: person.id, size: Space.s48)
                VStack(alignment: .leading, spacing: 0) {
                    Text(person.displayName)
                        .textStyle(.body, .bold)
                        .foregroundStyle(Theme.text)
                        .lineLimit(1)
                    if let caption {
                        Text(caption)
                            .textStyle(.caption)
                            .foregroundStyle(Theme.muted)
                            .lineLimit(1)
                    }
                }
                Spacer(minLength: 0)
            }
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
    }
}

/// Друг, ваша заявка или участник из поиска.
private struct PersonRow: View {
    @Environment(Social.self) private var social
    let person: Person

    var body: some View {
        HStack(spacing: Space.s12) {
            // ID — в поиске среди незнакомцев, чтобы различать одинаковые имена.
            PersonLabel(person: person, caption: person.relation == .none ? person.handle : nil)
            switch person.relation {
            case .friend:
                Image(systemName: "chevron.right")
                    .font(.system(size: 13, weight: .semibold))
                    .foregroundStyle(Theme.muted)
                    .accessibilityHidden(true)
            case .outgoing:
                StatusPill(text: "На рассмотрении")
            case .incoming:
                StatusPill(text: "Зовёт в друзья")
            case .none:
                Button {
                    Task { await social.sendRequest(to: person) }
                } label: {
                    if social.busy.contains(person.id) {
                        ProgressView().tint(Color.black)
                    } else {
                        Label("Добавить", systemImage: "plus")
                    }
                }
                .buttonStyle(SmallButtonStyle(kind: .accent))
                .disabled(social.busy.contains(person.id))
            }
        }
        .padding(.horizontal, Space.s16)
        .frame(minHeight: 72)
    }
}

/// Заявка вам: принять или отклонить прямо в списке.
private struct RequestRow: View {
    @Environment(Social.self) private var social
    let person: Person

    var body: some View {
        let busy = social.busy.contains(person.id)
        HStack(spacing: Space.s8) {
            PersonLabel(person: person, caption: "Заявка в друзья")
            if busy {
                ProgressView().tint(Theme.muted)
            } else {
                Button {
                    Task { await social.respond(to: person, accept: false) }
                } label: {
                    Image(systemName: "xmark")
                        .font(.system(size: 13, weight: .bold))
                }
                .buttonStyle(SmallButtonStyle(kind: .plain, square: true))
                .accessibilityLabel("Отклонить заявку")
                Button("Принять") {
                    Task { await social.respond(to: person, accept: true) }
                }
                .buttonStyle(SmallButtonStyle(kind: .white))
            }
        }
        .padding(.horizontal, Space.s16)
        .frame(minHeight: 72)
        .background(Theme.accent.opacity(0.08))
    }
}

private struct StatusPill: View {
    let text: String

    var body: some View {
        Text(text)
            .textStyle(.caption, .bold)
            .foregroundStyle(Theme.accent)
            .lineLimit(1)
            .padding(.horizontal, Space.s8)
            .frame(height: 28)
            .background(RoundedRectangle(cornerRadius: Radius.small, style: .continuous).fill(Theme.accent.opacity(0.16)))
    }
}

/// Маленькая кнопка в строке списка: 36 pt, капсула.
struct SmallButtonStyle: ButtonStyle {
    enum Kind { case white, accent, plain }
    var kind: Kind
    var square = false

    func makeBody(configuration: Configuration) -> some View {
        let fill: Color = switch kind {
        case .white: Theme.text
        case .accent: Theme.accent
        case .plain: Theme.surfaceRaised
        }
        return configuration.label
            .textStyle(.sub, .bold)
            .foregroundStyle(kind == .plain ? Theme.textSecondary : Color.black)
            .padding(.horizontal, square ? 0 : Space.s12)
            .frame(width: square ? 36 : nil, height: 36)
            .background(Capsule().fill(fill.opacity(configuration.isPressed ? 0.8 : 1)))
            .touchArea()
    }
}

/// Кнопка на плашке: чуть светлее плашки, чтобы её было видно.
struct RaisedButtonStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .textStyle(.body, .medium)
            .foregroundStyle(Theme.text)
            .frame(maxWidth: .infinity, minHeight: Space.s48)
            .padding(.horizontal, Space.s16)
            .background(Capsule().fill(configuration.isPressed ? Theme.lineStrong : Theme.surfaceRaised))
    }
}

// MARK: - Фото профиля

/// Круглое фото. Пока фото нет — первая буква имени на цветном круге.
struct AvatarView: View {
    @Environment(Server.self) private var server
    let path: String?
    let name: String
    /// Из чего выбирается цвет круга без фото (id участника).
    let seed: String
    let size: CGFloat

    @State private var loaded: (path: String, image: UIImage)?

    private var image: UIImage? {
        guard let path else { return nil }
        if let loaded, loaded.path == path { return loaded.image }
        return AvatarCache.cached(path)
    }

    private var letter: String {
        name.trimmingCharacters(in: .whitespacesAndNewlines).first.map { String($0).uppercased() } ?? ""
    }

    private var color: Color {
        var hash: UInt64 = 1469598103934665603
        for byte in seed.utf8 { hash = (hash ^ UInt64(byte)) &* 1099511628211 }
        return Color(hex: StickerPalette.color(Int(hash % 5)))
    }

    var body: some View {
        ZStack {
            if let image {
                Image(uiImage: image)
                    .resizable()
                    .scaledToFill()
            } else {
                color
                if letter.isEmpty {
                    Image(systemName: "person.fill")
                        .font(.system(size: size * 0.42))
                        .foregroundStyle(Color.black.opacity(0.75))
                } else {
                    Text(letter)
                        .font(.system(size: size * 0.4, weight: .bold))
                        .foregroundStyle(Color.black.opacity(0.85))
                }
            }
        }
        .frame(width: size, height: size)
        .clipShape(Circle())
        .accessibilityHidden(true)
        .task(id: path) {
            guard let path, AvatarCache.cached(path) == nil else { return }
            if let image = await AvatarCache.load(path, server: server) {
                loaded = (path, image)
            }
        }
    }
}

// MARK: - Страница участника

/// Страница друга или незнакомца: фото, имя, «О себе» (если открыто) и действия.
struct PersonView: View {
    @Environment(Social.self) private var social
    let personID: String
    @State private var confirmRemove = false

    var body: some View {
        ScrollView {
            if let person = social.person(personID) {
                VStack(alignment: .leading, spacing: Space.s32) {
                    header(person)
                    shelves(person)
                }
                .padding(.horizontal, Space.s20)
                .padding(.top, Space.s8)
                .padding(.bottom, Space.s32)
            }
        }
        .dockClearance()
        .background(Theme.background.ignoresSafeArea())
        .toolbar(.visible, for: .navigationBar)
        .toolbarBackground(Theme.background, for: .navigationBar)
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            if social.person(personID)?.relation == .friend {
                ToolbarItem(placement: .topBarTrailing) {
                    Menu {
                        Button("Удалить из друзей", role: .destructive) { confirmRemove = true }
                    } label: {
                        Image(systemName: "ellipsis")
                            .foregroundStyle(Theme.text)
                    }
                    .accessibilityLabel("Ещё")
                }
            }
        }
        .confirmationDialog("Удалить из друзей?", isPresented: $confirmRemove, titleVisibility: .visible) {
            Button("Удалить", role: .destructive) {
                if let person = social.person(personID) {
                    Task { await social.remove(person) }
                }
            }
            Button("Отмена", role: .cancel) {}
        } message: {
            Text("Вы перестанете видеть то, что этот человек показывает только друзьям. Он тоже.")
        }
    }

    private func header(_ person: Person) -> some View {
        let about = person.about.trimmingCharacters(in: .whitespacesAndNewlines)
        return VStack(alignment: .leading, spacing: 0) {
            HStack(alignment: .center, spacing: Space.s16) {
                AvatarView(path: person.avatarPath, name: person.name, seed: person.id, size: 96)
                VStack(alignment: .leading, spacing: 0) {
                    Text(person.displayName)
                        .textStyle(.h2)
                        .foregroundStyle(Theme.text)
                        .lineLimit(2)
                    Text([person.handle, person.relation == .friend ? "в друзьях" : nil]
                            .compactMap { $0 }.joined(separator: " · ").ifEmpty("Участник ance"))
                        .textStyle(.sub)
                        .foregroundStyle(Theme.muted)
                        .lineLimit(1)
                }
                Spacer(minLength: 0)
            }
            if !about.isEmpty {
                Text(about)
                    .textStyle(.body)
                    .foregroundStyle(Theme.textSecondary)
                    .fixedSize(horizontal: false, vertical: true)
                    .padding(.top, Space.s16)
            }
            actions(person)
        }
        .padding(Space.s16)
        .background(RoundedRectangle(cornerRadius: Radius.large, style: .continuous).fill(Theme.surface))
    }

    @ViewBuilder
    private func actions(_ person: Person) -> some View {
        let busy = social.busy.contains(person.id)
        switch person.relation {
        case .friend:
            EmptyView()
        case .none:
            Button {
                Task { await social.sendRequest(to: person) }
            } label: {
                if busy { ProgressView().tint(Color.black) } else { Label("Добавить в друзья", systemImage: "plus") }
            }
            .buttonStyle(PrimaryButtonStyle())
            .disabled(busy)
            .padding(.top, Space.s16)
        case .outgoing:
            VStack(spacing: Space.s8) {
                Text("Заявка на рассмотрении")
                    .textStyle(.sub)
                    .foregroundStyle(Theme.accent)
                    .frame(maxWidth: .infinity)
                Button("Отменить заявку") {
                    Task { await social.remove(person) }
                }
                .buttonStyle(RaisedButtonStyle())
                .disabled(busy)
            }
            .padding(.top, Space.s16)
        case .incoming:
            HStack(spacing: Space.s8) {
                Button("Отклонить") {
                    Task { await social.respond(to: person, accept: false) }
                }
                .buttonStyle(RaisedButtonStyle())
                Button("Принять") {
                    Task { await social.respond(to: person, accept: true) }
                }
                .buttonStyle(PrimaryButtonStyle())
            }
            .disabled(busy)
            .padding(.top, Space.s16)
        }
    }

    /// Полки коллекции появятся вместе с синхронизацией; пока — что открыто и что нет.
    @ViewBuilder
    private func shelves(_ person: Person) -> some View {
        let audience = person.relation == .friend ? "друзьям" : "незнакомцам"
        VStack(alignment: .leading, spacing: Space.s8) {
            Text(person.seesCollection
                 ? "Коллекция и оценки появятся здесь, когда включим синхронизацию."
                 : "\(person.displayName) не показывает коллекцию \(audience).")
            if !person.seesJournal && person.seesCollection {
                Text("Журналы и анкеты скрыты.")
            }
        }
        .textStyle(.sub)
        .foregroundStyle(Theme.muted)
        .fixedSize(horizontal: false, vertical: true)
        .frame(maxWidth: .infinity, alignment: .center)
        .multilineTextAlignment(.center)
    }
}

// MARK: - Настройки профиля

/// Фото, имя, «О себе», почта, пароль, видимость и выход.
struct ProfileSettingsView: View {
    @Environment(Server.self) private var server
    @Environment(Social.self) private var social
    @Environment(\.dismiss) private var dismiss

    @State private var name = ""
    @State private var username = ""
    @State private var usernameStatus: UsernameStatus = .unchanged
    @State private var about = ""
    @State private var didLoad = false
    @State private var photo: PhotosPickerItem?
    @State private var showEmail = false
    @State private var showPassword = false
    @State private var confirmSignOut = false
    @State private var error: String?

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 0) {
                photoBlock
                    .padding(.bottom, Space.s24)

                VStack(spacing: Space.s8) {
                    FieldBox(label: "Имя") {
                        TextField("", text: $name, prompt: Text("Как вас зовут").foregroundColor(Theme.muted))
                            .textContentType(.name)
                            .submitLabel(.done)
                    }
                    FieldBox(label: "ID") {
                        HStack(spacing: 2) {
                            Text("@").foregroundStyle(Theme.muted)
                            TextField("", text: $username, prompt: Text("придумайте").foregroundColor(Theme.muted))
                                .textInputAutocapitalization(.never)
                                .autocorrectionDisabled()
                                .keyboardType(.asciiCapable)
                                .textContentType(.username)
                            Spacer(minLength: Space.s8)
                            usernameBadge
                        }
                    }
                    Text("Строчные латинские буквы и цифры, от 3 до 20 знаков. По ID вас найдут в поиске; почту видите только вы.")
                        .textStyle(.caption)
                        .foregroundStyle(Theme.muted)
                        .fixedSize(horizontal: false, vertical: true)
                        .padding(.horizontal, Space.s16)
                        .padding(.bottom, Space.s4)
                        .frame(maxWidth: .infinity, alignment: .leading)
                    FieldBox(label: "О себе") {
                        TextField("", text: $about, prompt: Text("Пара слов о том, что вы любите смотреть").foregroundColor(Theme.muted),
                                  axis: .vertical)
                            .lineLimit(2...8)
                    }
                }

                if let error {
                    Text(error)
                        .textStyle(.sub)
                        .foregroundStyle(Theme.accent)
                        .padding(.top, Space.s8)
                }

                GroupLabel("Вход")
                SettingsGroup {
                    SettingsRow(title: "Почта", value: server.email ?? "") { showEmail = true }
                    RowDivider()
                    SettingsRow(title: "Пароль", value: "Сменить") { showPassword = true }
                }

                GroupLabel("Что видят друзья")
                SettingsGroup {
                    toggle("О себе", \.friendsAbout, "friends_about")
                    RowDivider()
                    toggle("Коллекция и оценки", \.shareCollection, "share_collection")
                    RowDivider()
                    toggle("Журналы и анкеты", \.shareJournal, "share_journal")
                }

                GroupLabel("Что видят незнакомцы")
                SettingsGroup {
                    toggle("О себе", \.strangersAbout, "strangers_about")
                    RowDivider()
                    toggle("Коллекция и оценки", \.strangersCollection, "strangers_collection")
                    RowDivider()
                    toggle("Журналы и анкеты", \.strangersJournal, "strangers_journal")
                }
                Text("Имя и фото видны всем участникам ance — по ним вас находят в поиске.")
                    .textStyle(.caption)
                    .foregroundStyle(Theme.muted)
                    .fixedSize(horizontal: false, vertical: true)
                    .padding(.horizontal, Space.s16)
                    .padding(.top, Space.s8)

                Button("Выйти из аккаунта") { confirmSignOut = true }
                    .buttonStyle(DangerButtonStyle())
                    .padding(.top, Space.s32)
            }
            .padding(.horizontal, Space.s20)
            .padding(.top, Space.s8)
            .padding(.bottom, Space.s32)
        }
        .dockClearance()
        .scrollDismissesKeyboard(.interactively)
        .background(Theme.background.ignoresSafeArea())
        .toolbar(.visible, for: .navigationBar)
        .toolbarBackground(Theme.background, for: .navigationBar)
        .navigationBarTitleDisplayMode(.inline)
        .navigationTitle("Настройки профиля")
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                Button("Готово") {
                    Task {
                        if await saveText() { dismiss() }
                    }
                }
                .fontWeight(.semibold)
                .foregroundStyle(Theme.accent)
            }
        }
        .onAppear {
            guard !didLoad else { return }
            name = social.me?.name ?? ""
            username = social.me?.username ?? ""
            about = social.me?.about ?? ""
            didLoad = true
        }
        .onDisappear {
            Task { _ = await saveText() }
        }
        .onChange(of: username) { _, value in
            let clean = Username.clean(value)
            if clean != value { username = clean }
        }
        .task(id: username) { await checkUsername() }
        .onChange(of: photo) { _, item in
            guard let item else { return }
            Task {
                if let data = try? await item.loadTransferable(type: Data.self) {
                    if !(await social.setAvatar(from: data)) {
                        error = "Не удалось загрузить фото. Проверьте интернет и попробуйте ещё раз."
                    }
                }
                photo = nil
            }
        }
        .sheet(isPresented: $showEmail) { ChangeEmailSheet() }
        .sheet(isPresented: $showPassword) { ChangePasswordSheet() }
        .confirmationDialog("Выйти из аккаунта?", isPresented: $confirmSignOut, titleVisibility: .visible) {
            Button("Выйти", role: .destructive) {
                social.reset()
                server.signOut()
            }
            Button("Отмена", role: .cancel) {}
        } message: {
            Text("Коллекция и журналы останутся на телефоне. Чтобы вернуться, понадобятся почта и пароль.")
        }
    }

    private var photoBlock: some View {
        VStack(spacing: Space.s12) {
            ZStack {
                AvatarView(path: social.me?.avatarPath, name: name, seed: server.userID ?? "", size: 96)
                if social.uploadingAvatar {
                    Circle().fill(Color.black.opacity(0.5)).frame(width: 96, height: 96)
                    ProgressView().tint(Theme.text)
                }
            }
            HStack(spacing: Space.s24) {
                PhotosPicker(selection: $photo, matching: .images) {
                    Text(social.me?.avatarPath == nil ? "Добавить фото" : "Изменить фото")
                        .textStyle(.sub, .bold)
                        .foregroundStyle(Theme.accent)
                }
                .touchArea()
                if social.me?.avatarPath != nil {
                    Button("Удалить") {
                        Task { await social.removeAvatar() }
                    }
                    .textStyle(.sub, .medium)
                    .foregroundStyle(Theme.muted)
                    .touchArea()
                }
            }
        }
        .frame(maxWidth: .infinity)
    }

    private func toggle(_ title: String, _ keyPath: WritableKeyPath<MyProfile, Bool>, _ column: String) -> some View {
        Toggle(isOn: Binding(
            get: { social.me?[keyPath: keyPath] ?? false },
            set: { social.setFlag(keyPath, column: column, to: $0) }
        )) {
            Text(title)
                .textStyle(.body)
                .foregroundStyle(Theme.text)
        }
        .tint(Color(hex: 0x34C759))
        .padding(.horizontal, Space.s16)
        .frame(minHeight: 56)
        .disabled(social.me == nil)
    }

    private func saveText() async -> Bool {
        guard didLoad, social.me != nil else { return true }
        if usernameStatus == .taken {
            error = "Этот ID уже занят. Придумайте другой."
            return false
        }
        error = await social.saveText(name: name, username: username, about: about)
        return error == nil
    }

    private enum UsernameStatus { case unchanged, short, checking, free, taken }

    @ViewBuilder
    private var usernameBadge: some View {
        switch usernameStatus {
        case .unchanged:
            EmptyView()
        case .short:
            Text("мин. 3").textStyle(.caption).foregroundStyle(Theme.muted)
        case .checking:
            ProgressView().controlSize(.small).tint(Theme.muted)
        case .free:
            Image(systemName: "checkmark.circle.fill").foregroundStyle(Color(hex: 0x34C759))
                .accessibilityLabel("ID свободен")
        case .taken:
            Text("занят").textStyle(.caption, .bold).foregroundStyle(Color(hex: 0xE5735F))
        }
    }

    /// Проверка ID, пока пользователь печатает: через полсекунды после последней буквы.
    private func checkUsername() async {
        let value = username
        if value.isEmpty || value == (social.me?.username ?? "") { usernameStatus = .unchanged; return }
        if value.count < Username.range.lowerBound { usernameStatus = .short; return }
        usernameStatus = .checking
        try? await Task.sleep(nanoseconds: 500_000_000)
        guard !Task.isCancelled else { return }
        if let free = try? await server.usernameAvailable(value), !Task.isCancelled {
            usernameStatus = free ? .free : .taken
        } else if !Task.isCancelled {
            usernameStatus = .unchanged
        }
    }
}

// MARK: - Элементы настроек

private struct GroupLabel: View {
    let text: String
    init(_ text: String) { self.text = text }

    var body: some View {
        Text(text)
            .textStyle(.caption, .medium, tracking: 0.8)
            .textCase(.uppercase)
            .foregroundStyle(Theme.muted)
            .padding(.horizontal, Space.s16)
            .padding(.top, Space.s24)
            .padding(.bottom, Space.s8)
    }
}

/// Группа строк одной плашкой. Между строками — RowDivider().
private struct SettingsGroup<Content: View>: View {
    @ViewBuilder var content: Content

    var body: some View {
        VStack(spacing: 0) { content }
            .background(RoundedRectangle(cornerRadius: Radius.large, style: .continuous).fill(Theme.surface))
            .clipShape(RoundedRectangle(cornerRadius: Radius.large, style: .continuous))
    }
}

private struct RowDivider: View {
    var body: some View {
        Rectangle().fill(Theme.lineStrong).frame(height: 1).padding(.leading, Space.s16)
    }
}

private struct SettingsRow: View {
    let title: String
    let value: String
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            HStack(spacing: Space.s8) {
                Text(title)
                    .textStyle(.body)
                    .foregroundStyle(Theme.text)
                Spacer(minLength: Space.s8)
                Text(value)
                    .textStyle(.sub)
                    .foregroundStyle(Theme.muted)
                    .lineLimit(1)
                    .truncationMode(.middle)
                Image(systemName: "chevron.right")
                    .font(.system(size: 13, weight: .semibold))
                    .foregroundStyle(Theme.muted)
            }
            .padding(.horizontal, Space.s16)
            .frame(minHeight: 56)
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
    }
}

/// Поле с подписью сверху — как в макете.
private struct FieldBox<Content: View>: View {
    let label: String
    @ViewBuilder var content: Content

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            Text(label)
                .textStyle(.caption)
                .foregroundStyle(Theme.muted)
            content
                .font(Font(AppFont.uiFont(.body) as CTFont))
                .foregroundStyle(Theme.text)
        }
        .padding(.horizontal, Space.s16)
        .padding(.vertical, Space.s12)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(RoundedRectangle(cornerRadius: 20, style: .continuous).fill(Theme.surface))
    }
}

private struct DangerButtonStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .textStyle(.body, .bold)
            .foregroundStyle(Color(hex: 0xE5735F))
            .frame(maxWidth: .infinity, minHeight: 56)
            .background(Capsule().fill(configuration.isPressed ? Theme.surfaceRaised : Theme.surface))
    }
}

/// Поле ввода в окнах смены почты и пароля.
private struct SheetField: View {
    let placeholder: String
    @Binding var text: String
    var secure = false

    var body: some View {
        Group {
            if secure {
                SecureField("", text: $text, prompt: Text(placeholder).foregroundColor(Theme.muted))
            } else {
                TextField("", text: $text, prompt: Text(placeholder).foregroundColor(Theme.muted))
                    .keyboardType(.emailAddress)
                    .textInputAutocapitalization(.never)
                    .autocorrectionDisabled()
            }
        }
        .font(Font(AppFont.uiFont(.body) as CTFont))
        .foregroundStyle(Theme.text)
        .padding(.horizontal, Space.s16)
        .frame(height: Space.s48)
        .background(Capsule().fill(Theme.surfaceRaised))
    }
}

private struct ChangeEmailSheet: View {
    @Environment(Server.self) private var server
    @Environment(\.dismiss) private var dismiss
    @State private var email = ""
    @State private var busy = false
    @State private var message: String?

    var body: some View {
        VStack(alignment: .leading, spacing: Space.s12) {
            Text("Новая почта")
                .textStyle(.h2)
                .foregroundStyle(Theme.text)
                .padding(.top, Space.s32)
            Text("Сейчас: \(server.email ?? "—"). Новой почтой вы будете входить в ance.")
                .textStyle(.sub)
                .foregroundStyle(Theme.muted)
                .fixedSize(horizontal: false, vertical: true)
            SheetField(placeholder: "Почта", text: $email)
            if let message {
                Text(message)
                    .textStyle(.sub)
                    .foregroundStyle(Theme.accent)
                    .fixedSize(horizontal: false, vertical: true)
            }
            Button {
                Task { await submit() }
            } label: {
                if busy { ProgressView().tint(Color.black) } else { Text("Сменить почту") }
            }
            .buttonStyle(PrimaryButtonStyle())
            .disabled(busy || !email.contains("@"))
            .padding(.top, Space.s8)
            Spacer()
        }
        .padding(.horizontal, Space.s20)
        .presentationDetents([.medium])
        .presentationBackground(Theme.surface)
    }

    private func submit() async {
        busy = true
        defer { busy = false }
        do {
            if try await server.changeEmail(email) {
                dismiss()
            } else {
                message = "Мы отправили письмо на новую почту. Откройте ссылку в нём — после этого почта сменится."
            }
        } catch {
            message = (error as? LocalizedError)?.errorDescription ?? error.localizedDescription
        }
    }
}

private struct ChangePasswordSheet: View {
    @Environment(Server.self) private var server
    @Environment(\.dismiss) private var dismiss
    @State private var current = ""
    @State private var new = ""
    @State private var repeated = ""
    @State private var busy = false
    @State private var message: String?

    private var problem: String? {
        if new.isEmpty || repeated.isEmpty { return nil }
        if new.count < 6 { return "Нужно не меньше 6 знаков." }
        if new != repeated { return "Пароли не совпадают." }
        return nil
    }

    var body: some View {
        VStack(alignment: .leading, spacing: Space.s12) {
            Text("Новый пароль")
                .textStyle(.h2)
                .foregroundStyle(Theme.text)
                .padding(.top, Space.s32)
            SheetField(placeholder: "Текущий пароль", text: $current, secure: true)
            SheetField(placeholder: "Новый пароль", text: $new, secure: true)
            SheetField(placeholder: "Новый пароль ещё раз", text: $repeated, secure: true)
            if let text = message ?? problem {
                Text(text)
                    .textStyle(.sub)
                    .foregroundStyle(Theme.accent)
                    .fixedSize(horizontal: false, vertical: true)
            }
            Button {
                Task { await submit() }
            } label: {
                if busy { ProgressView().tint(Color.black) } else { Text("Сменить пароль") }
            }
            .buttonStyle(PrimaryButtonStyle())
            .disabled(busy || current.isEmpty || new.count < 6 || new != repeated)
            .padding(.top, Space.s8)
            Spacer()
        }
        .padding(.horizontal, Space.s20)
        .presentationDetents([.medium, .large])
        .presentationBackground(Theme.surface)
    }

    private func submit() async {
        busy = true
        defer { busy = false }
        do {
            try await server.changePassword(current: current, new: new)
            dismiss()
        } catch {
            message = (error as? LocalizedError)?.errorDescription ?? error.localizedDescription
        }
    }
}

private extension String {
    func ifEmpty(_ fallback: String) -> String { isEmpty ? fallback : self }
}
