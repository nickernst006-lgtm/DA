import Foundation
import Observation
import UIKit

/// Профиль и друзья: свой профиль, остальные участники, заявки.
/// Последнее загруженное хранится на телефоне — вкладка открывается и без сети.
@MainActor
@Observable
final class Social {
    @ObservationIgnored private let server: Server

    private(set) var me: MyProfile?
    private(set) var people: [Person] = []
    private(set) var loaded = false
    private(set) var failed = false
    /// Участники, по которым сейчас идёт запрос (заявка, ответ, удаление).
    private(set) var busy: Set<String> = []
    private(set) var uploadingAvatar = false

    private static let meKey = "social.me"
    private static let peopleKey = "social.people"

    init(server: Server) {
        self.server = server
        let defaults = UserDefaults.standard
        if let data = defaults.data(forKey: Social.meKey) {
            me = try? JSONDecoder().decode(MyProfile.self, from: data)
        }
        if let data = defaults.data(forKey: Social.peopleKey),
           let saved = try? JSONDecoder().decode([Person].self, from: data) {
            people = saved
        }
    }

    // MARK: Списки

    /// Заявки вам — новые сверху.
    var incoming: [Person] {
        people.filter { $0.relation == .incoming }.sorted { ($0.since ?? "") > ($1.since ?? "") }
    }

    /// Ваши заявки, которые ещё не приняли.
    var outgoing: [Person] {
        people.filter { $0.relation == .outgoing }.sorted { ($0.since ?? "") > ($1.since ?? "") }
    }

    /// Друзья — по алфавиту.
    var friends: [Person] {
        people.filter { $0.relation == .friend }.sorted(by: Social.alphabetical)
    }

    /// Остальные участники — по алфавиту.
    var strangers: [Person] {
        people.filter { $0.relation == .none }.sorted(by: Social.alphabetical)
    }

    static func alphabetical(_ a: Person, _ b: Person) -> Bool {
        a.displayName.localizedCaseInsensitiveCompare(b.displayName) == .orderedAscending
    }

    func person(_ id: String) -> Person? {
        people.first { $0.id == id }
    }

    // MARK: Загрузка

    func load() async {
        guard server.isSignedIn else { return }
        do {
            async let profile = server.myProfile()
            async let list = server.people()
            let (loadedMe, loadedPeople) = try await (profile, list)
            me = loadedMe
            people = loadedPeople
            failed = false
            save()
        } catch {
            failed = true
        }
        loaded = true
    }

    /// После выхода из аккаунта — забыть чужие данные.
    func reset() {
        me = nil
        people = []
        loaded = false
        failed = false
        UserDefaults.standard.removeObject(forKey: Social.meKey)
        UserDefaults.standard.removeObject(forKey: Social.peopleKey)
    }

    private func save() {
        let defaults = UserDefaults.standard
        if let me, let data = try? JSONEncoder().encode(me) { defaults.set(data, forKey: Social.meKey) }
        if let data = try? JSONEncoder().encode(people) { defaults.set(data, forKey: Social.peopleKey) }
    }

    private func setRelation(_ id: String, _ relation: Person.Relation) {
        guard let index = people.firstIndex(where: { $0.id == id }) else { return }
        people[index].relation = relation
        if relation != .none { people[index].since = ISO8601DateFormatter().string(from: Date()) }
        save()
    }

    // MARK: Заявки

    @discardableResult
    func sendRequest(to person: Person) async -> Bool {
        busy.insert(person.id)
        defer { busy.remove(person.id) }
        do {
            let relation = try await server.sendFriendRequest(to: person.id)
            setRelation(person.id, relation)
            if relation == .friend { await load() }
            return true
        } catch {
            return false
        }
    }

    @discardableResult
    func respond(to person: Person, accept: Bool) async -> Bool {
        busy.insert(person.id)
        defer { busy.remove(person.id) }
        do {
            try await server.respondToRequest(from: person.id, accept: accept)
            setRelation(person.id, accept ? .friend : .none)
            // После «принять» сервер откроет то, что друг показывает друзьям.
            if accept { await load() }
            return true
        } catch {
            return false
        }
    }

    /// Отменить свою заявку или удалить из друзей.
    @discardableResult
    func remove(_ person: Person) async -> Bool {
        busy.insert(person.id)
        defer { busy.remove(person.id) }
        do {
            try await server.removeFriend(person.id)
            setRelation(person.id, .none)
            await load()
            return true
        } catch {
            return false
        }
    }

    // MARK: Свой профиль

    /// Сохранить имя, ID и «О себе», если изменились. Возвращает текст ошибки или nil.
    func saveText(name: String, username: String, about: String) async -> String? {
        let cleanName = name.trimmingCharacters(in: .whitespacesAndNewlines)
        let cleanAbout = about.trimmingCharacters(in: .whitespacesAndNewlines)
        let cleanUsername = Username.clean(username)
        guard var current = me else { return nil }
        guard current.name != cleanName || current.about != cleanAbout || (current.username ?? "") != cleanUsername else { return nil }
        if !cleanUsername.isEmpty && !Username.isValid(cleanUsername) {
            return "ID — от 3 до 20 строчных латинских букв и цифр."
        }
        let previous = current
        current.name = cleanName
        current.about = cleanAbout
        current.username = cleanUsername.isEmpty ? nil : cleanUsername
        me = current
        let usernameValue: Any = cleanUsername.isEmpty ? NSNull() : cleanUsername
        do {
            try await server.updateMyProfile(["name": cleanName, "about": cleanAbout, "username": usernameValue])
            save()
            return nil
        } catch {
            me = previous
            return (error as? LocalizedError)?.errorDescription ?? "Не удалось сохранить. Проверьте интернет и попробуйте ещё раз."
        }
    }

    /// Переключатель видимости. Меняется сразу, при ошибке возвращается обратно.
    func setFlag(_ keyPath: WritableKeyPath<MyProfile, Bool>, column: String, to value: Bool) {
        guard var current = me else { return }
        let previous = current
        current[keyPath: keyPath] = value
        me = current
        Task {
            do {
                try await server.updateMyProfile([column: value])
                save()
            } catch {
                me = previous
            }
        }
    }

    /// Новое фото профиля: уменьшаем до 512 точек, загружаем, старое удаляем.
    func setAvatar(from data: Data) async -> Bool {
        guard let jpeg = ImagePrep.jpeg(from: data, maxSide: 512) else { return false }
        uploadingAvatar = true
        defer { uploadingAvatar = false }
        do {
            let path = try await server.uploadAvatar(jpeg)
            let old = me?.avatarPath
            try await server.updateMyProfile(["avatar_path": path])
            if let image = UIImage(data: jpeg) { AvatarCache.store(image, data: jpeg, for: path) }
            me?.avatarPath = path
            save()
            if let old, old != path { await server.deleteAvatar(old) }
            return true
        } catch {
            return false
        }
    }

    func removeAvatar() async {
        guard let old = me?.avatarPath else { return }
        do {
            try await server.updateMyProfile(["avatar_path": NSNull()])
            me?.avatarPath = nil
            save()
            await server.deleteAvatar(old)
        } catch {}
    }
}

/// Фото профилей: память → файл в кэше → сервер.
/// Путь к фото меняется при каждой замене, поэтому кэш по пути никогда не устаревает.
enum AvatarCache {
    private static let memory = NSCache<NSString, UIImage>()

    private static let directory: URL = {
        let base = FileManager.default.urls(for: .cachesDirectory, in: .userDomainMask)[0]
        let dir = base.appendingPathComponent("avatars", isDirectory: true)
        try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        return dir
    }()

    private static func file(_ path: String) -> URL {
        directory.appendingPathComponent(path.replacingOccurrences(of: "/", with: "_"))
    }

    static func cached(_ path: String) -> UIImage? {
        memory.object(forKey: path as NSString)
    }

    static func store(_ image: UIImage, data: Data, for path: String) {
        memory.setObject(image, forKey: path as NSString)
        try? data.write(to: file(path), options: .atomic)
    }

    @MainActor
    static func load(_ path: String, server: Server) async -> UIImage? {
        if let image = memory.object(forKey: path as NSString) { return image }
        if let data = try? Data(contentsOf: file(path)), let image = UIImage(data: data) {
            memory.setObject(image, forKey: path as NSString)
            return image
        }
        guard let data = try? await server.downloadAvatar(path), let image = UIImage(data: data) else { return nil }
        store(image, data: data, for: path)
        return image
    }
}
